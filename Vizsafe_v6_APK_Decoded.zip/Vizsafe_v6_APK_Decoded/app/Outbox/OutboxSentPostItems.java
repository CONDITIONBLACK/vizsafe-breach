package com.vizsafe.app.Outbox;

public class OutboxSentPostItems {
    private String messageText;
    private String sentMessageUrl;
    private boolean status = true;

    public OutboxSentPostItems(String messageText, String sentMessageUrl, boolean status) {
        this.messageText = messageText;
        this.sentMessageUrl = sentMessageUrl;
        this.status = status;
    }

    public boolean getStatus() {
        return this.status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getSentMessageUrl() {
        return this.sentMessageUrl;
    }

    public void setSentMessageUrl(String sentMessageUrl) {
        this.sentMessageUrl = sentMessageUrl;
    }

    public String getMessageText() {
        return this.messageText;
    }

    public void setMessageText(String messageText) {
        this.messageText = messageText;
    }
}
