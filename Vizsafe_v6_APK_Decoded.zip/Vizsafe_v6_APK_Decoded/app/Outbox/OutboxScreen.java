package com.vizsafe.app.Outbox;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.p001v4.widget.SwipeRefreshLayout;
import android.support.p001v4.widget.SwipeRefreshLayout.OnRefreshListener;
import android.support.p002v7.widget.DefaultItemAnimator;
import android.support.p002v7.widget.LinearLayoutManager;
import android.support.p002v7.widget.RecyclerView;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.vizsafe.app.Adapters.OutboxListAdapter;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.Utils.PreferenceHandler;
import dmax.dialog.SpotsDialog;
import java.util.ArrayList;
import java.util.List;

public class OutboxScreen extends Activity {
    public static ArrayList<OutboxSentPostItems> arraylist = new ArrayList();
    public static ImageView doneBtn;
    private static OutboxListAdapter mAdapter;
    public static RecyclerView outboxList;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private TextView mTitle;
    private AlertDialog mTransparentProgressDialog;
    private OutboxScreen outboxScreen;
    private final BroadcastReceiver postReceiver = new C03943();

    /* renamed from: com.vizsafe.app.Outbox.OutboxScreen$1 */
    class C03921 implements OnRefreshListener {
        C03921() {
        }

        public void onRefresh() {
            OutboxScreen.this.setOutboxList(OutboxScreen.this.outboxScreen);
        }
    }

    /* renamed from: com.vizsafe.app.Outbox.OutboxScreen$2 */
    class C03932 implements OnClickListener {
        C03932() {
        }

        public void onClick(View v) {
            OutboxScreen.this.finish();
        }
    }

    /* renamed from: com.vizsafe.app.Outbox.OutboxScreen$3 */
    class C03943 extends BroadcastReceiver {
        C03943() {
        }

        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals("com.vizsafe.UPDATE_OUTBOX")) {
                OutboxScreen.this.setOutboxList(OutboxScreen.this.outboxScreen);
            }
        }
    }

    /* renamed from: com.vizsafe.app.Outbox.OutboxScreen$4 */
    class C03954 extends TypeToken<List<OutboxSentPostItems>> {
        C03954() {
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0421R.layout.outbox_screen);
        this.outboxScreen = this;
        doneBtn = (ImageView) findViewById(C0421R.C0419id.action_bar_back);
        this.mTitle = (TextView) findViewById(2131689653);
        this.mTitle.setText(getResources().getString(C0421R.string.outbox));
        outboxList = (RecyclerView) findViewById(C0421R.C0419id.outbox_list);
        this.mSwipeRefreshLayout = (SwipeRefreshLayout) findViewById(C0421R.C0419id.swipeRefreshLayout);
        this.mSwipeRefreshLayout.setColorSchemeResources(C0421R.color.colorPrimary, C0421R.color.colorPrimaryDark, C0421R.color.blue, 17170451);
        this.mTransparentProgressDialog = new SpotsDialog(this.outboxScreen, getResources().getString(C0421R.string.please_wait_loading));
        this.mTransparentProgressDialog.setCanceledOnTouchOutside(false);
        this.mTransparentProgressDialog.setCancelable(false);
        outboxList.setLayoutManager(new LinearLayoutManager(this.outboxScreen));
        outboxList.setItemAnimator(new DefaultItemAnimator());
        setOutboxList(this.outboxScreen);
        IntentFilter filter = new IntentFilter("android.intent.action.VIEW");
        filter.addAction("com.vizsafe.UPDATE_OUTBOX");
        filter.setPriority(1);
        registerReceiver(this.postReceiver, filter);
        IntentFilter filterFailed = new IntentFilter("android.intent.action.VIEW");
        filterFailed.addAction("com.vizsafe.POST_FAILED");
        filterFailed.setPriority(1);
        registerReceiver(this.postReceiver, filterFailed);
        this.mSwipeRefreshLayout.setOnRefreshListener(new C03921());
        doneBtn.setOnClickListener(new C03932());
    }

    public void setOutboxList(Activity activity) {
        this.mSwipeRefreshLayout.setRefreshing(false);
        arraylist = (ArrayList) new Gson().fromJson(PreferenceHandler.getInstance(activity).getOutBoxSet(), new C03954().getType());
        if (arraylist == null) {
            outboxList.setAdapter(null);
            return;
        }
        mAdapter = new OutboxListAdapter(activity, arraylist);
        outboxList.setAdapter(mAdapter);
    }

    protected void onDestroy() {
        unregisterReceiver(this.postReceiver);
        super.onDestroy();
    }

    public void broadcastOutboxIntent() {
        Intent intent = new Intent();
        intent.setAction("com.vizsafe.UPDATE_OUTBOX");
        sendBroadcast(intent);
    }
}
