package com.vizsafe.app.Wallet;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnKeyListener;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.p001v4.app.Fragment;
import android.support.p001v4.widget.SwipeRefreshLayout;
import android.support.p001v4.widget.SwipeRefreshLayout.OnRefreshListener;
import android.support.p002v7.widget.DefaultItemAnimator;
import android.support.p002v7.widget.LinearLayoutManager;
import android.support.p002v7.widget.RecyclerView;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.analytics.ecommerce.ProductAction;
import com.google.firebase.analytics.FirebaseAnalytics.Param;
import com.vizsafe.app.Adapters.TransactionListAdapter;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.GCMIntentService.GCMClientManager;
import com.vizsafe.app.POJO.EsTransactionList;
import com.vizsafe.app.Utils.CommonMember;
import com.vizsafe.app.Utils.PreferenceHandler;
import com.vizsafe.app.Utils.Webservice;
import com.vizsafe.app.Wallet.CreateWalletWebView.onGoToWalletPageListener;
import dmax.dialog.SpotsDialog;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class TransactionListActivity extends Fragment {
    private static String TAG = "ITEM_LIST_ACTIVITY";
    public static boolean mClickedSendBtn = false;
    private TransactionListAdapter adapter;
    Builder alertDialogBuilder;
    private TextView eth_address_textview;
    private TextView eth_amount_textview;
    private FloatingActionButton fab_logout;
    private String mAddress = "";
    ConnectivityManager mConnectivityManager;
    private Context mContext;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private String mSystemPwd;
    private ArrayList<EsTransactionList> mTransactionsArrayList = new ArrayList();
    RecyclerView mTransactionsListView;
    private AlertDialog mTransparentProgressDialog;
    private String mWalletBalance = "0";
    private TextView no_transactions_text;
    private ImageView send_btn;
    private ImageView show_mnemonic_btn;

    /* renamed from: com.vizsafe.app.Wallet.TransactionListActivity$1 */
    class C04491 implements OnClickListener {
        C04491() {
        }

        public void onClick(View view) {
            TransactionListActivity.mClickedSendBtn = true;
            TransactionListActivity.this.CallAlert();
        }
    }

    /* renamed from: com.vizsafe.app.Wallet.TransactionListActivity$2 */
    class C04502 implements OnClickListener {
        C04502() {
        }

        public void onClick(View view) {
            TransactionListActivity.this.CallAlert();
        }
    }

    /* renamed from: com.vizsafe.app.Wallet.TransactionListActivity$3 */
    class C04523 implements OnClickListener {

        /* renamed from: com.vizsafe.app.Wallet.TransactionListActivity$3$1 */
        class C04511 implements DialogInterface.OnClickListener {
            C04511() {
            }

            public void onClick(DialogInterface dialog, int id) {
                PreferenceHandler.getInstance(TransactionListActivity.this.mContext).setCurrentEthAddress("0");
                PreferenceHandler.getInstance(TransactionListActivity.this.mContext).setVerifyPasswordWallet(0);
                PreferenceHandler.getInstance(TransactionListActivity.this.mContext).setShowVerifyPhrase(0);
                PreferenceHandler.getInstance(TransactionListActivity.this.mContext).setVerifyPhrase(0);
                PreferenceHandler.getInstance(TransactionListActivity.this.mContext).setCheckImportPublicAddress("");
                PreferenceHandler.getInstance(TransactionListActivity.this.mContext).setMnemonicPhrase("");
                PreferenceHandler.getInstance(TransactionListActivity.this.mContext).setPrivateEthAddress("");
                PreferenceHandler.getInstance(TransactionListActivity.this.mContext).setPublicEthAddress("");
                ((onGoToWalletPageListener) TransactionListActivity.this.mContext).onGoToWalletPage();
            }
        }

        C04523() {
        }

        public void onClick(View view) {
            new android.support.p002v7.app.AlertDialog.Builder(TransactionListActivity.this.mContext).setMessage((CharSequence) "Are you sure you want to logout from the Wallet?").setCancelable(false).setPositiveButton(TransactionListActivity.this.getResources().getString(C0421R.string.okTxt), new C04511()).setNegativeButton(TransactionListActivity.this.getResources().getString(C0421R.string.cancel), null).show();
        }
    }

    /* renamed from: com.vizsafe.app.Wallet.TransactionListActivity$4 */
    class C04534 implements OnRefreshListener {
        C04534() {
        }

        public void onRefresh() {
            if (CommonMember.isNetworkOnline((ConnectivityManager) TransactionListActivity.this.mContext.getSystemService("connectivity"), TransactionListActivity.this.mContext)) {
                TransactionListActivity.this.fetchModelsAndReinit();
            } else {
                CommonMember.NetworkStatusAlert(TransactionListActivity.this.mContext);
            }
        }
    }

    /* renamed from: com.vizsafe.app.Wallet.TransactionListActivity$5 */
    class C04545 implements OnKeyListener {
        C04545() {
        }

        public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
            if (keyCode == 4) {
                dialog.dismiss();
            }
            return false;
        }
    }

    private class AsyncTaskGetBalance extends AsyncTask<String, String, JSONObject> {
        JSONObject GetBalanceResponse;

        private AsyncTaskGetBalance() {
            this.GetBalanceResponse = null;
        }

        /* synthetic */ AsyncTaskGetBalance(TransactionListActivity x0, C04491 x1) {
            this();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            TransactionListActivity.this.mTransparentProgressDialog.show();
        }

        protected JSONObject doInBackground(String... arg0) {
            try {
                this.GetBalanceResponse = Webservice.GetWalletBalanceVizsafeResponse(TransactionListActivity.this.mContext, PreferenceHandler.getInstance(TransactionListActivity.this.mContext).getUserName(), PreferenceHandler.getInstance(TransactionListActivity.this.mContext).getPassword(), TransactionListActivity.this.mAddress);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return this.GetBalanceResponse;
        }

        protected void onPostExecute(JSONObject mResponse) {
            TransactionListActivity.this.mTransparentProgressDialog.dismiss();
            TransactionListActivity.this.mSwipeRefreshLayout.setRefreshing(false);
            if (mResponse != null) {
                try {
                    JSONObject mJsonResponse = new JSONObject(String.valueOf(mResponse));
                    int httpCode = mJsonResponse.getInt("httpCode");
                    String mMessage = mJsonResponse.getString(GCMClientManager.EXTRA_MESSAGE);
                    TransactionListActivity.this.mWalletBalance = mJsonResponse.getString(ProductAction.ACTION_DETAIL);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                CommonMember.getErrorDialog(TransactionListActivity.this.getString(C0421R.string.unable_to_process_your_request), TransactionListActivity.this.mContext).show();
            }
            TransactionListActivity.this.setBalance();
            new AsyncTaskGetTransactionList(TransactionListActivity.this, null).execute(new String[0]);
        }
    }

    private class AsyncTaskGetTransactionList extends AsyncTask<String, String, JSONObject> {
        private JSONObject GetTransactionListResponse;
        private String blockHash;
        private String blockNumber;
        private String confirmations;
        private String contractAddress;
        private String cumulativeGasUsed;
        private String from;
        private String gas;
        private String gasPrice;
        private String gasUsed;
        private String hash;
        private String input;
        private String isError;
        private String nonce;
        private JSONArray resultArray;
        private JSONObject singleIncidentObject;
        private String timeStamp;
        /* renamed from: to */
        private String f459to;
        private String transactionIndex;
        private String value;

        private AsyncTaskGetTransactionList() {
            this.GetTransactionListResponse = null;
        }

        /* synthetic */ AsyncTaskGetTransactionList(TransactionListActivity x0, C04491 x1) {
            this();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            TransactionListActivity.this.mTransparentProgressDialog.show();
        }

        protected JSONObject doInBackground(String... arg0) {
            try {
                this.GetTransactionListResponse = Webservice.GetWalletTransactionListWebService(TransactionListActivity.this.mAddress);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return this.GetTransactionListResponse;
        }

        protected void onPostExecute(JSONObject mResponse) {
            if (TransactionListActivity.this.mTransparentProgressDialog.isShowing()) {
                TransactionListActivity.this.mTransparentProgressDialog.dismiss();
            }
            if (TransactionListActivity.this.mTransactionsArrayList != null) {
                TransactionListActivity.this.mTransactionsArrayList.clear();
            }
            if (this.GetTransactionListResponse != null) {
                try {
                    if (this.GetTransactionListResponse.getString("status").equals("1")) {
                        this.resultArray = this.GetTransactionListResponse.getJSONArray("result");
                        if (this.resultArray != null) {
                            for (int i = 0; i < this.resultArray.length(); i++) {
                                this.singleIncidentObject = this.resultArray.getJSONObject(i);
                                if (this.singleIncidentObject.has("blockNumber")) {
                                    this.blockNumber = this.singleIncidentObject.getString("blockNumber");
                                }
                                if (this.singleIncidentObject.has("timeStamp")) {
                                    this.timeStamp = this.singleIncidentObject.getString("timeStamp");
                                }
                                if (this.singleIncidentObject.has("hash")) {
                                    this.hash = this.singleIncidentObject.getString("hash");
                                }
                                if (this.singleIncidentObject.has("nonce")) {
                                    this.nonce = this.singleIncidentObject.getString("nonce");
                                }
                                if (this.singleIncidentObject.has("blockHash")) {
                                    this.blockHash = this.singleIncidentObject.getString("blockHash");
                                }
                                if (this.singleIncidentObject.has("transactionIndex")) {
                                    this.transactionIndex = this.singleIncidentObject.getString("transactionIndex");
                                }
                                if (this.singleIncidentObject.has("from")) {
                                    this.from = this.singleIncidentObject.getString("from");
                                }
                                if (this.singleIncidentObject.has("to")) {
                                    this.f459to = this.singleIncidentObject.getString("to");
                                }
                                if (this.singleIncidentObject.has(Param.VALUE)) {
                                    this.value = this.singleIncidentObject.getString(Param.VALUE);
                                }
                                if (this.singleIncidentObject.has("gas")) {
                                    this.gas = this.singleIncidentObject.getString("gas");
                                }
                                if (this.singleIncidentObject.has("gasPrice")) {
                                    this.gasPrice = this.singleIncidentObject.getString("gasPrice");
                                }
                                if (this.singleIncidentObject.has("isError")) {
                                    this.isError = this.singleIncidentObject.getString("isError");
                                }
                                if (this.singleIncidentObject.has("input")) {
                                    this.input = this.singleIncidentObject.getString("input");
                                }
                                if (this.singleIncidentObject.has("contractAddress")) {
                                    this.contractAddress = this.singleIncidentObject.getString("contractAddress");
                                }
                                if (this.singleIncidentObject.has("cumulativeGasUsed")) {
                                    this.cumulativeGasUsed = this.singleIncidentObject.getString("cumulativeGasUsed");
                                }
                                if (this.singleIncidentObject.has("gasUsed")) {
                                    this.gasUsed = this.singleIncidentObject.getString("gasUsed");
                                }
                                if (this.singleIncidentObject.has("confirmations")) {
                                    this.confirmations = this.singleIncidentObject.getString("confirmations");
                                }
                                TransactionListActivity.this.mTransactionsArrayList.add(new EsTransactionList(this.blockNumber, this.timeStamp, this.hash, this.nonce, this.blockHash, this.transactionIndex, this.from, this.f459to, this.value, this.gas, this.gasPrice, this.isError, this.input, this.contractAddress, this.cumulativeGasUsed, this.gasUsed, this.confirmations));
                            }
                        }
                    }
                } catch (JSONException e) {
                    TransactionListActivity.this.setTransactions();
                    e.printStackTrace();
                }
            } else {
                TransactionListActivity.this.setTransactions();
                CommonMember.getErrorDialog(TransactionListActivity.this.getString(C0421R.string.unable_to_process_your_request), TransactionListActivity.this.mContext).show();
            }
            TransactionListActivity.this.setTransactions();
        }
    }

    public static TransactionListActivity newInstance() {
        return new TransactionListActivity();
    }

    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.clear();
    }

    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        ((InputMethodManager) getActivity().getSystemService("input_method")).hideSoftInputFromWindow(getView().getWindowToken(), 0);
    }

    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ((InputMethodManager) getActivity().getSystemService("input_method")).hideSoftInputFromWindow(getView().getWindowToken(), 0);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getActivity().getWindow().setSoftInputMode(3);
        View vPage = inflater.inflate(C0421R.layout.activity_transaction_list, container, false);
        this.mContext = getActivity();
        this.mConnectivityManager = (ConnectivityManager) this.mContext.getSystemService("connectivity");
        this.mTransparentProgressDialog = new SpotsDialog(this.mContext, getResources().getString(C0421R.string.please_wait_loading));
        this.mTransparentProgressDialog.setCanceledOnTouchOutside(false);
        this.mTransparentProgressDialog.setCancelable(false);
        this.eth_address_textview = (TextView) vPage.findViewById(C0421R.C0419id.eth_address);
        this.eth_amount_textview = (TextView) vPage.findViewById(C0421R.C0419id.eth_amount_textview);
        this.no_transactions_text = (TextView) vPage.findViewById(C0421R.C0419id.no_transactions_text);
        this.send_btn = (ImageView) vPage.findViewById(C0421R.C0419id.send_btn);
        this.show_mnemonic_btn = (ImageView) vPage.findViewById(C0421R.C0419id.show_mnemonic_btn);
        this.fab_logout = (FloatingActionButton) vPage.findViewById(C0421R.C0419id.fab_logout);
        this.mTransactionsListView = (RecyclerView) vPage.findViewById(C0421R.C0419id.transaction_list1);
        this.mSwipeRefreshLayout = (SwipeRefreshLayout) vPage.findViewById(C0421R.C0419id.swipeRefreshLayout);
        this.mSwipeRefreshLayout.setColorSchemeResources(C0421R.color.colorPrimary, C0421R.color.colorPrimaryDark, C0421R.color.blue, 17170451);
        this.mTransactionsListView.setLayoutManager(new LinearLayoutManager(getActivity()));
        this.mTransactionsListView.setItemAnimator(new DefaultItemAnimator());
        this.adapter = new TransactionListAdapter(this.mContext, this.mTransactionsArrayList);
        this.mTransactionsListView.setAdapter(this.adapter);
        fetchModelsAndReinit();
        this.mAddress = PreferenceHandler.getInstance(this.mContext).getCurrentEthAddress();
        String mMnemonicPhrase = PreferenceHandler.getInstance(this.mContext).getMnemonicPhrase();
        this.mSystemPwd = PreferenceHandler.getInstance(this.mContext).getPassword();
        this.eth_address_textview.setText(this.mAddress);
        if (mMnemonicPhrase.equals("")) {
            this.show_mnemonic_btn.setVisibility(8);
        }
        this.send_btn.setOnClickListener(new C04491());
        this.show_mnemonic_btn.setOnClickListener(new C04502());
        this.fab_logout.setOnClickListener(new C04523());
        this.mSwipeRefreshLayout.setOnRefreshListener(new C04534());
        return vPage;
    }

    private void CallAlert() {
        final InputMethodManager imm = (InputMethodManager) this.mContext.getSystemService("input_method");
        View promptsView = LayoutInflater.from(this.mContext).inflate(C0421R.layout.prompt_alert_layout, null);
        this.alertDialogBuilder = new Builder(this.mContext);
        this.alertDialogBuilder.setView(promptsView);
        this.alertDialogBuilder.setCancelable(true);
        this.alertDialogBuilder.setTitle(getResources().getString(C0421R.string.enter_current_password));
        TextView userTitle = (TextView) promptsView.findViewById(C0421R.C0419id.txtAppName);
        final EditText userInput = (EditText) promptsView.findViewById(C0421R.C0419id.edtTxtAddNote);
        userTitle.setTextSize(15.0f);
        userTitle.setVisibility(8);
        userInput.setLines(1);
        userInput.setSingleLine();
        userInput.setInputType(129);
        userInput.requestFocus();
        this.alertDialogBuilder.setOnKeyListener(new C04545());
        this.alertDialogBuilder.setCancelable(true).setNegativeButton(getResources().getString(C0421R.string.cancel), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.dismiss();
                imm.toggleSoftInput(2, 0);
            }
        }).setPositiveButton(getResources().getString(C0421R.string.done), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                imm.toggleSoftInput(2, 0);
                String mCurrentPwd = userInput.getText().toString();
                if (mCurrentPwd.trim().isEmpty()) {
                    Toast.makeText(TransactionListActivity.this.mContext, TransactionListActivity.this.getResources().getString(C0421R.string.error_enter_password), 1).show();
                } else if (mCurrentPwd.isEmpty()) {
                    Toast.makeText(TransactionListActivity.this.mContext, TransactionListActivity.this.getResources().getString(C0421R.string.error_enter_password), 1).show();
                } else if (TransactionListActivity.this.mSystemPwd.equals(mCurrentPwd)) {
                    dialog.dismiss();
                    if (TransactionListActivity.mClickedSendBtn) {
                        TransactionListActivity.this.startActivity(new Intent(TransactionListActivity.this.mContext, SendWalletPage.class));
                        return;
                    }
                    TransactionListActivity.this.startActivity(new Intent(TransactionListActivity.this.mContext, ViewMnemonicPhrase.class));
                } else {
                    Toast.makeText(TransactionListActivity.this.mContext, TransactionListActivity.this.getResources().getString(C0421R.string.error_enter_password), 1).show();
                }
            }
        });
        this.alertDialogBuilder.create().show();
        imm.toggleSoftInput(2, 0);
    }

    public void fetchModelsAndReinit() {
        if (CommonMember.isNetworkOnline(this.mConnectivityManager, this.mContext)) {
            new AsyncTaskGetBalance(this, null).execute(new String[0]);
        } else {
            CommonMember.getErrorDialog(getString(C0421R.string.no_internet_access), this.mContext).show();
        }
    }

    private void setBalance() {
        this.eth_amount_textview.setText(this.mWalletBalance + " SPOT tokens balance");
    }

    private void setTransactions() {
        if (this.mTransactionsArrayList == null) {
            this.no_transactions_text.setVisibility(0);
            this.mTransactionsListView.setVisibility(8);
        } else if (this.mTransactionsArrayList.size() > 0) {
            this.no_transactions_text.setVisibility(8);
            this.mSwipeRefreshLayout.setRefreshing(false);
            this.mTransactionsListView.setVisibility(0);
            this.adapter = new TransactionListAdapter(this.mContext, this.mTransactionsArrayList);
            this.mTransactionsListView.setAdapter(this.adapter);
        } else {
            this.no_transactions_text.setVisibility(0);
            this.mTransactionsListView.setVisibility(8);
        }
    }
}
