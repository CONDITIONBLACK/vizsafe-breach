package com.vizsafe.app.Wallet;

import android.content.Context;
import com.google.android.gms.vision.MultiProcessor.Factory;
import com.google.android.gms.vision.Tracker;
import com.google.android.gms.vision.barcode.Barcode;

class BarcodeTrackerFactory implements Factory<Barcode> {
    private Context mContext;

    BarcodeTrackerFactory(Context context) {
        this.mContext = context;
    }

    public Tracker<Barcode> create(Barcode barcode) {
        return new BarcodeTracker(this.mContext);
    }
}
