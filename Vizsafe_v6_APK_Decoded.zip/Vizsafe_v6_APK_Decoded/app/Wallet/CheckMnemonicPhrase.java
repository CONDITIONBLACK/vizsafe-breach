package com.vizsafe.app.Wallet;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.p002v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.Utils.PreferenceHandler;
import dmax.dialog.SpotsDialog;
import java.io.IOException;
import java.util.ArrayList;
import org.apache.commons.p004io.IOUtils;

public class CheckMnemonicPhrase extends AppCompatActivity {
    private static final String TAG = "MNEMONIC";
    private ImageView back_btn;
    String content = null;
    private int[] ids;
    private String mCurrentAddress;
    private String mPhrase;
    private String mPrivKey;
    private String mPubKey;
    private StringBuilder mStringBuilder = new StringBuilder();
    private LinearLayout mTitleBar;
    private AlertDialog mTransparentProgressDialog;
    private TextView mVerifyButton;
    private WebView mWebView;
    private TextView mbackUpPhraseText;
    private EditText phrase10_text;
    private EditText phrase11_text;
    private EditText phrase12_text;
    private EditText phrase1_text;
    private EditText phrase2_text;
    private EditText phrase3_text;
    private EditText phrase4_text;
    private EditText phrase5_text;
    private EditText phrase6_text;
    private EditText phrase7_text;
    private EditText phrase8_text;
    private EditText phrase9_text;
    private String[] splitStr;
    private ArrayList<String> values = new ArrayList();

    /* renamed from: com.vizsafe.app.Wallet.CheckMnemonicPhrase$1 */
    class C04321 implements OnClickListener {
        C04321() {
        }

        public void onClick(View v) {
            PreferenceHandler.getInstance(CheckMnemonicPhrase.this.getApplicationContext()).setVerifyPasswordWallet(0);
            PreferenceHandler.getInstance(CheckMnemonicPhrase.this.getApplicationContext()).setShowVerifyPhrase(0);
            PreferenceHandler.getInstance(CheckMnemonicPhrase.this.getApplicationContext()).setVerifyPhrase(0);
            CheckMnemonicPhrase.this.finish();
        }
    }

    /* renamed from: com.vizsafe.app.Wallet.CheckMnemonicPhrase$2 */
    class C04332 implements OnClickListener {
        C04332() {
        }

        public void onClick(View v) {
            if (CheckMnemonicPhrase.this.phrase1_text.getText().toString().trim().isEmpty()) {
                CheckMnemonicPhrase.this.phrase1_text.setError(CheckMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (CheckMnemonicPhrase.this.phrase2_text.getText().toString().trim().isEmpty()) {
                CheckMnemonicPhrase.this.phrase2_text.setError(CheckMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (CheckMnemonicPhrase.this.phrase3_text.getText().toString().trim().isEmpty()) {
                CheckMnemonicPhrase.this.phrase3_text.setError(CheckMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (CheckMnemonicPhrase.this.phrase4_text.getText().toString().trim().isEmpty()) {
                CheckMnemonicPhrase.this.phrase4_text.setError(CheckMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (CheckMnemonicPhrase.this.phrase5_text.getText().toString().trim().isEmpty()) {
                CheckMnemonicPhrase.this.phrase5_text.setError(CheckMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (CheckMnemonicPhrase.this.phrase6_text.getText().toString().trim().isEmpty()) {
                CheckMnemonicPhrase.this.phrase6_text.setError(CheckMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (CheckMnemonicPhrase.this.phrase7_text.getText().toString().trim().isEmpty()) {
                CheckMnemonicPhrase.this.phrase7_text.setError(CheckMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (CheckMnemonicPhrase.this.phrase8_text.getText().toString().trim().isEmpty()) {
                CheckMnemonicPhrase.this.phrase8_text.setError(CheckMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (CheckMnemonicPhrase.this.phrase9_text.getText().toString().trim().isEmpty()) {
                CheckMnemonicPhrase.this.phrase9_text.setError(CheckMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (CheckMnemonicPhrase.this.phrase10_text.getText().toString().trim().isEmpty()) {
                CheckMnemonicPhrase.this.phrase10_text.setError(CheckMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (CheckMnemonicPhrase.this.phrase11_text.getText().toString().trim().isEmpty()) {
                CheckMnemonicPhrase.this.phrase11_text.setError(CheckMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (CheckMnemonicPhrase.this.phrase12_text.getText().toString().trim().isEmpty()) {
                CheckMnemonicPhrase.this.phrase12_text.setError(CheckMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else {
                for (int id : CheckMnemonicPhrase.this.ids) {
                    EditText t = (EditText) CheckMnemonicPhrase.this.findViewById(id);
                    CheckMnemonicPhrase.this.values.add(t.getText().toString().trim());
                    CheckMnemonicPhrase.this.mStringBuilder.append(t.getText().toString().trim()).append(" ");
                }
                PreferenceHandler.getInstance(CheckMnemonicPhrase.this.getApplicationContext()).setMnemonicPhrase(CheckMnemonicPhrase.this.mStringBuilder.toString().trim());
                String mMnemonicPhrase = PreferenceHandler.getInstance(CheckMnemonicPhrase.this.getApplicationContext()).getMnemonicPhrase();
                if (!(mMnemonicPhrase.startsWith("\"") || mMnemonicPhrase.endsWith("\""))) {
                    mMnemonicPhrase = "\"" + mMnemonicPhrase + "\"";
                }
                if (mMnemonicPhrase != null) {
                    try {
                        CheckMnemonicPhrase.this.content = IOUtils.toString(CheckMnemonicPhrase.this.getAssets().open("importwallet.html")).replaceAll("mCustomPhraseFromAndroid", mMnemonicPhrase);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                CheckMnemonicPhrase.this.mWebView.loadDataWithBaseURL("file:///android_asset/importwallet.html", CheckMnemonicPhrase.this.content, "text/html", "UTF-8", null);
                CheckMnemonicPhrase.this.mTransparentProgressDialog.show();
            }
        }
    }

    private class ImportWalletJavaScriptInterface {
        private Context context;

        public ImportWalletJavaScriptInterface(Context context) {
            this.context = context;
        }

        @JavascriptInterface
        public void makeToastPassValues(String phrase, String thisAddress, String thisPrivKey, String thisPubKey, String mIntex) {
            CheckMnemonicPhrase.this.mCurrentAddress = thisAddress;
            CheckMnemonicPhrase.this.mPrivKey = thisPrivKey;
            CheckMnemonicPhrase.this.mPubKey = thisPubKey;
            CheckMnemonicPhrase.this.mPhrase = phrase;
            String intex = mIntex;
            CheckMnemonicPhrase.this.mTransparentProgressDialog.dismiss();
            if (CheckMnemonicPhrase.this.mCurrentAddress.equalsIgnoreCase(PreferenceHandler.getInstance(CheckMnemonicPhrase.this.getApplicationContext()).getCheckImportPublicAddress())) {
                PreferenceHandler.getInstance(CheckMnemonicPhrase.this.getApplicationContext()).setMnemonicPhrase(CheckMnemonicPhrase.this.mPhrase);
                PreferenceHandler.getInstance(CheckMnemonicPhrase.this.getApplicationContext()).setCurrentEthAddress(CheckMnemonicPhrase.this.mCurrentAddress);
                PreferenceHandler.getInstance(CheckMnemonicPhrase.this.getApplicationContext()).setPrivateEthAddress(CheckMnemonicPhrase.this.mPrivKey);
                PreferenceHandler.getInstance(CheckMnemonicPhrase.this.getApplicationContext()).setPublicEthAddress(CheckMnemonicPhrase.this.mPubKey);
                PreferenceHandler.getInstance(CheckMnemonicPhrase.this.getApplicationContext()).setVerifyPasswordWallet(1);
                PreferenceHandler.getInstance(CheckMnemonicPhrase.this.getApplicationContext()).setShowVerifyPhrase(1);
                PreferenceHandler.getInstance(CheckMnemonicPhrase.this.getApplicationContext()).setVerifyPhrase(1);
                CheckMnemonicPhrase.this.finish();
            }
        }

        @JavascriptInterface
        public void makeToastPassError(String error) {
            CheckMnemonicPhrase.this.mTransparentProgressDialog.dismiss();
            Toast.makeText(CheckMnemonicPhrase.this.getApplicationContext(), CheckMnemonicPhrase.this.getResources().getString(C0421R.string.error_enter_passphrase), 1).show();
        }
    }

    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0421R.layout.activity_mnemonic_get);
        this.ids = new int[]{C0421R.C0419id.phrase1_edittext, C0421R.C0419id.phrase2_edittext, C0421R.C0419id.phrase3_edittext, C0421R.C0419id.phrase4_edittext, C0421R.C0419id.phrase5_edittext, C0421R.C0419id.phrase6_edittext, C0421R.C0419id.phrase7_edittext, C0421R.C0419id.phrase8_edittext, C0421R.C0419id.phrase9_edittext, C0421R.C0419id.phrase10_edittext, C0421R.C0419id.phrase11_edittext, C0421R.C0419id.phrase12_edittext};
        this.back_btn = (ImageView) findViewById(C0421R.C0419id.action_bar_back);
        this.mVerifyButton = (TextView) findViewById(C0421R.C0419id.next);
        this.phrase1_text = (EditText) findViewById(C0421R.C0419id.phrase1_edittext);
        this.phrase2_text = (EditText) findViewById(C0421R.C0419id.phrase2_edittext);
        this.phrase3_text = (EditText) findViewById(C0421R.C0419id.phrase3_edittext);
        this.phrase4_text = (EditText) findViewById(C0421R.C0419id.phrase4_edittext);
        this.phrase5_text = (EditText) findViewById(C0421R.C0419id.phrase5_edittext);
        this.phrase6_text = (EditText) findViewById(C0421R.C0419id.phrase6_edittext);
        this.phrase7_text = (EditText) findViewById(C0421R.C0419id.phrase7_edittext);
        this.phrase8_text = (EditText) findViewById(C0421R.C0419id.phrase8_edittext);
        this.phrase9_text = (EditText) findViewById(C0421R.C0419id.phrase9_edittext);
        this.phrase10_text = (EditText) findViewById(C0421R.C0419id.phrase10_edittext);
        this.phrase11_text = (EditText) findViewById(C0421R.C0419id.phrase11_edittext);
        this.phrase12_text = (EditText) findViewById(C0421R.C0419id.phrase12_edittext);
        this.mTransparentProgressDialog = new SpotsDialog((Context) this, getResources().getString(C0421R.string.please_wait_loading));
        this.mTransparentProgressDialog.setCanceledOnTouchOutside(false);
        this.mTransparentProgressDialog.setCancelable(false);
        this.mbackUpPhraseText = (TextView) findViewById(C0421R.C0419id.backup_phrase_text);
        this.mWebView = (WebView) findViewById(C0421R.C0419id.webview);
        this.mWebView.setVisibility(4);
        this.mWebView.getSettings().setJavaScriptEnabled(true);
        this.mWebView.setWebChromeClient(new WebChromeClient());
        this.mWebView.addJavascriptInterface(new ImportWalletJavaScriptInterface(this), "app");
        this.back_btn.setOnClickListener(new C04321());
        this.mVerifyButton.setOnClickListener(new C04332());
    }

    public void onBackPressed() {
        super.onBackPressed();
        PreferenceHandler.getInstance(getApplicationContext()).setVerifyPasswordWallet(0);
        PreferenceHandler.getInstance(getApplicationContext()).setShowVerifyPhrase(0);
        PreferenceHandler.getInstance(getApplicationContext()).setVerifyPhrase(0);
        finish();
    }
}
