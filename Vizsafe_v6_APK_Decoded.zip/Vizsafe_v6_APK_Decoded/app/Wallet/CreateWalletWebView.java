package com.vizsafe.app.Wallet;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.annotation.Nullable;
import android.support.p001v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import com.google.android.gms.internal.zzahn;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.Utils.PreferenceHandler;
import dmax.dialog.SpotsDialog;

public class CreateWalletWebView extends Fragment {
    private String intex;
    private Context mContext;
    private String mCurrentAddress;
    private TextView mDoneBtn;
    private String mPhrase;
    private String mPrivKey;
    private String mPubKey;
    private TextView mTitleBar;
    private AlertDialog mTransparentProgressDialog;
    private WebView mWebView;

    public interface onGoToWalletPageListener {
        void onGoToWalletPage();
    }

    private class CreateWalletJavaScriptInterface {
        private Context context;

        public CreateWalletJavaScriptInterface(Context context) {
            this.context = context;
        }

        @JavascriptInterface
        public void makeToastPassValues(String phrase, String thisAddress, String thisPrivKey, String thisPubKey, String mIntex) {
            CreateWalletWebView.this.mCurrentAddress = thisAddress;
            CreateWalletWebView.this.mPrivKey = thisPrivKey;
            CreateWalletWebView.this.mPubKey = thisPubKey;
            CreateWalletWebView.this.mPhrase = phrase;
            CreateWalletWebView.this.intex = mIntex;
            PreferenceHandler.getInstance(CreateWalletWebView.this.mContext).setMnemonicPhrase(CreateWalletWebView.this.mPhrase);
            PreferenceHandler.getInstance(CreateWalletWebView.this.mContext).setCurrentEthAddress(CreateWalletWebView.this.mCurrentAddress);
            PreferenceHandler.getInstance(CreateWalletWebView.this.mContext).setPrivateEthAddress(CreateWalletWebView.this.mPrivKey);
            PreferenceHandler.getInstance(CreateWalletWebView.this.mContext).setPublicEthAddress(CreateWalletWebView.this.mPubKey);
        }
    }

    private class VeritransWebViewClient extends WebViewClient {

        /* renamed from: com.vizsafe.app.Wallet.CreateWalletWebView$VeritransWebViewClient$1 */
        class C04381 implements Runnable {
            C04381() {
            }

            public void run() {
                new CountDownTimer(5000, 1000) {
                    public void onTick(long millisUntilFinished) {
                    }

                    public void onFinish() {
                        CreateWalletWebView.this.mTransparentProgressDialog.dismiss();
                        ((onGoToWalletPageListener) CreateWalletWebView.this.mContext).onGoToWalletPage();
                    }
                }.start();
            }
        }

        private VeritransWebViewClient() {
        }

        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }

        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            zzahn.runOnUiThread(new C04381());
        }

        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
        }
    }

    public static CreateWalletWebView newInstance() {
        return new CreateWalletWebView();
    }

    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.clear();
    }

    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        ((InputMethodManager) getActivity().getSystemService("input_method")).hideSoftInputFromWindow(getView().getWindowToken(), 0);
    }

    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ((InputMethodManager) getActivity().getSystemService("input_method")).hideSoftInputFromWindow(getView().getWindowToken(), 0);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getActivity().getWindow().setSoftInputMode(3);
        View vPage = inflater.inflate(C0421R.layout.activity_webview, container, false);
        this.mContext = getContext();
        this.mWebView = (WebView) vPage.findViewById(C0421R.C0419id.webview);
        this.mDoneBtn = (TextView) vPage.findViewById(C0421R.C0419id.action_bar_next);
        this.mTitleBar = (TextView) vPage.findViewById(2131689653);
        this.mTransparentProgressDialog = new SpotsDialog(this.mContext, getResources().getString(C0421R.string.please_wait_loading));
        this.mTransparentProgressDialog.setCanceledOnTouchOutside(false);
        this.mTransparentProgressDialog.setCancelable(false);
        this.mTransparentProgressDialog.show();
        this.mWebView.setVisibility(4);
        this.mTitleBar.setVisibility(8);
        this.mWebView.getSettings().setJavaScriptEnabled(true);
        this.mWebView.setWebChromeClient(new WebChromeClient());
        this.mWebView.loadUrl("file:///android_asset/bip39-standalone.html");
        this.mWebView.addJavascriptInterface(new CreateWalletJavaScriptInterface(this.mContext), "app");
        this.mWebView.setWebViewClient(new VeritransWebViewClient());
        return vPage;
    }
}
