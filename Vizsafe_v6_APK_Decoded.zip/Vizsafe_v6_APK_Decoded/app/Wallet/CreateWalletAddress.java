package com.vizsafe.app.Wallet;

import android.app.AlertDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.p001v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.Toast;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.GCMIntentService.GCMClientManager;
import com.vizsafe.app.Utils.CommonMember;
import com.vizsafe.app.Utils.PreferenceHandler;
import com.vizsafe.app.Utils.Webservice;
import dmax.dialog.SpotsDialog;
import org.json.JSONException;
import org.json.JSONObject;

public class CreateWalletAddress extends Fragment {
    private ConnectivityManager mConnectivityManager;
    private Context mCreateWalletAddress;
    private String mFrom;
    private AlertDialog mTransparentProgressDialog;
    private Button sign_in_wallet;
    private Button sign_up_wallet;

    public interface onGoToCreateWalletWebViewPageListener {
        void onGoToCreateWalletWebViewPage();
    }

    public interface onGoToImportPublicAddressPageListener {
        void ImportPublicAddressPage();
    }

    /* renamed from: com.vizsafe.app.Wallet.CreateWalletAddress$1 */
    class C04341 implements OnClickListener {
        C04341() {
        }

        public void onClick(View view) {
            if (CommonMember.isNetworkOnline((ConnectivityManager) CreateWalletAddress.this.mCreateWalletAddress.getSystemService("connectivity"), CreateWalletAddress.this.mCreateWalletAddress)) {
                CreateWalletAddress.this.mFrom = "Create";
                CreateWalletAddress.this.CheckPublicAddressAlreadyExist();
                return;
            }
            CommonMember.getErrorDialog(CreateWalletAddress.this.getString(C0421R.string.no_internet_access), CreateWalletAddress.this.mCreateWalletAddress).show();
        }
    }

    /* renamed from: com.vizsafe.app.Wallet.CreateWalletAddress$2 */
    class C04352 implements OnClickListener {
        C04352() {
        }

        public void onClick(View view) {
            if (CommonMember.isNetworkOnline((ConnectivityManager) CreateWalletAddress.this.mCreateWalletAddress.getSystemService("connectivity"), CreateWalletAddress.this.mCreateWalletAddress)) {
                CreateWalletAddress.this.mFrom = "Import";
                ((onGoToImportPublicAddressPageListener) CreateWalletAddress.this.mCreateWalletAddress).ImportPublicAddressPage();
                return;
            }
            CommonMember.getErrorDialog(CreateWalletAddress.this.getString(C0421R.string.no_internet_access), CreateWalletAddress.this.mCreateWalletAddress).show();
        }
    }

    private class AsyncTaskCheckAddress extends AsyncTask<String, String, JSONObject> {
        JSONObject GetPublicAddressResponse;
        private JSONObject mJsonResponse;

        private AsyncTaskCheckAddress() {
            this.GetPublicAddressResponse = null;
        }

        /* synthetic */ AsyncTaskCheckAddress(CreateWalletAddress x0, C04341 x1) {
            this();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            CreateWalletAddress.this.mTransparentProgressDialog.show();
        }

        protected JSONObject doInBackground(String... arg0) {
            try {
                this.GetPublicAddressResponse = Webservice.CheckPublicAddress(CreateWalletAddress.this.mCreateWalletAddress, PreferenceHandler.getInstance(CreateWalletAddress.this.mCreateWalletAddress).getUserName(), PreferenceHandler.getInstance(CreateWalletAddress.this.mCreateWalletAddress).getPassword(), PreferenceHandler.getInstance(CreateWalletAddress.this.mCreateWalletAddress).getUserUUID());
            } catch (Exception e) {
                e.printStackTrace();
            }
            return this.GetPublicAddressResponse;
        }

        protected void onPostExecute(JSONObject mResponse) {
            CreateWalletAddress.this.mTransparentProgressDialog.dismiss();
            if (mResponse != null) {
                try {
                    this.mJsonResponse = new JSONObject(String.valueOf(mResponse));
                    int httpCode = this.mJsonResponse.getInt("httpCode");
                    String mMessage = this.mJsonResponse.getString(GCMClientManager.EXTRA_MESSAGE);
                    boolean mAlreadyExist = this.mJsonResponse.getBoolean("AlreadyExist");
                    String mPublicAddress = this.mJsonResponse.getString("PublicAddress");
                    if (CreateWalletAddress.this.mFrom.equals("Create")) {
                        if (mAlreadyExist) {
                            Toast.makeText(CreateWalletAddress.this.mCreateWalletAddress, "You already have a wallet address associated with your Vizsafe account", 1).show();
                            return;
                        } else {
                            ((onGoToCreateWalletWebViewPageListener) CreateWalletAddress.this.mCreateWalletAddress).onGoToCreateWalletWebViewPage();
                            return;
                        }
                    } else if (CreateWalletAddress.this.mFrom.equals("Import")) {
                        ((onGoToImportPublicAddressPageListener) CreateWalletAddress.this.mCreateWalletAddress).ImportPublicAddressPage();
                        return;
                    } else {
                        return;
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    return;
                }
            }
            CommonMember.getErrorDialog(CreateWalletAddress.this.getString(C0421R.string.unable_to_process_your_request), CreateWalletAddress.this.mCreateWalletAddress).show();
        }
    }

    public static CreateWalletAddress newInstance() {
        return new CreateWalletAddress();
    }

    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.clear();
    }

    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        ((InputMethodManager) getActivity().getSystemService("input_method")).hideSoftInputFromWindow(getView().getWindowToken(), 0);
    }

    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ((InputMethodManager) getActivity().getSystemService("input_method")).hideSoftInputFromWindow(getView().getWindowToken(), 0);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getActivity().getWindow().setSoftInputMode(3);
        View vPage = inflater.inflate(C0421R.layout.create_wallet_address, container, false);
        this.mCreateWalletAddress = getContext();
        this.mConnectivityManager = (ConnectivityManager) this.mCreateWalletAddress.getSystemService("connectivity");
        this.mTransparentProgressDialog = new SpotsDialog(this.mCreateWalletAddress, getResources().getString(C0421R.string.please_wait_loading));
        this.mTransparentProgressDialog.setCanceledOnTouchOutside(false);
        this.mTransparentProgressDialog.setCancelable(false);
        this.sign_up_wallet = (Button) vPage.findViewById(C0421R.C0419id.sign_up_wallet);
        this.sign_in_wallet = (Button) vPage.findViewById(C0421R.C0419id.sign_in_wallet);
        this.sign_up_wallet.setOnClickListener(new C04341());
        this.sign_in_wallet.setOnClickListener(new C04352());
        return vPage;
    }

    private void CheckPublicAddressAlreadyExist() {
        if (CommonMember.isNetworkOnline(this.mConnectivityManager, this.mCreateWalletAddress)) {
            new AsyncTaskCheckAddress(this, null).execute(new String[0]);
        } else {
            CommonMember.getErrorDialog(getString(C0421R.string.no_internet_access), this.mCreateWalletAddress).show();
        }
    }
}
