package com.vizsafe.app.Wallet;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.p001v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.Utils.PreferenceHandler;
import com.vizsafe.app.Wallet.CreateWalletWebView.onGoToWalletPageListener;

public class VerifyPasswordFromUser extends Fragment {
    private String mConfirmPwd;
    private EditText mConfirmPwdEditText;
    private Context mContext;
    private String mCurrentPwd;
    private EditText mCurrentPwdEditText;
    private ImageView mDoneBtn;
    private TextView mNextButton;
    private String mSystemPwd;

    /* renamed from: com.vizsafe.app.Wallet.VerifyPasswordFromUser$1 */
    class C04571 implements OnClickListener {
        C04571() {
        }

        public void onClick(View v) {
            PreferenceHandler.getInstance(VerifyPasswordFromUser.this.mContext).setCurrentEthAddress("0");
            PreferenceHandler.getInstance(VerifyPasswordFromUser.this.mContext).setVerifyPasswordWallet(0);
            ((onGoToWalletPageListener) VerifyPasswordFromUser.this.mContext).onGoToWalletPage();
        }
    }

    /* renamed from: com.vizsafe.app.Wallet.VerifyPasswordFromUser$2 */
    class C04582 implements OnClickListener {
        C04582() {
        }

        public void onClick(View view) {
            VerifyPasswordFromUser.this.mCurrentPwd = VerifyPasswordFromUser.this.mCurrentPwdEditText.getText().toString().trim();
            if (VerifyPasswordFromUser.this.mCurrentPwd.isEmpty() || VerifyPasswordFromUser.this.mCurrentPwd == null) {
                VerifyPasswordFromUser.this.mCurrentPwdEditText.setError(VerifyPasswordFromUser.this.getString(C0421R.string.error_enter_password));
            } else if (VerifyPasswordFromUser.this.mSystemPwd.equals(VerifyPasswordFromUser.this.mCurrentPwd)) {
                ((InputMethodManager) VerifyPasswordFromUser.this.mContext.getSystemService("input_method")).toggleSoftInput(2, 0);
                PreferenceHandler.getInstance(VerifyPasswordFromUser.this.mContext).setVerifyPasswordWallet(1);
                ((onGoToWalletPageListener) VerifyPasswordFromUser.this.mContext).onGoToWalletPage();
            } else {
                VerifyPasswordFromUser.this.mCurrentPwdEditText.setError(VerifyPasswordFromUser.this.getString(C0421R.string.error_enter_password));
            }
        }
    }

    public static VerifyPasswordFromUser newInstance() {
        return new VerifyPasswordFromUser();
    }

    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.clear();
    }

    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        ((InputMethodManager) getActivity().getSystemService("input_method")).hideSoftInputFromWindow(getView().getWindowToken(), 0);
    }

    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ((InputMethodManager) getActivity().getSystemService("input_method")).hideSoftInputFromWindow(getView().getWindowToken(), 0);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getActivity().getWindow().setSoftInputMode(3);
        View vPage = inflater.inflate(C0421R.layout.verify_password_for_wallet, container, false);
        this.mContext = getActivity();
        this.mDoneBtn = (ImageView) vPage.findViewById(C0421R.C0419id.action_bar_back);
        this.mCurrentPwdEditText = (EditText) vPage.findViewById(C0421R.C0419id.verfify_password_current_password);
        this.mNextButton = (TextView) vPage.findViewById(C0421R.C0419id.next);
        this.mSystemPwd = PreferenceHandler.getInstance(this.mContext).getPassword();
        this.mDoneBtn.setOnClickListener(new C04571());
        this.mNextButton.setOnClickListener(new C04582());
        this.mContext = getActivity();
        return vPage;
    }
}
