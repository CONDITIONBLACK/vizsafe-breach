package com.vizsafe.app.Wallet;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.p002v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.Utils.CommonMember;
import com.vizsafe.app.Utils.PreferenceHandler;

public class TransactionDetails extends AppCompatActivity {
    private ImageView back_btn;
    private TextView mTransactionAmountValue;
    private TextView mTransactionBlockValue;
    private TextView mTransactionDateValue;
    private TextView mTransactionFromValue;
    private TextView mTransactionGasValue;
    private TextView mTransactionHashValue;
    private TextView mTransactionName_text;
    private TextView mTransactionToValue;

    /* renamed from: com.vizsafe.app.Wallet.TransactionDetails$1 */
    class C04481 implements OnClickListener {
        C04481() {
        }

        public void onClick(View view) {
            TransactionDetails.this.finish();
        }
    }

    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0421R.layout.transaction_details_page);
        this.mTransactionAmountValue = (TextView) findViewById(C0421R.C0419id.transactionAmountValue_text);
        this.mTransactionFromValue = (TextView) findViewById(C0421R.C0419id.transactionFromValue_text);
        this.mTransactionToValue = (TextView) findViewById(C0421R.C0419id.transactionToValue_text);
        this.mTransactionDateValue = (TextView) findViewById(C0421R.C0419id.transactionDateValue_text);
        this.mTransactionGasValue = (TextView) findViewById(C0421R.C0419id.transactionGasValue_text);
        this.mTransactionHashValue = (TextView) findViewById(C0421R.C0419id.transactionTransactionValue_text);
        this.mTransactionBlockValue = (TextView) findViewById(C0421R.C0419id.transactionBlockValue_text);
        this.mTransactionName_text = (TextView) findViewById(C0421R.C0419id.transactionName_text);
        this.back_btn = (ImageView) findViewById(C0421R.C0419id.action_bar_back);
        TextView mTitle = (TextView) findViewById(2131689653);
        mTitle.setVisibility(0);
        mTitle.setText(getResources().getString(C0421R.string.transaction_details));
        Intent intent = getIntent();
        String getvalue = intent.getExtras().getString("getvalue");
        String getfrom = intent.getExtras().getString("getfrom");
        String getto = intent.getExtras().getString("getto");
        String gettimeStamp = intent.getExtras().getString("gettimeStamp");
        String getgasUsed = intent.getExtras().getString("getgasUsed");
        String getblockHash = intent.getExtras().getString("getblockHash");
        String getHash = intent.getExtras().getString("getHash");
        if (getfrom.toLowerCase().equals(PreferenceHandler.getInstance(getApplicationContext()).getCurrentEthAddress().toLowerCase())) {
            this.mTransactionName_text.setText(getResources().getString(C0421R.string.sent));
        } else {
            this.mTransactionName_text.setText(getResources().getString(C0421R.string.received));
        }
        String wei = getvalue;
        String eth = CommonMember.WeiToEth(wei);
        if (wei.equals("0")) {
            this.mTransactionAmountValue.setText(eth);
        } else {
            this.mTransactionAmountValue.setText(eth);
        }
        try {
            getgasUsed = CommonMember.WeiToGwei(getgasUsed);
        } catch (Exception e) {
            e.printStackTrace();
        }
        this.mTransactionFromValue.setText(getfrom);
        this.mTransactionToValue.setText(getto);
        this.mTransactionDateValue.setText(CommonMember.GetDate(Long.decode(gettimeStamp).longValue()));
        this.mTransactionGasValue.setText(getgasUsed);
        this.mTransactionHashValue.setText(getHash);
        this.mTransactionBlockValue.setText(getblockHash);
        this.back_btn.setOnClickListener(new C04481());
    }

    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
