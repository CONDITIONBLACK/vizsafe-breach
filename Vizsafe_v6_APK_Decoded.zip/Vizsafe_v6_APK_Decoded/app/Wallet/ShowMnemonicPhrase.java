package com.vizsafe.app.Wallet;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.p001v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.Utils.PreferenceHandler;
import com.vizsafe.app.Wallet.CreateWalletWebView.onGoToWalletPageListener;

public class ShowMnemonicPhrase extends Fragment {
    private static final String TAG = "MNEMONIC";
    private ImageView back_btn;
    private Context mContext;
    private ImageView mDoneBtn;
    private TextView mVerifyButton;
    private TextView phrase10_text;
    private TextView phrase11_text;
    private TextView phrase12_text;
    private TextView phrase1_text;
    private TextView phrase2_text;
    private TextView phrase3_text;
    private TextView phrase4_text;
    private TextView phrase5_text;
    private TextView phrase6_text;
    private TextView phrase7_text;
    private TextView phrase8_text;
    private TextView phrase9_text;

    /* renamed from: com.vizsafe.app.Wallet.ShowMnemonicPhrase$1 */
    class C04461 implements OnClickListener {
        C04461() {
        }

        public void onClick(View v) {
            PreferenceHandler.getInstance(ShowMnemonicPhrase.this.mContext).setCurrentEthAddress("0");
            PreferenceHandler.getInstance(ShowMnemonicPhrase.this.mContext).setVerifyPasswordWallet(0);
            PreferenceHandler.getInstance(ShowMnemonicPhrase.this.mContext).setShowVerifyPhrase(0);
            ((onGoToWalletPageListener) ShowMnemonicPhrase.this.mContext).onGoToWalletPage();
        }
    }

    /* renamed from: com.vizsafe.app.Wallet.ShowMnemonicPhrase$2 */
    class C04472 implements OnClickListener {
        C04472() {
        }

        public void onClick(View v) {
            PreferenceHandler.getInstance(ShowMnemonicPhrase.this.mContext).setShowVerifyPhrase(1);
            ((onGoToWalletPageListener) ShowMnemonicPhrase.this.mContext).onGoToWalletPage();
        }
    }

    public static ShowMnemonicPhrase newInstance() {
        return new ShowMnemonicPhrase();
    }

    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.clear();
    }

    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        ((InputMethodManager) getActivity().getSystemService("input_method")).hideSoftInputFromWindow(getView().getWindowToken(), 0);
    }

    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ((InputMethodManager) getActivity().getSystemService("input_method")).hideSoftInputFromWindow(getView().getWindowToken(), 0);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getActivity().getWindow().setSoftInputMode(3);
        View vPage = inflater.inflate(C0421R.layout.activity_mnemonic_show, container, false);
        this.mContext = getContext();
        String mMnemonicPhrase = PreferenceHandler.getInstance(this.mContext).getMnemonicPhrase();
        this.mVerifyButton = (TextView) vPage.findViewById(C0421R.C0419id.next);
        this.mDoneBtn = (ImageView) vPage.findViewById(C0421R.C0419id.action_bar_back);
        this.phrase1_text = (TextView) vPage.findViewById(C0421R.C0419id.phrase1_text);
        this.phrase2_text = (TextView) vPage.findViewById(C0421R.C0419id.phrase2_text);
        this.phrase3_text = (TextView) vPage.findViewById(C0421R.C0419id.phrase3_text);
        this.phrase4_text = (TextView) vPage.findViewById(C0421R.C0419id.phrase4_text);
        this.phrase5_text = (TextView) vPage.findViewById(C0421R.C0419id.phrase5_text);
        this.phrase6_text = (TextView) vPage.findViewById(C0421R.C0419id.phrase6_text);
        this.phrase7_text = (TextView) vPage.findViewById(C0421R.C0419id.phrase7_text);
        this.phrase8_text = (TextView) vPage.findViewById(C0421R.C0419id.phrase8_text);
        this.phrase9_text = (TextView) vPage.findViewById(C0421R.C0419id.phrase9_text);
        this.phrase10_text = (TextView) vPage.findViewById(C0421R.C0419id.phrase10_text);
        this.phrase11_text = (TextView) vPage.findViewById(C0421R.C0419id.phrase11_text);
        this.phrase12_text = (TextView) vPage.findViewById(C0421R.C0419id.phrase12_text);
        if (mMnemonicPhrase != null) {
            String[] splitStr = mMnemonicPhrase.trim().split("\\s+");
            this.phrase1_text.setText(splitStr[0]);
            this.phrase2_text.setText(splitStr[1]);
            this.phrase3_text.setText(splitStr[2]);
            this.phrase4_text.setText(splitStr[3]);
            this.phrase5_text.setText(splitStr[4]);
            this.phrase6_text.setText(splitStr[5]);
            this.phrase7_text.setText(splitStr[6]);
            this.phrase8_text.setText(splitStr[7]);
            this.phrase9_text.setText(splitStr[8]);
            this.phrase10_text.setText(splitStr[9]);
            this.phrase11_text.setText(splitStr[10]);
            this.phrase12_text.setText(splitStr[11]);
        } else {
            Toast.makeText(this.mContext, "Invalid Mnemonic Phrase", 0).show();
        }
        this.mDoneBtn.setOnClickListener(new C04461());
        this.mVerifyButton.setOnClickListener(new C04472());
        return vPage;
    }
}
