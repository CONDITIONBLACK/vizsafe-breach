package com.vizsafe.app.Wallet;

import android.os.Bundle;
import android.support.p002v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.Utils.PreferenceHandler;

public class ViewMnemonicPhrase extends AppCompatActivity {
    private static final String TAG = "MNEMONIC";
    private ImageView back_btn;
    private TextView mVerifyButton;
    private TextView phrase10_text;
    private TextView phrase11_text;
    private TextView phrase12_text;
    private TextView phrase1_text;
    private TextView phrase2_text;
    private TextView phrase3_text;
    private TextView phrase4_text;
    private TextView phrase5_text;
    private TextView phrase6_text;
    private TextView phrase7_text;
    private TextView phrase8_text;
    private TextView phrase9_text;
    private TextView show_bottom_text;

    /* renamed from: com.vizsafe.app.Wallet.ViewMnemonicPhrase$1 */
    class C04591 implements OnClickListener {
        C04591() {
        }

        public void onClick(View v) {
            ViewMnemonicPhrase.this.finish();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "onCreate");
        super.onCreate(savedInstanceState);
        setContentView((int) C0421R.layout.activity_mnemonic_view);
        String mMnemonicPhrase = PreferenceHandler.getInstance(getApplicationContext()).getMnemonicPhrase();
        this.back_btn = (ImageView) findViewById(C0421R.C0419id.action_bar_back);
        this.show_bottom_text = (TextView) findViewById(C0421R.C0419id.show_bottom_text);
        this.show_bottom_text.setVisibility(8);
        this.phrase1_text = (TextView) findViewById(C0421R.C0419id.phrase1_text);
        this.phrase2_text = (TextView) findViewById(C0421R.C0419id.phrase2_text);
        this.phrase3_text = (TextView) findViewById(C0421R.C0419id.phrase3_text);
        this.phrase4_text = (TextView) findViewById(C0421R.C0419id.phrase4_text);
        this.phrase5_text = (TextView) findViewById(C0421R.C0419id.phrase5_text);
        this.phrase6_text = (TextView) findViewById(C0421R.C0419id.phrase6_text);
        this.phrase7_text = (TextView) findViewById(C0421R.C0419id.phrase7_text);
        this.phrase8_text = (TextView) findViewById(C0421R.C0419id.phrase8_text);
        this.phrase9_text = (TextView) findViewById(C0421R.C0419id.phrase9_text);
        this.phrase10_text = (TextView) findViewById(C0421R.C0419id.phrase10_text);
        this.phrase11_text = (TextView) findViewById(C0421R.C0419id.phrase11_text);
        this.phrase12_text = (TextView) findViewById(C0421R.C0419id.phrase12_text);
        if (mMnemonicPhrase != null) {
            String[] splitStr = mMnemonicPhrase.trim().split("\\s+");
            this.phrase1_text.setText(splitStr[0]);
            this.phrase2_text.setText(splitStr[1]);
            this.phrase3_text.setText(splitStr[2]);
            this.phrase4_text.setText(splitStr[3]);
            this.phrase5_text.setText(splitStr[4]);
            this.phrase6_text.setText(splitStr[5]);
            this.phrase7_text.setText(splitStr[6]);
            this.phrase8_text.setText(splitStr[7]);
            this.phrase9_text.setText(splitStr[8]);
            this.phrase10_text.setText(splitStr[9]);
            this.phrase11_text.setText(splitStr[10]);
            this.phrase12_text.setText(splitStr[11]);
        } else {
            Toast.makeText(getApplicationContext(), "Invalid Mnemonic Phrase", 0).show();
        }
        this.back_btn.setOnClickListener(new C04591());
    }

    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
