package com.vizsafe.app.Wallet;

import android.app.AlertDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.p001v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.analytics.ecommerce.ProductAction;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.GCMIntentService.GCMClientManager;
import com.vizsafe.app.Utils.CommonMember;
import com.vizsafe.app.Utils.PreferenceHandler;
import com.vizsafe.app.Utils.Webservice;
import com.vizsafe.app.Wallet.CreateWalletWebView.onGoToWalletPageListener;
import dmax.dialog.SpotsDialog;
import org.json.JSONException;
import org.json.JSONObject;

public class ImportPublicAddress extends Fragment {
    private TextView action_bar_title;
    private ImageView mBackButton;
    private ConnectivityManager mConnectivityManager;
    private Context mContext;
    private String mEmail;
    private boolean mIsEmptyAddress = true;
    private TextView mNextButton;
    private String mPassword;
    private String mPublicAddress = null;
    private EditText mPublicAddressEditText;
    private AlertDialog mTransparentProgressDialog;

    /* renamed from: com.vizsafe.app.Wallet.ImportPublicAddress$1 */
    class C04411 implements OnClickListener {
        C04411() {
        }

        public void onClick(View view) {
            ImportPublicAddress.this.mPublicAddress = ImportPublicAddress.this.mPublicAddressEditText.getText().toString().trim();
            if (ImportPublicAddress.this.mPublicAddress.isEmpty()) {
                ImportPublicAddress.this.mPublicAddressEditText.setError(ImportPublicAddress.this.getString(C0421R.string.error_enter_address));
            } else if (!CommonMember.isNetworkOnline(ImportPublicAddress.this.mConnectivityManager, ImportPublicAddress.this.mContext)) {
                CommonMember.getErrorDialog(ImportPublicAddress.this.getString(C0421R.string.no_internet_access), ImportPublicAddress.this.mContext).show();
            } else if (ImportPublicAddress.this.mIsEmptyAddress) {
                new AsyncTaskSavePublicAddress(ImportPublicAddress.this, null).execute(new String[0]);
            } else {
                new AsyncTaskSaveNewPublicAddress(ImportPublicAddress.this, null).execute(new String[0]);
            }
        }
    }

    /* renamed from: com.vizsafe.app.Wallet.ImportPublicAddress$2 */
    class C04422 implements OnClickListener {
        C04422() {
        }

        public void onClick(View view) {
            PreferenceHandler.getInstance(ImportPublicAddress.this.mContext).setVerifyPasswordWallet(0);
            PreferenceHandler.getInstance(ImportPublicAddress.this.mContext).setShowVerifyPhrase(0);
            PreferenceHandler.getInstance(ImportPublicAddress.this.mContext).setVerifyPhrase(0);
            ((onGoToWalletPageListener) ImportPublicAddress.this.mContext).onGoToWalletPage();
        }
    }

    private class AsyncTaskSaveNewPublicAddress extends AsyncTask<String, String, JSONObject> {
        JSONObject SavePublicAddressResponse;
        private JSONObject mJsonResponse;

        private AsyncTaskSaveNewPublicAddress() {
            this.SavePublicAddressResponse = null;
        }

        /* synthetic */ AsyncTaskSaveNewPublicAddress(ImportPublicAddress x0, C04411 x1) {
            this();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            ImportPublicAddress.this.mTransparentProgressDialog.show();
        }

        protected JSONObject doInBackground(String... arg0) {
            try {
                this.SavePublicAddressResponse = Webservice.SaveNewPublicAddressResponse(ImportPublicAddress.this.mContext, ImportPublicAddress.this.mEmail, ImportPublicAddress.this.mPassword, ImportPublicAddress.this.mPublicAddress);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return this.SavePublicAddressResponse;
        }

        protected void onPostExecute(JSONObject mResponse) {
            ImportPublicAddress.this.mTransparentProgressDialog.dismiss();
            if (mResponse != null) {
                try {
                    this.mJsonResponse = new JSONObject(String.valueOf(mResponse));
                    int httpCode = this.mJsonResponse.getInt("httpCode");
                    String mMessage = this.mJsonResponse.getString(GCMClientManager.EXTRA_MESSAGE);
                    if (httpCode == 200) {
                        PreferenceHandler.getInstance(ImportPublicAddress.this.mContext).setCurrentEthAddress(ImportPublicAddress.this.mPublicAddress);
                        PreferenceHandler.getInstance(ImportPublicAddress.this.mContext).setVerifyPasswordWallet(1);
                        PreferenceHandler.getInstance(ImportPublicAddress.this.mContext).setShowVerifyPhrase(1);
                        PreferenceHandler.getInstance(ImportPublicAddress.this.mContext).setVerifyPhrase(1);
                        ((onGoToWalletPageListener) ImportPublicAddress.this.mContext).onGoToWalletPage();
                        return;
                    }
                    Toast.makeText(ImportPublicAddress.this.mContext, ImportPublicAddress.this.getString(C0421R.string.error_enter_address), 1).show();
                    return;
                } catch (JSONException e) {
                    e.printStackTrace();
                    return;
                }
            }
            CommonMember.getErrorDialog(ImportPublicAddress.this.getString(C0421R.string.unable_to_process_your_request), ImportPublicAddress.this.mContext).show();
        }
    }

    private class AsyncTaskSavePublicAddress extends AsyncTask<String, String, JSONObject> {
        JSONObject SavePublicAddressResponse;
        private JSONObject mJsonResponse;

        private AsyncTaskSavePublicAddress() {
            this.SavePublicAddressResponse = null;
        }

        /* synthetic */ AsyncTaskSavePublicAddress(ImportPublicAddress x0, C04411 x1) {
            this();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            ImportPublicAddress.this.mTransparentProgressDialog.show();
        }

        protected JSONObject doInBackground(String... arg0) {
            try {
                this.SavePublicAddressResponse = Webservice.SavePublicAddressResponse(ImportPublicAddress.this.mContext, ImportPublicAddress.this.mEmail, ImportPublicAddress.this.mPassword, ImportPublicAddress.this.mPublicAddress, PreferenceHandler.getInstance(ImportPublicAddress.this.mContext).getUserUUID());
            } catch (Exception e) {
                e.printStackTrace();
            }
            return this.SavePublicAddressResponse;
        }

        protected void onPostExecute(JSONObject mResponse) {
            ImportPublicAddress.this.mTransparentProgressDialog.dismiss();
            if (mResponse != null) {
                try {
                    this.mJsonResponse = new JSONObject(String.valueOf(mResponse));
                    int httpCode = this.mJsonResponse.getInt("httpCode");
                    String mMessage = this.mJsonResponse.getString(GCMClientManager.EXTRA_MESSAGE);
                    String detail = this.mJsonResponse.getString(ProductAction.ACTION_DETAIL).toLowerCase();
                    String mServerPublicAddress = PreferenceHandler.getInstance(ImportPublicAddress.this.mContext).getCheckImportPublicAddress().toLowerCase();
                    ImportPublicAddress.this.mPublicAddress = ImportPublicAddress.this.mPublicAddress.toLowerCase();
                    if (httpCode == 200) {
                        PreferenceHandler.getInstance(ImportPublicAddress.this.mContext).setCurrentEthAddress(ImportPublicAddress.this.mPublicAddress);
                        PreferenceHandler.getInstance(ImportPublicAddress.this.mContext).setVerifyPasswordWallet(1);
                        PreferenceHandler.getInstance(ImportPublicAddress.this.mContext).setShowVerifyPhrase(1);
                        PreferenceHandler.getInstance(ImportPublicAddress.this.mContext).setVerifyPhrase(1);
                        ((onGoToWalletPageListener) ImportPublicAddress.this.mContext).onGoToWalletPage();
                        return;
                    } else if (detail.equalsIgnoreCase(ImportPublicAddress.this.mPublicAddress)) {
                        PreferenceHandler.getInstance(ImportPublicAddress.this.mContext).setCurrentEthAddress(ImportPublicAddress.this.mPublicAddress);
                        PreferenceHandler.getInstance(ImportPublicAddress.this.mContext).setVerifyPasswordWallet(1);
                        PreferenceHandler.getInstance(ImportPublicAddress.this.mContext).setShowVerifyPhrase(1);
                        PreferenceHandler.getInstance(ImportPublicAddress.this.mContext).setVerifyPhrase(1);
                        ((onGoToWalletPageListener) ImportPublicAddress.this.mContext).onGoToWalletPage();
                        return;
                    } else {
                        Toast.makeText(ImportPublicAddress.this.mContext, ImportPublicAddress.this.getString(C0421R.string.error_enter_address), 1).show();
                        return;
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    return;
                }
            }
            CommonMember.getErrorDialog(ImportPublicAddress.this.getString(C0421R.string.unable_to_process_your_request), ImportPublicAddress.this.mContext).show();
        }
    }

    private class AsyncTaskSavePublicAddressCheck extends AsyncTask<String, String, JSONObject> {
        JSONObject SavePublicAddressResponse;
        private JSONObject mJsonResponse;

        private AsyncTaskSavePublicAddressCheck() {
            this.SavePublicAddressResponse = null;
        }

        /* synthetic */ AsyncTaskSavePublicAddressCheck(ImportPublicAddress x0, C04411 x1) {
            this();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            ImportPublicAddress.this.mTransparentProgressDialog.show();
        }

        protected JSONObject doInBackground(String... arg0) {
            try {
                this.mJsonResponse = Webservice.CheckPublicAddress(ImportPublicAddress.this.mContext, ImportPublicAddress.this.mEmail, ImportPublicAddress.this.mPassword, PreferenceHandler.getInstance(ImportPublicAddress.this.mContext).getUserUUID());
            } catch (Exception e) {
                e.printStackTrace();
            }
            return this.mJsonResponse;
        }

        protected void onPostExecute(JSONObject mResponse) {
            ImportPublicAddress.this.mTransparentProgressDialog.dismiss();
            if (mResponse != null) {
                try {
                    this.mJsonResponse = new JSONObject(String.valueOf(mResponse));
                    int httpCode = this.mJsonResponse.getInt("httpCode");
                    String mMessage = this.mJsonResponse.getString(GCMClientManager.EXTRA_MESSAGE);
                    boolean mAlreadyExist = this.mJsonResponse.getBoolean("AlreadyExist");
                    String mResponsePublicAddress = this.mJsonResponse.getString("PublicAddress");
                    if (!mResponsePublicAddress.isEmpty()) {
                        ImportPublicAddress.this.mPublicAddressEditText.setText(mResponsePublicAddress);
                        ImportPublicAddress.this.mIsEmptyAddress = false;
                        return;
                    }
                    return;
                } catch (JSONException e) {
                    e.printStackTrace();
                    return;
                }
            }
            CommonMember.getErrorDialog(ImportPublicAddress.this.getString(C0421R.string.unable_to_process_your_request), ImportPublicAddress.this.mContext).show();
        }
    }

    public static ImportPublicAddress newInstance() {
        return new ImportPublicAddress();
    }

    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.clear();
    }

    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        ((InputMethodManager) getActivity().getSystemService("input_method")).hideSoftInputFromWindow(getView().getWindowToken(), 0);
    }

    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ((InputMethodManager) getActivity().getSystemService("input_method")).hideSoftInputFromWindow(getView().getWindowToken(), 0);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getActivity().getWindow().setSoftInputMode(3);
        View vPage = inflater.inflate(C0421R.layout.activity_import_public_address, container, false);
        this.mContext = getActivity();
        this.mBackButton = (ImageView) vPage.findViewById(C0421R.C0419id.action_bar_back);
        this.mNextButton = (TextView) vPage.findViewById(C0421R.C0419id.action_bar_next);
        this.action_bar_title = (TextView) vPage.findViewById(2131689653);
        this.mNextButton.setVisibility(0);
        this.action_bar_title.setVisibility(0);
        this.action_bar_title.setText(getResources().getString(C0421R.string.import_wallet));
        this.mPublicAddressEditText = (EditText) vPage.findViewById(C0421R.C0419id.public_address);
        this.mConnectivityManager = (ConnectivityManager) this.mContext.getSystemService("connectivity");
        this.mTransparentProgressDialog = new SpotsDialog(this.mContext, getResources().getString(C0421R.string.please_wait_loading));
        this.mTransparentProgressDialog.setCanceledOnTouchOutside(false);
        this.mTransparentProgressDialog.setCancelable(false);
        this.mEmail = PreferenceHandler.getInstance(this.mContext).getUserName();
        this.mPassword = PreferenceHandler.getInstance(this.mContext).getPassword();
        if (CommonMember.isNetworkOnline(this.mConnectivityManager, this.mContext)) {
            new AsyncTaskSavePublicAddressCheck(this, null).execute(new String[0]);
        } else {
            CommonMember.getErrorDialog(getString(C0421R.string.no_internet_access), this.mContext).show();
        }
        this.mNextButton.setOnClickListener(new C04411());
        this.mBackButton.setOnClickListener(new C04422());
        return vPage;
    }
}
