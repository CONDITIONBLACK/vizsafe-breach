package com.vizsafe.app.Wallet;

import android.app.AlertDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.p001v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.GCMIntentService.GCMClientManager;
import com.vizsafe.app.Utils.CommonMember;
import com.vizsafe.app.Utils.PreferenceHandler;
import com.vizsafe.app.Utils.Webservice;
import com.vizsafe.app.Wallet.CreateWalletWebView.onGoToWalletPageListener;
import dmax.dialog.SpotsDialog;
import org.json.JSONException;
import org.json.JSONObject;

public class GetMnemonicPhrase extends Fragment {
    private static final String TAG = "MNEMONIC";
    private ImageView back_btn;
    private String mAddress;
    private ConnectivityManager mConnectivityManager;
    private Context mContext;
    private String mEmail;
    private GetMnemonicPhrase mGetMnemonicPhrase;
    private String mPassword;
    private AlertDialog mTransparentProgressDialog;
    private TextView mVerifyButton;
    private EditText phrase10_text;
    private EditText phrase11_text;
    private EditText phrase12_text;
    private EditText phrase1_text;
    private EditText phrase2_text;
    private EditText phrase3_text;
    private EditText phrase4_text;
    private EditText phrase5_text;
    private EditText phrase6_text;
    private EditText phrase7_text;
    private EditText phrase8_text;
    private EditText phrase9_text;
    private String[] splitStr;

    /* renamed from: com.vizsafe.app.Wallet.GetMnemonicPhrase$1 */
    class C04391 implements OnClickListener {
        C04391() {
        }

        public void onClick(View v) {
            PreferenceHandler.getInstance(GetMnemonicPhrase.this.mContext).setShowVerifyPhrase(0);
            ((onGoToWalletPageListener) GetMnemonicPhrase.this.mContext).onGoToWalletPage();
        }
    }

    /* renamed from: com.vizsafe.app.Wallet.GetMnemonicPhrase$2 */
    class C04402 implements OnClickListener {
        C04402() {
        }

        public void onClick(View v) {
            if (GetMnemonicPhrase.this.phrase1_text.getText().toString().trim().isEmpty()) {
                GetMnemonicPhrase.this.phrase1_text.setError(GetMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (!GetMnemonicPhrase.this.phrase1_text.getText().toString().trim().equals(GetMnemonicPhrase.this.splitStr[0])) {
                GetMnemonicPhrase.this.phrase1_text.setError(GetMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (GetMnemonicPhrase.this.phrase2_text.getText().toString().trim().isEmpty()) {
                GetMnemonicPhrase.this.phrase2_text.setError(GetMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (!GetMnemonicPhrase.this.phrase2_text.getText().toString().trim().equals(GetMnemonicPhrase.this.splitStr[1])) {
                GetMnemonicPhrase.this.phrase2_text.setError(GetMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (GetMnemonicPhrase.this.phrase3_text.getText().toString().trim().isEmpty()) {
                GetMnemonicPhrase.this.phrase3_text.setError(GetMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (!GetMnemonicPhrase.this.phrase3_text.getText().toString().trim().equals(GetMnemonicPhrase.this.splitStr[2])) {
                GetMnemonicPhrase.this.phrase3_text.setError(GetMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (GetMnemonicPhrase.this.phrase4_text.getText().toString().trim().isEmpty()) {
                GetMnemonicPhrase.this.phrase4_text.setError(GetMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (!GetMnemonicPhrase.this.phrase4_text.getText().toString().trim().equals(GetMnemonicPhrase.this.splitStr[3])) {
                GetMnemonicPhrase.this.phrase4_text.setError(GetMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (GetMnemonicPhrase.this.phrase5_text.getText().toString().trim().isEmpty()) {
                GetMnemonicPhrase.this.phrase5_text.setError(GetMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (!GetMnemonicPhrase.this.phrase5_text.getText().toString().trim().equals(GetMnemonicPhrase.this.splitStr[4])) {
                GetMnemonicPhrase.this.phrase5_text.setError(GetMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (GetMnemonicPhrase.this.phrase6_text.getText().toString().trim().isEmpty()) {
                GetMnemonicPhrase.this.phrase6_text.setError(GetMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (!GetMnemonicPhrase.this.phrase6_text.getText().toString().trim().equals(GetMnemonicPhrase.this.splitStr[5])) {
                GetMnemonicPhrase.this.phrase6_text.setError(GetMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (GetMnemonicPhrase.this.phrase7_text.getText().toString().trim().isEmpty()) {
                GetMnemonicPhrase.this.phrase7_text.setError(GetMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (!GetMnemonicPhrase.this.phrase7_text.getText().toString().trim().equals(GetMnemonicPhrase.this.splitStr[6])) {
                GetMnemonicPhrase.this.phrase7_text.setError(GetMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (GetMnemonicPhrase.this.phrase8_text.getText().toString().trim().isEmpty()) {
                GetMnemonicPhrase.this.phrase8_text.setError(GetMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (!GetMnemonicPhrase.this.phrase8_text.getText().toString().trim().equals(GetMnemonicPhrase.this.splitStr[7])) {
                GetMnemonicPhrase.this.phrase8_text.setError(GetMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (GetMnemonicPhrase.this.phrase9_text.getText().toString().trim().isEmpty()) {
                GetMnemonicPhrase.this.phrase9_text.setError(GetMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (!GetMnemonicPhrase.this.phrase9_text.getText().toString().trim().equals(GetMnemonicPhrase.this.splitStr[8])) {
                GetMnemonicPhrase.this.phrase9_text.setError(GetMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (GetMnemonicPhrase.this.phrase10_text.getText().toString().trim().isEmpty()) {
                GetMnemonicPhrase.this.phrase10_text.setError(GetMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (!GetMnemonicPhrase.this.phrase10_text.getText().toString().trim().equals(GetMnemonicPhrase.this.splitStr[9])) {
                GetMnemonicPhrase.this.phrase10_text.setError(GetMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (GetMnemonicPhrase.this.phrase11_text.getText().toString().trim().isEmpty()) {
                GetMnemonicPhrase.this.phrase11_text.setError(GetMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (!GetMnemonicPhrase.this.phrase11_text.getText().toString().trim().equals(GetMnemonicPhrase.this.splitStr[10])) {
                GetMnemonicPhrase.this.phrase11_text.setError(GetMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (GetMnemonicPhrase.this.phrase12_text.getText().toString().trim().isEmpty()) {
                GetMnemonicPhrase.this.phrase12_text.setError(GetMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            } else if (GetMnemonicPhrase.this.phrase12_text.getText().toString().trim().equals(GetMnemonicPhrase.this.splitStr[11])) {
                PreferenceHandler.getInstance(GetMnemonicPhrase.this.mContext).setVerifyPhrase(1);
                if (!GetMnemonicPhrase.this.mAddress.isEmpty()) {
                    if (CommonMember.isNetworkOnline(GetMnemonicPhrase.this.mConnectivityManager, GetMnemonicPhrase.this.mContext)) {
                        new AsyncTaskSavePublicAddress(GetMnemonicPhrase.this, null).execute(new String[0]);
                    } else {
                        CommonMember.getErrorDialog(GetMnemonicPhrase.this.getString(C0421R.string.no_internet_access), GetMnemonicPhrase.this.mContext).show();
                    }
                }
            } else {
                GetMnemonicPhrase.this.phrase12_text.setError(GetMnemonicPhrase.this.getString(C0421R.string.error_enter_passphrase));
            }
        }
    }

    private class AsyncTaskSavePublicAddress extends AsyncTask<String, String, JSONObject> {
        JSONObject SavePublicAddressResponse;
        private JSONObject mJsonResponse;

        private AsyncTaskSavePublicAddress() {
            this.SavePublicAddressResponse = null;
        }

        /* synthetic */ AsyncTaskSavePublicAddress(GetMnemonicPhrase x0, C04391 x1) {
            this();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            GetMnemonicPhrase.this.mTransparentProgressDialog.show();
        }

        protected JSONObject doInBackground(String... arg0) {
            try {
                this.SavePublicAddressResponse = Webservice.SavePublicAddressResponse(GetMnemonicPhrase.this.mContext, GetMnemonicPhrase.this.mEmail, GetMnemonicPhrase.this.mPassword, GetMnemonicPhrase.this.mAddress, PreferenceHandler.getInstance(GetMnemonicPhrase.this.mContext).getUserUUID());
            } catch (Exception e) {
                e.printStackTrace();
            }
            return this.SavePublicAddressResponse;
        }

        protected void onPostExecute(JSONObject mResponse) {
            GetMnemonicPhrase.this.mTransparentProgressDialog.dismiss();
            if (mResponse != null) {
                try {
                    this.mJsonResponse = new JSONObject(String.valueOf(mResponse));
                    int httpCode = this.mJsonResponse.getInt("httpCode");
                    String mMessage = this.mJsonResponse.getString(GCMClientManager.EXTRA_MESSAGE);
                    if (httpCode == 200) {
                        ((onGoToWalletPageListener) GetMnemonicPhrase.this.mContext).onGoToWalletPage();
                        return;
                    }
                    Toast.makeText(GetMnemonicPhrase.this.mContext, mMessage, 1).show();
                    PreferenceHandler.getInstance(GetMnemonicPhrase.this.mContext).setCurrentEthAddress("0");
                    PreferenceHandler.getInstance(GetMnemonicPhrase.this.mContext).setVerifyPasswordWallet(0);
                    PreferenceHandler.getInstance(GetMnemonicPhrase.this.mContext).setShowVerifyPhrase(0);
                    PreferenceHandler.getInstance(GetMnemonicPhrase.this.mContext).setVerifyPhrase(0);
                    ((onGoToWalletPageListener) GetMnemonicPhrase.this.mContext).onGoToWalletPage();
                    return;
                } catch (JSONException e) {
                    e.printStackTrace();
                    return;
                }
            }
            CommonMember.getErrorDialog(GetMnemonicPhrase.this.getString(C0421R.string.unable_to_process_your_request), GetMnemonicPhrase.this.mContext).show();
        }
    }

    public static GetMnemonicPhrase newInstance() {
        return new GetMnemonicPhrase();
    }

    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.clear();
    }

    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        ((InputMethodManager) getActivity().getSystemService("input_method")).hideSoftInputFromWindow(getView().getWindowToken(), 0);
    }

    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ((InputMethodManager) getActivity().getSystemService("input_method")).hideSoftInputFromWindow(getView().getWindowToken(), 0);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getActivity().getWindow().setSoftInputMode(3);
        View vPage = inflater.inflate(C0421R.layout.activity_mnemonic_get, container, false);
        this.mContext = getContext();
        this.mConnectivityManager = (ConnectivityManager) this.mContext.getSystemService("connectivity");
        this.mTransparentProgressDialog = new SpotsDialog(this.mContext, getResources().getString(C0421R.string.please_wait_loading));
        this.mTransparentProgressDialog.setCanceledOnTouchOutside(false);
        this.mTransparentProgressDialog.setCancelable(false);
        this.mAddress = PreferenceHandler.getInstance(this.mContext).getCurrentEthAddress();
        this.mEmail = PreferenceHandler.getInstance(this.mContext).getUserName();
        this.mPassword = PreferenceHandler.getInstance(this.mContext).getPassword();
        this.splitStr = PreferenceHandler.getInstance(this.mContext).getMnemonicPhrase().trim().split("\\s+");
        this.back_btn = (ImageView) vPage.findViewById(C0421R.C0419id.action_bar_back);
        this.mVerifyButton = (TextView) vPage.findViewById(C0421R.C0419id.next);
        this.phrase1_text = (EditText) vPage.findViewById(C0421R.C0419id.phrase1_edittext);
        this.phrase2_text = (EditText) vPage.findViewById(C0421R.C0419id.phrase2_edittext);
        this.phrase3_text = (EditText) vPage.findViewById(C0421R.C0419id.phrase3_edittext);
        this.phrase4_text = (EditText) vPage.findViewById(C0421R.C0419id.phrase4_edittext);
        this.phrase5_text = (EditText) vPage.findViewById(C0421R.C0419id.phrase5_edittext);
        this.phrase6_text = (EditText) vPage.findViewById(C0421R.C0419id.phrase6_edittext);
        this.phrase7_text = (EditText) vPage.findViewById(C0421R.C0419id.phrase7_edittext);
        this.phrase8_text = (EditText) vPage.findViewById(C0421R.C0419id.phrase8_edittext);
        this.phrase9_text = (EditText) vPage.findViewById(C0421R.C0419id.phrase9_edittext);
        this.phrase10_text = (EditText) vPage.findViewById(C0421R.C0419id.phrase10_edittext);
        this.phrase11_text = (EditText) vPage.findViewById(C0421R.C0419id.phrase11_edittext);
        this.phrase12_text = (EditText) vPage.findViewById(C0421R.C0419id.phrase12_edittext);
        this.phrase1_text.setText(this.splitStr[0]);
        this.phrase2_text.setText(this.splitStr[1]);
        this.phrase3_text.setText(this.splitStr[2]);
        this.phrase4_text.setText(this.splitStr[3]);
        this.phrase5_text.setText(this.splitStr[4]);
        this.phrase6_text.setText(this.splitStr[5]);
        this.phrase7_text.setText(this.splitStr[6]);
        this.phrase8_text.setText(this.splitStr[7]);
        this.phrase9_text.setText(this.splitStr[8]);
        this.phrase10_text.setText(this.splitStr[9]);
        this.phrase11_text.setText(this.splitStr[10]);
        this.phrase12_text.setText(this.splitStr[11]);
        this.back_btn.setOnClickListener(new C04391());
        this.mVerifyButton.setOnClickListener(new C04402());
        return vPage;
    }
}
