package com.vizsafe.app.Wallet;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.p001v4.app.ActivityCompat;
import android.support.p001v4.content.ContextCompat;
import android.util.DisplayMetrics;
import android.util.Log;
import android.widget.Toast;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.vision.MultiProcessor;
import com.google.android.gms.vision.barcode.Barcode;
import com.google.android.gms.vision.barcode.BarcodeDetector;
import com.google.android.gms.vision.barcode.BarcodeDetector.Builder;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.Wallet.BarcodeTracker.BarcodeGraphicTrackerCallback;
import java.io.IOException;

public final class BarcodeCaptureActivity extends Activity implements BarcodeGraphicTrackerCallback {
    public static final String BarcodeObject = "Barcode";
    private static final int RC_HANDLE_CAMERA_PERM = 2;
    private static final int RC_HANDLE_GMS = 9001;
    private static final String TAG = "Barcode-reader";
    private CameraSource mCameraSource;
    private CameraSourcePreview mPreview;

    /* renamed from: com.vizsafe.app.Wallet.BarcodeCaptureActivity$1 */
    class C04291 implements OnClickListener {
        C04291() {
        }

        public void onClick(DialogInterface dialog, int id) {
            BarcodeCaptureActivity.this.finish();
        }
    }

    public void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        setContentView(C0421R.layout.barcode_capture);
        this.mPreview = (CameraSourcePreview) findViewById(C0421R.C0419id.preview);
        if (ContextCompat.checkSelfPermission(this, "android.permission.CAMERA") == 0) {
            createCameraSource(true, false);
        } else {
            requestCameraPermission();
        }
    }

    public void onDetectedQrCode(Barcode barcode) {
        if (barcode != null) {
            Intent intent = new Intent();
            intent.putExtra(BarcodeObject, barcode);
            setResult(0, intent);
            finish();
        }
    }

    private void requestCameraPermission() {
        Log.w(TAG, "Camera permission is not granted. Requesting permission");
        String[] permissions = new String[]{"android.permission.CAMERA"};
        if (!ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.CAMERA")) {
            ActivityCompat.requestPermissions(this, permissions, 2);
        }
    }

    @SuppressLint({"InlinedApi"})
    private void createCameraSource(boolean autoFocus, boolean useFlash) {
        String str = null;
        BarcodeDetector barcodeDetector = new Builder(getApplicationContext()).setBarcodeFormats(0).build();
        barcodeDetector.setProcessor(new MultiProcessor.Builder(new BarcodeTrackerFactory(this)).build());
        if (!barcodeDetector.isOperational()) {
            boolean hasLowStorage;
            Log.w(TAG, "Detector dependencies are not yet available.");
            if (registerReceiver(null, new IntentFilter("android.intent.action.DEVICE_STORAGE_LOW")) != null) {
                hasLowStorage = true;
            } else {
                hasLowStorage = false;
            }
            if (hasLowStorage) {
                Toast.makeText(this, C0421R.string.low_storage_error, 1).show();
                Log.w(TAG, getString(C0421R.string.low_storage_error));
            }
        }
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        CameraSource.Builder builder = new CameraSource.Builder(getApplicationContext(), barcodeDetector).setFacing(0).setRequestedPreviewSize(metrics.widthPixels, metrics.heightPixels).setRequestedFps(24.0f);
        if (VERSION.SDK_INT >= 14) {
            String str2;
            if (autoFocus) {
                str2 = "continuous-picture";
            } else {
                str2 = null;
            }
            builder = builder.setFocusMode(str2);
        }
        if (useFlash) {
            str = "torch";
        }
        this.mCameraSource = builder.setFlashMode(str).build();
    }

    protected void onResume() {
        super.onResume();
        startCameraSource();
    }

    protected void onPause() {
        super.onPause();
        if (this.mPreview != null) {
            this.mPreview.stop();
        }
    }

    protected void onDestroy() {
        super.onDestroy();
        if (this.mPreview != null) {
            this.mPreview.release();
        }
    }

    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode != 2) {
            Log.d(TAG, "Got unexpected permission result: " + requestCode);
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        } else if (grantResults.length == 0 || grantResults[0] != 0) {
            Log.e(TAG, "Permission not granted: results len = " + grantResults.length + " Result code = " + (grantResults.length > 0 ? Integer.valueOf(grantResults[0]) : "(empty)"));
            new AlertDialog.Builder(this).setTitle("Multitracker sample").setMessage(C0421R.string.no_camera_permission).setPositiveButton(C0421R.string.okTxt, new C04291()).show();
        } else {
            Log.d(TAG, "Camera permission granted - initialize the camera source");
            createCameraSource(true, false);
        }
    }

    private void startCameraSource() throws SecurityException {
        int code = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(getApplicationContext());
        if (code != 0) {
            GoogleApiAvailability.getInstance().getErrorDialog(this, code, 9001).show();
        }
        if (this.mCameraSource != null) {
            try {
                this.mPreview.start(this.mCameraSource);
            } catch (IOException e) {
                Log.e(TAG, "Unable to start camera source.", e);
                this.mCameraSource.release();
                this.mCameraSource = null;
            }
        }
    }
}
