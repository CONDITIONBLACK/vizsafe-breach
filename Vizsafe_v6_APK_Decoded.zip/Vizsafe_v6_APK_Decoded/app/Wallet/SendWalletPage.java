package com.vizsafe.app.Wallet;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Point;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.vision.barcode.Barcode;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.Utils.CommonMember;
import com.vizsafe.app.Utils.PreferenceHandler;
import com.vizsafe.app.Wallet.CreateWalletWebView.onGoToWalletPageListener;

public class SendWalletPage extends Activity {
    private static final int BARCODE_READER_REQUEST_CODE = 1;
    private static final String LOG_TAG = SendWalletPage.class.getSimpleName();
    private EditText ToAddressView;
    private ImageView backBtn;
    private String mAddress;
    private ImageView mBarcodeIcon;
    private EditText mEthAmountView;
    private SendWalletPage mSendWalletPage;
    private Button sendButton;

    /* renamed from: com.vizsafe.app.Wallet.SendWalletPage$1 */
    class C04431 implements OnClickListener {
        C04431() {
        }

        public void onClick(View view) {
            TransactionListActivity.mClickedSendBtn = false;
            SendWalletPage.this.finish();
        }
    }

    /* renamed from: com.vizsafe.app.Wallet.SendWalletPage$2 */
    class C04442 implements OnClickListener {
        C04442() {
        }

        public void onClick(View view) {
            SendWalletPage.this.startActivityForResult(new Intent(SendWalletPage.this.getApplicationContext(), BarcodeCaptureActivity.class), 1);
        }
    }

    /* renamed from: com.vizsafe.app.Wallet.SendWalletPage$3 */
    class C04453 implements OnClickListener {
        C04453() {
        }

        public void onClick(View view) {
            String mToAddress = SendWalletPage.this.ToAddressView.getText().toString().trim();
            String mEthAmount = SendWalletPage.this.mEthAmountView.getText().toString().trim();
            if (mToAddress.isEmpty() || mToAddress.length() == 0) {
                SendWalletPage.this.ToAddressView.setError(SendWalletPage.this.getString(C0421R.string.error_enter_address));
            } else if (mToAddress.equalsIgnoreCase(SendWalletPage.this.mAddress)) {
                SendWalletPage.this.ToAddressView.setError(SendWalletPage.this.getString(C0421R.string.error_notsame_address));
            } else if (mEthAmount.isEmpty() || mEthAmount.length() == 0) {
                SendWalletPage.this.mEthAmountView.setError(SendWalletPage.this.getString(C0421R.string.error_enter_amount));
            } else if (!CommonMember.isNetworkOnline((ConnectivityManager) SendWalletPage.this.getSystemService("connectivity"), SendWalletPage.this)) {
                CommonMember.getErrorDialog(SendWalletPage.this.getString(C0421R.string.no_internet_access), SendWalletPage.this).show();
            }
        }
    }

    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0421R.layout.send_eth_page);
        this.mSendWalletPage = this;
        this.backBtn = (ImageView) findViewById(C0421R.C0419id.action_bar_back);
        this.ToAddressView = (EditText) findViewById(C0421R.C0419id.ToAddress_view);
        this.mBarcodeIcon = (ImageView) findViewById(C0421R.C0419id.barcode_icon);
        this.mEthAmountView = (EditText) findViewById(C0421R.C0419id.ethamount_view);
        this.sendButton = (Button) findViewById(C0421R.C0419id.send_button);
        TextView mTitle = (TextView) findViewById(2131689653);
        mTitle.setVisibility(0);
        mTitle.setText(getResources().getString(C0421R.string.SendTokensText));
        this.mAddress = PreferenceHandler.getInstance(this.mSendWalletPage).getCurrentEthAddress();
        this.backBtn.setOnClickListener(new C04431());
        this.mBarcodeIcon.setOnClickListener(new C04442());
        this.sendButton.setOnClickListener(new C04453());
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode != 1) {
            super.onActivityResult(requestCode, resultCode, data);
        } else if (resultCode != 0) {
            Log.e("SEND", String.format(getString(C0421R.string.barcode_error_format), new Object[]{CommonStatusCodes.getStatusCodeString(resultCode)}));
        } else if (data != null) {
            Barcode barcode = (Barcode) data.getParcelableExtra(BarcodeCaptureActivity.BarcodeObject);
            String extracted_address = QRURLParser.getInstance().extractAddressFromQrString(barcode.displayValue);
            if (extracted_address == null) {
                Toast.makeText(this, C0421R.string.barcode_error_format, 0).show();
                return;
            }
            Point[] p = barcode.cornerPoints;
            this.ToAddressView.setText(extracted_address);
        }
    }

    public void onBackPressed() {
        super.onBackPressed();
        TransactionListActivity.mClickedSendBtn = false;
        ((onGoToWalletPageListener) getApplicationContext()).onGoToWalletPage();
    }
}
