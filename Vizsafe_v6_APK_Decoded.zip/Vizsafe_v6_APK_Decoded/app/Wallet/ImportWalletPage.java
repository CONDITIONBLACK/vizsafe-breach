package com.vizsafe.app.Wallet;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.p001v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.TextView;
import android.widget.Toast;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.Utils.PreferenceHandler;
import dmax.dialog.SpotsDialog;
import java.io.IOException;
import org.apache.commons.p004io.IOUtils;

public class ImportWalletPage extends Fragment {
    String content = null;
    private Context mContext;
    private String mCurrentAddress;
    private TextView mDoneBtn;
    private String mPhrase;
    private String mPrivKey;
    private String mPubKey;
    private TextView mTitleBar;
    private AlertDialog mTransparentProgressDialog;
    private WebView mWebView;

    private class ImportWalletJavaScriptInterface {
        private Context context;

        public ImportWalletJavaScriptInterface(Context context) {
            this.context = context;
        }

        @JavascriptInterface
        public void makeToastPassValues(String phrase, String thisAddress, String thisPrivKey, String thisPubKey, String mIntex) {
            ImportWalletPage.this.mCurrentAddress = thisAddress;
            ImportWalletPage.this.mPrivKey = thisPrivKey;
            ImportWalletPage.this.mPubKey = thisPubKey;
            ImportWalletPage.this.mPhrase = phrase;
            String intex = mIntex;
            PreferenceHandler.getInstance(ImportWalletPage.this.mContext).setMnemonicPhrase(ImportWalletPage.this.mPhrase);
            PreferenceHandler.getInstance(ImportWalletPage.this.mContext).setCurrentEthAddress(ImportWalletPage.this.mCurrentAddress);
            PreferenceHandler.getInstance(ImportWalletPage.this.mContext).setPrivateEthAddress(ImportWalletPage.this.mPrivKey);
            PreferenceHandler.getInstance(ImportWalletPage.this.mContext).setPublicEthAddress(ImportWalletPage.this.mPubKey);
        }

        @JavascriptInterface
        public void makeToastPassError(String error) {
            Toast.makeText(ImportWalletPage.this.mContext, ImportWalletPage.this.getResources().getString(C0421R.string.error_enter_passphrase), 1).show();
            ImportWalletPage.this.getActivity().finish();
        }
    }

    public static ImportWalletPage newInstance() {
        return new ImportWalletPage();
    }

    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.clear();
    }

    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        ((InputMethodManager) getActivity().getSystemService("input_method")).hideSoftInputFromWindow(getView().getWindowToken(), 0);
    }

    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ((InputMethodManager) getActivity().getSystemService("input_method")).hideSoftInputFromWindow(getView().getWindowToken(), 0);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getActivity().getWindow().setSoftInputMode(3);
        View vPage = inflater.inflate(C0421R.layout.activity_webview, container, false);
        this.mContext = getActivity();
        String mMnemonicPhrase = PreferenceHandler.getInstance(this.mContext).getMnemonicPhrase();
        this.mWebView = (WebView) vPage.findViewById(C0421R.C0419id.webview);
        this.mDoneBtn = (TextView) vPage.findViewById(C0421R.C0419id.action_bar_next);
        this.mTitleBar = (TextView) vPage.findViewById(2131689653);
        this.mTransparentProgressDialog = new SpotsDialog(this.mContext, getResources().getString(C0421R.string.please_wait_loading));
        this.mTransparentProgressDialog.setCanceledOnTouchOutside(false);
        this.mTransparentProgressDialog.setCancelable(false);
        this.mWebView.setVisibility(4);
        this.mTitleBar.setVisibility(8);
        this.mWebView.getSettings().setJavaScriptEnabled(true);
        this.mWebView.setWebChromeClient(new WebChromeClient());
        this.mWebView.addJavascriptInterface(new ImportWalletJavaScriptInterface(this.mContext), "app");
        if (!(mMnemonicPhrase.startsWith("\"") || mMnemonicPhrase.endsWith("\""))) {
            mMnemonicPhrase = "\"" + mMnemonicPhrase + "\"";
        }
        if (mMnemonicPhrase != null) {
            try {
                this.content = IOUtils.toString(this.mContext.getAssets().open("importwallet.html")).replaceAll("mCustomPhraseFromAndroid", mMnemonicPhrase);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        this.mWebView.loadDataWithBaseURL("file:///android_asset/importwallet.html", this.content, "text/html", "UTF-8", null);
        return vPage;
    }
}
