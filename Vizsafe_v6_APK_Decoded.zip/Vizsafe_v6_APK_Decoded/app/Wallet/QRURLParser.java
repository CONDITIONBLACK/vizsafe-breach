package com.vizsafe.app.Wallet;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class QRURLParser {
    private static final int ADDRESS_LENGTH = 42;
    private static QRURLParser mInstance;

    public class QrUrlResult {
        private String address;
        private Map<String, String> parameters;
        private String protocol;

        QrUrlResult(String protocol, String address, Map<String, String> parameters) {
            this.protocol = protocol;
            this.address = address;
            this.parameters = parameters;
        }

        public String getProtocol() {
            return this.protocol;
        }

        public String getAddress() {
            return this.address;
        }

        public Map<String, String> getParameters() {
            return this.parameters;
        }
    }

    public static QRURLParser getInstance() {
        if (mInstance == null) {
            synchronized (QRURLParser.class) {
                if (mInstance == null) {
                    mInstance = new QRURLParser();
                }
            }
        }
        return mInstance;
    }

    private QRURLParser() {
    }

    private static boolean isValidAddress(String address) {
        return address.length() == 42;
    }

    private static String extractAddress(String str) {
        try {
            String address = str.substring(0, 42).toLowerCase();
            if (isValidAddress(address)) {
                return address;
            }
            return null;
        } catch (StringIndexOutOfBoundsException e) {
            return null;
        }
    }

    public QrUrlResult parse(String url) {
        String address;
        String[] parts = url.split(":");
        if (parts.length == 1) {
            address = extractAddress(parts[0]);
            if (address != null) {
                return new QrUrlResult("", address.toLowerCase(), new HashMap());
            }
        }
        if (parts.length == 2) {
            String protocol = parts[0];
            address = extractAddress(parts[1]);
            if (address != null) {
                Map<String, String> params = new HashMap();
                String[] afterProtocol = parts[1].split("\\?");
                if (afterProtocol.length == 2) {
                    params = parseParamsFromParamParts(Arrays.asList(afterProtocol[1].split("&")));
                }
                return new QrUrlResult(protocol, address, params);
            }
        }
        return null;
    }

    private static Map<String, String> parseParamsFromParamParts(List<String> paramParts) {
        Map<String, String> params = new HashMap();
        if (!paramParts.isEmpty()) {
            for (String pairStr : paramParts) {
                String[] pair = pairStr.split("=");
                if (pair.length < 2) {
                    break;
                }
                params.put(pair[0], pair[1]);
            }
        }
        return params;
    }

    public String extractAddressFromQrString(String url) {
        QrUrlResult result = parse(url);
        if (result == null) {
            return null;
        }
        return result.getAddress();
    }
}
