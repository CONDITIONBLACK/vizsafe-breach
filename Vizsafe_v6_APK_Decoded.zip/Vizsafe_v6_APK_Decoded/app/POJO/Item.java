package com.vizsafe.app.POJO;

public interface Item {
    boolean isSection();
}
