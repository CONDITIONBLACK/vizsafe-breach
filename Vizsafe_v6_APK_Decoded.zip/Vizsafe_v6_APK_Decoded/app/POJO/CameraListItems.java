package com.vizsafe.app.POJO;

public class CameraListItems {
    private String cameraIcon;
    private final String cameraLatitude;
    private final String cameraLongitude;
    private String cameraName;
    private String cameraUuid;
    private String videoInput;

    public CameraListItems(String cameraIcon, String cameraName, String cameraUuid, String cameraLatitude, String cameraLongitude, String videoInput) {
        this.cameraIcon = cameraIcon;
        this.cameraName = cameraName;
        this.cameraUuid = cameraUuid;
        this.cameraLatitude = cameraLatitude;
        this.cameraLongitude = cameraLongitude;
        this.videoInput = videoInput;
    }

    public String getCameraLatitude() {
        return this.cameraLatitude;
    }

    public String getCameraLongitude() {
        return this.cameraLongitude;
    }

    public String getCameraUuid() {
        return this.cameraUuid;
    }

    public void setCameraUuid(String cameraUuid) {
        this.cameraUuid = cameraUuid;
    }

    public String getCameraIcon() {
        return this.cameraIcon;
    }

    public void setCameraIcon(String cameraIcon) {
        this.cameraIcon = cameraIcon;
    }

    public String getCameraName() {
        return this.cameraName;
    }

    public void setCameraName(String cameraName) {
        this.cameraName = cameraName;
    }

    public String getvideoInput() {
        return this.videoInput;
    }

    public void setvideoInput(String videoInput) {
        this.videoInput = videoInput;
    }
}
