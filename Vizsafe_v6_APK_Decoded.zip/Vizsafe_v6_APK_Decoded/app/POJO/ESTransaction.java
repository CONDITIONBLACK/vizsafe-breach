package com.vizsafe.app.POJO;

import com.google.gson.annotations.SerializedName;

public class ESTransaction {
    @SerializedName("blockHash")
    private String blockHash;
    @SerializedName("blockNumber")
    private String blockNumber;
    @SerializedName("confirmations")
    private String confirmations;
    @SerializedName("contractAddress")
    private String contractAddress;
    @SerializedName("cumulativeGasUsed")
    private String cumulativeGasUsed;
    @SerializedName("from")
    private String from;
    @SerializedName("gas")
    private String gas;
    @SerializedName("gasPrice")
    private String gasPrice;
    @SerializedName("gasUsed")
    private String gasUsed;
    @SerializedName("hash")
    private String hash;
    @SerializedName("input")
    private String input;
    @SerializedName("isError")
    private String isError;
    @SerializedName("nonce")
    private String nonce;
    @SerializedName("timeStamp")
    private String timeStamp;
    @SerializedName("to")
    /* renamed from: to */
    private String f36to;
    @SerializedName("transactionIndex")
    private String transactionIndex;
    @SerializedName("value")
    private String value;

    public String getBlockNumber() {
        return this.blockNumber;
    }

    public String getTimeStamp() {
        return this.timeStamp;
    }

    public String getHash() {
        return this.hash;
    }

    public String getNonce() {
        return this.nonce;
    }

    public String getBlockHash() {
        return this.blockHash;
    }

    public String getTransactionIndex() {
        return this.transactionIndex;
    }

    public String getFrom() {
        return this.from;
    }

    public String getTo() {
        return this.f36to;
    }

    public String getValue() {
        return this.value;
    }

    public String getGas() {
        return this.gas;
    }

    public String getGasPrice() {
        return this.gasPrice;
    }

    public String getIsError() {
        return this.isError;
    }

    public String getInput() {
        return this.input;
    }

    public String getContractAddress() {
        return this.contractAddress;
    }

    public String getCumulativeGasUsed() {
        return this.cumulativeGasUsed;
    }

    public String getGasUsed() {
        return this.gasUsed;
    }

    public String getConfirmations() {
        return this.confirmations;
    }
}
