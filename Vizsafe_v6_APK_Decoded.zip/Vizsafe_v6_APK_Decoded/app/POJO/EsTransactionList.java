package com.vizsafe.app.POJO;

public class EsTransactionList {
    private String blockHash;
    private String blockNumber;
    private String confirmations;
    private String contractAddress;
    private String cumulativeGasUsed;
    private String from;
    private String gas;
    private String gasPrice;
    private String gasUsed;
    private String hash;
    private String input;
    private String isError;
    private String nonce;
    private String timeStamp;
    /* renamed from: to */
    private String f37to;
    private String transactionIndex;
    private String value;

    public EsTransactionList(String blockNumber, String timeStamp, String hash, String nonce, String blockHash, String transactionIndex, String from, String to, String value, String gas, String gasPrice, String isError, String input, String contractAddress, String cumulativeGasUsed, String gasUsed, String confirmations) {
        this.blockNumber = blockNumber;
        this.timeStamp = timeStamp;
        this.hash = hash;
        this.nonce = nonce;
        this.blockHash = blockHash;
        this.transactionIndex = transactionIndex;
        this.from = from;
        this.f37to = to;
        this.value = value;
        this.gas = gas;
        this.gasPrice = gasPrice;
        this.isError = isError;
        this.input = input;
        this.contractAddress = contractAddress;
        this.cumulativeGasUsed = cumulativeGasUsed;
        this.gasUsed = gasUsed;
        this.confirmations = confirmations;
    }

    public String getblockNumber() {
        return this.blockNumber;
    }

    public void setblockNumber(String blockNumber) {
        this.blockNumber = blockNumber;
    }

    public String gettimeStamp() {
        return this.timeStamp;
    }

    public void settimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

    public String gethash() {
        return this.hash;
    }

    public void sethash(String hash) {
        this.hash = hash;
    }

    public String getnonce() {
        return this.nonce;
    }

    public void setnonce(String nonce) {
        this.nonce = nonce;
    }

    public String getblockHash() {
        return this.blockHash;
    }

    public void setblockHash(String blockHash) {
        this.blockHash = blockHash;
    }

    public String gettransactionIndex() {
        return this.transactionIndex;
    }

    public void settransactionIndex(String transactionIndex) {
        this.transactionIndex = transactionIndex;
    }

    public String getfrom() {
        return this.from;
    }

    public void setfrom(String from) {
        this.from = from;
    }

    public String getto() {
        return this.f37to;
    }

    public void setto(String to) {
        this.f37to = to;
    }

    public String getvalue() {
        return this.value;
    }

    public void setvalue(String value) {
        this.value = value;
    }

    public String getgas() {
        return this.gas;
    }

    public void setgas(String gas) {
        this.gas = gas;
    }

    public String getgasPrice() {
        return this.gasPrice;
    }

    public void setgasPrice(String gasPrice) {
        this.gasPrice = gasPrice;
    }

    public String getisError() {
        return this.isError;
    }

    public void setisError(String isError) {
        this.isError = isError;
    }

    public String getinput() {
        return this.input;
    }

    public void setinput(String input) {
        this.input = input;
    }

    public String getcontractAddress() {
        return this.contractAddress;
    }

    public void setcontractAddress(String contractAddress) {
        this.contractAddress = contractAddress;
    }

    public String getcumulativeGasUsed() {
        return this.cumulativeGasUsed;
    }

    public void setcumulativeGasUsed(String cumulativeGasUsed) {
        this.cumulativeGasUsed = cumulativeGasUsed;
    }

    public String getgasUsed() {
        return this.gasUsed;
    }

    public void setgasUsed(String gasUsed) {
        this.gasUsed = gasUsed;
    }

    public String getconfirmations() {
        return this.confirmations;
    }

    public void setconfirmations(String confirmations) {
        this.confirmations = confirmations;
    }
}
