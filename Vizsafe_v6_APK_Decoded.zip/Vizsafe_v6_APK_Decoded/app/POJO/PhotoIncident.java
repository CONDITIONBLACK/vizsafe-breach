package com.vizsafe.app.POJO;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class PhotoIncident extends Incident {
    public PhotoIncident(String type, String path) {
        setType(type);
        setPath(path);
    }

    public void setPath(String path) {
        this.path = path;
        this.base64Data = getBase64DatafromFile(path);
    }

    public Bitmap getBitmap() throws FileNotFoundException {
        return getBitmap(320, 240);
    }

    public Bitmap getBitmap(int width, int height) throws FileNotFoundException {
        float rotation = 0.0f;
        try {
            switch (new ExifInterface(getPath()).getAttributeInt("Orientation", -1)) {
                case 3:
                    rotation = 180.0f;
                    break;
                case 6:
                    rotation = 90.0f;
                    break;
                case 8:
                    rotation = 270.0f;
                    break;
            }
            Bitmap bitmap = Bitmap.createScaledBitmap(BitmapFactory.decodeStream(new FileInputStream(getPath())), width, height, true);
            Matrix matrix = new Matrix();
            matrix.postRotate(rotation);
            return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
        } catch (IOException e) {
            throw new FileNotFoundException(e.getMessage());
        }
    }
}
