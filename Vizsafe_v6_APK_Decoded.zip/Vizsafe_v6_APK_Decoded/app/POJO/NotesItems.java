package com.vizsafe.app.POJO;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class NotesItems implements Parcelable {
    public static final Creator<NotesItems> CREATOR = new C03961();
    public final String description;
    public final String incidentID;
    public final String noteuuid;
    public final String uploadedBy;
    public final long uploadedDate;

    /* renamed from: com.vizsafe.app.POJO.NotesItems$1 */
    static class C03961 implements Creator<NotesItems> {
        C03961() {
        }

        public NotesItems[] newArray(int size) {
            return new NotesItems[size];
        }

        public NotesItems createFromParcel(Parcel source) {
            return new NotesItems(source);
        }
    }

    public NotesItems(String uploadedBy, String description, long uploadedDate, String incidentID, String noteuuid) {
        this.uploadedBy = uploadedBy;
        this.description = description;
        this.uploadedDate = uploadedDate;
        this.incidentID = incidentID;
        this.noteuuid = noteuuid;
    }

    public NotesItems(Parcel p) {
        this.uploadedBy = p.readString();
        this.description = p.readString();
        this.uploadedDate = p.readLong();
        this.incidentID = p.readString();
        this.noteuuid = p.readString();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.uploadedBy);
        dest.writeString(this.description);
        dest.writeLong(this.uploadedDate);
        dest.writeString(this.incidentID);
        dest.writeString(this.noteuuid);
    }
}
