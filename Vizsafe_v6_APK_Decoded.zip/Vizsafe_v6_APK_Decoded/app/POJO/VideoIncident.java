package com.vizsafe.app.POJO;

import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.media.ThumbnailUtils;
import android.util.Base64;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;

public class VideoIncident extends Incident {
    public String still;

    public VideoIncident(String type, String path) {
        setType(type);
        setPath(path);
    }

    public void setPath(String path) {
        super.setPath(path);
        setStill(path);
    }

    private void setStill(String path) {
        Bitmap bitmap = ThumbnailUtils.createVideoThumbnail(path, 2);
        ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
        bitmap.compress(CompressFormat.JPEG, 40, byteStream);
        this.still = Base64.encodeToString(byteStream.toByteArray(), 2);
    }

    public Bitmap getBitmap() throws FileNotFoundException {
        return ThumbnailUtils.createVideoThumbnail(getPath(), 1);
    }
}
