package com.vizsafe.app.POJO;

import java.util.ArrayList;

public class MicelloMapsListItem {
    private int DrawingId;
    private ArrayList<Integer> DrawingIdList;
    private ArrayList<Integer> LevelId;
    private int mapId;

    public MicelloMapsListItem(int mapId, int DrawingId, ArrayList<Integer> LevelId) {
        this.mapId = mapId;
        this.DrawingId = DrawingId;
        this.LevelId = LevelId;
    }

    public MicelloMapsListItem(int DrawingId, ArrayList<Integer> LevelId) {
        this.DrawingId = DrawingId;
        this.LevelId = LevelId;
    }

    public int getMapId() {
        return this.mapId;
    }

    public void setMapId(int mapId) {
        this.mapId = mapId;
    }

    public int getDrawingId() {
        return this.DrawingId;
    }

    public void setDrawingId(int DrawingId) {
        this.DrawingId = DrawingId;
    }

    public ArrayList<Integer> getDrawingIdList() {
        return this.DrawingIdList;
    }

    public void setDrawingIdList(ArrayList<Integer> DrawingIdList) {
        this.DrawingIdList = DrawingIdList;
    }

    public ArrayList<Integer> getLevelId() {
        return this.LevelId;
    }

    public void setLevelId(ArrayList<Integer> LevelId) {
        this.LevelId = LevelId;
    }
}
