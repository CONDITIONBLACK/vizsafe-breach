package com.vizsafe.app.POJO;

import android.graphics.Bitmap;
import android.util.Base64;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;

public class Incident implements Serializable {
    public String base64Data;
    public String channels;
    private ArrayList<Channel> channelsArray = new ArrayList();
    public String description;
    int flags = 10;
    public String latitude;
    public String longitude;
    protected String path;
    public String timestamp;
    public String type;

    public void setType(String type) {
        this.type = Base64.encodeToString(type.getBytes(), this.flags);
    }

    public Bitmap getBitmap() throws FileNotFoundException {
        return null;
    }

    public String getType() {
        return new String(Base64.decode(this.type, this.flags));
    }

    public void setLongitude(float longitude) {
        this.longitude = Base64.encodeToString(Float.toString(longitude).getBytes(), 10);
    }

    public float getLongitude() {
        return Float.parseFloat(new String(Base64.decode(this.longitude, this.flags)));
    }

    public void setLatitude(float val) {
        this.latitude = Base64.encodeToString(Float.toString(val).getBytes(), 10);
    }

    public float getLatitude() {
        return Float.parseFloat(new String(Base64.decode(this.latitude, this.flags)));
    }

    public void setDescription(String val) {
        this.description = Base64.encodeToString(val.getBytes(), this.flags);
    }

    public String getDescription() {
        return new String(Base64.decode(this.description, this.flags));
    }

    public void setChannels(ArrayList<Channel> channels) {
        this.channelsArray = channels;
        this.channels = Base64.encodeToString(getChannelsString(channels).getBytes(), 10);
    }

    public ArrayList<Channel> getChannels() {
        return this.channelsArray;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = Base64.encodeToString(Long.toString(timestamp).getBytes(), 10);
    }

    public long getTimestamp() {
        return Long.parseLong(new String(Base64.decode(this.timestamp, this.flags)));
    }

    public void setPath(String path) {
        this.path = path;
        this.base64Data = getBase64DatafromFile(path);
    }

    public String getPath() {
        return this.path;
    }

    protected String getChannelsString(ArrayList<Channel> channels) {
        StringBuffer buffer = new StringBuffer();
        for (int i = 0; i < channels.size(); i++) {
            if (i > 0) {
                buffer.append(", ");
            }
            buffer.append(((Channel) channels.get(i)).uuid);
        }
        return buffer.toString();
    }

    protected String getBase64DatafromFile(String filePath) {
        String ret = "";
        try {
            File queryImg = new File(filePath);
            byte[] imgData = new byte[((int) queryImg.length())];
            new FileInputStream(queryImg).read(imgData);
            return Base64.encodeToString(imgData, 2);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return ret;
        } catch (IOException e2) {
            e2.printStackTrace();
            return ret;
        }
    }

    public static Incident create(String type, String path) {
        if (type.equals("video")) {
            return new VideoIncident(type, path);
        }
        return new PhotoIncident(type, path);
    }
}
