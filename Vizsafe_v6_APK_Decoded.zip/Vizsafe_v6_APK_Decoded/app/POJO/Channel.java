package com.vizsafe.app.POJO;

import java.io.Serializable;

public class Channel implements Serializable {
    public String channelPicture;
    public String description;
    public String name;
    public String owner;
    public boolean selected;
    public String uuid;
    public String vizsafe;

    public String toString() {
        return this.name;
    }
}
