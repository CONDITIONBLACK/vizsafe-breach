package com.vizsafe.app.POJO;

public class GeofencesListItems {
    private String geofenceLatitude;
    private String geofenceLocationLevel;
    private String geofenceLongitude;
    private String geofenceName;
    private String geofenceUuid;

    public GeofencesListItems(String geofenceName, String geofenceUuid, String geofenceLocationLevel, String geofenceLatitude, String geofenceLongitude) {
        this.geofenceName = geofenceName;
        this.geofenceUuid = geofenceUuid;
        this.geofenceLocationLevel = geofenceLocationLevel;
        this.geofenceLatitude = geofenceLatitude;
        this.geofenceLongitude = geofenceLongitude;
    }

    public String getGeofenceUuid() {
        return this.geofenceUuid;
    }

    public void setGeofenceUuid(String geofenceUuid) {
        this.geofenceUuid = geofenceUuid;
    }

    public String getGeofenceLocationLevel() {
        return this.geofenceLocationLevel;
    }

    public void setGeofenceLocationLevel(String geofenceLocationLevel) {
        this.geofenceLocationLevel = geofenceLocationLevel;
    }

    public String getGeofenceLatitude() {
        return this.geofenceLatitude;
    }

    public void setGeofenceLatitude(String geofenceLatitude) {
        this.geofenceLatitude = geofenceLatitude;
    }

    public String getGeofenceLongitude() {
        return this.geofenceLongitude;
    }

    public void setGeofenceLongitude(String geofenceLongitude) {
        this.geofenceLongitude = geofenceLongitude;
    }

    public String getGeofenceName() {
        return this.geofenceName;
    }

    public void setGeofenceName(String geofenceName) {
        this.geofenceName = geofenceName;
    }
}
