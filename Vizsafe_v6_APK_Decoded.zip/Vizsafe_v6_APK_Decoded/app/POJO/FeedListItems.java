package com.vizsafe.app.POJO;

import java.util.ArrayList;

public class FeedListItems {
    private int communityid;
    private int drawingid;
    private String feedAbuseOrNot;
    private ArrayList<ChannelsListItem> feedChannels;
    private String feedDetail;
    private String feedIcon;
    private String feedLatitude;
    private String feedLongitude;
    private ArrayList<NotesItems> feedNotes;
    private String feedPostedBy;
    private int feedRatings;
    private boolean feedRatingsByMe;
    private String feedType;
    private String feedUploadedByUuid;
    private String feedUploadedTime;
    private String incidentClearedBy;
    private String incidentClearedTimeStamp;
    private String incidentState;
    private int levelid;
    private String severityLevel;

    public FeedListItems(String feedType, String feedIcon, String feedDetail, String feedPostedBy, String feedUploadedTime, String feedUploadedByUuid, ArrayList<ChannelsListItem> feedChannels, String feedLatitude, String feedLongitude, String feedAbuseOrNot, int feedRatings, boolean feedRatingsByMe, String incidentState, String incidentClearedBy, String incidentClearedTimeStamp, ArrayList<NotesItems> feedNotes, int communityid, int drawingid, int levelid, String severityLevel) {
        this.feedType = feedType;
        this.feedIcon = feedIcon;
        this.feedDetail = feedDetail;
        this.feedPostedBy = feedPostedBy;
        this.feedUploadedTime = feedUploadedTime;
        this.feedUploadedByUuid = feedUploadedByUuid;
        this.feedChannels = feedChannels;
        this.feedLatitude = feedLatitude;
        this.feedLongitude = feedLongitude;
        this.feedAbuseOrNot = feedAbuseOrNot;
        this.feedRatings = feedRatings;
        this.feedRatingsByMe = feedRatingsByMe;
        this.incidentState = incidentState;
        this.incidentClearedBy = incidentClearedBy;
        this.incidentClearedTimeStamp = incidentClearedTimeStamp;
        this.feedNotes = feedNotes;
        this.communityid = communityid;
        this.drawingid = drawingid;
        this.levelid = levelid;
        this.severityLevel = severityLevel;
    }

    public String getSeverityLevel() {
        return this.severityLevel;
    }

    public void setSeverityLevel(String severityLevel) {
        this.severityLevel = severityLevel;
    }

    public String getFeedType() {
        return this.feedType;
    }

    public void setFeedType(String feedType) {
        this.feedType = feedType;
    }

    public int getFeedRatings() {
        return this.feedRatings;
    }

    public void setFeedRatings(int feedRatings) {
        this.feedRatings = feedRatings;
    }

    public int getCommunityId() {
        return this.communityid;
    }

    public void setCommunityId(int communityid) {
        this.communityid = communityid;
    }

    public int getDrawingid() {
        return this.drawingid;
    }

    public void setDrawingid(int drawingid) {
        this.drawingid = drawingid;
    }

    public int getLevelId() {
        return this.levelid;
    }

    public void setLevelId(int levelid) {
        this.levelid = levelid;
    }

    public boolean getIsFeedRatingsByMe() {
        return this.feedRatingsByMe;
    }

    public void setIsFeedRatingsByMe(boolean feedRatingsByMe) {
        this.feedRatingsByMe = feedRatingsByMe;
    }

    public String getFeedAbuseOrNot() {
        return this.feedAbuseOrNot;
    }

    public void setFeedAbuseOrNot(String feedAbuseOrNot) {
        this.feedAbuseOrNot = feedAbuseOrNot;
    }

    public String getFeedLatitude() {
        return this.feedLatitude;
    }

    public void setFeedLatitude(String feedLatitude) {
        this.feedLatitude = feedLatitude;
    }

    public String getFeedLongitude() {
        return this.feedLongitude;
    }

    public void setFeedLongitude(String feedLongitude) {
        this.feedLongitude = feedLongitude;
    }

    public String getFeedUploadedByUuid() {
        return this.feedUploadedByUuid;
    }

    public void setFeedUploadedByUuid(String feedUploadedByUuid) {
        this.feedUploadedByUuid = feedUploadedByUuid;
    }

    public String getFeedDetail() {
        return this.feedDetail;
    }

    public void setFeedDetail(String feedDetail) {
        this.feedDetail = feedDetail;
    }

    public String getFeedPostedBy() {
        return this.feedPostedBy;
    }

    public void setFeedPostedBy(String feedPostedBy) {
        this.feedPostedBy = feedPostedBy;
    }

    public String getFeedUploadedTime() {
        return this.feedUploadedTime;
    }

    public void setFeedUploadedTime(String feedUploadedTime) {
        this.feedUploadedTime = feedUploadedTime;
    }

    public ArrayList<ChannelsListItem> getFeedChannels() {
        return this.feedChannels;
    }

    public void setFeedChannels(ArrayList<ChannelsListItem> feedChannels) {
        this.feedChannels = feedChannels;
    }

    public String getFeedIcon() {
        return this.feedIcon;
    }

    public void setFeedIcon(String feedIcon) {
        this.feedIcon = feedIcon;
    }

    public String getIncidentState() {
        return this.incidentState;
    }

    public void setIncidentState(String incidentState) {
        this.incidentState = incidentState;
    }

    public String getIncidentClearedBy() {
        return this.incidentClearedBy;
    }

    public void setIncidentClearedBy(String incidentClearedBy) {
        this.incidentClearedBy = incidentClearedBy;
    }

    public String getIncidentClearedTimeStamp() {
        return this.incidentClearedTimeStamp;
    }

    public void setIncidentClearedTimeStamp(String incidentClearedTimeStamp) {
        this.incidentClearedTimeStamp = incidentClearedTimeStamp;
    }

    public ArrayList<NotesItems> getFeedNotes() {
        return this.feedNotes;
    }

    public void setFeedNotes(ArrayList<NotesItems> feedNotes) {
        this.feedNotes = feedNotes;
    }
}
