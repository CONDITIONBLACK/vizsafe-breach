package com.vizsafe.app.POJO;

public class ChannelsListItem implements Item {
    public final String image;
    public final boolean isMassaged;
    public final boolean isPrivate;
    public final boolean isSecret;
    public final boolean isVizsafe;
    public final String owner;
    public final String subtitle;
    public final String title;
    public final String uuid;

    public ChannelsListItem(String title, String subtitle, String image, String uuid, String owner, boolean isVizsafe, boolean isPrivate, boolean isSecret, boolean isMassaged) {
        this.title = title;
        this.subtitle = subtitle;
        this.image = image;
        this.uuid = uuid;
        this.owner = owner;
        this.isVizsafe = isVizsafe;
        this.isPrivate = isPrivate;
        this.isSecret = isSecret;
        this.isMassaged = isMassaged;
    }

    public boolean isSection() {
        return false;
    }
}
