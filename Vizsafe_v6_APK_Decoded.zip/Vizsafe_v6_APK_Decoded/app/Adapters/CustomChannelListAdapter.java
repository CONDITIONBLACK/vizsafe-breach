package com.vizsafe.app.Adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.Channels.ChannelDetailScreen;
import com.vizsafe.app.ImageUtil.ImageLoader;
import com.vizsafe.app.POJO.ChannelsListItem;
import com.vizsafe.app.POJO.Item;
import com.vizsafe.app.POJO.SectionItem;
import java.util.ArrayList;

public class CustomChannelListAdapter extends ArrayAdapter<Item> {
    String channelPictureUrl;
    private final Context context;
    private final ArrayList<ChannelsListItem> favouriteChannelItems;
    public ImageLoader imageLoader;
    private final ArrayList<Item> items;
    boolean memberShipStatus = false;
    /* renamed from: vi */
    private final LayoutInflater f23vi;

    public CustomChannelListAdapter(Context context, ArrayList<Item> items, ArrayList<ChannelsListItem> favouriteChannelItems) {
        super(context, 0, items);
        this.context = context;
        this.items = items;
        this.favouriteChannelItems = favouriteChannelItems;
        this.f23vi = (LayoutInflater) context.getSystemService("layout_inflater");
        this.imageLoader = new ImageLoader(context.getApplicationContext());
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;
        Item i = (Item) this.items.get(position);
        if (i == null) {
            return v;
        }
        if (i.isSection()) {
            SectionItem si = (SectionItem) i;
            v = this.f23vi.inflate(C0421R.layout.channel_list_section_raw, null);
            v.setOnClickListener(null);
            v.setOnLongClickListener(null);
            v.setLongClickable(false);
            ((TextView) v.findViewById(C0421R.C0419id.list_item_section_text)).setText(si.getTitle());
            return v;
        }
        final ChannelsListItem ei = (ChannelsListItem) i;
        v = this.f23vi.inflate(C0421R.layout.channel_list_item_raw, null);
        TextView title = (TextView) v.findViewById(C0421R.C0419id.list_item_entry_title);
        TextView subtitle = (TextView) v.findViewById(C0421R.C0419id.list_item_entry_summary);
        ImageView image = (ImageView) v.findViewById(C0421R.C0419id.channel_icon);
        ImageView info = (ImageView) v.findViewById(C0421R.C0419id.info_btn);
        ImageView checkMark = (ImageView) v.findViewById(C0421R.C0419id.check_mark);
        if (title != null) {
            title.setText(ei.title);
        }
        if (subtitle != null) {
            subtitle.setText(ei.subtitle);
        }
        Glide.with(this.context).load(ei.image).placeholder((int) C0421R.mipmap.ic_launcher).into(image);
        for (int k = 0; k < this.favouriteChannelItems.size(); k++) {
            if (ei.uuid.equals(((ChannelsListItem) this.favouriteChannelItems.get(k)).uuid)) {
                checkMark.setVisibility(0);
                break;
            }
            checkMark.setVisibility(4);
        }
        info.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                Intent channelInfo = new Intent(CustomChannelListAdapter.this.context, ChannelDetailScreen.class);
                channelInfo.putExtra("channel_name", ei.title);
                channelInfo.putExtra("channel_description", ei.subtitle);
                int i = 0;
                while (i < CustomChannelListAdapter.this.favouriteChannelItems.size()) {
                    if (ei.uuid.equals(((ChannelsListItem) CustomChannelListAdapter.this.favouriteChannelItems.get(i)).uuid)) {
                        CustomChannelListAdapter.this.memberShipStatus = true;
                        break;
                    } else {
                        CustomChannelListAdapter.this.memberShipStatus = false;
                        i++;
                    }
                }
                channelInfo.putExtra("channel_member", CustomChannelListAdapter.this.memberShipStatus);
                CustomChannelListAdapter.this.context.startActivity(channelInfo);
            }
        });
        return v;
    }
}
