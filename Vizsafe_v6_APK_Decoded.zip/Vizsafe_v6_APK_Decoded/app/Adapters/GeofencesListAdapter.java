package com.vizsafe.app.Adapters;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.p002v7.widget.RecyclerView.Adapter;
import android.support.p002v7.widget.RecyclerView.ViewHolder;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.vizsafe.app.APIClientMethods.DeleteGeoFenceApi;
import com.vizsafe.app.APIClientMethods.DeleteGeoFenceApi.ResponseDeleteGeoFenceApi;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.GeoFence.AddGeofencesScreen;
import com.vizsafe.app.GeoFence.GeofencesScreen;
import com.vizsafe.app.POJO.GeofencesListItems;
import com.vizsafe.app.Utils.PreferenceHandler;
import dmax.dialog.SpotsDialog;
import java.util.ArrayList;
import java.util.List;
import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class GeofencesListAdapter extends Adapter<MyViewHolder> {
    private ArrayList<GeofencesListItems> arraylist;
    String authenticationString;
    Context context;
    String email;
    String geoFencesUuid = "";
    List<GeofencesListItems> mGeofencesListItems;
    AlertDialog mTransparentProgressDialog;
    String password;

    /* renamed from: com.vizsafe.app.Adapters.GeofencesListAdapter$3 */
    class C02033 implements Callback<ResponseDeleteGeoFenceApi> {
        C02033() {
        }

        public void success(ResponseDeleteGeoFenceApi responseDeleteGeoFenceApi, Response response) {
            GeofencesListAdapter.this.mTransparentProgressDialog.dismiss();
            GeofencesListAdapter.this.loadData();
        }

        public void failure(RetrofitError error) {
            GeofencesListAdapter.this.mTransparentProgressDialog.dismiss();
            error.printStackTrace();
            GeofencesListAdapter.this.loadData();
        }
    }

    public class MyViewHolder extends ViewHolder {
        ImageView deleteBtn;
        TextView geofencesName;

        public MyViewHolder(View view) {
            super(view);
            this.deleteBtn = (ImageView) view.findViewById(C0421R.C0419id.delete_btn);
            this.geofencesName = (TextView) view.findViewById(C0421R.C0419id.geofences_name);
        }
    }

    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(parent.getContext()).inflate(C0421R.layout.geofences_list_raw, parent, false));
    }

    public GeofencesListAdapter(Context mContext, List<GeofencesListItems> mGeofencesListItems) {
        this.mGeofencesListItems = mGeofencesListItems;
        this.context = mContext;
        this.arraylist = new ArrayList();
        this.arraylist.addAll(mGeofencesListItems);
        this.mTransparentProgressDialog = new SpotsDialog(this.context, this.context.getResources().getString(C0421R.string.please_wait_loading));
        this.mTransparentProgressDialog.setCanceledOnTouchOutside(false);
        this.mTransparentProgressDialog.setCancelable(false);
        this.email = PreferenceHandler.getInstance(this.context).getUserName();
        this.password = PreferenceHandler.getInstance(this.context).getPassword();
        this.authenticationString = "Basic " + Base64.encodeToString((this.email + ":" + this.password).getBytes(), 2);
    }

    public void onBindViewHolder(MyViewHolder holder, final int position) {
        holder.geofencesName.setText(((GeofencesListItems) this.mGeofencesListItems.get(position)).getGeofenceName());
        holder.geofencesName.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                GeofencesListItems myItem = (GeofencesListItems) GeofencesListAdapter.this.mGeofencesListItems.get(position);
                Intent goToAddGeoFences = new Intent(GeofencesListAdapter.this.context, AddGeofencesScreen.class);
                goToAddGeoFences.putExtra("geoFence_uuid", myItem.getGeofenceUuid());
                goToAddGeoFences.putExtra("geoFence_latitude", myItem.getGeofenceLatitude());
                goToAddGeoFences.putExtra("geoFence_longitude", myItem.getGeofenceLongitude());
                goToAddGeoFences.putExtra("geoFence_name", myItem.getGeofenceName());
                GeofencesListAdapter.this.context.startActivity(goToAddGeoFences);
            }
        });
        holder.deleteBtn.setOnClickListener(new OnClickListener() {

            /* renamed from: com.vizsafe.app.Adapters.GeofencesListAdapter$2$1 */
            class C02011 implements DialogInterface.OnClickListener {
                C02011() {
                }

                public void onClick(DialogInterface dialog, int id) {
                    GeofencesListItems myItem = (GeofencesListItems) GeofencesListAdapter.this.mGeofencesListItems.get(position);
                    GeofencesListAdapter.this.geoFencesUuid = myItem.getGeofenceUuid();
                    GeofencesListAdapter.this.TaskDeleteGeoFence(GeofencesListAdapter.this.geoFencesUuid);
                    GeofencesListAdapter.this.mGeofencesListItems.remove(position);
                    GeofencesListAdapter.this.notifyItemRemoved(position);
                    GeofencesListAdapter.this.notifyItemRangeChanged(position, GeofencesListAdapter.this.mGeofencesListItems.size());
                }
            }

            public void onClick(View v) {
                new Builder(GeofencesListAdapter.this.context).setMessage(GeofencesListAdapter.this.context.getResources().getString(C0421R.string.title_delete_account)).setCancelable(false).setPositiveButton(GeofencesListAdapter.this.context.getResources().getString(C0421R.string.okTxt), new C02011()).setNegativeButton(GeofencesListAdapter.this.context.getResources().getString(C0421R.string.cancel), null).show();
            }
        });
    }

    public int getItemCount() {
        return this.mGeofencesListItems.size();
    }

    private void TaskDeleteGeoFence(String geoFencesUuid) {
        this.mTransparentProgressDialog.show();
        loadData();
        DeleteGeoFenceApi.getInstance().Callresponse(this.context, this.authenticationString, geoFencesUuid, new C02033());
    }

    public void loadData() {
        if (this.arraylist.size() == 0) {
            GeofencesScreen.upperLine.setVisibility(8);
            GeofencesScreen.lowerLine.setVisibility(8);
        }
        notifyDataSetChanged();
    }
}
