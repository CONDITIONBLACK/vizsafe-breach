package com.vizsafe.app.Adapters;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.DownloadManager;
import android.app.DownloadManager.Request;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.UiThread;
import android.support.p002v7.widget.PopupMenu;
import android.support.p002v7.widget.PopupMenu.OnMenuItemClickListener;
import android.support.p002v7.widget.RecyclerView.Adapter;
import android.support.p002v7.widget.RecyclerView.ViewHolder;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.bumptech.glide.Glide;
import com.vizsafe.app.Adapters.CameraListAdapter.onGoToMapPageListener;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.Feeds.FeedIconScreen;
import com.vizsafe.app.Feeds.LoadMicelloSingleFeed;
import com.vizsafe.app.HomePage.MapsPage.onGoToReportDetailsPageListener;
import com.vizsafe.app.POJO.ChannelsListItem;
import com.vizsafe.app.POJO.FeedListItems;
import com.vizsafe.app.POJO.NotesItems;
import com.vizsafe.app.Utils.CommonMember;
import com.vizsafe.app.Utils.PreferenceHandler;
import com.vizsafe.app.Utils.TimeAgo;
import com.vizsafe.app.Utils.Webservice;
import dmax.dialog.SpotsDialog;
import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import org.apache.http.protocol.HTTP;
import org.json.JSONObject;

public class FeedListAdapter extends Adapter<MyViewHolder> {
    public static boolean DOWNLOAD_IMAGE = false;
    public static ProgressDialog downloadImageDialog = null;
    private ArrayList<FeedListItems> arraylist = new ArrayList();
    private String feedIconUrl;
    String feedUuid;
    private MyViewHolder holder;
    private int imageHeight;
    private int imageWidth;
    private Context mContext;
    FeedListItems mFeedListItem;
    private ArrayList<FeedListItems> mFeedListItems;
    private int mPosition;
    private AlertDialog mTransparentProgressDialog;
    private String shareString;

    private class AsynceTaskDeleteFeed extends AsyncTask<String, String, String> {
        String response;

        private AsynceTaskDeleteFeed() {
            this.response = null;
        }

        /* synthetic */ AsynceTaskDeleteFeed(FeedListAdapter x0, C01911 x1) {
            this();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            FeedListAdapter.this.mTransparentProgressDialog.show();
        }

        protected String doInBackground(String... arg0) {
            String email = PreferenceHandler.getInstance(FeedListAdapter.this.mContext).getUserName();
            String password = PreferenceHandler.getInstance(FeedListAdapter.this.mContext).getPassword();
            try {
                this.response = new Webservice().deleteFeedAction(FeedListAdapter.this.mContext, email, password, arg0[0]);
                return this.response;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        protected void onPostExecute(String result) {
            if (FeedListAdapter.this.mTransparentProgressDialog.isShowing()) {
                FeedListAdapter.this.mTransparentProgressDialog.dismiss();
            }
            if (result != null) {
                Toast.makeText(FeedListAdapter.this.mContext, FeedListAdapter.this.mContext.getResources().getString(C0421R.string.feed_deleted), 0).show();
                FeedListAdapter.this.mFeedListItems.remove(FeedListAdapter.this.mPosition);
                FeedListAdapter.this.notifyItemRemoved(FeedListAdapter.this.mPosition);
                FeedListAdapter.this.notifyItemRangeChanged(FeedListAdapter.this.mPosition, FeedListAdapter.this.mFeedListItems.size());
                return;
            }
            CommonMember.getErrorDialog(FeedListAdapter.this.mContext.getString(C0421R.string.unable_to_delete_feed), FeedListAdapter.this.mContext).show();
        }
    }

    private class AsynceTaskReportAbuse extends AsyncTask<String, String, String> {
        ProgressDialog pDialog;
        JSONObject response;

        private AsynceTaskReportAbuse() {
            this.response = null;
        }

        /* synthetic */ AsynceTaskReportAbuse(FeedListAdapter x0, C01911 x1) {
            this();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            FeedListAdapter.this.mTransparentProgressDialog.show();
        }

        protected String doInBackground(String... arg0) {
            String email = PreferenceHandler.getInstance(FeedListAdapter.this.mContext).getUserName();
            String password = PreferenceHandler.getInstance(FeedListAdapter.this.mContext).getPassword();
            try {
                this.response = new Webservice().reportAbuseAction(FeedListAdapter.this.mContext, email, password, arg0[0]);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        protected void onPostExecute(String result) {
            if (FeedListAdapter.this.mTransparentProgressDialog.isShowing()) {
                FeedListAdapter.this.mTransparentProgressDialog.dismiss();
            }
            FeedListAdapter.this.notifyItemChanged(FeedListAdapter.this.mPosition);
            FeedListAdapter.this.notifyDataSetChanged();
            Toast.makeText(FeedListAdapter.this.mContext, FeedListAdapter.this.mContext.getResources().getString(C0421R.string.abuse_reported), 0).show();
        }
    }

    public class MyViewHolder extends ViewHolder {
        Button deleteBtn;
        LinearLayout feedChannelsImages;
        LinearLayout feedClick;
        TextView feedDetail;
        ImageView feedIcon;
        RelativeLayout feedIconLayout;
        TextView feedPostedBy;
        TextView feedUploadedTime;
        LinearLayout feedheaderTitleLayout;
        ImageView imgPostPin;
        ImageView indoormapBtn;
        ImageView mapBtn;
        ImageView moreOptions;
        ImageView reportAbuseImage;
        ImageView severityBtn;
        ImageView starIcon;
        ImageView videoIcon;
        ImageView warningBtn;

        public MyViewHolder(View rowView) {
            super(rowView);
            this.feedDetail = (TextView) rowView.findViewById(C0421R.C0419id.feed_info);
            this.feedPostedBy = (TextView) rowView.findViewById(C0421R.C0419id.feed_uploaded_by);
            this.feedUploadedTime = (TextView) rowView.findViewById(C0421R.C0419id.feed_upload_time);
            this.feedIconLayout = (RelativeLayout) rowView.findViewById(C0421R.C0419id.feed_icon_layout);
            this.feedIcon = (ImageView) rowView.findViewById(C0421R.C0419id.feed_icon);
            this.reportAbuseImage = (ImageView) rowView.findViewById(C0421R.C0419id.report_abuse);
            this.videoIcon = (ImageView) rowView.findViewById(C0421R.C0419id.videoIcon);
            this.moreOptions = (ImageView) rowView.findViewById(C0421R.C0419id.more_options_feed_list);
            this.feedChannelsImages = (LinearLayout) rowView.findViewById(C0421R.C0419id.feed_channels_images);
            this.feedClick = (LinearLayout) rowView.findViewById(C0421R.C0419id.feed_click_layout);
            this.feedheaderTitleLayout = (LinearLayout) rowView.findViewById(C0421R.C0419id.header_title_layout);
            this.indoormapBtn = (ImageView) rowView.findViewById(C0421R.C0419id.indoor_map_btn);
            this.mapBtn = (ImageView) rowView.findViewById(C0421R.C0419id.map_btn);
            this.warningBtn = (ImageView) rowView.findViewById(C0421R.C0419id.warning_btn);
            this.severityBtn = (ImageView) rowView.findViewById(C0421R.C0419id.severity_image);
            this.imgPostPin = (ImageView) rowView.findViewById(C0421R.C0419id.imgPostPin);
        }
    }

    public FeedListAdapter(Context mContext, ArrayList<FeedListItems> mFeedListItems) {
        this.mFeedListItems = mFeedListItems;
        this.mContext = mContext;
        this.arraylist.addAll(mFeedListItems);
        this.mTransparentProgressDialog = new SpotsDialog(mContext, mContext.getResources().getString(C0421R.string.please_wait_loading));
        this.mTransparentProgressDialog.setCanceledOnTouchOutside(false);
        this.mTransparentProgressDialog.setCancelable(false);
    }

    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(parent.getContext()).inflate(C0421R.layout.feed_list_raw, parent, false));
    }

    public void onBindViewHolder(MyViewHolder holder, int position) {
        final int i;
        this.holder = holder;
        this.mFeedListItem = (FeedListItems) this.mFeedListItems.get(position);
        int mIndoorMapCommunity = this.mFeedListItem.getCommunityId();
        int mIndoorMapdrawingid = this.mFeedListItem.getDrawingid();
        int mIndoorMaplevelid = this.mFeedListItem.getLevelId();
        if (mIndoorMapCommunity == 0 || mIndoorMapdrawingid == 0 || mIndoorMaplevelid == 0) {
            holder.indoormapBtn.setVisibility(8);
        } else {
            holder.indoormapBtn.setVisibility(0);
        }
        String mSeverity = this.mFeedListItem.getSeverityLevel();
        if (mSeverity.equals("0")) {
            holder.severityBtn.setVisibility(8);
        } else {
            holder.severityBtn.setVisibility(0);
            if (mSeverity.equals("1")) {
                holder.severityBtn.setBackgroundResource(C0421R.C0418drawable.severity_s1_off);
            } else if (mSeverity.equals("2")) {
                holder.severityBtn.setBackgroundResource(C0421R.C0418drawable.severity_s2_off);
            } else {
                holder.severityBtn.setBackgroundResource(C0421R.C0418drawable.severity_s3_off);
            }
        }
        holder.feedDetail.setText(this.mFeedListItem.getFeedDetail());
        if (this.mFeedListItem.getFeedPostedBy() == null) {
            holder.feedPostedBy.setText(this.mContext.getResources().getString(C0421R.string.report_by_anonymous));
        } else if (this.mFeedListItem.getFeedPostedBy().trim().equals("null")) {
            holder.feedPostedBy.setText(this.mContext.getResources().getString(C0421R.string.unknown_report));
        } else {
            holder.feedPostedBy.setText(this.mContext.getResources().getString(C0421R.string.report_by) + " " + this.mFeedListItem.getFeedPostedBy());
        }
        try {
            holder.feedUploadedTime.setText(new TimeAgo().timeAgo(new Date(Long.parseLong(this.mFeedListItem.getFeedUploadedTime())).getTime()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (isTablet(this.mContext)) {
            this.imageHeight = 200;
            this.imageWidth = 200;
        } else {
            this.imageHeight = 200;
            this.imageWidth = 200;
        }
        this.feedIconUrl = CommonMember.getURL(this.mContext) + "/incident/";
        if (this.mFeedListItem.getFeedType().equalsIgnoreCase("photo")) {
            Glide.with(this.mContext).load(this.feedIconUrl + this.mFeedListItem.getFeedIcon() + "/resize?height=" + this.imageHeight + "&width=" + this.imageWidth).error((int) C0421R.C0418drawable.loading_image).placeholder((int) C0421R.C0418drawable.loading_image).into(holder.feedIcon);
            holder.videoIcon.setVisibility(8);
        } else {
            Glide.with(this.mContext).load(this.feedIconUrl + this.mFeedListItem.getFeedIcon() + "/still?height=" + this.imageHeight + "&width=" + this.imageWidth).error((int) C0421R.C0418drawable.loading_image).into(holder.feedIcon);
            holder.videoIcon.setVisibility(0);
        }
        holder.warningBtn.setVisibility(8);
        if (Boolean.parseBoolean(this.mFeedListItem.getFeedAbuseOrNot())) {
            holder.reportAbuseImage.setVisibility(0);
            holder.warningBtn.setVisibility(8);
        } else {
            holder.reportAbuseImage.setVisibility(8);
            holder.warningBtn.setVisibility(8);
        }
        String incidentState = this.mFeedListItem.getIncidentState();
        if (incidentState == null) {
            this.mFeedListItem.setIncidentState("open");
            incidentState = this.mFeedListItem.getIncidentState();
        }
        if (incidentState.equalsIgnoreCase("open")) {
            holder.imgPostPin.setImageResource(C0421R.C0418drawable.red_marker);
            holder.imgPostPin.setClickable(true);
        } else if (incidentState.equalsIgnoreCase("pending")) {
            holder.imgPostPin.setImageResource(C0421R.C0418drawable.yellow_marker);
            holder.imgPostPin.setClickable(true);
        } else {
            holder.imgPostPin.setImageResource(C0421R.C0418drawable.green_marker);
            holder.imgPostPin.setClickable(false);
        }
        holder.feedChannelsImages.removeAllViews();
        for (int i2 = 0; i2 < ((FeedListItems) this.mFeedListItems.get(position)).getFeedChannels().size(); i2++) {
            LayoutParams layoutParams = new LayoutParams(dpToPx(40), dpToPx(40));
            ImageView imageView = new ImageView(this.mContext);
            layoutParams.setMargins(0, 0, 10, 0);
            imageView.setLayoutParams(layoutParams);
            imageView.setId(i2);
            Glide.with(this.mContext).load(((ChannelsListItem) ((FeedListItems) this.mFeedListItems.get(position)).getFeedChannels().get(i2)).image).error((int) C0421R.C0418drawable.loading_image).into(imageView);
            holder.feedChannelsImages.addView(imageView);
            final int finalI = i2;
            i = position;
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View v) {
                    Toast.makeText(FeedListAdapter.this.mContext, ((ChannelsListItem) ((FeedListItems) FeedListAdapter.this.mFeedListItems.get(i)).getFeedChannels().get(finalI)).title, 0).show();
                }
            });
        }
        i = position;
        holder.feedheaderTitleLayout.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                FeedListAdapter.this.GotoReportDeatilsPage(i);
            }
        });
        i = position;
        holder.feedClick.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                FeedListAdapter.this.GotoReportDeatilsPage(i);
            }
        });
        i = position;
        holder.feedIcon.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                FeedListAdapter.this.mFeedListItem = (FeedListItems) FeedListAdapter.this.mFeedListItems.get(i);
                Intent goToFeedIconScreen = new Intent(FeedListAdapter.this.mContext, FeedIconScreen.class);
                goToFeedIconScreen.putExtra("feed_type", FeedListAdapter.this.mFeedListItem.getFeedType());
                goToFeedIconScreen.putExtra("feed_icon", FeedListAdapter.this.mFeedListItem.getFeedIcon());
                FeedListAdapter.this.mContext.startActivity(goToFeedIconScreen);
            }
        });
        i = position;
        holder.indoormapBtn.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                FeedListAdapter.this.mFeedListItem = (FeedListItems) FeedListAdapter.this.mFeedListItems.get(i);
                int mIndoorMapCommunity = FeedListAdapter.this.mFeedListItem.getCommunityId();
                int mIndoorMapdrawingid = FeedListAdapter.this.mFeedListItem.getDrawingid();
                int mIndoorMaplevelid = FeedListAdapter.this.mFeedListItem.getLevelId();
                if (mIndoorMapCommunity != 0 && mIndoorMapdrawingid != 0 && mIndoorMaplevelid != 0) {
                    Intent goToFeedIconScreen = new Intent(FeedListAdapter.this.mContext, LoadMicelloSingleFeed.class);
                    goToFeedIconScreen.putExtra("mIndoorMapCommunity", mIndoorMapCommunity);
                    goToFeedIconScreen.putExtra("mIndoorMapdrawingid", mIndoorMapdrawingid);
                    goToFeedIconScreen.putExtra("mIndoorMaplevelid", mIndoorMaplevelid);
                    goToFeedIconScreen.putExtra("feed_description", FeedListAdapter.this.mFeedListItem.getFeedDetail());
                    goToFeedIconScreen.putExtra("feed_latitude", FeedListAdapter.this.mFeedListItem.getFeedLatitude());
                    goToFeedIconScreen.putExtra("feed_longitude", FeedListAdapter.this.mFeedListItem.getFeedLongitude());
                    goToFeedIconScreen.putExtra("feed_type", FeedListAdapter.this.mFeedListItem.getFeedType());
                    goToFeedIconScreen.putExtra("feedUUID", FeedListAdapter.this.mFeedListItem.getFeedIcon());
                    goToFeedIconScreen.putExtra("feedState", FeedListAdapter.this.mFeedListItem.getIncidentState());
                    goToFeedIconScreen.setFlags(1073741824);
                    FeedListAdapter.this.mContext.startActivity(goToFeedIconScreen);
                }
            }
        });
        i = position;
        holder.mapBtn.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                FeedListAdapter.this.mFeedListItem = (FeedListItems) FeedListAdapter.this.mFeedListItems.get(i);
                ((onGoToMapPageListener) FeedListAdapter.this.mContext).onGoToMapPage(FeedListAdapter.this.mFeedListItem.getFeedLatitude(), FeedListAdapter.this.mFeedListItem.getFeedLongitude());
            }
        });
        i = position;
        holder.moreOptions.setOnClickListener(new OnClickListener() {

            /* renamed from: com.vizsafe.app.Adapters.FeedListAdapter$7$1 */
            class C01971 implements OnMenuItemClickListener {
                C01971() {
                }

                public boolean onMenuItemClick(MenuItem item) {
                    switch (item.getItemId()) {
                        case C0421R.C0419id.details_fromfeed /*2131690093*/:
                            FeedListAdapter.this.GotoReportDeatilsPage(i);
                            return true;
                        case C0421R.C0419id.share_fromfeed /*2131690094*/:
                            FeedListAdapter.this.DoShare(FeedListAdapter.this.feedUuid);
                            return true;
                        case C0421R.C0419id.download_fromfeed /*2131690095*/:
                            FeedListAdapter.this.DoDownload(FeedListAdapter.this.feedUuid);
                            return true;
                        case C0421R.C0419id.delete_fromfeed /*2131690096*/:
                            FeedListAdapter.this.mPosition = i;
                            FeedListAdapter.this.DoDelete(FeedListAdapter.this.feedUuid);
                            return true;
                        default:
                            return false;
                    }
                }
            }

            public void onClick(View view) {
                FeedListAdapter.this.mFeedListItem = (FeedListItems) FeedListAdapter.this.mFeedListItems.get(i);
                FeedListAdapter.this.feedUuid = FeedListAdapter.this.mFeedListItem.getFeedIcon();
                PopupMenu popup = new PopupMenu(FeedListAdapter.this.mContext, view);
                popup.inflate(C0421R.C0420menu.options_menu_feed_list);
                MenuItem deleteBtn = popup.getMenu().findItem(C0421R.C0419id.delete_fromfeed);
                if (FeedListAdapter.this.mFeedListItem.getFeedUploadedByUuid() == null || !FeedListAdapter.this.mFeedListItem.getFeedUploadedByUuid().equals(PreferenceHandler.getInstance(FeedListAdapter.this.mContext).getUserUUID())) {
                    deleteBtn.setVisible(false);
                } else {
                    deleteBtn.setVisible(true);
                }
                popup.setOnMenuItemClickListener(new C01971());
                popup.show();
            }
        });
    }

    private void GotoReportDeatilsPage(int position) {
        this.mFeedListItem = (FeedListItems) this.mFeedListItems.get(position);
        if (this.mFeedListItem != null) {
            String uploadedByString = "";
            if (this.mFeedListItem.getFeedPostedBy() != null) {
                uploadedByString = this.mContext.getResources().getString(C0421R.string.report_by) + " " + this.mFeedListItem.getFeedPostedBy();
            } else {
                uploadedByString = this.mContext.getResources().getString(C0421R.string.report_by_anonymous);
            }
            String feedInfoString = this.mFeedListItem.getFeedDetail();
            String feedSeverityString = this.mFeedListItem.getSeverityLevel();
            String feedTimeStampString = this.mFeedListItem.getFeedUploadedTime();
            String feedIconString = this.mFeedListItem.getFeedIcon();
            String feedAbuseOrNotString = this.mFeedListItem.getFeedAbuseOrNot();
            String feedLatitudeString = this.mFeedListItem.getFeedLatitude();
            String feedLongitudeString = this.mFeedListItem.getFeedLongitude();
            String feedType = this.mFeedListItem.getFeedType();
            String incidentState = this.mFeedListItem.getIncidentState();
            String incidentClearedBy = this.mFeedListItem.getIncidentClearedBy();
            String incidentClearedTimeStamp = this.mFeedListItem.getIncidentClearedTimeStamp();
            String feedPostedBy = this.mFeedListItem.getFeedPostedBy();
            int CommunityId = this.mFeedListItem.getCommunityId();
            int Drawingid = this.mFeedListItem.getDrawingid();
            int LevelId = this.mFeedListItem.getLevelId();
            int channelSize = this.mFeedListItem.getFeedChannels().size();
            ArrayList<NotesItems> notesItem = this.mFeedListItem.getFeedNotes();
            ArrayList<ChannelsListItem> mChannelsList = this.mFeedListItem.getFeedChannels();
            boolean isSecretChannel = false;
            int i = 0;
            while (i < channelSize) {
                if (((ChannelsListItem) this.mFeedListItem.getFeedChannels().get(i)).isSecret) {
                    isSecretChannel = true;
                    break;
                } else {
                    isSecretChannel = false;
                    i++;
                }
            }
            boolean isPrivateChannel = false;
            i = 0;
            while (i < channelSize) {
                if (((ChannelsListItem) this.mFeedListItem.getFeedChannels().get(i)).isPrivate) {
                    isPrivateChannel = true;
                    break;
                } else {
                    isPrivateChannel = false;
                    i++;
                }
            }
            int feedRatings = this.mFeedListItem.getFeedRatings();
            boolean feedRatingsByMe = this.mFeedListItem.getIsFeedRatingsByMe();
            Bundle markerInfoDetail = new Bundle();
            markerInfoDetail.putString("feed_uploadedBy", uploadedByString);
            markerInfoDetail.putString("feed_description", feedInfoString);
            markerInfoDetail.putString("feed_timestamp", feedTimeStampString);
            markerInfoDetail.putString("feed_imageUrl", feedIconString);
            markerInfoDetail.putString("feed_abuse", feedAbuseOrNotString);
            markerInfoDetail.putString("feed_latitude", feedLatitudeString);
            markerInfoDetail.putString("feed_longitude", feedLongitudeString);
            markerInfoDetail.putInt("feed_ratings", feedRatings);
            markerInfoDetail.putBoolean("feed_rating_by_me", feedRatingsByMe);
            markerInfoDetail.putString("feed_type", feedType);
            markerInfoDetail.putString("incident_state", incidentState);
            markerInfoDetail.putString("incident_cleared_by", incidentClearedBy);
            markerInfoDetail.putString("incident_cleared_timestamp", incidentClearedTimeStamp);
            markerInfoDetail.putString("feed_posted_by", feedPostedBy);
            markerInfoDetail.putBoolean("is_channel_secret", isSecretChannel);
            markerInfoDetail.putBoolean("is_channel_private", isPrivateChannel);
            markerInfoDetail.putSerializable("notes_data_list", notesItem);
            markerInfoDetail.putSerializable("channel_list", mChannelsList);
            markerInfoDetail.putString("from", "Feed");
            markerInfoDetail.putInt("CommunityId", CommunityId);
            markerInfoDetail.putInt("Drawingid", Drawingid);
            markerInfoDetail.putInt("LevelId", LevelId);
            markerInfoDetail.putString("Context", this.mContext.toString());
            markerInfoDetail.putString("severity", feedSeverityString);
            ((onGoToReportDetailsPageListener) this.mContext).onGoToReportDetailsPage(markerInfoDetail);
        }
    }

    public int getItemCount() {
        return this.mFeedListItems.size();
    }

    public static boolean isTablet(Context context) {
        return (context.getResources().getConfiguration().screenLayout & 15) >= 3;
    }

    public int dpToPx(int dp) {
        return Math.round(((float) dp) * (this.mContext.getResources().getDisplayMetrics().xdpi / 160.0f));
    }

    private void DoDownload(final String feedUuid) {
        String AssignContact = this.mContext.getResources().getString(C0421R.string.assign_contact);
        String DownloadImage = this.mContext.getResources().getString(C0421R.string.download_image);
        String[] MenuItems = new String[]{AssignContact, DownloadImage};
        Builder alertDialogBuilder = new Builder(this.mContext);
        alertDialogBuilder.setCancelable(true).setItems(MenuItems, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                if (!CommonMember.isNetworkOnline((ConnectivityManager) FeedListAdapter.this.mContext.getSystemService("connectivity"), FeedListAdapter.this.mContext)) {
                    CommonMember.NetworkStatusAlert(FeedListAdapter.this.mContext);
                } else if (which == 0) {
                    String downloadImageUrl = FeedListAdapter.this.feedIconUrl + feedUuid + "/resize?height=" + 100 + "&width=" + 100;
                    File direct = new File(Environment.getExternalStorageDirectory() + "/VizsafeImages");
                    if (!direct.exists()) {
                        direct.mkdirs();
                    }
                    FeedListAdapter.this.downloadFile(downloadImageUrl);
                } else if (which == 1) {
                    FeedListAdapter.DOWNLOAD_IMAGE = true;
                    FeedListAdapter.this.downloadFile(FeedListAdapter.this.feedIconUrl + feedUuid + "/png");
                }
            }
        });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.setCanceledOnTouchOutside(true);
        alertDialog.show();
    }

    private void DoDelete(String feedUuid) {
        if (CommonMember.isNetworkOnline((ConnectivityManager) this.mContext.getSystemService("connectivity"), this.mContext)) {
            new AsynceTaskDeleteFeed(this, null).execute(new String[]{feedUuid});
            return;
        }
        CommonMember.NetworkStatusAlert(this.mContext);
    }

    private void DoShare(String feedUuid) {
        this.shareString = "https://" + PreferenceHandler.getInstance(this.mContext).getServerName() + "/map?incidentUUID=";
        Intent i = new Intent("android.intent.action.SEND");
        i.setType(HTTP.PLAIN_TEXT_TYPE);
        i.putExtra("android.intent.extra.SUBJECT", "VizSafe:");
        this.shareString += feedUuid;
        i.putExtra("android.intent.extra.TEXT", this.shareString);
        this.mContext.startActivity(Intent.createChooser(i, "Share via"));
    }

    private void DoAbuse(String feedAbuseOrNot, String feedIcon) {
        this.holder.reportAbuseImage.setVisibility(0);
        this.holder.reportAbuseImage.setImageResource(C0421R.C0418drawable.report_abuse_image);
        new AsynceTaskReportAbuse(this, null).execute(new String[]{feedIcon});
    }

    public void downloadFile(String url) {
        DownloadManager mgr = (DownloadManager) this.mContext.getSystemService("download");
        Request request = new Request(Uri.parse(url));
        request.setAllowedNetworkTypes(3).setAllowedOverRoaming(false).setTitle(this.mContext.getResources().getString(C0421R.string.app_name)).setDescription(this.mContext.getResources().getString(C0421R.string.downloading_image)).setDestinationInExternalPublicDir("/VizsafeImages", "fileName.jpg");
        mgr.enqueue(request);
    }

    public void loadData() {
        notifyDataSetChanged();
    }

    @UiThread
    protected void dataSetChanged() {
        notifyDataSetChanged();
    }
}
