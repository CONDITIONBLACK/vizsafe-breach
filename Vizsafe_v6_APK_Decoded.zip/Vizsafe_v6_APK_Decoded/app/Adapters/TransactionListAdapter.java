package com.vizsafe.app.Adapters;

import android.content.Context;
import android.content.Intent;
import android.support.p002v7.widget.RecyclerView.Adapter;
import android.support.p002v7.widget.RecyclerView.ViewHolder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.POJO.EsTransactionList;
import com.vizsafe.app.Utils.CommonMember;
import com.vizsafe.app.Utils.PreferenceHandler;
import com.vizsafe.app.Wallet.TransactionDetails;
import java.util.ArrayList;
import java.util.List;

public class TransactionListAdapter extends Adapter<MyViewHolder> {
    private ArrayList<EsTransactionList> arraylist = new ArrayList();
    private Context mContext;
    private List<EsTransactionList> mEsTransactionItems;

    public class MyViewHolder extends ViewHolder {
        TextView TransactionAddressView;
        TextView TransactionAmountView;
        TextView TransactionDateView;
        TextView TransactionNameView;
        LinearLayout trasaction_list_layout;

        public MyViewHolder(View rowView) {
            super(rowView);
            this.TransactionNameView = (TextView) rowView.findViewById(C0421R.C0419id.TransactionNameView);
            this.TransactionAddressView = (TextView) rowView.findViewById(C0421R.C0419id.TransactionAddressView);
            this.TransactionDateView = (TextView) rowView.findViewById(C0421R.C0419id.TransactionDateView);
            this.TransactionAmountView = (TextView) rowView.findViewById(C0421R.C0419id.TransactionAmountView);
            this.trasaction_list_layout = (LinearLayout) rowView.findViewById(C0421R.C0419id.trasaction_list_layout);
        }
    }

    public TransactionListAdapter(Context mContext, ArrayList<EsTransactionList> mTransactionsArrayList) {
        this.mEsTransactionItems = mTransactionsArrayList;
        this.mContext = mContext;
        this.arraylist.addAll(mTransactionsArrayList);
    }

    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(parent.getContext()).inflate(C0421R.layout.transacrion_list_raw, parent, false));
    }

    public void onBindViewHolder(MyViewHolder holder, int position) {
        final EsTransactionList mEsTransactionItem = (EsTransactionList) this.mEsTransactionItems.get(position);
        holder.TransactionDateView.setText(CommonMember.GetDate(Long.decode(mEsTransactionItem.gettimeStamp()).longValue()));
        boolean isSent = mEsTransactionItem.getfrom().toLowerCase().equals(PreferenceHandler.getInstance(this.mContext).getCurrentEthAddress().toLowerCase());
        String wei = mEsTransactionItem.getvalue();
        String sign = "+";
        if (isSent) {
            holder.TransactionNameView.setText(this.mContext.getResources().getString(C0421R.string.sent));
            holder.TransactionNameView.setTextColor(this.mContext.getResources().getColor(C0421R.color.red));
            holder.TransactionAmountView.setTextColor(this.mContext.getResources().getColor(C0421R.color.red));
            holder.TransactionAddressView.setText(mEsTransactionItem.getto());
            sign = "-";
        } else {
            holder.TransactionNameView.setText(this.mContext.getResources().getString(C0421R.string.received));
            holder.TransactionNameView.setTextColor(this.mContext.getResources().getColor(C0421R.color.green));
            holder.TransactionAddressView.setText(mEsTransactionItem.getfrom());
            sign = "+";
            holder.TransactionAmountView.setTextColor(this.mContext.getResources().getColor(C0421R.color.green));
        }
        String eth = "0";
        try {
            eth = CommonMember.WeiToEth(wei, 5);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (mEsTransactionItem.getvalue().equals("0")) {
            holder.TransactionAmountView.setText(eth);
        } else {
            holder.TransactionAmountView.setText(sign + eth);
        }
        holder.trasaction_list_layout.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                EsTransactionList extraParse = mEsTransactionItem;
                Intent intent = new Intent(TransactionListAdapter.this.mContext, TransactionDetails.class);
                intent.putExtra("getvalue", extraParse.getvalue());
                intent.putExtra("getfrom", extraParse.getfrom());
                intent.putExtra("getto", extraParse.getto());
                intent.putExtra("gettimeStamp", extraParse.gettimeStamp());
                intent.putExtra("getgasUsed", extraParse.getgasUsed());
                intent.putExtra("getblockHash", extraParse.getblockHash());
                intent.putExtra("getHash", extraParse.gethash());
                TransactionListAdapter.this.mContext.startActivity(intent);
            }
        });
    }

    public int getItemCount() {
        return this.mEsTransactionItems.size();
    }
}
