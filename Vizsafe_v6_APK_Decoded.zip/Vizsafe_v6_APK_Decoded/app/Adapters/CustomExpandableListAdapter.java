package com.vizsafe.app.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.POJO.ChannelsListItem;
import com.vizsafe.app.PostReportPages.SelectChannelToPost;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class CustomExpandableListAdapter extends BaseExpandableListAdapter {
    private Context context;
    private HashMap<String, List<ChannelsListItem>> listDataChild;
    private List<String> listDataHeader;
    private ArrayList<ChannelsListItem> selectedChannelItems;

    public CustomExpandableListAdapter(SelectChannelToPost context, List<String> listDataHeader, HashMap<String, List<ChannelsListItem>> listChildData, ArrayList<ChannelsListItem> selectedChannelItems) {
        this.context = context;
        this.listDataHeader = listDataHeader;
        this.listDataChild = listChildData;
        this.selectedChannelItems = selectedChannelItems;
    }

    public Object getChild(int groupPosition, int childPosititon) {
        return ((List) this.listDataChild.get(this.listDataHeader.get(groupPosition))).get(childPosititon);
    }

    public long getChildId(int groupPosition, int childPosition) {
        return (long) childPosition;
    }

    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
        ChannelsListItem childText = (ChannelsListItem) getChild(groupPosition, childPosition);
        if (convertView == null) {
            convertView = ((LayoutInflater) this.context.getSystemService("layout_inflater")).inflate(C0421R.layout.channel_list_item_raw, null);
        }
        TextView title = (TextView) convertView.findViewById(C0421R.C0419id.list_item_entry_title);
        TextView subtitle = (TextView) convertView.findViewById(C0421R.C0419id.list_item_entry_summary);
        ImageView image = (ImageView) convertView.findViewById(C0421R.C0419id.channel_icon);
        ImageView checkMark = (ImageView) convertView.findViewById(C0421R.C0419id.check_mark);
        ((ImageView) convertView.findViewById(C0421R.C0419id.info_btn)).setVisibility(8);
        title.setText(childText.title);
        subtitle.setText(childText.subtitle);
        Glide.with(this.context).load(childText.image).error((int) C0421R.C0418drawable.loading_image).into(image);
        for (int k = 0; k < this.selectedChannelItems.size(); k++) {
            if (childText.uuid.equals(((ChannelsListItem) this.selectedChannelItems.get(k)).uuid)) {
                checkMark.setVisibility(0);
                break;
            }
            checkMark.setVisibility(4);
        }
        return convertView;
    }

    public int getChildrenCount(int groupPosition) {
        return ((List) this.listDataChild.get(this.listDataHeader.get(groupPosition))).size();
    }

    public Object getGroup(int groupPosition) {
        return this.listDataHeader.get(groupPosition);
    }

    public int getGroupCount() {
        return this.listDataHeader.size();
    }

    public long getGroupId(int groupPosition) {
        return (long) groupPosition;
    }

    public boolean hasStableIds() {
        return false;
    }

    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
        String headerTitle = (String) getGroup(groupPosition);
        if (convertView == null) {
            convertView = ((LayoutInflater) this.context.getSystemService("layout_inflater")).inflate(C0421R.layout.channel_list_section_raw, null);
        }
        TextView lblListHeader = (TextView) convertView.findViewById(C0421R.C0419id.list_item_section_text);
        ImageView lblListImage = (ImageView) convertView.findViewById(C0421R.C0419id.list_item_section_image);
        lblListHeader.setTypeface(null, 1);
        lblListHeader.setText(headerTitle);
        if (isExpanded) {
            lblListImage.setBackgroundResource(C0421R.C0418drawable.ic_keyboard_arrow_down_white);
        } else {
            lblListImage.setBackgroundResource(C0421R.C0418drawable.ic_keyboard_arrow_right_white);
        }
        return convertView;
    }

    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }
}
