package com.vizsafe.app.Adapters;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Build.VERSION;
import android.support.p002v7.widget.RecyclerView.Adapter;
import android.support.p002v7.widget.RecyclerView.ViewHolder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.google.firebase.analytics.FirebaseAnalytics.Param;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.CustomViews.SampleWebview;
import com.vizsafe.app.LiveCameraMethods.CameraLiveScreen;
import com.vizsafe.app.POJO.CameraListItems;
import com.vizsafe.app.Utils.CommonMember;
import com.vizsafe.app.Utils.Webservice;
import dmax.dialog.SpotsDialog;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import org.json.JSONException;
import org.json.JSONObject;

public class CameraListAdapter extends Adapter<MyViewHolder> {
    public static String ClickedUuid;
    public static String mFinalurl;
    private ArrayList<CameraListItems> arraylist = new ArrayList();
    private List<CameraListItems> mCameraListItems;
    private Context mContext;
    private AlertDialog mTransparentProgressDialog;

    private class AsyncEgsStreamResponse extends AsyncTask<String, String, String> {
        JSONObject mResponse = null;
        String mURL = null;
        String response = null;

        private AsyncEgsStreamResponse() {
        }

        protected void onPreExecute() {
            super.onPreExecute();
            CameraListAdapter.this.mTransparentProgressDialog.show();
        }

        protected String doInBackground(String... arg0) {
            this.mResponse = Webservice.GetEGSURL(CameraListAdapter.this.mContext, arg0[0]);
            return null;
        }

        protected void onPostExecute(String result) {
            if (CameraListAdapter.this.mTransparentProgressDialog.isShowing()) {
                CameraListAdapter.this.mTransparentProgressDialog.dismiss();
            }
            if (this.mResponse != null) {
                try {
                    this.mURL = new JSONObject(String.valueOf(this.mResponse)).getString(Param.LOCATION);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (this.mURL == null || !this.mURL.isEmpty()) {
                }
            }
        }
    }

    public class MyViewHolder extends ViewHolder {
        ImageView camera_icon;
        LinearLayout mCameraListClick;
        Button mMapIcon;
        public TextView textview_camera_name;

        public MyViewHolder(View view) {
            super(view);
            this.mMapIcon = (Button) view.findViewById(C0421R.C0419id.camera_on_map);
            this.textview_camera_name = (TextView) view.findViewById(C0421R.C0419id.textview_camera_name);
            this.camera_icon = (ImageView) view.findViewById(C0421R.C0419id.camera_icon);
            this.mCameraListClick = (LinearLayout) view.findViewById(C0421R.C0419id.camera_click);
        }
    }

    public interface onGoToMapPageListener {
        void onGoToMapPage(String str, String str2);
    }

    public CameraListAdapter(Context mContext, List<CameraListItems> mCameraListItems) {
        this.mCameraListItems = mCameraListItems;
        this.mContext = mContext;
        this.arraylist.addAll(mCameraListItems);
        this.mTransparentProgressDialog = new SpotsDialog(mContext, mContext.getResources().getString(C0421R.string.please_wait_loading));
        this.mTransparentProgressDialog.setCanceledOnTouchOutside(false);
        this.mTransparentProgressDialog.setCancelable(false);
    }

    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(parent.getContext()).inflate(C0421R.layout.cameras_list_raw, parent, false));
    }

    public void onBindViewHolder(MyViewHolder holder, final int position) {
        CameraListItems mCameraListItem = (CameraListItems) this.mCameraListItems.get(position);
        holder.textview_camera_name.setText(mCameraListItem.getCameraName());
        final String Lat = mCameraListItem.getCameraLatitude();
        final String Long = mCameraListItem.getCameraLongitude();
        if (Lat == null || Lat.isEmpty() || Lat.equals("null") || Long == null || Long.isEmpty() || Long.equals("null")) {
            holder.mMapIcon.setVisibility(8);
        } else {
            holder.mMapIcon.setVisibility(0);
        }
        holder.mCameraListClick.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                if (CommonMember.isNetworkOnline((ConnectivityManager) CameraListAdapter.this.mContext.getSystemService("connectivity"), CameraListAdapter.this.mContext)) {
                    CameraListItems myList = (CameraListItems) CameraListAdapter.this.mCameraListItems.get(position);
                    CameraListAdapter.ClickedUuid = myList.getCameraUuid();
                    String videoInput = myList.getvideoInput();
                    Intent goToLiveCameraScreen;
                    if (VERSION.SDK_INT >= 23) {
                        if (videoInput == null) {
                            goToLiveCameraScreen = new Intent(CameraListAdapter.this.mContext, SampleWebview.class);
                            goToLiveCameraScreen.putExtra("camera_uuid", CameraListAdapter.ClickedUuid);
                            goToLiveCameraScreen.putExtra("camera_pass", "true");
                            CameraListAdapter.this.mContext.startActivity(goToLiveCameraScreen);
                            return;
                        } else if (!videoInput.equalsIgnoreCase("egs")) {
                            goToLiveCameraScreen = new Intent(CameraListAdapter.this.mContext, SampleWebview.class);
                            goToLiveCameraScreen.putExtra("camera_uuid", CameraListAdapter.ClickedUuid);
                            goToLiveCameraScreen.putExtra("camera_pass", "true");
                            CameraListAdapter.this.mContext.startActivity(goToLiveCameraScreen);
                            return;
                        } else {
                            return;
                        }
                    } else if (videoInput == null) {
                        goToLiveCameraScreen = new Intent(CameraListAdapter.this.mContext, CameraLiveScreen.class);
                        goToLiveCameraScreen.putExtra("camera_uuid", CameraListAdapter.ClickedUuid);
                        goToLiveCameraScreen.putExtra("camera_pass", "true");
                        CameraListAdapter.this.mContext.startActivity(goToLiveCameraScreen);
                        return;
                    } else if (!videoInput.equalsIgnoreCase("egs")) {
                        goToLiveCameraScreen = new Intent(CameraListAdapter.this.mContext, CameraLiveScreen.class);
                        goToLiveCameraScreen.putExtra("camera_uuid", CameraListAdapter.ClickedUuid);
                        goToLiveCameraScreen.putExtra("camera_pass", "true");
                        CameraListAdapter.this.mContext.startActivity(goToLiveCameraScreen);
                        return;
                    } else {
                        return;
                    }
                }
                CommonMember.getErrorDialog(CameraListAdapter.this.mContext.getString(C0421R.string.no_internet_access), CameraListAdapter.this.mContext).show();
            }
        });
        holder.mMapIcon.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                ((onGoToMapPageListener) CameraListAdapter.this.mContext).onGoToMapPage(Lat, Long);
            }
        });
    }

    public int getItemCount() {
        return this.mCameraListItems.size();
    }

    public void filter(String charText) {
        charText = charText.toLowerCase(Locale.getDefault());
        this.mCameraListItems.clear();
        if (charText.length() == 0) {
            this.mCameraListItems.addAll(this.arraylist);
        } else {
            Iterator it = this.arraylist.iterator();
            while (it.hasNext()) {
                CameraListItems wp = (CameraListItems) it.next();
                if (wp.getCameraName().toLowerCase(Locale.getDefault()).contains(charText)) {
                    this.mCameraListItems.add(wp);
                }
            }
        }
        notifyDataSetChanged();
    }
}
