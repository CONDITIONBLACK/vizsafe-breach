package com.vizsafe.app.Adapters;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.Feeds.FeedIconScreen;
import com.vizsafe.app.Feeds.ReportDetails;
import com.vizsafe.app.ImageUtil.ImageLoader;
import com.vizsafe.app.POJO.NotesItems;
import com.vizsafe.app.Utils.CommonMember;
import java.util.ArrayList;
import java.util.List;

public class CustomNotesListAdapter extends ArrayAdapter<NotesItems> {
    private final ArrayList<NotesItems> arraylist;
    private final Activity context;
    public ImageLoader imageLoader;
    private LayoutInflater inflater = null;
    private List<NotesItems> notesItems = null;

    public class ViewHolder {
        TextView Date;
        TextView Description;
        ImageView NoteIcon;
        TextView ReportedBy;
        String mDate;
        String mDescription;
        String mNoteIconURL;
        String mReportedBy;
    }

    public CustomNotesListAdapter(Activity context, int arg1, List<NotesItems> notesItems) {
        super(context, arg1, notesItems);
        this.notesItems = notesItems;
        this.context = context;
        this.arraylist = new ArrayList();
        this.arraylist.addAll(notesItems);
        this.inflater = context.getLayoutInflater();
        this.imageLoader = new ImageLoader(context.getApplicationContext());
    }

    public int getCount() {
        return this.notesItems.size();
    }

    public NotesItems getItem(int position) {
        return (NotesItems) this.notesItems.get(position);
    }

    public long getItemId(int position) {
        return (long) position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        String mNoteUUID;
        View rowView = convertView;
        ViewHolder viewHolder = new ViewHolder();
        if (convertView == null) {
            rowView = this.inflater.inflate(C0421R.layout.notes_raw_item, parent, false);
            viewHolder.ReportedBy = (TextView) rowView.findViewById(C0421R.C0419id.notes_reportedby);
            viewHolder.Date = (TextView) rowView.findViewById(C0421R.C0419id.notes_date);
            viewHolder.Description = (TextView) rowView.findViewById(C0421R.C0419id.notes_description);
            viewHolder.NoteIcon = (ImageView) rowView.findViewById(C0421R.C0419id.notes_image);
            rowView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) rowView.getTag();
        }
        viewHolder.ReportedBy.setText(getItem(position).uploadedBy);
        viewHolder.Description.setText(getItem(position).description);
        viewHolder.Date.setText(String.valueOf(ReportDetails.getFormattedDateFromTimestamp(1000 * getItem(position).uploadedDate)));
        if (isTablet(this.context)) {
        }
        String mNoteIconURL = CommonMember.getURL(this.context) + "/incident/";
        if (getItem(position).noteuuid == null || getItem(position).noteuuid.equals("null") || getItem(position).noteuuid.isEmpty()) {
            mNoteUUID = getItem(position).incidentID;
        } else {
            mNoteUUID = getItem(position).noteuuid;
        }
        this.imageLoader.DisplayImage(mNoteIconURL + mNoteUUID + "/jpeg/", viewHolder.NoteIcon, false);
        viewHolder.NoteIcon.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                Intent goToFeedIconScreen = new Intent(CustomNotesListAdapter.this.context, FeedIconScreen.class);
                goToFeedIconScreen.putExtra("feed_type", "photo");
                goToFeedIconScreen.putExtra("feed_icon", mNoteUUID);
                CustomNotesListAdapter.this.context.startActivity(goToFeedIconScreen);
            }
        });
        return rowView;
    }

    private static boolean isTablet(Context context) {
        return (context.getResources().getConfiguration().screenLayout & 15) >= 3;
    }
}
