package com.vizsafe.app.Adapters;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.support.p002v7.widget.RecyclerView.Adapter;
import android.support.p002v7.widget.RecyclerView.ViewHolder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.Outbox.OutboxSentPostItems;
import com.vizsafe.app.Utils.CommonMember;
import com.vizsafe.app.Utils.PreferenceHandler;
import com.vizsafe.app.Utils.Webservice;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONObject;

public class OutboxListAdapter extends Adapter<MyViewHolder> {
    private ArrayList<OutboxSentPostItems> arraylist = new ArrayList();
    private Context mContext;
    private List<OutboxSentPostItems> mOutboxSentPostItems;

    private class AsyncTaskPostFeed extends AsyncTask<String, String, String> {
        int position;
        JSONObject response;
        String successStatus;

        private AsyncTaskPostFeed() {
            this.response = null;
            this.successStatus = "yes";
        }

        /* synthetic */ AsyncTaskPostFeed(OutboxListAdapter x0, C02071 x1) {
            this();
        }

        protected void onPreExecute() {
            super.onPreExecute();
        }

        protected String doInBackground(String... arg0) {
            String email = PreferenceHandler.getInstance(OutboxListAdapter.this.mContext).getUserName();
            String password = PreferenceHandler.getInstance(OutboxListAdapter.this.mContext).getPassword();
            try {
                this.response = new Webservice().postFeedWebService(OutboxListAdapter.this.mContext, email, password, arg0[0]);
                this.position = Integer.parseInt(arg0[1]);
            } catch (Exception e) {
                e.printStackTrace();
                this.successStatus = "no";
            }
            return this.successStatus;
        }

        protected void onPostExecute(String result) {
            if (this.response != null) {
                Toast.makeText(OutboxListAdapter.this.mContext, OutboxListAdapter.this.mContext.getString(C0421R.string.post_success), 1).show();
                OutboxListAdapter.this.arraylist.remove(this.position);
                OutboxListAdapter.this.notifyDataSetChanged();
                OutboxListAdapter.this.broadcastOutboxIntent();
            }
        }
    }

    public class MyViewHolder extends ViewHolder {
        LinearLayout mOutboxLayout;
        TextView messageText;
        String postData;
        ImageView statusImage;

        public MyViewHolder(View view) {
            super(view);
            this.messageText = (TextView) view.findViewById(C0421R.C0419id.messageText);
            this.statusImage = (ImageView) view.findViewById(C0421R.C0419id.statusImage);
            this.mOutboxLayout = (LinearLayout) view.findViewById(C0421R.C0419id.outbox_layout);
        }
    }

    public OutboxListAdapter(Context mContext, List<OutboxSentPostItems> mOutboxSentPostItems) {
        this.mOutboxSentPostItems = mOutboxSentPostItems;
        this.mContext = mContext;
        this.arraylist.addAll(mOutboxSentPostItems);
    }

    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(parent.getContext()).inflate(C0421R.layout.outbox_list_item_raw, parent, false));
    }

    public void onBindViewHolder(MyViewHolder holder, final int position) {
        OutboxSentPostItems mOutboxSentPostItem = (OutboxSentPostItems) this.mOutboxSentPostItems.get(position);
        if (mOutboxSentPostItem.getStatus()) {
            holder.statusImage.setImageResource(C0421R.C0418drawable.post_status_true);
        } else {
            holder.statusImage.setImageResource(C0421R.C0418drawable.post_status_false);
        }
        if (mOutboxSentPostItem.getMessageText().trim().equals("")) {
            holder.messageText.setText(this.mContext.getString(C0421R.string.no_description));
        } else {
            holder.messageText.setText(mOutboxSentPostItem.getMessageText());
        }
        holder.mOutboxLayout.setOnClickListener(new OnClickListener() {

            /* renamed from: com.vizsafe.app.Adapters.OutboxListAdapter$1$2 */
            class C02062 implements DialogInterface.OnClickListener {

                /* renamed from: com.vizsafe.app.Adapters.OutboxListAdapter$1$2$1 */
                class C02051 extends TypeToken<List<OutboxSentPostItems>> {
                    C02051() {
                    }
                }

                C02062() {
                }

                public void onClick(DialogInterface dialog, int which) {
                    ArrayList<OutboxSentPostItems> arraylist1 = new ArrayList();
                    Object arraylist12 = (ArrayList) new Gson().fromJson(PreferenceHandler.getInstance(OutboxListAdapter.this.mContext).getOutBoxSet(), new C02051().getType());
                    if (arraylist12 == null || arraylist12.size() <= 0) {
                        arraylist12.remove(position);
                        OutboxListAdapter.this.notifyItemRemoved(position);
                        OutboxListAdapter.this.notifyItemRangeChanged(position, arraylist12.size());
                    } else {
                        arraylist12.remove(position);
                        OutboxListAdapter.this.notifyItemRemoved(position);
                        OutboxListAdapter.this.notifyItemRangeChanged(position, arraylist12.size());
                    }
                    try {
                        PreferenceHandler.getInstance(OutboxListAdapter.this.mContext).setOutBoxSet(new Gson().toJson(arraylist12));
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    OutboxListAdapter.this.mOutboxSentPostItems.remove(position);
                    OutboxListAdapter.this.notifyItemRemoved(position);
                    OutboxListAdapter.this.notifyItemRangeChanged(position, OutboxListAdapter.this.mOutboxSentPostItems.size());
                }
            }

            public void onClick(View v) {
                final OutboxSentPostItems outboxSentPostItems = (OutboxSentPostItems) OutboxListAdapter.this.arraylist.get(position);
                if (outboxSentPostItems.getStatus()) {
                    Builder dialog = new Builder(OutboxListAdapter.this.mContext);
                    dialog.setTitle(OutboxListAdapter.this.mContext.getString(C0421R.string.app_name));
                    dialog.setMessage(OutboxListAdapter.this.mContext.getString(C0421R.string.error_occured_post_again));
                    Builder builder = dialog.setPositiveButton(OutboxListAdapter.this.mContext.getString(C0421R.string.retry), new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            if (!CommonMember.isNetworkOnline((ConnectivityManager) OutboxListAdapter.this.mContext.getSystemService("connectivity"), OutboxListAdapter.this.mContext)) {
                                CommonMember.getErrorDialog(OutboxListAdapter.this.mContext.getString(C0421R.string.no_internet_access), OutboxListAdapter.this.mContext).show();
                            } else if (OutboxListAdapter.this.arraylist.size() > 0) {
                                String postData = outboxSentPostItems.getSentMessageUrl();
                                new AsyncTaskPostFeed(OutboxListAdapter.this, null).execute(new String[]{postData, String.valueOf(position)});
                            }
                        }
                    });
                    dialog.setNegativeButton(OutboxListAdapter.this.mContext.getString(C0421R.string.remove), new C02062());
                    AlertDialog errorDialog = dialog.create();
                    errorDialog.setCanceledOnTouchOutside(true);
                    errorDialog.show();
                }
            }
        });
    }

    public int getItemCount() {
        return this.mOutboxSentPostItems.size();
    }

    public void broadcastOutboxIntent() {
        Intent intent = new Intent();
        intent.setAction("com.vizsafe.UPDATE_OUTBOX");
        this.mContext.sendBroadcast(intent);
    }
}
