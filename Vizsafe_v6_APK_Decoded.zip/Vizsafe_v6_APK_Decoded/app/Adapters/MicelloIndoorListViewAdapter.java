package com.vizsafe.app.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.vizsafe.app.C0421R;
import java.util.ArrayList;

public class MicelloIndoorListViewAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<String> mPlaceIdList = new ArrayList();
    private ArrayList<String> mPlaceNameList = new ArrayList();

    class DrawerItemHolder {
        TextView txtPlaceName;

        DrawerItemHolder() {
        }
    }

    public MicelloIndoorListViewAdapter(Context applicationContext, ArrayList<String> mPlaceNameList, ArrayList<String> mPlaceIdList) {
        this.context = applicationContext;
        this.mPlaceNameList = mPlaceNameList;
        this.mPlaceIdList = mPlaceIdList;
    }

    public int getCount() {
        return this.mPlaceNameList.size();
    }

    public Object getItem(int position) {
        return this.mPlaceNameList.get(position);
    }

    public long getItemId(int position) {
        return (long) position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        DrawerItemHolder drawerHolder;
        View view = convertView;
        if (view == null) {
            LayoutInflater mInflater = (LayoutInflater) this.context.getSystemService("layout_inflater");
            drawerHolder = new DrawerItemHolder();
            view = mInflater.inflate(C0421R.layout.activity_row_item_micello_listview, parent, false);
            drawerHolder.txtPlaceName = (TextView) view.findViewById(C0421R.C0419id.place_name_micello_listview);
            view.setTag(drawerHolder);
        } else {
            drawerHolder = (DrawerItemHolder) view.getTag();
        }
        drawerHolder.txtPlaceName.setText((CharSequence) this.mPlaceNameList.get(position));
        return view;
    }
}
