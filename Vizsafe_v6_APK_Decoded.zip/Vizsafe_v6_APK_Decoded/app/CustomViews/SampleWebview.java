package com.vizsafe.app.CustomViews;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Picture;
import android.os.Bundle;
import android.os.Environment;
import android.support.p001v4.app.ActivityCompat;
import android.support.p001v4.content.ContextCompat;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings.PluginState;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.Toast;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.Utils.CommonMember;
import com.vizsafe.app.Utils.PreferenceHandler;
import dmax.dialog.SpotsDialog;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;

public class SampleWebview extends Activity {
    private static final int REQUEST_WRITE_STORAGE = 112;
    String authenticationString;
    Bitmap bitmap;
    String cameraPass;
    String cameraUuid;
    ImageView downloadImage;
    String email;
    /* renamed from: i */
    int f25i = 0;
    private boolean mClicked = true;
    private ImageView mDoneBtn;
    private int mPlaceUuid;
    private AlertDialog mTransparentProgressDialog;
    private WebView mWebView;
    SampleWebview mWebviewLoader;
    String password;
    private ProgressDialog progressBar;

    /* renamed from: com.vizsafe.app.CustomViews.SampleWebview$1 */
    class C02241 implements OnClickListener {
        C02241() {
        }

        public void onClick(View v) {
            SampleWebview.this.finish();
        }
    }

    /* renamed from: com.vizsafe.app.CustomViews.SampleWebview$3 */
    class C02263 extends WebViewClient {
        C02263() {
        }

        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            SampleWebview.this.mTransparentProgressDialog.show();
            view.loadUrl(url);
            return true;
        }

        public void onPageFinished(WebView view, String url) {
            if (SampleWebview.this.mTransparentProgressDialog.isShowing()) {
                SampleWebview.this.mTransparentProgressDialog.dismiss();
            }
            view.loadUrl(url);
        }

        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            if (SampleWebview.this.mTransparentProgressDialog.isShowing()) {
                SampleWebview.this.mTransparentProgressDialog.dismiss();
            }
        }
    }

    /* renamed from: com.vizsafe.app.CustomViews.SampleWebview$4 */
    class C02274 implements OnClickListener {
        C02274() {
        }

        public void onClick(View v) {
            Picture picture = SampleWebview.this.mWebView.capturePicture();
            if (picture.getWidth() > 0 && picture.getHeight() > 0) {
                SampleWebview.this.bitmap = Bitmap.createBitmap(picture.getWidth(), picture.getHeight(), Config.ARGB_8888);
                picture.draw(new Canvas(SampleWebview.this.bitmap));
                if (SampleWebview.this.bitmap == null) {
                    return;
                }
                if ("mounted".equals(Environment.getExternalStorageState())) {
                    SampleWebview sampleWebview;
                    File directory = new File(Environment.getExternalStorageDirectory() + "/VizsafeImages");
                    directory.mkdirs();
                    File yourFile = new File(directory, "CameraImage" + SampleWebview.this.f25i + ".jpg");
                    while (yourFile.exists()) {
                        sampleWebview = SampleWebview.this;
                        sampleWebview.f25i++;
                        yourFile = new File(directory, "CameraImage" + SampleWebview.this.f25i + ".jpg");
                    }
                    if (!yourFile.exists() && directory.canWrite()) {
                        try {
                            FileOutputStream out = new FileOutputStream(yourFile, true);
                            SampleWebview.this.bitmap.compress(CompressFormat.JPEG, 100, out);
                            out.flush();
                            out.close();
                            Toast.makeText(SampleWebview.this, "File Saved to /VizsafeImages/CameraImage" + SampleWebview.this.f25i + ".jpg", 0).show();
                            sampleWebview = SampleWebview.this;
                            sampleWebview.f25i++;
                            return;
                        } catch (IOException e) {
                            e.printStackTrace();
                            return;
                        }
                    }
                    return;
                }
                Toast.makeText(SampleWebview.this, SampleWebview.this.getResources().getString(C0421R.string.sdcard_not_available), 0).show();
            }
        }
    }

    @SuppressLint({"SetJavaScriptEnabled"})
    public void onCreate(Bundle savedInstanceState) {
        boolean hasPermission;
        super.onCreate(savedInstanceState);
        setContentView(C0421R.layout.activity_webview);
        this.mWebviewLoader = this;
        this.mWebView = (WebView) findViewById(C0421R.C0419id.webview);
        this.mDoneBtn = (ImageView) findViewById(C0421R.C0419id.action_bar_back);
        this.downloadImage = (ImageView) findViewById(C0421R.C0419id.action_bar_imageview_right);
        this.mTransparentProgressDialog = new SpotsDialog((Context) this, getResources().getString(C0421R.string.please_wait_loading));
        this.mTransparentProgressDialog.setCanceledOnTouchOutside(false);
        this.mTransparentProgressDialog.setCancelable(false);
        this.cameraUuid = getIntent().getExtras().getString("camera_uuid");
        this.cameraPass = getIntent().getExtras().getString("camera_pass");
        this.email = PreferenceHandler.getInstance(this.mWebviewLoader).getUserName();
        this.password = PreferenceHandler.getInstance(this.mWebviewLoader).getPassword();
        if (ContextCompat.checkSelfPermission(getApplicationContext(), "android.permission.WRITE_EXTERNAL_STORAGE") == 0) {
            hasPermission = true;
        } else {
            hasPermission = false;
        }
        if (!hasPermission) {
            ActivityCompat.requestPermissions(this, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 112);
        }
        this.mWebView.getSettings().setJavaScriptEnabled(true);
        this.mWebView.getSettings().setLoadWithOverviewMode(true);
        this.mWebView.getSettings().setUseWideViewPort(true);
        this.mWebView.getSettings().setPluginState(PluginState.ON);
        this.mWebView.setScrollBarStyle(33554432);
        this.mWebView.setScrollbarFadingEnabled(false);
        this.mWebView.getSettings().setBuiltInZoomControls(true);
        this.mWebView.getSettings().setSupportZoom(true);
        this.mWebView.getSettings().setLoadsImagesAutomatically(true);
        this.downloadImage.setBackgroundResource(C0421R.C0418drawable.ic_file_download);
        this.downloadImage.setVisibility(0);
        this.mDoneBtn.setOnClickListener(new C02241());
        String mKey = CommonMember.GetKeyString();
        String mToken = null;
        try {
            mToken = CommonMember.GetOrinalKey(mKey);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        String URL = CommonMember.getURL(getApplicationContext()) + "/camera/" + this.cameraUuid + "/mjpeg?key=" + mKey + "&token=" + mToken;
        this.mWebView.setWebChromeClient(new WebChromeClient() {
            public void onProgressChanged(WebView view, int progress) {
                this.setProgress(progress * 1000);
            }
        });
        this.mWebView.setWebViewClient(new C02263());
        this.mWebView.loadUrl(URL);
        this.downloadImage.setOnClickListener(new C02274());
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 112:
                if (grantResults.length <= 0 || grantResults[0] != 0) {
                    Toast.makeText(getApplicationContext(), "The app was not allowed to write to your storage. Hence, it cannot function properly. Please consider granting it this permission", 1).show();
                    return;
                }
                return;
            default:
                return;
        }
    }

    public void onBackPressed() {
        super.onBackPressed();
        this.mWebView.loadUrl("file:///android_asset/nonexistent.html");
        if (this.mTransparentProgressDialog.isShowing()) {
            this.mTransparentProgressDialog.dismiss();
        }
        finish();
    }

    public void onPause() {
        super.onPause();
        this.mWebView.loadUrl("file:///android_asset/nonexistent.html");
        if (this.mTransparentProgressDialog.isShowing()) {
            this.mTransparentProgressDialog.dismiss();
        }
    }

    public void onResume() {
        super.onResume();
        this.mWebView.onResume();
        if (this.mTransparentProgressDialog.isShowing()) {
            this.mTransparentProgressDialog.dismiss();
        }
    }
}
