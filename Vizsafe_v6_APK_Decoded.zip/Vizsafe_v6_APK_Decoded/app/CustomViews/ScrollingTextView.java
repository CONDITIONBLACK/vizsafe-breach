package com.vizsafe.app.CustomViews;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Point;
import android.graphics.Rect;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.view.Display;
import android.view.WindowManager;
import android.view.animation.LinearInterpolator;
import android.widget.Scroller;
import android.widget.TextView;
import com.vizsafe.app.C0421R;

@SuppressLint({"AppCompatCustomView"})
public class ScrollingTextView extends TextView {
    private boolean mPaused;
    private int mRndDuration;
    private Scroller mSlr;
    private int mXPaused;

    public ScrollingTextView(Context context) {
        this(context, null);
        setSingleLine();
        setEllipsize(null);
        setVisibility(4);
        startScroll(null);
    }

    public ScrollingTextView(Context context, AttributeSet attrs) {
        this(context, attrs, 16842884);
        setSingleLine();
        setEllipsize(null);
        setVisibility(4);
        startScroll(attrs);
    }

    public ScrollingTextView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mRndDuration = 20000;
        this.mXPaused = 0;
        this.mPaused = true;
        setSingleLine();
        setEllipsize(null);
        setVisibility(4);
        startScroll(attrs);
    }

    public void startScroll(AttributeSet attrs) {
        int width = 0;
        if (!(attrs == null || getContext().obtainStyledAttributes(attrs, C0421R.styleable.ScrollingTextView).getInt(0, 0) == 0)) {
            width = getCalculatedWidth();
        }
        if (calculateScrollingLen() > width) {
            this.mXPaused = getWidth() * -1;
            this.mPaused = true;
            resumeScroll();
            return;
        }
        setVisibility(0);
    }

    public void resumeScroll() {
        if (this.mPaused) {
            setHorizontallyScrolling(true);
            this.mSlr = new Scroller(getContext(), new LinearInterpolator());
            setScroller(this.mSlr);
            int scrollingLen = calculateScrollingLen();
            int distance = scrollingLen - (getWidth() + this.mXPaused);
            int duration = new Double((((double) (this.mRndDuration * distance)) * 1.0d) / ((double) scrollingLen)).intValue();
            setVisibility(0);
            this.mSlr.startScroll(this.mXPaused, 0, distance, 0, duration);
            invalidate();
            this.mPaused = false;
        }
    }

    private int calculateScrollingLen() {
        TextPaint tp = getPaint();
        Rect rect = new Rect();
        String strTxt = getText().toString();
        tp.getTextBounds(strTxt, 0, strTxt.length(), rect);
        return rect.width() + getWidth();
    }

    public void pauseScroll() {
        if (this.mSlr != null && !this.mPaused) {
            this.mPaused = true;
            this.mXPaused = this.mSlr.getCurrX();
            this.mSlr.abortAnimation();
        }
    }

    public void computeScroll() {
        super.computeScroll();
        if (this.mSlr != null && this.mSlr.isFinished() && !this.mPaused) {
            startScroll(null);
        }
    }

    public int getRndDuration() {
        return this.mRndDuration;
    }

    public void setRndDuration(int duration) {
        this.mRndDuration = duration;
    }

    public boolean isPaused() {
        return this.mPaused;
    }

    public void setText(String str) {
        super.setText(str);
        if (calculateScrollingLen() > getCalculatedWidth()) {
            this.mXPaused = getWidth() * -1;
            this.mPaused = true;
            resumeScroll();
            return;
        }
        setVisibility(0);
    }

    public int getCalculatedWidth() {
        Display display = ((WindowManager) getContext().getSystemService("window")).getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        return size.x;
    }
}
