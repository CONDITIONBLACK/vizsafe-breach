package com.vizsafe.app.CustomViews;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;
import android.view.animation.RotateAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.vizsafe.app.C0421R;
import java.text.SimpleDateFormat;
import java.util.Date;

public class PullToRefreshListView extends ListView {
    private static final int BOUNCE_ANIMATION_DELAY = 100;
    private static final int BOUNCE_ANIMATION_DURATION = 700;
    private static final float BOUNCE_OVERSHOOT_TENSION = 1.4f;
    private static final float PULL_RESISTANCE = 1.7f;
    private static final int ROTATE_ARROW_ANIMATION_DURATION = 250;
    private static int measuredHeaderHeight;
    private final int IDLE_DISTANCE = 5;
    private boolean bounceBackHeader;
    private RotateAnimation flipAnimation;
    private boolean hasResetHeader;
    private RelativeLayout header;
    private LinearLayout headerContainer;
    private int headerPadding;
    private ImageView image;
    private long lastUpdated = -1;
    private SimpleDateFormat lastUpdatedDateFormat = new SimpleDateFormat("dd/MM HH:mm");
    private String lastUpdatedText;
    private TextView lastUpdatedTextView;
    private boolean lockScrollWhileRefreshing;
    private float mScrollStartY;
    private OnItemClickListener onItemClickListener;
    private OnItemLongClickListener onItemLongClickListener;
    private OnRefreshListener onRefreshListener;
    private float previousY;
    private String pullToRefreshText;
    private String refreshingText;
    private String releaseToRefreshText;
    private RotateAnimation reverseFlipAnimation;
    private boolean scrollbarEnabled;
    private boolean showLastUpdatedText;
    private ProgressBar spinner;
    private State state;
    private TextView text;

    private class HeaderAnimationListener implements AnimationListener {
        private int height;
        private State stateAtAnimationStart;
        private final int translation;

        /* renamed from: com.vizsafe.app.CustomViews.PullToRefreshListView$HeaderAnimationListener$1 */
        class C02221 implements Runnable {
            C02221() {
            }

            public void run() {
                PullToRefreshListView.this.resetHeader();
            }
        }

        public HeaderAnimationListener(int translation) {
            this.translation = translation;
        }

        public void onAnimationStart(Animation animation) {
            this.stateAtAnimationStart = PullToRefreshListView.this.state;
            LayoutParams lp = PullToRefreshListView.this.getLayoutParams();
            this.height = lp.height;
            lp.height = PullToRefreshListView.this.getHeight() - this.translation;
            PullToRefreshListView.this.setLayoutParams(lp);
            if (PullToRefreshListView.this.scrollbarEnabled) {
                PullToRefreshListView.this.setVerticalScrollBarEnabled(false);
            }
        }

        public void onAnimationEnd(Animation animation) {
            int i;
            PullToRefreshListView pullToRefreshListView = PullToRefreshListView.this;
            if (this.stateAtAnimationStart == State.REFRESHING) {
                i = 0;
            } else {
                i = (-PullToRefreshListView.measuredHeaderHeight) - PullToRefreshListView.this.headerContainer.getTop();
            }
            pullToRefreshListView.setHeaderPadding(i);
            PullToRefreshListView.this.setSelection(0);
            LayoutParams lp = PullToRefreshListView.this.getLayoutParams();
            lp.height = this.height;
            PullToRefreshListView.this.setLayoutParams(lp);
            if (PullToRefreshListView.this.scrollbarEnabled) {
                PullToRefreshListView.this.setVerticalScrollBarEnabled(true);
            }
            if (PullToRefreshListView.this.bounceBackHeader) {
                PullToRefreshListView.this.bounceBackHeader = false;
                PullToRefreshListView.this.postDelayed(new C02221(), 100);
            } else if (this.stateAtAnimationStart != State.REFRESHING) {
                PullToRefreshListView.this.setState(State.PULL_TO_REFRESH);
            }
        }

        public void onAnimationRepeat(Animation animation) {
        }
    }

    public interface OnRefreshListener {
        void onRefresh();
    }

    private class PTROnGlobalLayoutListener implements OnGlobalLayoutListener {
        private PTROnGlobalLayoutListener() {
        }

        public void onGlobalLayout() {
            int initialHeaderHeight = PullToRefreshListView.this.header.getHeight();
            if (initialHeaderHeight > 0) {
                PullToRefreshListView.measuredHeaderHeight = initialHeaderHeight;
                if (PullToRefreshListView.measuredHeaderHeight > 0 && PullToRefreshListView.this.state != State.REFRESHING) {
                    PullToRefreshListView.this.setHeaderPadding(-PullToRefreshListView.measuredHeaderHeight);
                    PullToRefreshListView.this.requestLayout();
                }
            }
            PullToRefreshListView.this.getViewTreeObserver().removeGlobalOnLayoutListener(this);
        }
    }

    private class PTROnItemClickListener implements OnItemClickListener {
        private PTROnItemClickListener() {
        }

        public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
            PullToRefreshListView.this.hasResetHeader = false;
            if (PullToRefreshListView.this.onItemClickListener != null && PullToRefreshListView.this.state == State.PULL_TO_REFRESH) {
                PullToRefreshListView.this.onItemClickListener.onItemClick(adapterView, view, position - PullToRefreshListView.this.getHeaderViewsCount(), id);
            }
        }
    }

    private class PTROnItemLongClickListener implements OnItemLongClickListener {
        private PTROnItemLongClickListener() {
        }

        public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long id) {
            PullToRefreshListView.this.hasResetHeader = false;
            if (PullToRefreshListView.this.onItemLongClickListener == null || PullToRefreshListView.this.state != State.PULL_TO_REFRESH) {
                return false;
            }
            return PullToRefreshListView.this.onItemLongClickListener.onItemLongClick(adapterView, view, position - PullToRefreshListView.this.getHeaderViewsCount(), id);
        }
    }

    private enum State {
        PULL_TO_REFRESH,
        RELEASE_TO_REFRESH,
        REFRESHING
    }

    public PullToRefreshListView(Context context) {
        super(context);
        init();
    }

    public PullToRefreshListView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public PullToRefreshListView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    public void setOnItemLongClickListener(OnItemLongClickListener onItemLongClickListener) {
        this.onItemLongClickListener = onItemLongClickListener;
    }

    public void setOnRefreshListener(OnRefreshListener onRefreshListener) {
        this.onRefreshListener = onRefreshListener;
    }

    public boolean isRefreshing() {
        return this.state == State.REFRESHING;
    }

    public void setLockScrollWhileRefreshing(boolean lockScrollWhileRefreshing) {
        this.lockScrollWhileRefreshing = lockScrollWhileRefreshing;
    }

    public void setShowLastUpdatedText(boolean showLastUpdatedText) {
        this.showLastUpdatedText = showLastUpdatedText;
        if (!showLastUpdatedText) {
            this.lastUpdatedTextView.setVisibility(8);
        }
    }

    public void setLastUpdatedDateFormat(SimpleDateFormat lastUpdatedDateFormat) {
        this.lastUpdatedDateFormat = lastUpdatedDateFormat;
    }

    public void setRefreshing() {
        this.state = State.REFRESHING;
        scrollTo(0, 0);
        setUiRefreshing();
        setHeaderPadding(0);
    }

    public void onRefreshComplete() {
        this.state = State.PULL_TO_REFRESH;
        resetHeader();
        this.lastUpdated = System.currentTimeMillis();
    }

    public void setTextPullToRefresh(String pullToRefreshText) {
        this.pullToRefreshText = pullToRefreshText;
        if (this.state == State.PULL_TO_REFRESH) {
            this.text.setText(pullToRefreshText);
        }
    }

    public void setTextReleaseToRefresh(String releaseToRefreshText) {
        this.releaseToRefreshText = releaseToRefreshText;
        if (this.state == State.RELEASE_TO_REFRESH) {
            this.text.setText(releaseToRefreshText);
        }
    }

    public void setTextRefreshing(String refreshingText) {
        this.refreshingText = refreshingText;
        if (this.state == State.REFRESHING) {
            this.text.setText(refreshingText);
        }
    }

    private void init() {
        setVerticalFadingEdgeEnabled(false);
        this.headerContainer = (LinearLayout) LayoutInflater.from(getContext()).inflate(C0421R.layout.ptr_header, null);
        this.header = (RelativeLayout) this.headerContainer.findViewById(C0421R.C0419id.ptr_id_header);
        this.text = (TextView) this.header.findViewById(C0421R.C0419id.ptr_id_text);
        this.lastUpdatedTextView = (TextView) this.header.findViewById(C0421R.C0419id.ptr_id_last_updated);
        this.image = (ImageView) this.header.findViewById(C0421R.C0419id.ptr_id_image);
        this.spinner = (ProgressBar) this.header.findViewById(C0421R.C0419id.ptr_id_spinner);
        this.pullToRefreshText = getContext().getString(C0421R.string.ptr_pull_to_refresh);
        this.releaseToRefreshText = getContext().getString(C0421R.string.ptr_release_to_refresh);
        this.refreshingText = getContext().getString(C0421R.string.ptr_refreshing);
        this.lastUpdatedText = getContext().getString(C0421R.string.ptr_last_updated);
        this.flipAnimation = new RotateAnimation(0.0f, -180.0f, 1, 0.5f, 1, 0.5f);
        this.flipAnimation.setInterpolator(new LinearInterpolator());
        this.flipAnimation.setDuration(250);
        this.flipAnimation.setFillAfter(true);
        this.reverseFlipAnimation = new RotateAnimation(-180.0f, 0.0f, 1, 0.5f, 1, 0.5f);
        this.reverseFlipAnimation.setInterpolator(new LinearInterpolator());
        this.reverseFlipAnimation.setDuration(250);
        this.reverseFlipAnimation.setFillAfter(true);
        addHeaderView(this.headerContainer);
        setState(State.PULL_TO_REFRESH);
        this.scrollbarEnabled = isVerticalScrollBarEnabled();
        this.header.getViewTreeObserver().addOnGlobalLayoutListener(new PTROnGlobalLayoutListener());
        super.setOnItemClickListener(new PTROnItemClickListener());
        super.setOnItemLongClickListener(new PTROnItemLongClickListener());
    }

    private void setHeaderPadding(int padding) {
        this.headerPadding = padding;
        MarginLayoutParams mlp = (MarginLayoutParams) this.header.getLayoutParams();
        mlp.setMargins(0, Math.round((float) padding), 0, 0);
        this.header.setLayoutParams(mlp);
    }

    public boolean onTouchEvent(MotionEvent event) {
        if (this.lockScrollWhileRefreshing && (this.state == State.REFRESHING || (getAnimation() != null && !getAnimation().hasEnded()))) {
            return true;
        }
        switch (event.getAction()) {
            case 0:
                if (getFirstVisiblePosition() == 0) {
                    this.previousY = event.getY();
                } else {
                    this.previousY = -1.0f;
                }
                this.mScrollStartY = event.getY();
                break;
            case 1:
                if (this.previousY != -1.0f && (this.state == State.RELEASE_TO_REFRESH || getFirstVisiblePosition() == 0)) {
                    switch (this.state) {
                        case RELEASE_TO_REFRESH:
                            setState(State.REFRESHING);
                            bounceBackHeader();
                            break;
                        case PULL_TO_REFRESH:
                            resetHeader();
                            break;
                    }
                }
                break;
            case 2:
                if (this.previousY != -1.0f && getFirstVisiblePosition() == 0 && Math.abs(this.mScrollStartY - event.getY()) > 5.0f) {
                    float y = event.getY();
                    float diff = y - this.previousY;
                    if (diff > 0.0f) {
                        diff /= PULL_RESISTANCE;
                    }
                    this.previousY = y;
                    int newHeaderPadding = Math.max(Math.round(((float) this.headerPadding) + diff), -this.header.getHeight());
                    if (!(newHeaderPadding == this.headerPadding || this.state == State.REFRESHING)) {
                        setHeaderPadding(newHeaderPadding);
                        if (this.state != State.PULL_TO_REFRESH || this.headerPadding <= 0) {
                            if (this.state == State.RELEASE_TO_REFRESH && this.headerPadding < 0) {
                                setState(State.PULL_TO_REFRESH);
                                this.image.clearAnimation();
                                this.image.startAnimation(this.reverseFlipAnimation);
                                break;
                            }
                        }
                        setState(State.RELEASE_TO_REFRESH);
                        this.image.clearAnimation();
                        this.image.startAnimation(this.flipAnimation);
                        break;
                    }
                }
                break;
        }
        return super.onTouchEvent(event);
    }

    private void bounceBackHeader() {
        int yTranslate;
        if (this.state == State.REFRESHING) {
            yTranslate = this.header.getHeight() - this.headerContainer.getHeight();
        } else {
            yTranslate = 0;
        }
        TranslateAnimation bounceAnimation = new TranslateAnimation(0, 0.0f, 0, 0.0f, 0, 0.0f, 0, (float) yTranslate);
        bounceAnimation.setDuration(700);
        bounceAnimation.setFillEnabled(true);
        bounceAnimation.setFillAfter(false);
        bounceAnimation.setFillBefore(true);
        bounceAnimation.setInterpolator(new OvershootInterpolator(BOUNCE_OVERSHOOT_TENSION));
        bounceAnimation.setAnimationListener(new HeaderAnimationListener(yTranslate));
        startAnimation(bounceAnimation);
    }

    private void resetHeader() {
        if (getFirstVisiblePosition() > 0) {
            setHeaderPadding(-this.header.getHeight());
            setState(State.PULL_TO_REFRESH);
        } else if (getAnimation() == null || getAnimation().hasEnded()) {
            bounceBackHeader();
        } else {
            this.bounceBackHeader = true;
        }
    }

    private void setUiRefreshing() {
        this.spinner.setVisibility(0);
        this.image.clearAnimation();
        this.image.setVisibility(4);
        this.text.setText(this.refreshingText);
    }

    private void setState(State state) {
        this.state = state;
        switch (state) {
            case RELEASE_TO_REFRESH:
                this.spinner.setVisibility(4);
                this.image.setVisibility(0);
                this.text.setText(this.releaseToRefreshText);
                return;
            case PULL_TO_REFRESH:
                this.spinner.setVisibility(4);
                this.image.setVisibility(0);
                this.text.setText(this.pullToRefreshText);
                if (this.showLastUpdatedText && this.lastUpdated != -1) {
                    this.lastUpdatedTextView.setVisibility(0);
                    this.lastUpdatedTextView.setText(String.format(this.lastUpdatedText, new Object[]{this.lastUpdatedDateFormat.format(new Date(this.lastUpdated))}));
                    return;
                }
                return;
            case REFRESHING:
                setUiRefreshing();
                this.lastUpdated = System.currentTimeMillis();
                if (this.onRefreshListener == null) {
                    setState(State.PULL_TO_REFRESH);
                    return;
                } else {
                    this.onRefreshListener.onRefresh();
                    return;
                }
            default:
                return;
        }
    }

    protected void onScrollChanged(int l, int t, int oldl, int oldt) {
        super.onScrollChanged(l, t, oldl, oldt);
        if (!this.hasResetHeader) {
            if (measuredHeaderHeight > 0 && this.state != State.REFRESHING) {
                setHeaderPadding(-measuredHeaderHeight);
            }
            this.hasResetHeader = true;
        }
    }
}
