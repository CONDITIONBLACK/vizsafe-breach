package com.vizsafe.app.CustomViews;

import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnLayoutChangeListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.MarginLayoutParams;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;

public class PanAndZoomListener implements OnTouchListener {
    static final int DRAG = 1;
    static final int NONE = 0;
    private static final String TAG = "PanAndZoomListener";
    static final int ZOOM = 2;
    PointF mid = new PointF();
    int mode = 0;
    float oldDist = 1.0f;
    PanZoomCalculator panZoomCalculator;
    PointF start = new PointF();

    public static class Anchor {
        public static final int CENTER = 0;
        public static final int TOPLEFT = 1;
    }

    class PanZoomCalculator {
        int anchor;
        View child;
        PointF currentPan = new PointF(0.0f, 0.0f);
        float currentZoom = 1.0f;
        Matrix matrix;
        int panJitter = 0;
        View window;

        PanZoomCalculator(View container, View child, int anchor) {
            this.window = container;
            this.child = child;
            this.matrix = new Matrix();
            this.anchor = anchor;
            onPanZoomChanged();
            this.child.addOnLayoutChangeListener(new OnLayoutChangeListener(PanAndZoomListener.this) {
                public void onLayoutChange(View v, int left, int top, int right, int bottom, int oldLeft, int oldTop, int oldRight, int oldBottom) {
                    PanZoomCalculator.this.onPanZoomChanged();
                }
            });
        }

        public void doZoom(float scale, PointF zoomCenter) {
            float oldZoom = this.currentZoom;
            this.currentZoom *= scale;
            this.currentZoom = Math.max(getMinimumZoom(), this.currentZoom);
            this.currentZoom = Math.min(8.0f, this.currentZoom);
            float width = (float) this.window.getWidth();
            float height = (float) this.window.getHeight();
            float oldScaledWidth = width * oldZoom;
            float oldScaledHeight = height * oldZoom;
            float newScaledWidth = width * this.currentZoom;
            float newScaledHeight = height * this.currentZoom;
            float reqXPos;
            float reqYPos;
            float actualXPos;
            float actualYPos;
            PointF pointF;
            if (this.anchor == 0) {
                reqXPos = ((((oldScaledWidth - width) * 0.5f) + zoomCenter.x) - this.currentPan.x) / oldScaledWidth;
                reqYPos = ((((oldScaledHeight - height) * 0.5f) + zoomCenter.y) - this.currentPan.y) / oldScaledHeight;
                actualXPos = ((((newScaledWidth - width) * 0.5f) + zoomCenter.x) - this.currentPan.x) / newScaledWidth;
                actualYPos = ((((newScaledHeight - height) * 0.5f) + zoomCenter.y) - this.currentPan.y) / newScaledHeight;
                pointF = this.currentPan;
                pointF.x += (actualXPos - reqXPos) * newScaledWidth;
                pointF = this.currentPan;
                pointF.y += (actualYPos - reqYPos) * newScaledHeight;
            } else {
                reqXPos = (zoomCenter.x - this.currentPan.x) / oldScaledWidth;
                reqYPos = (zoomCenter.y - this.currentPan.y) / oldScaledHeight;
                actualXPos = (zoomCenter.x - this.currentPan.x) / newScaledWidth;
                actualYPos = (zoomCenter.y - this.currentPan.y) / newScaledHeight;
                pointF = this.currentPan;
                pointF.x += (actualXPos - reqXPos) * newScaledWidth;
                pointF = this.currentPan;
                pointF.y += (actualYPos - reqYPos) * newScaledHeight;
            }
            onPanZoomChanged();
        }

        public void doPan(float panX, float panY) {
            PointF pointF = this.currentPan;
            pointF.x += panX;
            pointF = this.currentPan;
            pointF.y += panY;
            onPanZoomChanged();
        }

        private float getMinimumZoom() {
            return 1.0f;
        }

        public void reset() {
            this.currentZoom = getMinimumZoom();
            this.currentPan = new PointF(0.0f, 0.0f);
            onPanZoomChanged();
        }

        public void onPanZoomChanged() {
            float winWidth = (float) this.window.getWidth();
            float winHeight = (float) this.window.getHeight();
            float maxPanX;
            float maxPanY;
            if (this.currentZoom <= 1.0f) {
                this.currentPan.x = 0.0f;
                this.currentPan.y = 0.0f;
            } else if (this.anchor == 0) {
                maxPanX = ((this.currentZoom - 1.0f) * ((float) this.window.getWidth())) * 0.5f;
                maxPanY = ((this.currentZoom - 1.0f) * ((float) this.window.getHeight())) * 0.5f;
                this.currentPan.x = Math.max(-maxPanX, Math.min(maxPanX, this.currentPan.x));
                this.currentPan.y = Math.max(-maxPanY, Math.min(maxPanY, this.currentPan.y));
            } else {
                maxPanX = (this.currentZoom - 1.0f) * ((float) this.window.getWidth());
                maxPanY = (this.currentZoom - 1.0f) * ((float) this.window.getHeight());
                this.currentPan.x = Math.max(-maxPanX, Math.min(0.0f, this.currentPan.x));
                this.currentPan.y = Math.max(-maxPanY, Math.min(0.0f, this.currentPan.y));
            }
            if ((this.child instanceof ImageView) && ((ImageView) this.child).getScaleType() == ScaleType.MATRIX) {
                Drawable drawable = this.child.getDrawable();
                if (drawable != null) {
                    Bitmap bm = ((BitmapDrawable) drawable).getBitmap();
                    if (bm != null) {
                        float bmWidth = (float) bm.getWidth();
                        float bmHeight = (float) bm.getHeight();
                        float fitToWindow = Math.min(winWidth / bmWidth, winHeight / bmHeight);
                        float xOffset = ((winWidth - (bmWidth * fitToWindow)) * 0.5f) * this.currentZoom;
                        float yOffset = ((winHeight - (bmHeight * fitToWindow)) * 0.5f) * this.currentZoom;
                        this.matrix.reset();
                        this.matrix.postScale(this.currentZoom * fitToWindow, this.currentZoom * fitToWindow);
                        this.matrix.postTranslate(this.currentPan.x + xOffset, this.currentPan.y + yOffset);
                        ((ImageView) this.child).setImageMatrix(this.matrix);
                        return;
                    }
                    return;
                }
                return;
            }
            MarginLayoutParams lp = (MarginLayoutParams) this.child.getLayoutParams();
            lp.leftMargin = ((int) this.currentPan.x) + this.panJitter;
            lp.topMargin = (int) this.currentPan.y;
            lp.width = (int) (((float) this.window.getWidth()) * this.currentZoom);
            lp.height = (int) (((float) this.window.getHeight()) * this.currentZoom);
            this.panJitter ^= 1;
            this.child.setLayoutParams(lp);
        }
    }

    public PanAndZoomListener(FrameLayout containter, View view, int anchor) {
        this.panZoomCalculator = new PanZoomCalculator(containter, view, anchor);
    }

    public boolean onTouch(View view, MotionEvent event) {
        switch (event.getAction() & 255) {
            case 0:
                this.start.set(event.getX(), event.getY());
                Log.d(TAG, "mode=DRAG");
                this.mode = 1;
                break;
            case 1:
            case 6:
                this.mode = 0;
                Log.d(TAG, "mode=NONE");
                break;
            case 2:
                if (this.mode != 1) {
                    if (this.mode == 2) {
                        float newDist = spacing(event);
                        Log.d(TAG, "newDist=" + newDist);
                        if (newDist > 10.0f) {
                            float scale = newDist / this.oldDist;
                            this.oldDist = newDist;
                            this.panZoomCalculator.doZoom(scale, this.mid);
                            break;
                        }
                    }
                }
                this.panZoomCalculator.doPan(event.getX() - this.start.x, event.getY() - this.start.y);
                this.start.set(event.getX(), event.getY());
                break;
                break;
            case 5:
                this.oldDist = spacing(event);
                Log.d(TAG, "oldDist=" + this.oldDist);
                if (this.oldDist > 10.0f) {
                    midPoint(this.mid, event);
                    this.mode = 2;
                    Log.d(TAG, "mode=ZOOM");
                    break;
                }
                break;
        }
        return true;
    }

    private float spacing(MotionEvent event) {
        float x = event.getX(0) - event.getX(1);
        float y = event.getY(0) - event.getY(1);
        return (float) Math.sqrt((double) ((x * x) + (y * y)));
    }

    private void midPoint(PointF point, MotionEvent event) {
        point.set((event.getX(0) + event.getX(1)) / 2.0f, (event.getY(0) + event.getY(1)) / 2.0f);
    }
}
