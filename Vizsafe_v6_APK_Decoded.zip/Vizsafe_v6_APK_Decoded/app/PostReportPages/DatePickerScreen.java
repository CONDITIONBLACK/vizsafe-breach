package com.vizsafe.app.PostReportPages;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;
import com.vizsafe.app.C0421R;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DatePickerScreen extends Activity {
    public static String currDate;
    public static boolean inDateTimePicker = false;
    String currentDate;
    private DatePicker datePicker;
    private int day;
    private int month;
    private TextView nextBtn;
    private TimePicker timePicker;
    private int year;

    /* renamed from: com.vizsafe.app.PostReportPages.DatePickerScreen$1 */
    class C03971 implements OnClickListener {
        C03971() {
        }

        public void onClick(View v) {
            DatePickerScreen.this.year = DatePickerScreen.this.datePicker.getYear();
            DatePickerScreen.this.month = DatePickerScreen.this.datePicker.getMonth() + 1;
            DatePickerScreen.this.day = DatePickerScreen.this.datePicker.getDayOfMonth();
            DatePickerScreen.this.currentDate = DatePickerScreen.this.month + " " + DatePickerScreen.this.day + ", " + DatePickerScreen.this.year;
            DateFormat dffrom = new SimpleDateFormat("MM dd, yyyy");
            DateFormat dfto = new SimpleDateFormat("MMM dd, yyyy");
            Date today = null;
            try {
                today = dffrom.parse(DatePickerScreen.this.currentDate);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            DatePickerScreen.currDate = dfto.format(today);
            DatePickerScreen.this.startActivity(new Intent(DatePickerScreen.this, TimePickerScreen.class));
            DatePickerScreen.this.finish();
            DatePickerScreen.inDateTimePicker = true;
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0421R.layout.date_time_picker_screen);
        this.nextBtn = (TextView) findViewById(C0421R.C0419id.action_bar_next);
        this.datePicker = (DatePicker) findViewById(C0421R.C0419id.datePicker1);
        this.timePicker = (TimePicker) findViewById(C0421R.C0419id.timePicker1);
        this.timePicker.setVisibility(8);
        Calendar c = Calendar.getInstance();
        this.year = c.get(1);
        this.month = c.get(2);
        this.day = c.get(5);
        this.datePicker.init(this.year, this.month, this.day, null);
        this.datePicker.setMaxDate(c.getTimeInMillis());
        this.nextBtn.setOnClickListener(new C03971());
    }
}
