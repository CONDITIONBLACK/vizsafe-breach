package com.vizsafe.app.PostReportPages;

import android.app.Activity;
import android.content.Intent;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.p001v4.app.ActivityCompat;
import android.support.p001v4.content.ContextCompat;
import android.support.p002v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnMapLongClickListener;
import com.google.android.gms.maps.GoogleMap.OnMyLocationButtonClickListener;
import com.google.android.gms.maps.GoogleMap.OnMyLocationClickListener;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition.Builder;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.analytics.FirebaseAnalytics.Param;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.HomePage.ReportPage;
import com.vizsafe.app.Utils.VizsafeGPSTracker;

public class SelectLocationScreen extends AppCompatActivity implements OnMyLocationButtonClickListener, OnMyLocationClickListener, OnMapReadyCallback, OnMapLongClickListener, ConnectionCallbacks, LocationListener {
    private static final String COURSE_LOCATION = "android.permission.ACCESS_COARSE_LOCATION";
    private static final float DEFAULT_ZOOM = 18.0f;
    private static final String FINE_LOCATION = "android.permission.ACCESS_FINE_LOCATION";
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1234;
    private static final String TAG = "MapActivity";
    public static double latitude = FirebaseRemoteConfig.DEFAULT_VALUE_FOR_DOUBLE;
    public static double longitude = FirebaseRemoteConfig.DEFAULT_VALUE_FOR_DOUBLE;
    public static SelectLocationScreen mSelectLocationScreen;
    private ImageView backBtn;
    private VizsafeGPSTracker gps;
    private boolean gps_enabled;
    TextView locationText;
    private FusedLocationProviderClient mFusedLocationProviderClient;
    GoogleApiClient mGoogleApiClient;
    Location mLastLocation;
    private Boolean mLocationPermissionsGranted = Boolean.valueOf(false);
    LocationRequest mLocationRequest;
    private GoogleMap mMap;
    Marker marker = null;
    TextView saveBtn;

    /* renamed from: com.vizsafe.app.PostReportPages.SelectLocationScreen$1 */
    class C04141 implements OnClickListener {
        C04141() {
        }

        public void onClick(View v) {
            SelectLocationScreen.this.finish();
        }
    }

    /* renamed from: com.vizsafe.app.PostReportPages.SelectLocationScreen$2 */
    class C04152 implements OnClickListener {
        C04152() {
        }

        public void onClick(View v) {
            Intent goToPostFeed;
            if (SelectLocationScreen.this.marker == null) {
                Toast.makeText(SelectLocationScreen.this, SelectLocationScreen.this.getString(C0421R.string.select_location_first), 1).show();
            } else if (DatePickerScreen.inDateTimePicker) {
                goToPostFeed = new Intent(SelectLocationScreen.this, PostFeedScreen.class);
                goToPostFeed.putExtra(ReportPage.KEY_FOR_POST_FEED, ReportPage.PATH);
                SelectLocationScreen.this.startActivity(goToPostFeed);
                DatePickerScreen.inDateTimePicker = false;
                SelectLocationScreen.this.finish();
            } else {
                goToPostFeed = new Intent(SelectLocationScreen.this, PostFeedScreen.class);
                String setTime = SelectLocationScreen.this.getIntent().getExtras().getString(ReportPage.CURRENT_TIME);
                String setDate = SelectLocationScreen.this.getIntent().getExtras().getString(ReportPage.CURRENT_DATE);
                goToPostFeed.putExtra(ReportPage.CURRENT_TIME, setTime);
                goToPostFeed.putExtra(ReportPage.CURRENT_DATE, setDate);
                goToPostFeed.putExtra(ReportPage.KEY_FOR_POST_FEED, ReportPage.PATH);
                SelectLocationScreen.this.startActivity(goToPostFeed);
                SelectLocationScreen.this.finish();
            }
        }
    }

    /* renamed from: com.vizsafe.app.PostReportPages.SelectLocationScreen$3 */
    class C04163 implements OnCompleteListener {
        C04163() {
        }

        public void onComplete(@NonNull Task task) {
            if (task.isSuccessful()) {
                Log.d(SelectLocationScreen.TAG, "onComplete: found location!");
                Location currentLocation = (Location) task.getResult();
                if (currentLocation != null) {
                    SelectLocationScreen.this.moveCamera(new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude()), SelectLocationScreen.DEFAULT_ZOOM);
                    return;
                }
                return;
            }
            Log.d(SelectLocationScreen.TAG, "onComplete: current location is null");
            Toast.makeText(SelectLocationScreen.this, "unable to get current location", 0).show();
        }
    }

    @RequiresApi(api = 23)
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0421R.layout.activity_select_location);
        mSelectLocationScreen = this;
        this.saveBtn = (TextView) findViewById(C0421R.C0419id.action_bar_next);
        this.backBtn = (ImageView) findViewById(C0421R.C0419id.action_bar_back);
        this.saveBtn.setVisibility(0);
        this.gps = new VizsafeGPSTracker(getApplicationContext());
        this.gps_enabled = ((LocationManager) getApplicationContext().getSystemService(Param.LOCATION)).isProviderEnabled("gps");
        getLocationPermission();
        ((SupportMapFragment) getSupportFragmentManager().findFragmentById(C0421R.C0419id.map)).getMapAsync(this);
        this.backBtn.setOnClickListener(new C04141());
        this.saveBtn.setOnClickListener(new C04152());
    }

    protected void onStart() {
        super.onStart();
    }

    protected void onStop() {
        super.onStop();
    }

    public void onMapLongClick(LatLng point) {
        if (this.marker != null) {
            this.marker.remove();
        }
        BitmapDescriptor icon = BitmapDescriptorFactory.fromResource(C0421R.C0418drawable.marker_report_map);
        MarkerOptions markerOption = new MarkerOptions();
        markerOption.position(point).icon(icon);
        this.marker = this.mMap.addMarker(markerOption);
        latitude = point.latitude;
        longitude = point.longitude;
        ReportPage.LATITUDE = String.valueOf(latitude);
        ReportPage.LONGITUDE = String.valueOf(longitude);
    }

    public boolean onMyLocationButtonClick() {
        return false;
    }

    public void onMyLocationClick(@NonNull Location location) {
        latitude = location.getLatitude();
        longitude = location.getLongitude();
        if (this.marker != null) {
            this.marker.remove();
        }
        BitmapDescriptor icon = BitmapDescriptorFactory.fromResource(C0421R.C0418drawable.marker_report_map);
        MarkerOptions markerOption = new MarkerOptions();
        markerOption.position(new LatLng(latitude, longitude)).icon(icon);
        this.marker = this.mMap.addMarker(markerOption);
        ReportPage.LATITUDE = String.valueOf(latitude);
        ReportPage.LONGITUDE = String.valueOf(longitude);
    }

    @RequiresApi(api = 23)
    private boolean getLocationPermission() {
        Log.d(TAG, "getLocationPermission: getting location permissions");
        if (ContextCompat.checkSelfPermission(this, COURSE_LOCATION) == 0) {
            return true;
        }
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, COURSE_LOCATION)) {
            requestPermissions(new String[]{COURSE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
            return false;
        }
        requestPermissions(new String[]{COURSE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
        return false;
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case LOCATION_PERMISSION_REQUEST_CODE /*1234*/:
                if (grantResults.length > 0 && grantResults[0] == 0 && ContextCompat.checkSelfPermission(this, COURSE_LOCATION) == 0) {
                    if (this.mGoogleApiClient == null) {
                        buildGoogleApiClient();
                    }
                    this.mMap.setMyLocationEnabled(true);
                    return;
                }
                return;
            default:
                return;
        }
    }

    private void moveCamera(LatLng latLng, float zoom) {
        Log.d(TAG, "moveCamera: moving the camera to: lat: " + latLng.latitude + ", lng: " + latLng.longitude);
        this.mMap.animateCamera(CameraUpdateFactory.newCameraPosition(new Builder().target(latLng).tilt(0.0f).zoom(zoom).bearing(0.0f).build()));
        latitude = latLng.latitude;
        longitude = latLng.longitude;
        if (this.marker != null) {
            this.marker.remove();
        }
        BitmapDescriptor icon = BitmapDescriptorFactory.fromResource(C0421R.C0418drawable.marker_report_map);
        MarkerOptions markerOption = new MarkerOptions();
        markerOption.position(new LatLng(latitude, longitude)).icon(icon);
        this.marker = this.mMap.addMarker(markerOption);
        ReportPage.LATITUDE = String.valueOf(latitude);
        ReportPage.LONGITUDE = String.valueOf(longitude);
    }

    private void getDeviceLocation() {
        Log.d(TAG, "getDeviceLocation: getting the devices current location");
        this.mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient((Activity) this);
        try {
            if (this.mLocationPermissionsGranted.booleanValue()) {
                this.mFusedLocationProviderClient.getLastLocation().addOnCompleteListener(new C04163());
            }
        } catch (SecurityException e) {
            Log.e(TAG, "getDeviceLocation: SecurityException: " + e.getMessage());
        }
    }

    public void onMapReady(GoogleMap googleMap) {
        Log.d(TAG, "onMapReady: map is ready");
        this.mMap = googleMap;
        if (VERSION.SDK_INT < 23) {
            buildGoogleApiClient();
            this.mMap.setMapType(4);
            googleMap.getUiSettings().setZoomControlsEnabled(true);
            googleMap.setTrafficEnabled(true);
            this.mMap.setMyLocationEnabled(true);
            this.mMap.setOnMyLocationButtonClickListener(this);
            this.mMap.setOnMyLocationClickListener(this);
            this.mMap.setOnMapLongClickListener(this);
        } else if (ContextCompat.checkSelfPermission(this, COURSE_LOCATION) == 0) {
            buildGoogleApiClient();
            this.mMap.setMapType(4);
            googleMap.getUiSettings().setZoomControlsEnabled(true);
            googleMap.setTrafficEnabled(true);
            this.mMap.setMyLocationEnabled(true);
            this.mMap.setOnMyLocationButtonClickListener(this);
            this.mMap.setOnMyLocationClickListener(this);
            this.mMap.setOnMapLongClickListener(this);
        }
    }

    protected synchronized void buildGoogleApiClient() {
        this.mGoogleApiClient = new GoogleApiClient.Builder(this).addConnectionCallbacks(this).addApi(LocationServices.API).build();
        this.mGoogleApiClient.connect();
    }

    protected void onResume() {
        super.onResume();
    }

    public void onConnected(@Nullable Bundle bundle) {
        this.mLocationRequest = new LocationRequest();
        this.mLocationRequest.setInterval(2000);
        if (ContextCompat.checkSelfPermission(this, COURSE_LOCATION) == 0) {
            LocationServices.FusedLocationApi.requestLocationUpdates(this.mGoogleApiClient, this.mLocationRequest, (LocationListener) this);
        }
    }

    public void onConnectionSuspended(int i) {
    }

    public void onLocationChanged(Location location) {
        if (!(location == null || this.mLocationPermissionsGranted.booleanValue())) {
            this.mLocationPermissionsGranted = Boolean.valueOf(true);
            getDeviceLocation();
        }
        if (this.mGoogleApiClient != null) {
            LocationServices.FusedLocationApi.removeLocationUpdates(this.mGoogleApiClient, (LocationListener) this);
        }
    }

    protected void onDestroy() {
        super.onDestroy();
        if (this.mGoogleApiClient != null) {
            LocationServices.FusedLocationApi.removeLocationUpdates(this.mGoogleApiClient, (LocationListener) this);
        }
    }
}
