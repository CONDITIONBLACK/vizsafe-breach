package com.vizsafe.app.PostReportPages;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.location.LocationManager;
import android.media.ExifInterface;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Environment;
import android.support.p002v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.analytics.ecommerce.ProductAction;
import com.vizsafe.app.APIClientMethods.GetLocationAddressApi;
import com.vizsafe.app.APIClientMethods.GetLocationAddressApi.ResponseGetLocationAddressApi;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.CustomViews.ScrollingTextView;
import com.vizsafe.app.GCMIntentService.GCMClientManager;
import com.vizsafe.app.HomePage.ReportPage;
import com.vizsafe.app.Utils.CommonMember;
import com.vizsafe.app.Utils.PreferenceHandler;
import com.vizsafe.app.Utils.VizsafeConfigFile;
import com.vizsafe.app.Utils.Webservice;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class PostFeedScreen extends AppCompatActivity implements OnItemSelectedListener {
    public static String mCity;
    public static String mCountry;
    public static String mState;
    public static PostFeedScreen postFeedScreen;
    boolean TextOnly = false;
    private ImageView anonymousImage;
    boolean anonymousStatus = false;
    private ImageView cancelBtn;
    private String cityString;
    private String countryString;
    private TextView currentDate;
    ScrollingTextView currentLocation;
    private TextView currentTime;
    private String date;
    private String dateAndTime;
    long dateAndTimeInMilliseconds;
    private String exifOrientation;
    private String formattedAddress;
    private ExifInterface interfaceExif = null;
    private String lat;
    private String latitude;
    double latitudeValue;
    private String lng;
    protected LocationManager locationManager;
    private String longitude;
    double longitudeValue;
    private double mAltitude;
    private String mAltitudeValue;
    private Integer mCommunitySelectedValue = Integer.valueOf(0);
    private ArrayList<Integer> mDrawingIdList = new ArrayList();
    private ArrayList<String> mDrawingNameList = new ArrayList();
    private Integer mDrawingSelectedValue = Integer.valueOf(0);
    private ArrayAdapter<String> mDrawingSpinnerAdapter;
    private Spinner mDrawingValues;
    private String mErrorMsg = "null";
    private Integer mLevelSelectedValue = Integer.valueOf(0);
    private ArrayAdapter<String> mLevelSpinnerAdapter;
    private Spinner mLevelValues;
    private ArrayList<String> mPlaceIdList = new ArrayList();
    private ArrayList<String> mPlaceNameList = new ArrayList();
    private ArrayList<Integer> mSelectedArraylist;
    private ArrayList<String> mSelectedNameArraylist;
    private LinearLayout mSeverityLayout;
    private CheckBox mSeverityLevel1_CB;
    private CheckBox mSeverityLevel2_CB;
    private CheckBox mSeverityLevel3_CB;
    private String mSeverityLevelValue = "0";
    private boolean mSpinnerClicked = false;
    private String mStadiumCommunityIdFromConfigFile = null;
    private String mStadiumNameFromConfigFile;
    private LinearLayout mStadiumViewLayout;
    private AlertDialog mTransparentProgressDialog;
    private TextView mVenueNameTV;
    private ArrayList<String> mlevelIdList = new ArrayList();
    private ArrayList<ArrayList<Integer>> mlevelIdWholeList = new ArrayList();
    private ArrayList<ArrayList<String>> mlevelNameWholeList = new ArrayList();
    private Bitmap myBitmap;
    private TextView nextBtn;
    private String pathOfFile;
    private EditText postDescription;
    private ImageView postImage;
    private String postType = "photo";
    private String postalCode;
    float rotationDegree;
    private String stateString;
    private String status;
    private String time;

    /* renamed from: com.vizsafe.app.PostReportPages.PostFeedScreen$1 */
    class C03981 implements OnCheckedChangeListener {
        C03981() {
        }

        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            if (isChecked) {
                PostFeedScreen.this.mSeverityLevelValue = "1";
                PostFeedScreen.this.mSeverityLevel2_CB.setChecked(false);
                PostFeedScreen.this.mSeverityLevel3_CB.setChecked(false);
            }
        }
    }

    /* renamed from: com.vizsafe.app.PostReportPages.PostFeedScreen$2 */
    class C03992 implements OnCheckedChangeListener {
        C03992() {
        }

        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            if (isChecked) {
                PostFeedScreen.this.mSeverityLevelValue = "2";
                PostFeedScreen.this.mSeverityLevel1_CB.setChecked(false);
                PostFeedScreen.this.mSeverityLevel3_CB.setChecked(false);
            }
        }
    }

    /* renamed from: com.vizsafe.app.PostReportPages.PostFeedScreen$3 */
    class C04003 implements OnCheckedChangeListener {
        C04003() {
        }

        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            if (isChecked) {
                PostFeedScreen.this.mSeverityLevelValue = "3";
                PostFeedScreen.this.mSeverityLevel1_CB.setChecked(false);
                PostFeedScreen.this.mSeverityLevel2_CB.setChecked(false);
            }
        }
    }

    /* renamed from: com.vizsafe.app.PostReportPages.PostFeedScreen$4 */
    class C04014 implements OnClickListener {
        C04014() {
        }

        public void onClick(View v) {
            if (PostFeedScreen.this.anonymousStatus) {
                PostFeedScreen.this.anonymousImage.setImageResource(C0421R.C0418drawable.checkbox_unchecked_white);
                PostFeedScreen.this.anonymousStatus = false;
                return;
            }
            PostFeedScreen.this.anonymousImage.setImageResource(C0421R.C0418drawable.checkbox_checked_white);
            PostFeedScreen.this.anonymousStatus = true;
        }
    }

    /* renamed from: com.vizsafe.app.PostReportPages.PostFeedScreen$5 */
    class C04025 implements OnClickListener {
        C04025() {
        }

        public void onClick(View v) {
            Intent goToChannelScreen;
            if (PostFeedScreen.this.TextOnly) {
                Bitmap myBitmap = BitmapFactory.decodeResource(PostFeedScreen.this.getResources(), C0421R.C0418drawable.text_vizsafe_new);
                File directory = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/VizsafeImages");
                directory.mkdirs();
                File yourFile = new File(directory, "TextOnlyImageNew.PNG");
                try {
                    FileOutputStream outStream = new FileOutputStream(yourFile);
                    myBitmap.compress(CompressFormat.PNG, 100, outStream);
                    outStream.flush();
                    outStream.close();
                    PostFeedScreen.this.pathOfFile = yourFile.getPath();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                goToChannelScreen = new Intent(PostFeedScreen.this, SelectChannelToPost.class);
                goToChannelScreen.putExtra("post_type", PostFeedScreen.this.postType);
                goToChannelScreen.putExtra("post_image_data", PostFeedScreen.this.pathOfFile);
                goToChannelScreen.putExtra("post_latitude", PostFeedScreen.this.latitude);
                goToChannelScreen.putExtra("post_longitude", PostFeedScreen.this.longitude);
                goToChannelScreen.putExtra("Altitude", String.valueOf(PostFeedScreen.this.mAltitude));
                goToChannelScreen.putExtra("post_description", PostFeedScreen.this.postDescription.getText().toString().trim());
                goToChannelScreen.putExtra("post_timestamp", String.valueOf(PostFeedScreen.this.dateAndTimeInMilliseconds));
                goToChannelScreen.putExtra("post_anonymous", String.valueOf(PostFeedScreen.this.anonymousStatus));
                goToChannelScreen.putExtra("severity", PostFeedScreen.this.mSeverityLevelValue);
                if (!(PostFeedScreen.this.mCommunitySelectedValue.intValue() == 0 || PostFeedScreen.this.mDrawingSelectedValue.intValue() == 0 || PostFeedScreen.this.mLevelSelectedValue.intValue() == 0)) {
                    goToChannelScreen.putExtra("mCommunitySelectedValue", PostFeedScreen.this.mCommunitySelectedValue);
                    goToChannelScreen.putExtra("mDrawingSelectedValue", PostFeedScreen.this.mDrawingSelectedValue);
                    goToChannelScreen.putExtra("mLevelSelectedValue", PostFeedScreen.this.mLevelSelectedValue);
                }
                PostFeedScreen.this.startActivity(goToChannelScreen);
                return;
            }
            goToChannelScreen = new Intent(PostFeedScreen.this, SelectChannelToPost.class);
            goToChannelScreen.putExtra("post_type", PostFeedScreen.this.postType);
            goToChannelScreen.putExtra("post_image_data", PostFeedScreen.this.pathOfFile);
            goToChannelScreen.putExtra("post_latitude", PostFeedScreen.this.latitude);
            goToChannelScreen.putExtra("post_longitude", PostFeedScreen.this.longitude);
            goToChannelScreen.putExtra("Altitude", String.valueOf(PostFeedScreen.this.mAltitude));
            goToChannelScreen.putExtra("post_description", PostFeedScreen.this.postDescription.getText().toString().trim());
            goToChannelScreen.putExtra("post_timestamp", String.valueOf(PostFeedScreen.this.dateAndTimeInMilliseconds));
            goToChannelScreen.putExtra("post_anonymous", String.valueOf(PostFeedScreen.this.anonymousStatus));
            goToChannelScreen.putExtra("severity", PostFeedScreen.this.mSeverityLevelValue);
            if (!(PostFeedScreen.this.mCommunitySelectedValue.intValue() == 0 || PostFeedScreen.this.mDrawingSelectedValue.intValue() == 0 || PostFeedScreen.this.mLevelSelectedValue.intValue() == 0)) {
                goToChannelScreen.putExtra("mCommunitySelectedValue", PostFeedScreen.this.mCommunitySelectedValue);
                goToChannelScreen.putExtra("mDrawingSelectedValue", PostFeedScreen.this.mDrawingSelectedValue);
                goToChannelScreen.putExtra("mLevelSelectedValue", PostFeedScreen.this.mLevelSelectedValue);
            }
            PostFeedScreen.this.startActivity(goToChannelScreen);
        }
    }

    /* renamed from: com.vizsafe.app.PostReportPages.PostFeedScreen$6 */
    class C04036 implements OnClickListener {
        C04036() {
        }

        public void onClick(View v) {
            ReportPage.TEXT_ONLY = false;
            View view = PostFeedScreen.this.getCurrentFocus();
            if (view != null) {
                ((InputMethodManager) PostFeedScreen.this.getSystemService("input_method")).hideSoftInputFromWindow(view.getWindowToken(), 0);
            }
            PostFeedScreen.this.mSeverityLevelValue = null;
            PostFeedScreen.this.finish();
        }
    }

    /* renamed from: com.vizsafe.app.PostReportPages.PostFeedScreen$7 */
    class C04047 implements Callback<ResponseGetLocationAddressApi> {
        C04047() {
        }

        public void success(ResponseGetLocationAddressApi responseGetLocationAddressApi, Response response) {
            if (responseGetLocationAddressApi != null) {
                PostFeedScreen.mCountry = responseGetLocationAddressApi.getDetail().getCountry();
                PostFeedScreen.mState = responseGetLocationAddressApi.getDetail().getState();
                PostFeedScreen.mCity = responseGetLocationAddressApi.getDetail().getCity();
                PostFeedScreen.this.postalCode = responseGetLocationAddressApi.getDetail().getZipcode();
                String mCountrycode = responseGetLocationAddressApi.getDetail().getCountrycode();
                if (PostFeedScreen.this.postalCode != null) {
                    for (int count = 0; count < VizsafeConfigFile.mZipCode.length; count++) {
                        if (PostFeedScreen.this.postalCode.equals(VizsafeConfigFile.mZipCode[count])) {
                            PostFeedScreen.this.mStadiumNameFromConfigFile = VizsafeConfigFile.mStadiumName[count];
                            PostFeedScreen.this.mStadiumCommunityIdFromConfigFile = VizsafeConfigFile.mStadiumCommunityId[count];
                            if (CommonMember.isNetworkOnline((ConnectivityManager) PostFeedScreen.this.getSystemService("connectivity"), PostFeedScreen.this)) {
                                new AsyncTaskGetMicelloIndoorMapsList(PostFeedScreen.this, null).execute(new String[0]);
                                return;
                            }
                            return;
                        }
                    }
                    return;
                }
                return;
            }
            Toast.makeText(PostFeedScreen.this.getApplicationContext(), PostFeedScreen.this.getResources().getString(C0421R.string.unable_to_sign_up), 1).show();
            PostFeedScreen.this.finish();
        }

        public void failure(RetrofitError error) {
            Toast.makeText(PostFeedScreen.this.getApplicationContext(), PostFeedScreen.this.getResources().getString(C0421R.string.ActivateNetworkTxt), 1).show();
            PostFeedScreen.this.finish();
            error.printStackTrace();
        }
    }

    /* renamed from: com.vizsafe.app.PostReportPages.PostFeedScreen$8 */
    class C04058 implements Callback<ResponseGetLocationAddressApi> {
        C04058() {
        }

        public void success(ResponseGetLocationAddressApi responseGetLocationAddressApi, Response response) {
            PostFeedScreen.this.mTransparentProgressDialog.dismiss();
            if (responseGetLocationAddressApi != null) {
                PostFeedScreen.this.countryString = responseGetLocationAddressApi.getDetail().getCountry();
                PostFeedScreen.this.stateString = responseGetLocationAddressApi.getDetail().getState();
                PostFeedScreen.this.cityString = responseGetLocationAddressApi.getDetail().getCity();
                if (PostFeedScreen.this.cityString != null) {
                    PostFeedScreen.this.currentLocation.setText(PostFeedScreen.this.cityString + ", " + PostFeedScreen.this.stateString + ", " + PostFeedScreen.this.countryString);
                    return;
                } else if (PostFeedScreen.this.stateString != null) {
                    PostFeedScreen.this.currentLocation.setText(PostFeedScreen.this.stateString + ", " + PostFeedScreen.this.countryString);
                    return;
                } else if (PostFeedScreen.this.countryString != null) {
                    PostFeedScreen.this.currentLocation.setText(PostFeedScreen.this.countryString);
                    return;
                } else {
                    return;
                }
            }
            PostFeedScreen.this.currentLocation.setText(PostFeedScreen.this.getString(C0421R.string.unknown_location));
        }

        public void failure(RetrofitError error) {
            PostFeedScreen.this.mTransparentProgressDialog.dismiss();
            error.printStackTrace();
        }
    }

    private class AsyncTaskCheckUserGroupExisting extends AsyncTask<String, String, JSONObject> {
        JSONObject response;

        private AsyncTaskCheckUserGroupExisting() {
            this.response = null;
        }

        /* synthetic */ AsyncTaskCheckUserGroupExisting(PostFeedScreen x0, C03981 x1) {
            this();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            PostFeedScreen.this.mTransparentProgressDialog.show();
        }

        protected JSONObject doInBackground(String... arg0) {
            String email = PreferenceHandler.getInstance(PostFeedScreen.postFeedScreen).getUserName();
            String password = PreferenceHandler.getInstance(PostFeedScreen.postFeedScreen).getPassword();
            String useruuid = PreferenceHandler.getInstance(PostFeedScreen.postFeedScreen).getUserUUID();
            Webservice mWebservice = new Webservice();
            try {
                this.response = Webservice.CheckUserGroupExistingWebService(PostFeedScreen.this.getApplicationContext(), email, password, useruuid);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return this.response;
        }

        protected void onPostExecute(JSONObject mResponse) {
            PostFeedScreen.this.mTransparentProgressDialog.dismiss();
            if (mResponse != null) {
                try {
                    int httpCode = mResponse.getInt("httpCode");
                    String mMessage = mResponse.getString(GCMClientManager.EXTRA_MESSAGE);
                    if (Boolean.valueOf(mResponse.getBoolean(ProductAction.ACTION_DETAIL)).booleanValue()) {
                        PostFeedScreen.this.mSeverityLayout.setVisibility(0);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private class AsyncTaskGetMicelloIndoorMapsList extends AsyncTask<String, String, JSONObject> {
        JSONObject mDrawingListObject;
        JSONArray mDrawingsListArray;
        JSONArray mLevelListArray;
        JSONObject mLevelListObject;
        JSONArray mMapsListArray;
        JSONObject mMapsListObject;
        JSONObject response;

        private AsyncTaskGetMicelloIndoorMapsList() {
            this.response = null;
            this.mMapsListArray = null;
            this.mMapsListObject = null;
            this.mDrawingListObject = null;
            this.mDrawingsListArray = null;
            this.mLevelListObject = null;
            this.mLevelListArray = null;
        }

        /* synthetic */ AsyncTaskGetMicelloIndoorMapsList(PostFeedScreen x0, C03981 x1) {
            this();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            PostFeedScreen.this.mTransparentProgressDialog.show();
        }

        protected JSONObject doInBackground(String... arg0) {
            String email = PreferenceHandler.getInstance(PostFeedScreen.postFeedScreen).getUserName();
            String password = PreferenceHandler.getInstance(PostFeedScreen.postFeedScreen).getPassword();
            try {
                this.response = new Webservice().GetMicelloIndoorMapsListWebService(PostFeedScreen.this.getApplicationContext(), email, password);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return this.response;
        }

        protected void onPostExecute(JSONObject mResponse) {
            if (mResponse != null) {
                try {
                    int mTotal = mResponse.getInt("total");
                    if (mTotal > 0) {
                        this.mMapsListArray = mResponse.getJSONArray("floorplans");
                        if (this.mMapsListArray != null) {
                            int mMap_community_id = 0;
                            String indoor_map_name = null;
                            for (int i = 0; i < mTotal; i++) {
                                this.mMapsListObject = this.mMapsListArray.getJSONObject(i);
                                mMap_community_id = this.mMapsListObject.getInt("map_community_id");
                                indoor_map_name = this.mMapsListObject.getString("indoor_map_name");
                                PostFeedScreen.this.mPlaceNameList.add(String.valueOf(indoor_map_name));
                                PostFeedScreen.this.mPlaceIdList.add(String.valueOf(mMap_community_id));
                                if (this.mMapsListObject.has("map_drawing_id")) {
                                    this.mMapsListObject.getInt("map_drawing_id");
                                }
                                if (this.mMapsListObject.has("map_level_id")) {
                                    this.mMapsListObject.getInt("map_level_id");
                                }
                                if (Integer.parseInt(PostFeedScreen.this.mStadiumCommunityIdFromConfigFile) == mMap_community_id) {
                                    PostFeedScreen.this.mCommunitySelectedValue = Integer.valueOf(mMap_community_id);
                                    if (this.mMapsListObject.has("drawings")) {
                                        this.mDrawingsListArray = this.mMapsListObject.getJSONArray("drawings");
                                        for (int j = 0; j < this.mDrawingsListArray.length(); j++) {
                                            int map_drawing_id;
                                            this.mDrawingListObject = this.mDrawingsListArray.getJSONObject(j);
                                            if (this.mDrawingListObject.has("map_drawing_id")) {
                                                map_drawing_id = this.mDrawingListObject.getInt("map_drawing_id");
                                            } else {
                                                map_drawing_id = Integer.parseInt(String.valueOf(j));
                                            }
                                            if (this.mDrawingListObject.has("map_drawing_name")) {
                                                PostFeedScreen.this.mDrawingNameList.add(this.mDrawingListObject.getString("map_drawing_name"));
                                            } else {
                                                PostFeedScreen.this.mDrawingNameList.add(String.valueOf(j));
                                            }
                                            PostFeedScreen.this.mDrawingIdList.add(Integer.valueOf(map_drawing_id));
                                            this.mLevelListArray = this.mDrawingListObject.getJSONArray("levels");
                                            ArrayList<Integer> mLevelIdArrayList = new ArrayList();
                                            ArrayList<String> mLevelNameArrayList = new ArrayList();
                                            for (int k = 0; k < this.mLevelListArray.length(); k++) {
                                                int map_level_id;
                                                String map_level_name;
                                                this.mLevelListObject = this.mLevelListArray.getJSONObject(k);
                                                if (this.mLevelListObject.has("map_level_id")) {
                                                    map_level_id = this.mLevelListObject.getInt("map_level_id");
                                                } else {
                                                    map_level_id = Integer.parseInt(String.valueOf(k));
                                                }
                                                if (this.mLevelListObject.has("map_level_name")) {
                                                    map_level_name = this.mLevelListObject.getString("map_level_name");
                                                } else {
                                                    map_level_name = String.valueOf(Integer.parseInt(String.valueOf(k)));
                                                }
                                                mLevelIdArrayList.add(Integer.valueOf(map_level_id));
                                                mLevelNameArrayList.add(map_level_name);
                                            }
                                            PostFeedScreen.this.mlevelIdWholeList.add(mLevelIdArrayList);
                                            PostFeedScreen.this.mlevelNameWholeList.add(mLevelNameArrayList);
                                        }
                                    }
                                }
                                if (Integer.parseInt(PostFeedScreen.this.mStadiumCommunityIdFromConfigFile) == mMap_community_id) {
                                    break;
                                }
                            }
                            if (PostFeedScreen.this.mTransparentProgressDialog.isShowing()) {
                                PostFeedScreen.this.mTransparentProgressDialog.dismiss();
                            }
                            if (Integer.parseInt(PostFeedScreen.this.mStadiumCommunityIdFromConfigFile) == mMap_community_id && PostFeedScreen.this.mDrawingIdList.size() > 0) {
                                PostFeedScreen.this.mStadiumViewLayout.setVisibility(0);
                                PostFeedScreen.this.mVenueNameTV.setText(indoor_map_name);
                            }
                            PostFeedScreen.this.mDrawingSpinnerAdapter = new ArrayAdapter(PostFeedScreen.this, C0421R.layout.spinner_item, PostFeedScreen.this.mDrawingNameList);
                            PostFeedScreen.this.mDrawingSpinnerAdapter.setDropDownViewResource(17367049);
                            PostFeedScreen.this.mDrawingValues.setAdapter(PostFeedScreen.this.mDrawingSpinnerAdapter);
                            PostFeedScreen.this.mDrawingValues.setSelection(0);
                        } else if (PostFeedScreen.this.mTransparentProgressDialog.isShowing()) {
                            PostFeedScreen.this.mTransparentProgressDialog.dismiss();
                        }
                    } else if (PostFeedScreen.this.mTransparentProgressDialog.isShowing()) {
                        PostFeedScreen.this.mTransparentProgressDialog.dismiss();
                    }
                } catch (JSONException e) {
                    if (PostFeedScreen.this.mTransparentProgressDialog.isShowing()) {
                        PostFeedScreen.this.mTransparentProgressDialog.dismiss();
                    }
                    e.printStackTrace();
                }
            } else if (PostFeedScreen.this.mTransparentProgressDialog.isShowing()) {
                PostFeedScreen.this.mTransparentProgressDialog.dismiss();
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:58:0x0521  */
    /* JADX WARNING: Removed duplicated region for block: B:66:0x0569  */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x02be  */
    /* JADX WARNING: Removed duplicated region for block: B:87:0x068f  */
    /* JADX WARNING: Removed duplicated region for block: B:28:0x033b  */
    /* JADX WARNING: Removed duplicated region for block: B:89:0x06d6 A:{SYNTHETIC, Splitter:B:89:0x06d6} */
    /* JADX WARNING: Removed duplicated region for block: B:37:0x03c6 A:{Catch:{ ParseException -> 0x06e2 }} */
    /* JADX WARNING: Removed duplicated region for block: B:58:0x0521  */
    /* JADX WARNING: Removed duplicated region for block: B:61:0x0547  */
    /* JADX WARNING: Removed duplicated region for block: B:73:0x05e1  */
    /* JADX WARNING: Removed duplicated region for block: B:78:0x060f  */
    /* JADX WARNING: Removed duplicated region for block: B:66:0x0569  */
    /* JADX WARNING: Removed duplicated region for block: B:10:0x025a  */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x02be  */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x030f  */
    /* JADX WARNING: Removed duplicated region for block: B:28:0x033b  */
    /* JADX WARNING: Removed duplicated region for block: B:87:0x068f  */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x035c A:{SKIP} */
    /* JADX WARNING: Removed duplicated region for block: B:37:0x03c6 A:{Catch:{ ParseException -> 0x06e2 }} */
    /* JADX WARNING: Removed duplicated region for block: B:89:0x06d6 A:{SYNTHETIC, Splitter:B:89:0x06d6} */
    protected void onCreate(android.os.Bundle r35) {
        /*
        r34 = this;
        super.onCreate(r35);
        r28 = r34.getWindow();
        r29 = 16;
        r28.setSoftInputMode(r29);
        r28 = 2130968694; // 0x7f040076 float:1.7546049E38 double:1.052838424E-314;
        r0 = r34;
        r1 = r28;
        r0.setContentView(r1);
        postFeedScreen = r34;
        r28 = new dmax.dialog.SpotsDialog;
        r29 = postFeedScreen;
        r30 = r34.getResources();
        r31 = 2131230948; // 0x7f0800e4 float:1.8077963E38 double:1.052967995E-314;
        r30 = r30.getString(r31);
        r28.<init>(r29, r30);
        r0 = r28;
        r1 = r34;
        r1.mTransparentProgressDialog = r0;
        r0 = r34;
        r0 = r0.mTransparentProgressDialog;
        r28 = r0;
        r29 = 0;
        r28.setCanceledOnTouchOutside(r29);
        r0 = r34;
        r0 = r0.mTransparentProgressDialog;
        r28 = r0;
        r29 = 0;
        r28.setCancelable(r29);
        r28 = 2131689861; // 0x7f0f0185 float:1.900875E38 double:1.053194728E-314;
        r0 = r34;
        r1 = r28;
        r28 = r0.findViewById(r1);
        r28 = (android.widget.TextView) r28;
        r0 = r28;
        r1 = r34;
        r1.nextBtn = r0;
        r28 = 2131689860; // 0x7f0f0184 float:1.9008747E38 double:1.0531947274E-314;
        r0 = r34;
        r1 = r28;
        r28 = r0.findViewById(r1);
        r28 = (android.widget.ImageView) r28;
        r0 = r28;
        r1 = r34;
        r1.cancelBtn = r0;
        r28 = 2131690009; // 0x7f0f0219 float:1.900905E38 double:1.053194801E-314;
        r0 = r34;
        r1 = r28;
        r28 = r0.findViewById(r1);
        r28 = (android.widget.TextView) r28;
        r0 = r28;
        r1 = r34;
        r1.currentDate = r0;
        r28 = 2131690011; // 0x7f0f021b float:1.9009054E38 double:1.053194802E-314;
        r0 = r34;
        r1 = r28;
        r28 = r0.findViewById(r1);
        r28 = (android.widget.TextView) r28;
        r0 = r28;
        r1 = r34;
        r1.currentTime = r0;
        r28 = 2131690021; // 0x7f0f0225 float:1.9009074E38 double:1.053194807E-314;
        r0 = r34;
        r1 = r28;
        r28 = r0.findViewById(r1);
        r28 = (android.widget.TextView) r28;
        r0 = r28;
        r1 = r34;
        r1.mVenueNameTV = r0;
        r28 = 2131690012; // 0x7f0f021c float:1.9009056E38 double:1.0531948025E-314;
        r0 = r34;
        r1 = r28;
        r28 = r0.findViewById(r1);
        r28 = (com.vizsafe.app.CustomViews.ScrollingTextView) r28;
        r0 = r28;
        r1 = r34;
        r1.currentLocation = r0;
        r28 = 2131690013; // 0x7f0f021d float:1.9009058E38 double:1.053194803E-314;
        r0 = r34;
        r1 = r28;
        r28 = r0.findViewById(r1);
        r28 = (android.widget.ImageView) r28;
        r0 = r28;
        r1 = r34;
        r1.anonymousImage = r0;
        r28 = 2131690008; // 0x7f0f0218 float:1.9009047E38 double:1.0531948005E-314;
        r0 = r34;
        r1 = r28;
        r28 = r0.findViewById(r1);
        r28 = (android.widget.ImageView) r28;
        r0 = r28;
        r1 = r34;
        r1.postImage = r0;
        r28 = 2131690014; // 0x7f0f021e float:1.900906E38 double:1.0531948035E-314;
        r0 = r34;
        r1 = r28;
        r28 = r0.findViewById(r1);
        r28 = (android.widget.EditText) r28;
        r0 = r28;
        r1 = r34;
        r1.postDescription = r0;
        r28 = 2131690019; // 0x7f0f0223 float:1.900907E38 double:1.053194806E-314;
        r0 = r34;
        r1 = r28;
        r28 = r0.findViewById(r1);
        r28 = (android.widget.LinearLayout) r28;
        r0 = r28;
        r1 = r34;
        r1.mStadiumViewLayout = r0;
        r28 = 2131690015; // 0x7f0f021f float:1.9009062E38 double:1.053194804E-314;
        r0 = r34;
        r1 = r28;
        r28 = r0.findViewById(r1);
        r28 = (android.widget.LinearLayout) r28;
        r0 = r28;
        r1 = r34;
        r1.mSeverityLayout = r0;
        r28 = 2131690023; // 0x7f0f0227 float:1.9009078E38 double:1.053194808E-314;
        r0 = r34;
        r1 = r28;
        r28 = r0.findViewById(r1);
        r28 = (android.widget.Spinner) r28;
        r0 = r28;
        r1 = r34;
        r1.mDrawingValues = r0;
        r28 = 2131690025; // 0x7f0f0229 float:1.9009082E38 double:1.053194809E-314;
        r0 = r34;
        r1 = r28;
        r28 = r0.findViewById(r1);
        r28 = (android.widget.Spinner) r28;
        r0 = r28;
        r1 = r34;
        r1.mLevelValues = r0;
        r28 = 2131690016; // 0x7f0f0220 float:1.9009064E38 double:1.0531948045E-314;
        r0 = r34;
        r1 = r28;
        r28 = r0.findViewById(r1);
        r28 = (android.widget.CheckBox) r28;
        r0 = r28;
        r1 = r34;
        r1.mSeverityLevel1_CB = r0;
        r28 = 2131690017; // 0x7f0f0221 float:1.9009066E38 double:1.053194805E-314;
        r0 = r34;
        r1 = r28;
        r28 = r0.findViewById(r1);
        r28 = (android.widget.CheckBox) r28;
        r0 = r28;
        r1 = r34;
        r1.mSeverityLevel2_CB = r0;
        r28 = 2131690018; // 0x7f0f0222 float:1.9009068E38 double:1.0531948055E-314;
        r0 = r34;
        r1 = r28;
        r28 = r0.findViewById(r1);
        r28 = (android.widget.CheckBox) r28;
        r0 = r28;
        r1 = r34;
        r1.mSeverityLevel3_CB = r0;
        r0 = r34;
        r0 = r0.nextBtn;
        r28 = r0;
        r29 = 0;
        r28.setVisibility(r29);
        r28 = r34.getIntent();
        r28 = r28.getExtras();
        r29 = com.vizsafe.app.HomePage.ReportPage.KEY_FOR_POST_FEED;
        r28 = r28.getString(r29);
        r0 = r28;
        r1 = r34;
        r1.pathOfFile = r0;
        r28 = com.vizsafe.app.HomePage.ReportPage.TEXT_ONLY;
        r0 = r28;
        r1 = r34;
        r1.TextOnly = r0;
        r0 = r34;
        r0 = r0.mDrawingValues;
        r28 = r0;
        r0 = r28;
        r1 = r34;
        r0.setOnItemSelectedListener(r1);
        r0 = r34;
        r0 = r0.mLevelValues;
        r28 = r0;
        r0 = r28;
        r1 = r34;
        r0.setOnItemSelectedListener(r1);
        r0 = r34;
        r0 = r0.TextOnly;
        r28 = r0;
        if (r28 == 0) goto L_0x0441;
    L_0x01bf:
        r28 = r34.getResources();
        r29 = 2130837986; // 0x7f0201e2 float:1.7280942E38 double:1.0527738457E-314;
        r10 = r28.getDrawable(r29);
        r28 = r10.getIntrinsicWidth();
        r29 = r10.getIntrinsicHeight();
        r30 = android.graphics.Bitmap.Config.ARGB_8888;
        r28 = android.graphics.Bitmap.createBitmap(r28, r29, r30);
        r0 = r28;
        r1 = r34;
        r1.myBitmap = r0;
        r7 = new android.graphics.Canvas;
        r0 = r34;
        r0 = r0.myBitmap;
        r28 = r0;
        r0 = r28;
        r7.<init>(r0);
        r28 = 0;
        r29 = 0;
        r30 = r7.getWidth();
        r31 = r7.getHeight();
        r0 = r28;
        r1 = r29;
        r2 = r30;
        r3 = r31;
        r10.setBounds(r0, r1, r2, r3);
        r10.draw(r7);
        r0 = r34;
        r0 = r0.postImage;
        r28 = r0;
        r0 = r34;
        r0 = r0.myBitmap;
        r29 = r0;
        r28.setImageBitmap(r29);
    L_0x0214:
        r28 = com.vizsafe.app.HomePage.ReportPage.LATITUDE;
        r0 = r28;
        r1 = r34;
        r1.latitude = r0;
        r28 = com.vizsafe.app.HomePage.ReportPage.LONGITUDE;
        r0 = r28;
        r1 = r34;
        r1.longitude = r0;
        r0 = r34;
        r0 = r0.latitude;
        r28 = r0;
        if (r28 != 0) goto L_0x024c;
    L_0x022c:
        r0 = r34;
        r0 = r0.longitude;
        r28 = r0;
        if (r28 != 0) goto L_0x024c;
    L_0x0234:
        r28 = com.vizsafe.app.PostReportPages.SelectLocationScreen.latitude;
        r28 = java.lang.String.valueOf(r28);
        r0 = r28;
        r1 = r34;
        r1.latitude = r0;
        r28 = com.vizsafe.app.PostReportPages.SelectLocationScreen.longitude;
        r28 = java.lang.String.valueOf(r28);
        r0 = r28;
        r1 = r34;
        r1.longitude = r0;
    L_0x024c:
        r0 = r34;
        r0 = r0.latitude;
        r28 = r0;
        r29 = "0.0";
        r28 = r28.equals(r29);
        if (r28 == 0) goto L_0x0268;
    L_0x025a:
        r0 = r34;
        r0 = r0.longitude;
        r28 = r0;
        r29 = "0.0";
        r28 = r28.equals(r29);
        if (r28 != 0) goto L_0x0635;
    L_0x0268:
        r0 = r34;
        r0 = r0.currentLocation;
        r28 = r0;
        r29 = new java.lang.StringBuilder;
        r29.<init>();
        r30 = "";
        r29 = r29.append(r30);
        r0 = r34;
        r0 = r0.latitude;
        r30 = r0;
        r31 = 0;
        r32 = 5;
        r30 = r30.substring(r31, r32);
        r29 = r29.append(r30);
        r30 = ", ";
        r29 = r29.append(r30);
        r0 = r34;
        r0 = r0.longitude;
        r30 = r0;
        r31 = 0;
        r32 = 5;
        r30 = r30.substring(r31, r32);
        r29 = r29.append(r30);
        r29 = r29.toString();
        r28.setText(r29);
    L_0x02aa:
        r28 = "connectivity";
        r0 = r34;
        r1 = r28;
        r8 = r0.getSystemService(r1);
        r8 = (android.net.ConnectivityManager) r8;
        r0 = r34;
        r18 = com.vizsafe.app.Utils.CommonMember.isNetworkOnline(r8, r0);
        if (r18 == 0) goto L_0x030b;
    L_0x02be:
        r0 = r34;
        r0 = r0.latitude;
        r28 = r0;
        if (r28 == 0) goto L_0x02f3;
    L_0x02c6:
        r0 = r34;
        r0 = r0.longitude;
        r28 = r0;
        if (r28 == 0) goto L_0x02f3;
    L_0x02ce:
        r0 = r34;
        r0 = r0.latitude;
        r28 = r0;
        r28 = java.lang.Double.valueOf(r28);
        r28 = r28.doubleValue();
        r0 = r34;
        r0 = r0.longitude;
        r30 = r0;
        r30 = java.lang.Double.valueOf(r30);
        r30 = r30.doubleValue();
        r0 = r34;
        r1 = r28;
        r3 = r30;
        r0.GetLocationToAddress(r1, r3);
    L_0x02f3:
        r28 = new com.vizsafe.app.PostReportPages.PostFeedScreen$AsyncTaskCheckUserGroupExisting;
        r29 = 0;
        r0 = r28;
        r1 = r34;
        r2 = r29;
        r0.<init>(r1, r2);
        r29 = 0;
        r0 = r29;
        r0 = new java.lang.String[r0];
        r29 = r0;
        r28.execute(r29);
    L_0x030b:
        r28 = com.vizsafe.app.HomePage.ReportPage.FinalAltitudeValue;
        if (r28 == 0) goto L_0x0669;
    L_0x030f:
        r28 = com.vizsafe.app.HomePage.ReportPage.FinalAltitudeValue;
        r28 = r28.doubleValue();
        r30 = 0;
        r28 = (r28 > r30 ? 1 : (r28 == r30 ? 0 : -1));
        if (r28 == 0) goto L_0x0669;
    L_0x031b:
        r28 = com.vizsafe.app.HomePage.ReportPage.FinalAltitudeValue;
        r28 = r28.doubleValue();
        r0 = r28;
        r2 = r34;
        r2.mAltitude = r0;
    L_0x0327:
        r28 = "connectivity";
        r0 = r34;
        r1 = r28;
        r9 = r0.getSystemService(r1);
        r9 = (android.net.ConnectivityManager) r9;
        r0 = r34;
        r19 = com.vizsafe.app.Utils.CommonMember.isNetworkOnline(r9, r0);
        if (r19 != 0) goto L_0x068f;
    L_0x033b:
        com.vizsafe.app.Utils.CommonMember.NetworkStatusAlert(r34);
    L_0x033e:
        r28 = r34.getIntent();
        r28 = r28.getExtras();
        r29 = com.vizsafe.app.HomePage.ReportPage.CURRENT_TIME;
        r27 = r28.getString(r29);
        r28 = r34.getIntent();
        r28 = r28.getExtras();
        r29 = com.vizsafe.app.HomePage.ReportPage.CURRENT_DATE;
        r26 = r28.getString(r29);
        if (r27 == 0) goto L_0x069d;
    L_0x035c:
        if (r26 == 0) goto L_0x069d;
    L_0x035e:
        r0 = r34;
        r0 = r0.currentDate;
        r28 = r0;
        r0 = r28;
        r1 = r26;
        r0.setText(r1);
        r0 = r34;
        r0 = r0.currentTime;
        r28 = r0;
        r0 = r28;
        r1 = r27;
        r0.setText(r1);
        r28 = new java.lang.StringBuilder;
        r28.<init>();
        r0 = r28;
        r1 = r26;
        r28 = r0.append(r1);
        r29 = " ";
        r28 = r28.append(r29);
        r0 = r28;
        r1 = r27;
        r28 = r0.append(r1);
        r28 = r28.toString();
        r0 = r28;
        r1 = r34;
        r1.dateAndTime = r0;
    L_0x039d:
        r25 = new java.text.SimpleDateFormat;
        r28 = "MMM dd, yyyy hh:mm:ss";
        r0 = r25;
        r1 = r28;
        r0.<init>(r1);
        r0 = r34;
        r0 = r0.dateAndTime;	 Catch:{ ParseException -> 0x06e2 }
        r28 = r0;
        r0 = r25;
        r1 = r28;
        r16 = r0.parse(r1);	 Catch:{ ParseException -> 0x06e2 }
        r28 = r16.getTime();	 Catch:{ ParseException -> 0x06e2 }
        r28 = java.lang.String.valueOf(r28);	 Catch:{ ParseException -> 0x06e2 }
        r29 = "000";
        r28 = r28.endsWith(r29);	 Catch:{ ParseException -> 0x06e2 }
        if (r28 == 0) goto L_0x06d6;
    L_0x03c6:
        r28 = r16.getTime();	 Catch:{ ParseException -> 0x06e2 }
        r30 = 1000; // 0x3e8 float:1.401E-42 double:4.94E-321;
        r28 = r28 / r30;
        r0 = r28;
        r2 = r34;
        r2.dateAndTimeInMilliseconds = r0;	 Catch:{ ParseException -> 0x06e2 }
    L_0x03d4:
        r0 = r34;
        r0 = r0.mSeverityLevel1_CB;
        r28 = r0;
        r29 = new com.vizsafe.app.PostReportPages.PostFeedScreen$1;
        r0 = r29;
        r1 = r34;
        r0.<init>();
        r28.setOnCheckedChangeListener(r29);
        r0 = r34;
        r0 = r0.mSeverityLevel2_CB;
        r28 = r0;
        r29 = new com.vizsafe.app.PostReportPages.PostFeedScreen$2;
        r0 = r29;
        r1 = r34;
        r0.<init>();
        r28.setOnCheckedChangeListener(r29);
        r0 = r34;
        r0 = r0.mSeverityLevel3_CB;
        r28 = r0;
        r29 = new com.vizsafe.app.PostReportPages.PostFeedScreen$3;
        r0 = r29;
        r1 = r34;
        r0.<init>();
        r28.setOnCheckedChangeListener(r29);
        r0 = r34;
        r0 = r0.anonymousImage;
        r28 = r0;
        r29 = new com.vizsafe.app.PostReportPages.PostFeedScreen$4;
        r0 = r29;
        r1 = r34;
        r0.<init>();
        r28.setOnClickListener(r29);
        r0 = r34;
        r0 = r0.nextBtn;
        r28 = r0;
        r29 = new com.vizsafe.app.PostReportPages.PostFeedScreen$5;
        r0 = r29;
        r1 = r34;
        r0.<init>();
        r28.setOnClickListener(r29);
        r0 = r34;
        r0 = r0.cancelBtn;
        r28 = r0;
        r29 = new com.vizsafe.app.PostReportPages.PostFeedScreen$6;
        r0 = r29;
        r1 = r34;
        r0.<init>();
        r28.setOnClickListener(r29);
        return;
    L_0x0441:
        r0 = r34;
        r0 = r0.pathOfFile;	 Catch:{ IOException -> 0x05c3 }
        r28 = r0;
        r17 = com.vizsafe.app.Utils.CommonMember.showBitmapFromFile(r28);	 Catch:{ IOException -> 0x05c3 }
        r0 = r34;
        r0 = r0.postImage;	 Catch:{ IOException -> 0x05c3 }
        r28 = r0;
        r0 = r28;
        r1 = r17;
        r0.setImageBitmap(r1);	 Catch:{ IOException -> 0x05c3 }
        r12 = new android.media.ExifInterface;	 Catch:{ IOException -> 0x05c3 }
        r0 = r34;
        r0 = r0.pathOfFile;	 Catch:{ IOException -> 0x05c3 }
        r28 = r0;
        r0 = r28;
        r12.<init>(r0);	 Catch:{ IOException -> 0x05c3 }
        r28 = "Orientation";
        r0 = r28;
        r28 = r12.getAttribute(r0);	 Catch:{ IOException -> 0x05c3 }
        r0 = r28;
        r1 = r34;
        r1.exifOrientation = r0;	 Catch:{ IOException -> 0x05c3 }
    L_0x0473:
        r13 = new java.io.File;
        r0 = r34;
        r0 = r0.pathOfFile;
        r28 = r0;
        r0 = r28;
        r13.<init>(r0);
        r21 = new android.graphics.BitmapFactory$Options;
        r21.<init>();
        r28 = 1;
        r0 = r28;
        r1 = r21;
        r1.inJustDecodeBounds = r0;
        r14 = 0;
        r15 = new java.io.FileInputStream;	 Catch:{ Exception -> 0x05c9 }
        r15.<init>(r13);	 Catch:{ Exception -> 0x05c9 }
        r28 = 0;
        r0 = r28;
        r1 = r21;
        android.graphics.BitmapFactory.decodeStream(r15, r0, r1);	 Catch:{ Exception -> 0x06e8 }
        r15.close();	 Catch:{ Exception -> 0x06e8 }
        r6 = 1024; // 0x400 float:1.435E-42 double:5.06E-321;
        r23 = 1;
        r0 = r21;
        r0 = r0.outHeight;	 Catch:{ Exception -> 0x06e8 }
        r28 = r0;
        r0 = r28;
        if (r0 > r6) goto L_0x04b7;
    L_0x04ad:
        r0 = r21;
        r0 = r0.outWidth;	 Catch:{ Exception -> 0x06e8 }
        r28 = r0;
        r0 = r28;
        if (r0 <= r6) goto L_0x04f6;
    L_0x04b7:
        r28 = 4611686018427387904; // 0x4000000000000000 float:0.0 double:2.0;
        r0 = (double) r6;	 Catch:{ Exception -> 0x06e8 }
        r30 = r0;
        r0 = r21;
        r0 = r0.outHeight;	 Catch:{ Exception -> 0x06e8 }
        r32 = r0;
        r0 = r21;
        r0 = r0.outWidth;	 Catch:{ Exception -> 0x06e8 }
        r33 = r0;
        r32 = java.lang.Math.max(r32, r33);	 Catch:{ Exception -> 0x06e8 }
        r0 = r32;
        r0 = (double) r0;	 Catch:{ Exception -> 0x06e8 }
        r32 = r0;
        r30 = r30 / r32;
        r30 = java.lang.Math.log(r30);	 Catch:{ Exception -> 0x06e8 }
        r32 = 4602678819172646912; // 0x3fe0000000000000 float:0.0 double:0.5;
        r32 = java.lang.Math.log(r32);	 Catch:{ Exception -> 0x06e8 }
        r30 = r30 / r32;
        r30 = java.lang.Math.round(r30);	 Catch:{ Exception -> 0x06e8 }
        r0 = r30;
        r0 = (int) r0;	 Catch:{ Exception -> 0x06e8 }
        r30 = r0;
        r0 = r30;
        r0 = (double) r0;	 Catch:{ Exception -> 0x06e8 }
        r30 = r0;
        r28 = java.lang.Math.pow(r28, r30);	 Catch:{ Exception -> 0x06e8 }
        r0 = r28;
        r0 = (int) r0;	 Catch:{ Exception -> 0x06e8 }
        r23 = r0;
    L_0x04f6:
        r22 = new android.graphics.BitmapFactory$Options;	 Catch:{ Exception -> 0x06e8 }
        r22.<init>();	 Catch:{ Exception -> 0x06e8 }
        r0 = r23;
        r1 = r22;
        r1.inSampleSize = r0;	 Catch:{ Exception -> 0x06e8 }
        r14 = new java.io.FileInputStream;	 Catch:{ Exception -> 0x06e8 }
        r14.<init>(r13);	 Catch:{ Exception -> 0x06e8 }
        r28 = 0;
        r0 = r28;
        r1 = r22;
        r28 = android.graphics.BitmapFactory.decodeStream(r14, r0, r1);	 Catch:{ Exception -> 0x05c9 }
        r0 = r28;
        r1 = r34;
        r1.myBitmap = r0;	 Catch:{ Exception -> 0x05c9 }
        r14.close();	 Catch:{ Exception -> 0x05c9 }
    L_0x0519:
        r0 = r34;
        r0 = r0.myBitmap;
        r28 = r0;
        if (r28 != 0) goto L_0x053b;
    L_0x0521:
        r0 = r34;
        r0 = r0.pathOfFile;
        r28 = r0;
        r29 = 3;
        r28 = android.media.ThumbnailUtils.createVideoThumbnail(r28, r29);
        r0 = r28;
        r1 = r34;
        r1.myBitmap = r0;
        r28 = "video";
        r0 = r28;
        r1 = r34;
        r1.postType = r0;
    L_0x053b:
        r0 = r34;
        r0 = r0.exifOrientation;
        r28 = r0;
        r28 = java.lang.Integer.parseInt(r28);
        if (r28 < 0) goto L_0x05cf;
    L_0x0547:
        r0 = r34;
        r0 = r0.exifOrientation;
        r28 = r0;
        r28 = java.lang.Integer.parseInt(r28);
        r29 = 1;
        r0 = r28;
        r1 = r29;
        if (r0 > r1) goto L_0x05cf;
    L_0x0559:
        r28 = 0;
        r0 = r28;
        r1 = r34;
        r1.rotationDegree = r0;
    L_0x0561:
        r0 = r34;
        r0 = r0.myBitmap;
        r28 = r0;
        if (r28 == 0) goto L_0x0214;
    L_0x0569:
        r0 = r34;
        r0 = r0.myBitmap;
        r28 = r0;
        r28 = r28.getHeight();
        r0 = r28;
        r0 = (double) r0;
        r28 = r0;
        r30 = 4647714815446351872; // 0x4080000000000000 float:0.0 double:512.0;
        r0 = r34;
        r0 = r0.myBitmap;
        r32 = r0;
        r32 = r32.getWidth();
        r0 = r32;
        r0 = (double) r0;
        r32 = r0;
        r30 = r30 / r32;
        r28 = r28 * r30;
        r0 = r28;
        r0 = (int) r0;
        r20 = r0;
        r0 = r34;
        r0 = r0.myBitmap;
        r28 = r0;
        r29 = 512; // 0x200 float:7.175E-43 double:2.53E-321;
        r30 = 1;
        r0 = r28;
        r1 = r29;
        r2 = r20;
        r3 = r30;
        r24 = android.graphics.Bitmap.createScaledBitmap(r0, r1, r2, r3);
        r0 = r34;
        r0 = r0.postImage;
        r28 = r0;
        r0 = r34;
        r0 = r0.rotationDegree;
        r29 = r0;
        r0 = r34;
        r1 = r24;
        r2 = r29;
        r29 = r0.rotateImage(r1, r2);
        r28.setImageBitmap(r29);
        goto L_0x0214;
    L_0x05c3:
        r11 = move-exception;
        r11.printStackTrace();
        goto L_0x0473;
    L_0x05c9:
        r11 = move-exception;
    L_0x05ca:
        r11.printStackTrace();
        goto L_0x0519;
    L_0x05cf:
        r0 = r34;
        r0 = r0.exifOrientation;
        r28 = r0;
        r28 = java.lang.Integer.parseInt(r28);
        r29 = 2;
        r0 = r28;
        r1 = r29;
        if (r0 < r1) goto L_0x05fd;
    L_0x05e1:
        r0 = r34;
        r0 = r0.exifOrientation;
        r28 = r0;
        r28 = java.lang.Integer.parseInt(r28);
        r29 = 4;
        r0 = r28;
        r1 = r29;
        if (r0 > r1) goto L_0x05fd;
    L_0x05f3:
        r28 = 1127481344; // 0x43340000 float:180.0 double:5.570497984E-315;
        r0 = r28;
        r1 = r34;
        r1.rotationDegree = r0;
        goto L_0x0561;
    L_0x05fd:
        r0 = r34;
        r0 = r0.exifOrientation;
        r28 = r0;
        r28 = java.lang.Integer.parseInt(r28);
        r29 = 7;
        r0 = r28;
        r1 = r29;
        if (r0 < r1) goto L_0x062b;
    L_0x060f:
        r0 = r34;
        r0 = r0.exifOrientation;
        r28 = r0;
        r28 = java.lang.Integer.parseInt(r28);
        r29 = 8;
        r0 = r28;
        r1 = r29;
        if (r0 < r1) goto L_0x062b;
    L_0x0621:
        r28 = 1132920832; // 0x43870000 float:270.0 double:5.597372625E-315;
        r0 = r28;
        r1 = r34;
        r1.rotationDegree = r0;
        goto L_0x0561;
    L_0x062b:
        r28 = 1119092736; // 0x42b40000 float:90.0 double:5.529052754E-315;
        r0 = r28;
        r1 = r34;
        r1.rotationDegree = r0;
        goto L_0x0561;
    L_0x0635:
        r0 = r34;
        r0 = r0.currentLocation;
        r28 = r0;
        r29 = new java.lang.StringBuilder;
        r29.<init>();
        r30 = "";
        r29 = r29.append(r30);
        r0 = r34;
        r0 = r0.latitude;
        r30 = r0;
        r29 = r29.append(r30);
        r30 = ", ";
        r29 = r29.append(r30);
        r0 = r34;
        r0 = r0.longitude;
        r30 = r0;
        r29 = r29.append(r30);
        r29 = r29.toString();
        r28.setText(r29);
        goto L_0x02aa;
    L_0x0669:
        r0 = r34;
        r0 = r0.longitude;	 Catch:{ IOException -> 0x0689 }
        r28 = r0;
        r28 = java.lang.Double.parseDouble(r28);	 Catch:{ IOException -> 0x0689 }
        r0 = r34;
        r0 = r0.latitude;	 Catch:{ IOException -> 0x0689 }
        r30 = r0;
        r30 = java.lang.Double.parseDouble(r30);	 Catch:{ IOException -> 0x0689 }
        r28 = com.vizsafe.app.Utils.Webservice.getElevationFromGoogleMaps(r28, r30);	 Catch:{ IOException -> 0x0689 }
        r0 = r28;
        r2 = r34;
        r2.mAltitude = r0;	 Catch:{ IOException -> 0x0689 }
        goto L_0x0327;
    L_0x0689:
        r11 = move-exception;
        r11.printStackTrace();
        goto L_0x0327;
    L_0x068f:
        r0 = r34;
        r0 = r0.mTransparentProgressDialog;
        r28 = r0;
        r28.show();
        r34.GetLocationAddress();
        goto L_0x033e;
    L_0x069d:
        r0 = r34;
        r0 = r0.currentDate;
        r28 = r0;
        r29 = com.vizsafe.app.PostReportPages.DatePickerScreen.currDate;
        r28.setText(r29);
        r0 = r34;
        r0 = r0.currentTime;
        r28 = r0;
        r29 = com.vizsafe.app.PostReportPages.TimePickerScreen.currTime;
        r28.setText(r29);
        r28 = new java.lang.StringBuilder;
        r28.<init>();
        r29 = com.vizsafe.app.PostReportPages.DatePickerScreen.currDate;
        r28 = r28.append(r29);
        r29 = " ";
        r28 = r28.append(r29);
        r29 = com.vizsafe.app.PostReportPages.TimePickerScreen.currTime;
        r28 = r28.append(r29);
        r28 = r28.toString();
        r0 = r28;
        r1 = r34;
        r1.dateAndTime = r0;
        goto L_0x039d;
    L_0x06d6:
        r28 = r16.getTime();	 Catch:{ ParseException -> 0x06e2 }
        r0 = r28;
        r2 = r34;
        r2.dateAndTimeInMilliseconds = r0;	 Catch:{ ParseException -> 0x06e2 }
        goto L_0x03d4;
    L_0x06e2:
        r11 = move-exception;
        r11.printStackTrace();
        goto L_0x03d4;
    L_0x06e8:
        r11 = move-exception;
        r14 = r15;
        goto L_0x05ca;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.vizsafe.app.PostReportPages.PostFeedScreen.onCreate(android.os.Bundle):void");
    }

    private void GetLocationToAddress(double latitudeValue, double longitudeValue) {
        GetLocationAddressApi.getInstance().Callresponse(getApplicationContext(), latitudeValue, longitudeValue, new C04047());
    }

    private void GetLocationAddress() {
        this.latitudeValue = Double.parseDouble(this.latitude);
        this.longitudeValue = Double.parseDouble(this.longitude);
        GetLocationAddressApi.getInstance().Callresponse(getApplicationContext(), this.latitudeValue, this.longitudeValue, new C04058());
    }

    public Bitmap rotateImage(Bitmap src, float degree) {
        Matrix matrix = new Matrix();
        matrix.postRotate(degree);
        return Bitmap.createBitmap(src, 0, 0, src.getWidth(), src.getHeight(), matrix, true);
    }

    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        Spinner spinner = (Spinner) parent;
        if (spinner.getId() == C0421R.C0419id.textViewFloorName) {
            if (position == 1) {
                this.mDrawingSelectedValue = (Integer) this.mDrawingIdList.get(1);
                this.mSelectedNameArraylist = (ArrayList) this.mlevelNameWholeList.get(1);
                this.mSelectedArraylist = (ArrayList) this.mlevelIdWholeList.get(1);
            } else {
                this.mSpinnerClicked = true;
                this.mDrawingSelectedValue = (Integer) this.mDrawingIdList.get(position);
                this.mSelectedNameArraylist = (ArrayList) this.mlevelNameWholeList.get(position);
                this.mSelectedArraylist = (ArrayList) this.mlevelIdWholeList.get(position);
            }
            ArrayList<String> mLevelValues1 = new ArrayList();
            this.mLevelSpinnerAdapter = new ArrayAdapter(this, C0421R.layout.spinner_item, this.mSelectedNameArraylist);
            this.mLevelSpinnerAdapter.setDropDownViewResource(17367049);
            this.mLevelValues.setAdapter(this.mLevelSpinnerAdapter);
        } else if (spinner.getId() == C0421R.C0419id.textViewFloorLevelsName) {
            String item = spinner.getItemAtPosition(position).toString();
            this.mLevelSelectedValue = (Integer) this.mSelectedArraylist.get(position);
        }
    }

    public void onNothingSelected(AdapterView<?> adapterView) {
    }

    public void onBackPressed() {
        super.onBackPressed();
        View view = getCurrentFocus();
        if (view != null) {
            ((InputMethodManager) getSystemService("input_method")).hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
        this.mSeverityLevelValue = null;
        finish();
    }
}
