package com.vizsafe.app.PostReportPages;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.Matrix;
import android.media.MediaMetadataRetriever;
import android.media.ThumbnailUtils;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Parcelable;
import android.support.p002v7.app.AppCompatActivity;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.vizsafe.app.APIClientMethods.AllChannelsApi;
import com.vizsafe.app.APIClientMethods.AllChannelsApi.ResponseAllChannelsApi;
import com.vizsafe.app.APIClientMethods.FavouriteChannelsApi;
import com.vizsafe.app.APIClientMethods.FavouriteChannelsApi.Channel;
import com.vizsafe.app.APIClientMethods.FavouriteChannelsApi.Detail;
import com.vizsafe.app.APIClientMethods.FavouriteChannelsApi.ResponseFavouriteChannelsApi;
import com.vizsafe.app.APIClientMethods.VizsafeChannelsApi;
import com.vizsafe.app.APIClientMethods.VizsafeChannelsApi.ResponseVizsafeChannelsApi;
import com.vizsafe.app.Adapters.CustomExpandableListAdapter;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.Database.AppDatabase;
import com.vizsafe.app.Database.Tables.AllChannelsTable;
import com.vizsafe.app.Database.Tables.FavChannelTable;
import com.vizsafe.app.Database.Tables.TipsChannelTable;
import com.vizsafe.app.Database.Tables.VizsafeChannelTable;
import com.vizsafe.app.HomePage.ReportPage;
import com.vizsafe.app.Outbox.OutboxSentPostItems;
import com.vizsafe.app.POJO.ChannelsListItem;
import com.vizsafe.app.POJO.Item;
import com.vizsafe.app.POJO.SectionItem;
import com.vizsafe.app.Utils.CommonMember;
import com.vizsafe.app.Utils.PreferenceHandler;
import com.vizsafe.app.Utils.Webservice;
import dmax.dialog.SpotsDialog;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import org.json.JSONObject;
import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class SelectChannelToPost extends AppCompatActivity {
    public static boolean SelectChannelToPostsendBtn = false;
    public static SelectChannelToPost selectChannelToPost;
    private String POST_DATA;
    private ArrayList<Item> allChannels = new ArrayList();
    ArrayList<ChannelsListItem> allchannels;
    private String anonymusStatus;
    private String authenticationString;
    private ImageView backBtn;
    private String base64Altitude;
    private String base64AnonymusStatus;
    private String base64ChannelsUuidToPost;
    private String base64CommunityId;
    private String base64Description;
    private String base64DrawingId;
    private String base64Image;
    private String base64Latitude;
    private String base64LevelId;
    private String base64Longitude;
    private String base64PostType;
    private String base64SeverityStatus;
    private String base64ThumnailImage;
    private String base64TimeAndDate;
    String channelDescription;
    boolean channelMassaged;
    String channelName;
    String channelOwner;
    String channelPicture;
    private String channelPictureUrl;
    boolean channelPrivate;
    boolean channelSecret;
    boolean channelTips;
    String channelUuid;
    boolean channelVizsafe;
    private String channeslUuidToPost = "";
    private String description;
    private String email;
    ExpandableListView expListView;
    ArrayList<ChannelsListItem> favchannels;
    private ArrayList<Item> favoriteChannel = new ArrayList();
    private String imagePath;
    private ArrayList<Item> items = new ArrayList();
    private String latitude;
    CustomExpandableListAdapter listAdapter;
    HashMap<String, List<ChannelsListItem>> listDataChild;
    List<String> listDataHeader;
    private String longitude;
    private String mAltitudeValue;
    AppDatabase mAppDatabase;
    private List<Channel> mChannelsList;
    boolean mCheckSecret = false;
    private Integer mCommunitySelectedValue = Integer.valueOf(0);
    private Integer mDrawingSelectedValue = Integer.valueOf(0);
    private Integer mLevelSelectedValue = Integer.valueOf(0);
    private AlertDialog mTransparentProgressDialog;
    private TextView nextBtn;
    private String password;
    private String postType;
    private Parcelable scrollState = null;
    ArrayList<ChannelsListItem> selectedChannelItems = new ArrayList();
    private Button sendBtn;
    private String severityStatus;
    private String timeAndDate;
    private ArrayList<Item> tipsChannel = new ArrayList();
    ArrayList<ChannelsListItem> tipschannels;
    private ArrayList<Item> vizsafeChannel = new ArrayList();
    ArrayList<ChannelsListItem> vizsafechannels;

    /* renamed from: com.vizsafe.app.PostReportPages.SelectChannelToPost$1 */
    class C04071 implements OnClickListener {

        /* renamed from: com.vizsafe.app.PostReportPages.SelectChannelToPost$1$1 */
        class C04061 extends TypeToken<List<OutboxSentPostItems>> {
            C04061() {
            }
        }

        C04071() {
        }

        public void onClick(View v) {
            ReportPage.TEXT_ONLY = false;
            if (!SelectChannelToPost.SelectChannelToPostsendBtn) {
                SelectChannelToPost.SelectChannelToPostsendBtn = true;
                if (SelectChannelToPost.this.selectedChannelItems.isEmpty()) {
                    CommonMember.getErrorDialog(SelectChannelToPost.this.getString(C0421R.string.please_select_atleast_one_channel), SelectChannelToPost.selectChannelToPost).show();
                    SelectChannelToPost.SelectChannelToPostsendBtn = false;
                    return;
                }
                for (int i = 0; i < SelectChannelToPost.this.selectedChannelItems.size(); i++) {
                    if (((ChannelsListItem) SelectChannelToPost.this.selectedChannelItems.get(i)).isSecret) {
                        SelectChannelToPost.this.mCheckSecret = true;
                    }
                    SelectChannelToPost.this.channeslUuidToPost = SelectChannelToPost.this.channeslUuidToPost + ((ChannelsListItem) SelectChannelToPost.this.selectedChannelItems.get(i)).uuid + ",";
                }
                SelectChannelToPost.this.channeslUuidToPost = SelectChannelToPost.this.channeslUuidToPost.substring(0, SelectChannelToPost.this.channeslUuidToPost.trim().length() - 1);
                if (!SelectChannelToPost.this.mCheckSecret) {
                    SelectChannelToPost.this.severityStatus = "0";
                }
                SelectChannelToPost.this.base64PostType = Base64.encodeToString(SelectChannelToPost.this.postType.getBytes(), 10);
                SelectChannelToPost.this.base64Latitude = Base64.encodeToString(SelectChannelToPost.this.latitude.getBytes(), 10);
                SelectChannelToPost.this.base64Longitude = Base64.encodeToString(SelectChannelToPost.this.longitude.getBytes(), 10);
                SelectChannelToPost.this.base64Altitude = Base64.encodeToString(SelectChannelToPost.this.mAltitudeValue.getBytes(), 10);
                SelectChannelToPost.this.base64Description = Base64.encodeToString(SelectChannelToPost.this.description.getBytes(), 10);
                SelectChannelToPost.this.base64SeverityStatus = Base64.encodeToString(SelectChannelToPost.this.severityStatus.getBytes(), 10);
                SelectChannelToPost.this.base64TimeAndDate = Base64.encodeToString(SelectChannelToPost.this.timeAndDate.getBytes(), 10);
                SelectChannelToPost.this.base64AnonymusStatus = Base64.encodeToString(SelectChannelToPost.this.anonymusStatus.getBytes(), 10);
                SelectChannelToPost.this.base64ChannelsUuidToPost = Base64.encodeToString(SelectChannelToPost.this.channeslUuidToPost.getBytes(), 10);
                SelectChannelToPost.this.base64CommunityId = Base64.encodeToString(String.valueOf(SelectChannelToPost.this.mCommunitySelectedValue).getBytes(), 10);
                SelectChannelToPost.this.base64DrawingId = Base64.encodeToString(String.valueOf(SelectChannelToPost.this.mDrawingSelectedValue).getBytes(), 10);
                SelectChannelToPost.this.base64LevelId = Base64.encodeToString(String.valueOf(SelectChannelToPost.this.mLevelSelectedValue).getBytes(), 10);
                if (SelectChannelToPost.this.postType.equalsIgnoreCase("video")) {
                    if (SelectChannelToPost.this.mCommunitySelectedValue.intValue() == 0 || SelectChannelToPost.this.mDrawingSelectedValue.intValue() == 0 || SelectChannelToPost.this.mLevelSelectedValue.intValue() == 0) {
                        SelectChannelToPost.this.POST_DATA = "type=" + SelectChannelToPost.this.base64PostType + "&latitude=" + SelectChannelToPost.this.base64Latitude + "&longitude=" + SelectChannelToPost.this.base64Longitude + "&description=" + SelectChannelToPost.this.base64Description + "&timestamp=" + SelectChannelToPost.this.base64TimeAndDate + "&anonymous=" + SelectChannelToPost.this.base64AnonymusStatus + "&channels=" + SelectChannelToPost.this.base64ChannelsUuidToPost + "&elevation=" + SelectChannelToPost.this.base64Altitude + "&severitylevel=" + SelectChannelToPost.this.base64SeverityStatus + "&still=" + SelectChannelToPost.this.base64ThumnailImage + "&base64Data=" + SelectChannelToPost.this.base64Image;
                    } else {
                        SelectChannelToPost.this.POST_DATA = "type=" + SelectChannelToPost.this.base64PostType + "&latitude=" + SelectChannelToPost.this.base64Latitude + "&longitude=" + SelectChannelToPost.this.base64Longitude + "&description=" + SelectChannelToPost.this.base64Description + "&timestamp=" + SelectChannelToPost.this.base64TimeAndDate + "&anonymous=" + SelectChannelToPost.this.base64AnonymusStatus + "&channels=" + SelectChannelToPost.this.base64ChannelsUuidToPost + "&elevation=" + SelectChannelToPost.this.base64Altitude + "&communityid=" + SelectChannelToPost.this.base64CommunityId + "&drawingid=" + SelectChannelToPost.this.base64DrawingId + "&levelid=" + SelectChannelToPost.this.base64LevelId + "&severitylevel=" + SelectChannelToPost.this.base64SeverityStatus + "&still=" + SelectChannelToPost.this.base64ThumnailImage + "&base64Data=" + SelectChannelToPost.this.base64Image;
                    }
                } else if (SelectChannelToPost.this.mCommunitySelectedValue.intValue() == 0 || SelectChannelToPost.this.mDrawingSelectedValue.intValue() == 0 || SelectChannelToPost.this.mLevelSelectedValue.intValue() == 0) {
                    SelectChannelToPost.this.POST_DATA = "type=" + SelectChannelToPost.this.base64PostType + "&latitude=" + SelectChannelToPost.this.base64Latitude + "&longitude=" + SelectChannelToPost.this.base64Longitude + "&description=" + SelectChannelToPost.this.base64Description + "&timestamp=" + SelectChannelToPost.this.base64TimeAndDate + "&anonymous=" + SelectChannelToPost.this.base64AnonymusStatus + "&channels=" + SelectChannelToPost.this.base64ChannelsUuidToPost + "&elevation=" + SelectChannelToPost.this.base64Altitude + "&severitylevel=" + SelectChannelToPost.this.base64SeverityStatus + "&base64Data=" + SelectChannelToPost.this.base64Image;
                } else {
                    SelectChannelToPost.this.POST_DATA = "type=" + SelectChannelToPost.this.base64PostType + "&latitude=" + SelectChannelToPost.this.base64Latitude + "&longitude=" + SelectChannelToPost.this.base64Longitude + "&description=" + SelectChannelToPost.this.base64Description + "&timestamp=" + SelectChannelToPost.this.base64TimeAndDate + "&anonymous=" + SelectChannelToPost.this.base64AnonymusStatus + "&channels=" + SelectChannelToPost.this.base64ChannelsUuidToPost + "&elevation=" + SelectChannelToPost.this.base64Altitude + "&communityid=" + SelectChannelToPost.this.base64CommunityId + "&drawingid=" + SelectChannelToPost.this.base64DrawingId + "&levelid=" + SelectChannelToPost.this.base64LevelId + "&severitylevel=" + SelectChannelToPost.this.base64SeverityStatus + "&base64Data=" + SelectChannelToPost.this.base64Image;
                }
                OutboxSentPostItems outboxSentPostItems = new OutboxSentPostItems(SelectChannelToPost.this.description, SelectChannelToPost.this.POST_DATA, true);
                ArrayList<OutboxSentPostItems> arraylist = new ArrayList();
                Object arraylist2 = (ArrayList) new Gson().fromJson(PreferenceHandler.getInstance(SelectChannelToPost.this).getOutBoxSet(), new C04061().getType());
                if (arraylist2 == null || arraylist2.size() <= 0) {
                    arraylist2 = new ArrayList();
                    arraylist2.add(outboxSentPostItems);
                } else {
                    arraylist2.add(outboxSentPostItems);
                }
                try {
                    PreferenceHandler.getInstance(SelectChannelToPost.selectChannelToPost).setOutBoxSet(new Gson().toJson(arraylist2));
                } catch (Exception e) {
                    e.printStackTrace();
                }
                SelectChannelToPost.this.broadcastOutboxIntent();
                if (CommonMember.isNetworkOnline((ConnectivityManager) SelectChannelToPost.this.getSystemService("connectivity"), SelectChannelToPost.this)) {
                    new AsyncTaskPostFeed(SelectChannelToPost.this, null).execute(new String[0]);
                }
                SelectChannelToPost.selectChannelToPost.finish();
                PostFeedScreen.postFeedScreen.finish();
                if (ReportPage.userChoosenTask.equals("Choose from Library") && SelectLocationScreen.mSelectLocationScreen != null) {
                    SelectLocationScreen.mSelectLocationScreen.finish();
                }
                SelectChannelToPost.SelectChannelToPostsendBtn = false;
                Toast.makeText(SelectChannelToPost.this.getApplicationContext(), SelectChannelToPost.this.getString(C0421R.string.sending_report), 1).show();
            }
        }
    }

    /* renamed from: com.vizsafe.app.PostReportPages.SelectChannelToPost$2 */
    class C04082 implements OnClickListener {
        C04082() {
        }

        public void onClick(View v) {
            SelectChannelToPost.this.finish();
        }
    }

    /* renamed from: com.vizsafe.app.PostReportPages.SelectChannelToPost$3 */
    class C04093 implements OnChildClickListener {
        C04093() {
        }

        public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
            if (SelectChannelToPost.this.listDataChild != null) {
                ChannelsListItem childText = (ChannelsListItem) ((List) SelectChannelToPost.this.listDataChild.get(SelectChannelToPost.this.listDataHeader.get(groupPosition))).get(childPosition);
                if (((ImageView) v.findViewById(C0421R.C0419id.check_mark)).getVisibility() != 0) {
                    SelectChannelToPost.this.selectedChannelItems.add(new ChannelsListItem(childText.title, childText.subtitle, childText.image, childText.uuid, childText.owner, childText.isVizsafe, childText.isPrivate, childText.isSecret, childText.isMassaged));
                } else {
                    int i = 0;
                    Iterator it = SelectChannelToPost.this.selectedChannelItems.iterator();
                    while (it.hasNext()) {
                        if (childText.uuid.equals(((ChannelsListItem) it.next()).uuid)) {
                            SelectChannelToPost.this.selectedChannelItems.remove(i);
                            break;
                        }
                        i++;
                    }
                }
                SelectChannelToPost.this.listAdapter.notifyDataSetChanged();
            }
            return false;
        }
    }

    /* renamed from: com.vizsafe.app.PostReportPages.SelectChannelToPost$4 */
    class C04104 implements Callback<ResponseFavouriteChannelsApi> {
        C04104() {
        }

        public void success(ResponseFavouriteChannelsApi responseFavouriteChannelsApi, Response response) {
            if (responseFavouriteChannelsApi.getHttpCode().intValue() == 200) {
                SelectChannelToPost.this.items.clear();
                SelectChannelToPost.this.selectedChannelItems.clear();
                Detail mDetailChannels = responseFavouriteChannelsApi.getDetail();
                try {
                    if (SelectChannelToPost.this.mChannelsList != null) {
                        SelectChannelToPost.this.mChannelsList.clear();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                SelectChannelToPost.this.mChannelsList = mDetailChannels.getChannels();
                SelectChannelToPost.this.listDataHeader = new ArrayList();
                SelectChannelToPost.this.favchannels = new ArrayList();
                SelectChannelToPost.this.listDataChild = new HashMap();
                if (SelectChannelToPost.this.mChannelsList != null) {
                    SelectChannelToPost.this.listDataHeader.add(SelectChannelToPost.this.getString(C0421R.string.favorite_channels));
                    SelectChannelToPost.this.mAppDatabase.mFavChannelDao().delete();
                    for (int count = 0; count < SelectChannelToPost.this.mChannelsList.size(); count++) {
                        String channelName = ((Channel) SelectChannelToPost.this.mChannelsList.get(count)).getName();
                        String channelDescription = ((Channel) SelectChannelToPost.this.mChannelsList.get(count)).getDescription();
                        String channelUuid = ((Channel) SelectChannelToPost.this.mChannelsList.get(count)).getUuid();
                        String channelPicture = ((Channel) SelectChannelToPost.this.mChannelsList.get(count)).getChannelPicture();
                        String channelOwner = ((Channel) SelectChannelToPost.this.mChannelsList.get(count)).getOwner();
                        boolean channelVizsafe = ((Channel) SelectChannelToPost.this.mChannelsList.get(count)).getVizsafeChannel().booleanValue();
                        boolean channelPrivate = ((Channel) SelectChannelToPost.this.mChannelsList.get(count)).getPrivateChannel().booleanValue();
                        boolean channelSecret = ((Channel) SelectChannelToPost.this.mChannelsList.get(count)).getSecretChannel().booleanValue();
                        boolean channelMassaged = ((Channel) SelectChannelToPost.this.mChannelsList.get(count)).getMassaged().booleanValue();
                        SelectChannelToPost.this.favchannels.add(new ChannelsListItem(channelName, channelDescription, SelectChannelToPost.this.channelPictureUrl + channelPicture, channelUuid, channelOwner, channelVizsafe, channelPrivate, channelSecret, channelMassaged));
                        SelectChannelToPost.this.listDataChild.put(SelectChannelToPost.this.getString(C0421R.string.favorite_channels), SelectChannelToPost.this.favchannels);
                        FavChannelTable mItem = new FavChannelTable();
                        mItem.setTitle(channelName);
                        mItem.setSubtitle(channelDescription);
                        mItem.setImage(SelectChannelToPost.this.channelPictureUrl + channelPicture);
                        mItem.setUuid(channelUuid);
                        mItem.setOwner(channelOwner);
                        mItem.setVizsafechannel(channelVizsafe);
                        mItem.setPrivatechannel(channelPrivate);
                        mItem.setSecretchannel(channelSecret);
                        mItem.setMassaged(channelMassaged);
                        SelectChannelToPost.this.mAppDatabase.mFavChannelDao().insertAll(mItem);
                    }
                }
                SelectChannelToPost.this.TaskAllChannels();
                return;
            }
            SelectChannelToPost.this.mTransparentProgressDialog.dismiss();
            Toast.makeText(SelectChannelToPost.this.getApplicationContext(), responseFavouriteChannelsApi.getMessage(), 0).show();
        }

        public void failure(RetrofitError error) {
            SelectChannelToPost.this.mTransparentProgressDialog.dismiss();
            Toast.makeText(SelectChannelToPost.this.getApplicationContext(), SelectChannelToPost.this.getString(C0421R.string.unable_to_get_channels), 0).show();
            error.printStackTrace();
        }
    }

    /* renamed from: com.vizsafe.app.PostReportPages.SelectChannelToPost$5 */
    class C04115 implements Callback<ResponseVizsafeChannelsApi> {
        C04115() {
        }

        public void success(ResponseVizsafeChannelsApi responseVizsafeChannelsApi, Response response) {
            if (responseVizsafeChannelsApi.getHttpCode().intValue() == 200) {
                Detail mDetailChannels = responseVizsafeChannelsApi.getDetail();
                try {
                    SelectChannelToPost.this.mChannelsList.clear();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                SelectChannelToPost.this.mChannelsList = mDetailChannels.getChannels();
                if (SelectChannelToPost.this.mChannelsList != null) {
                    SelectChannelToPost.this.vizsafechannels = new ArrayList();
                    SelectChannelToPost.this.listDataHeader.add(SelectChannelToPost.this.getString(C0421R.string.vizsafe_channels));
                    SelectChannelToPost.this.mAppDatabase.mVizsafeChannelDao().delete();
                    for (int count = 0; count < SelectChannelToPost.this.mChannelsList.size(); count++) {
                        String channelName = ((Channel) SelectChannelToPost.this.mChannelsList.get(count)).getName();
                        String channelDescription = ((Channel) SelectChannelToPost.this.mChannelsList.get(count)).getDescription();
                        String channelUuid = ((Channel) SelectChannelToPost.this.mChannelsList.get(count)).getUuid();
                        String channelPicture = ((Channel) SelectChannelToPost.this.mChannelsList.get(count)).getChannelPicture();
                        String channelOwner = ((Channel) SelectChannelToPost.this.mChannelsList.get(count)).getOwner();
                        boolean channelVizsafe = ((Channel) SelectChannelToPost.this.mChannelsList.get(count)).getVizsafeChannel().booleanValue();
                        boolean channelPrivate = ((Channel) SelectChannelToPost.this.mChannelsList.get(count)).getPrivateChannel().booleanValue();
                        boolean channelSecret = ((Channel) SelectChannelToPost.this.mChannelsList.get(count)).getSecretChannel().booleanValue();
                        boolean channelMassaged = ((Channel) SelectChannelToPost.this.mChannelsList.get(count)).getMassaged().booleanValue();
                        SelectChannelToPost.this.vizsafechannels.add(new ChannelsListItem(channelName, channelDescription, SelectChannelToPost.this.channelPictureUrl + channelPicture, channelUuid, channelOwner, channelVizsafe, channelPrivate, channelSecret, channelMassaged));
                        SelectChannelToPost.this.listDataChild.put(SelectChannelToPost.this.getString(C0421R.string.vizsafe_channels), SelectChannelToPost.this.vizsafechannels);
                        VizsafeChannelTable mItem = new VizsafeChannelTable();
                        mItem.setTitle(channelName);
                        mItem.setSubtitle(channelDescription);
                        mItem.setImage(SelectChannelToPost.this.channelPictureUrl + channelPicture);
                        mItem.setUuid(channelUuid);
                        mItem.setOwner(channelOwner);
                        mItem.setVizsafechannel(channelVizsafe);
                        mItem.setPrivatechannel(channelPrivate);
                        mItem.setSecretchannel(channelSecret);
                        mItem.setMassaged(channelMassaged);
                        SelectChannelToPost.this.mAppDatabase.mVizsafeChannelDao().insertAll(mItem);
                    }
                }
                SelectChannelToPost.this.TaskAllChannels();
                return;
            }
            SelectChannelToPost.this.mTransparentProgressDialog.dismiss();
            Toast.makeText(SelectChannelToPost.this.getApplicationContext(), responseVizsafeChannelsApi.getMessage(), 0).show();
        }

        public void failure(RetrofitError error) {
            SelectChannelToPost.this.mTransparentProgressDialog.dismiss();
            Toast.makeText(SelectChannelToPost.this.getApplicationContext(), SelectChannelToPost.this.getString(C0421R.string.unable_to_get_channels), 0).show();
            error.printStackTrace();
        }
    }

    /* renamed from: com.vizsafe.app.PostReportPages.SelectChannelToPost$6 */
    class C04126 implements Callback<ResponseAllChannelsApi> {
        C04126() {
        }

        public void success(ResponseAllChannelsApi responseAllChannelsApi, Response response) {
            SelectChannelToPost.this.mTransparentProgressDialog.dismiss();
            if (responseAllChannelsApi.getHttpCode().intValue() == 200) {
                Detail mDetailChannels = responseAllChannelsApi.getDetail();
                try {
                    SelectChannelToPost.this.mChannelsList.clear();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                SelectChannelToPost.this.mChannelsList = mDetailChannels.getChannels();
                if (SelectChannelToPost.this.mChannelsList != null) {
                    SelectChannelToPost.this.listDataHeader.add(SelectChannelToPost.this.getString(C0421R.string.all_channels));
                    SelectChannelToPost.this.allchannels = new ArrayList();
                    SelectChannelToPost.this.mAppDatabase.mTipsChannelDao().delete();
                    SelectChannelToPost.this.mAppDatabase.mAllChannelsDao().delete();
                    for (int count = 0; count < SelectChannelToPost.this.mChannelsList.size(); count++) {
                        String channelName = ((Channel) SelectChannelToPost.this.mChannelsList.get(count)).getName();
                        String channelDescription = ((Channel) SelectChannelToPost.this.mChannelsList.get(count)).getDescription();
                        String channelUuid = ((Channel) SelectChannelToPost.this.mChannelsList.get(count)).getUuid();
                        String channelPicture = ((Channel) SelectChannelToPost.this.mChannelsList.get(count)).getChannelPicture();
                        String channelOwner = ((Channel) SelectChannelToPost.this.mChannelsList.get(count)).getOwner();
                        boolean channelVizsafe = ((Channel) SelectChannelToPost.this.mChannelsList.get(count)).getVizsafeChannel().booleanValue();
                        boolean channelPrivate = ((Channel) SelectChannelToPost.this.mChannelsList.get(count)).getPrivateChannel().booleanValue();
                        boolean channelSecret = ((Channel) SelectChannelToPost.this.mChannelsList.get(count)).getSecretChannel().booleanValue();
                        boolean channelMassaged = ((Channel) SelectChannelToPost.this.mChannelsList.get(count)).getMassaged().booleanValue();
                        if (((Channel) SelectChannelToPost.this.mChannelsList.get(count)).equals("tips")) {
                            boolean channelTips = ((Channel) SelectChannelToPost.this.mChannelsList.get(count)).getTips().booleanValue();
                            SelectChannelToPost.this.tipschannels = new ArrayList();
                            boolean mTipsHad = false;
                            for (int i = 0; i < SelectChannelToPost.this.listDataHeader.size(); i++) {
                                if (((String) SelectChannelToPost.this.listDataHeader.get(i)).equals(SelectChannelToPost.this.getString(C0421R.string.tips_channels))) {
                                    mTipsHad = true;
                                }
                            }
                            if (!mTipsHad) {
                                SelectChannelToPost.this.listDataHeader.add(SelectChannelToPost.this.getString(C0421R.string.tips_channels));
                            }
                            if (channelTips) {
                                SelectChannelToPost.this.tipschannels.add(new ChannelsListItem(channelName, channelDescription, SelectChannelToPost.this.channelPictureUrl + channelPicture, channelUuid, channelOwner, channelVizsafe, channelPrivate, channelSecret, channelMassaged));
                                SelectChannelToPost.this.listDataChild.put(SelectChannelToPost.this.getString(C0421R.string.tips_channels), SelectChannelToPost.this.tipschannels);
                                TipsChannelTable mItem = new TipsChannelTable();
                                mItem.setTitle(channelName);
                                mItem.setSubtitle(channelDescription);
                                mItem.setImage(SelectChannelToPost.this.channelPictureUrl + channelPicture);
                                mItem.setUuid(channelUuid);
                                mItem.setOwner(channelOwner);
                                mItem.setVizsafechannel(channelVizsafe);
                                mItem.setPrivatechannel(channelPrivate);
                                mItem.setSecretchannel(channelSecret);
                                mItem.setMassaged(channelMassaged);
                                SelectChannelToPost.this.mAppDatabase.mTipsChannelDao().insertAll(mItem);
                            }
                        }
                        AllChannelsTable mAllChannelsTable = new AllChannelsTable();
                        mAllChannelsTable.setTitle(channelName);
                        mAllChannelsTable.setSubtitle(channelDescription);
                        mAllChannelsTable.setImage(SelectChannelToPost.this.channelPictureUrl + channelPicture);
                        mAllChannelsTable.setUuid(channelUuid);
                        mAllChannelsTable.setOwner(channelOwner);
                        mAllChannelsTable.setVizsafechannel(channelVizsafe);
                        mAllChannelsTable.setPrivatechannel(channelPrivate);
                        mAllChannelsTable.setSecretchannel(channelSecret);
                        mAllChannelsTable.setMassaged(channelMassaged);
                        SelectChannelToPost.this.mAppDatabase.mAllChannelsDao().insertAll(mAllChannelsTable);
                        SelectChannelToPost.this.allchannels.add(new ChannelsListItem(channelName, channelDescription, SelectChannelToPost.this.channelPictureUrl + channelPicture, channelUuid, channelOwner, channelVizsafe, channelPrivate, channelSecret, channelMassaged));
                        SelectChannelToPost.this.listDataChild.put(SelectChannelToPost.this.getString(C0421R.string.all_channels), SelectChannelToPost.this.allchannels);
                    }
                }
                if (!(SelectChannelToPost.this.tipsChannel == null || SelectChannelToPost.this.tipsChannel.isEmpty())) {
                    SelectChannelToPost.this.items.add(new SectionItem(SelectChannelToPost.this.getString(C0421R.string.tips_channels)));
                    SelectChannelToPost.this.items.addAll(SelectChannelToPost.this.tipsChannel);
                }
                if (!(SelectChannelToPost.this.favoriteChannel == null || SelectChannelToPost.this.favoriteChannel.isEmpty())) {
                    SelectChannelToPost.this.items.add(new SectionItem(SelectChannelToPost.this.getString(C0421R.string.favorite_channels)));
                    SelectChannelToPost.this.items.addAll(SelectChannelToPost.this.favoriteChannel);
                }
                if (!(SelectChannelToPost.this.vizsafeChannel == null || SelectChannelToPost.this.vizsafeChannel.isEmpty())) {
                    SelectChannelToPost.this.items.add(new SectionItem(SelectChannelToPost.this.getString(C0421R.string.vizsafe_channels)));
                    SelectChannelToPost.this.items.addAll(SelectChannelToPost.this.vizsafeChannel);
                }
                if (!(SelectChannelToPost.this.allChannels == null || SelectChannelToPost.this.allChannels.isEmpty())) {
                    SelectChannelToPost.this.items.add(new SectionItem(SelectChannelToPost.this.getString(C0421R.string.all_channels)));
                    SelectChannelToPost.this.items.addAll(SelectChannelToPost.this.allChannels);
                }
                SelectChannelToPost.this.listAdapter = new CustomExpandableListAdapter(SelectChannelToPost.selectChannelToPost, SelectChannelToPost.this.listDataHeader, SelectChannelToPost.this.listDataChild, SelectChannelToPost.this.selectedChannelItems);
                SelectChannelToPost.this.expListView.setAdapter(SelectChannelToPost.this.listAdapter);
                if (SelectChannelToPost.this.listDataHeader.size() > 0) {
                    SelectChannelToPost.this.expListView.expandGroup(0);
                }
                if (SelectChannelToPost.this.listDataChild.size() == 0) {
                    Toast.makeText(SelectChannelToPost.this.getApplicationContext(), SelectChannelToPost.this.getResources().getString(C0421R.string.subscribe_channel_atleast_one), 1).show();
                    return;
                }
                return;
            }
            SelectChannelToPost.this.mTransparentProgressDialog.dismiss();
            Toast.makeText(SelectChannelToPost.this.getApplicationContext(), responseAllChannelsApi.getMessage(), 0).show();
        }

        public void failure(RetrofitError error) {
            SelectChannelToPost.this.mTransparentProgressDialog.dismiss();
            Toast.makeText(SelectChannelToPost.this.getApplicationContext(), SelectChannelToPost.this.getString(C0421R.string.unable_to_get_channels), 0).show();
            error.printStackTrace();
        }
    }

    private class AsyncTaskPostFeed extends AsyncTask<String, String, String> {
        JSONObject response;
        String successStatus;

        /* renamed from: com.vizsafe.app.PostReportPages.SelectChannelToPost$AsyncTaskPostFeed$1 */
        class C04131 extends TypeToken<List<OutboxSentPostItems>> {
            C04131() {
            }
        }

        private AsyncTaskPostFeed() {
            this.response = null;
            this.successStatus = "yes";
        }

        /* synthetic */ AsyncTaskPostFeed(SelectChannelToPost x0, C04071 x1) {
            this();
        }

        protected void onPreExecute() {
            super.onPreExecute();
        }

        protected String doInBackground(String... arg0) {
            String email = PreferenceHandler.getInstance(SelectChannelToPost.selectChannelToPost).getUserName();
            String password = PreferenceHandler.getInstance(SelectChannelToPost.selectChannelToPost).getPassword();
            try {
                this.response = new Webservice().postFeedWebService(SelectChannelToPost.this.getApplicationContext(), email, password, SelectChannelToPost.this.POST_DATA);
            } catch (Exception e) {
                e.printStackTrace();
                this.successStatus = "no";
            }
            return this.successStatus;
        }

        protected void onPostExecute(String result) {
            if (this.response != null) {
                Toast.makeText(SelectChannelToPost.selectChannelToPost, SelectChannelToPost.this.getResources().getString(C0421R.string.post_success), 1).show();
                Gson gson = new Gson();
                String jsonCars = PreferenceHandler.getInstance(SelectChannelToPost.this).getOutBoxSet();
                Type type = new C04131().getType();
                ArrayList arrayList = new ArrayList();
                Object arrayList2 = (ArrayList) gson.fromJson(jsonCars, type);
                if (arrayList2 == null || arrayList2.size() <= 0) {
                    PreferenceHandler.getInstance(SelectChannelToPost.this).setOutBoxSet("");
                } else {
                    arrayList2.remove(arrayList2.size() - 1);
                    PreferenceHandler.getInstance(SelectChannelToPost.this).setOutBoxSet(gson.toJson(arrayList2));
                }
                SelectChannelToPost.this.broadcastOutboxIntent();
            }
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0421R.layout.select_channel_to_post);
        selectChannelToPost = this;
        this.mTransparentProgressDialog = new SpotsDialog(selectChannelToPost, getResources().getString(C0421R.string.please_wait_loading));
        this.mTransparentProgressDialog.setCanceledOnTouchOutside(false);
        this.mTransparentProgressDialog.setCancelable(false);
        this.channelPictureUrl = CommonMember.getURL(selectChannelToPost) + "/picture/";
        this.expListView = (ExpandableListView) findViewById(C0421R.C0419id.lvExp);
        this.backBtn = (ImageView) findViewById(C0421R.C0419id.action_bar_back);
        this.nextBtn = (TextView) findViewById(C0421R.C0419id.action_bar_next);
        this.nextBtn.setVisibility(0);
        this.nextBtn.setText(getResources().getString(C0421R.string.send));
        this.email = PreferenceHandler.getInstance(selectChannelToPost).getUserName();
        this.password = PreferenceHandler.getInstance(selectChannelToPost).getPassword();
        this.authenticationString = "Basic " + Base64.encodeToString((this.email + ":" + this.password).getBytes(), 2);
        boolean network = CommonMember.isNetworkOnline((ConnectivityManager) getSystemService("connectivity"), this);
        this.mAppDatabase = AppDatabase.getAppDatabase(this);
        if (network) {
            TaskFavouriteChannels();
        } else {
            if (this.mAppDatabase.mTipsChannelDao().getAll().size() > 0) {
                getTipsChannelFromDB();
            }
            if (this.mAppDatabase.mFavChannelDao().getAll().size() > 0) {
                getFavChannelFromDB();
            }
            if (this.mAppDatabase.mAllChannelsDao().getAll().size() > 0) {
                getAllChannelFromDB();
            }
            this.listAdapter = new CustomExpandableListAdapter(selectChannelToPost, this.listDataHeader, this.listDataChild, this.selectedChannelItems);
            this.expListView.setAdapter(this.listAdapter);
            if (this.listDataHeader.size() > 0) {
                this.expListView.expandGroup(0);
            }
            if (this.listDataChild.size() == 0) {
                Toast.makeText(getApplicationContext(), getResources().getString(C0421R.string.subscribe_channel_atleast_one), 1).show();
            }
        }
        this.postType = getIntent().getExtras().getString("post_type");
        this.imagePath = getIntent().getExtras().getString("post_image_data");
        this.latitude = getIntent().getExtras().getString("post_latitude");
        this.longitude = getIntent().getExtras().getString("post_longitude");
        this.mAltitudeValue = getIntent().getExtras().getString("Altitude");
        this.description = getIntent().getExtras().getString("post_description");
        this.timeAndDate = getIntent().getExtras().getString("post_timestamp");
        this.anonymusStatus = getIntent().getExtras().getString("post_anonymous");
        this.severityStatus = getIntent().getExtras().getString("severity");
        this.mCommunitySelectedValue = Integer.valueOf(getIntent().getExtras().getInt("mCommunitySelectedValue"));
        this.mDrawingSelectedValue = Integer.valueOf(getIntent().getExtras().getInt("mDrawingSelectedValue"));
        this.mLevelSelectedValue = Integer.valueOf(getIntent().getExtras().getInt("mLevelSelectedValue"));
        if (this.postType.equalsIgnoreCase("video")) {
            this.base64ThumnailImage = Base64.encodeToString(getBytesFromBitmap(ThumbnailUtils.createVideoThumbnail(this.imagePath, 3)), 2);
            InputStream inputStream = null;
            try {
                inputStream = getContentResolver().openInputStream(Uri.fromFile(new File(this.imagePath)));
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            byte[] buffer = new byte[1024];
            ByteArrayOutputStream byteBuffer = new ByteArrayOutputStream();
            while (true) {
                try {
                    int len = inputStream.read(buffer);
                    if (len == -1) {
                        break;
                    }
                    byteBuffer.write(buffer, 0, len);
                } catch (IOException e2) {
                    e2.printStackTrace();
                }
            }
            this.base64Image = Base64.encodeToString(byteBuffer.toByteArray(), 0);
            Log.d("Res VideoData  **> -  ", this.base64Image);
        } else {
            this.base64Image = getBase64DatafromImage(this.imagePath);
            Log.d("Res imagePath photo - ", this.base64Image);
        }
        this.nextBtn.setOnClickListener(new C04071());
        this.backBtn.setOnClickListener(new C04082());
        this.expListView.setOnChildClickListener(new C04093());
    }

    private void getAllChannelFromDB() {
        List<AllChannelsTable> channel = this.mAppDatabase.mAllChannelsDao().getAll();
        this.allchannels = new ArrayList();
        for (int count = 0; count < channel.size(); count++) {
            String channelName = ((AllChannelsTable) channel.get(count)).getTitle();
            String channelDescription = ((AllChannelsTable) channel.get(count)).getSubtitle();
            String channelUuid = ((AllChannelsTable) channel.get(count)).getUuid();
            String channelPicture = ((AllChannelsTable) channel.get(count)).getImage();
            this.allchannels.add(new ChannelsListItem(channelName, channelDescription, this.channelPictureUrl + channelPicture, channelUuid, ((AllChannelsTable) channel.get(count)).getOwner(), ((AllChannelsTable) channel.get(count)).getVizsafechannel(), ((AllChannelsTable) channel.get(count)).getPrivatechannel(), ((AllChannelsTable) channel.get(count)).getSecretchannel(), ((AllChannelsTable) channel.get(count)).getMassaged()));
            this.listDataChild.put(getString(C0421R.string.all_channels), this.allchannels);
        }
        this.listDataHeader.add(getString(C0421R.string.all_channels));
    }

    private void getVizsafeChannelFromDB() {
        List<VizsafeChannelTable> channel = this.mAppDatabase.mVizsafeChannelDao().getAll();
        this.vizsafechannels = new ArrayList();
        for (int count = 0; count < channel.size(); count++) {
            String channelName = ((VizsafeChannelTable) channel.get(count)).getTitle();
            String channelDescription = ((VizsafeChannelTable) channel.get(count)).getSubtitle();
            String channelUuid = ((VizsafeChannelTable) channel.get(count)).getUuid();
            String channelPicture = ((VizsafeChannelTable) channel.get(count)).getImage();
            this.vizsafechannels.add(new ChannelsListItem(channelName, channelDescription, this.channelPictureUrl + channelPicture, channelUuid, ((VizsafeChannelTable) channel.get(count)).getOwner(), ((VizsafeChannelTable) channel.get(count)).getVizsafechannel(), ((VizsafeChannelTable) channel.get(count)).getPrivatechannel(), ((VizsafeChannelTable) channel.get(count)).getSecretchannel(), ((VizsafeChannelTable) channel.get(count)).getMassaged()));
            this.listDataChild.put(getString(C0421R.string.vizsafe_channels), this.vizsafechannels);
        }
        this.listDataHeader.add(getString(C0421R.string.vizsafe_channels));
    }

    private void getFavChannelFromDB() {
        List<FavChannelTable> channel = this.mAppDatabase.mFavChannelDao().getAll();
        this.listDataChild = new HashMap();
        this.listDataHeader = new ArrayList();
        this.favchannels = new ArrayList();
        for (int count = 0; count < channel.size(); count++) {
            String channelName = ((FavChannelTable) channel.get(count)).getTitle();
            String channelDescription = ((FavChannelTable) channel.get(count)).getSubtitle();
            String channelUuid = ((FavChannelTable) channel.get(count)).getUuid();
            String channelPicture = ((FavChannelTable) channel.get(count)).getImage();
            this.favchannels.add(new ChannelsListItem(channelName, channelDescription, this.channelPictureUrl + channelPicture, channelUuid, ((FavChannelTable) channel.get(count)).getOwner(), ((FavChannelTable) channel.get(count)).getVizsafechannel(), ((FavChannelTable) channel.get(count)).getPrivatechannel(), ((FavChannelTable) channel.get(count)).getSecretchannel(), ((FavChannelTable) channel.get(count)).getMassaged()));
            this.listDataChild.put(getString(C0421R.string.favorite_channels), this.favchannels);
        }
        this.listDataHeader.add(getString(C0421R.string.favorite_channels));
    }

    private void getTipsChannelFromDB() {
        List<TipsChannelTable> channel = this.mAppDatabase.mTipsChannelDao().getAll();
        this.tipschannels = new ArrayList();
        this.listDataChild = new HashMap();
        this.listDataHeader = new ArrayList();
        for (int count = 0; count < channel.size(); count++) {
            String channelName = ((TipsChannelTable) channel.get(count)).getTitle();
            String channelDescription = ((TipsChannelTable) channel.get(count)).getSubtitle();
            String channelUuid = ((TipsChannelTable) channel.get(count)).getUuid();
            String channelPicture = ((TipsChannelTable) channel.get(count)).getImage();
            this.tipschannels.add(new ChannelsListItem(channelName, channelDescription, this.channelPictureUrl + channelPicture, channelUuid, ((TipsChannelTable) channel.get(count)).getOwner(), ((TipsChannelTable) channel.get(count)).getVizsafechannel(), ((TipsChannelTable) channel.get(count)).getPrivatechannel(), ((TipsChannelTable) channel.get(count)).getSecretchannel(), ((TipsChannelTable) channel.get(count)).getMassaged()));
            this.listDataChild.put(getString(C0421R.string.tips_channels), this.tipschannels);
        }
        this.listDataHeader.add(getString(C0421R.string.tips_channels));
    }

    public static byte[] getBytesFromBitmap(Bitmap bitmap) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(CompressFormat.JPEG, 70, stream);
        return stream.toByteArray();
    }

    private Bitmap createThumbnailAtTime(String filePath, int timeInSeconds) {
        MediaMetadataRetriever mMMR = new MediaMetadataRetriever();
        mMMR.setDataSource(filePath);
        return mMMR.getFrameAtTime((long) (1000000 * timeInSeconds), 2);
    }

    private void TaskFavouriteChannels() {
        this.mTransparentProgressDialog.show();
        FavouriteChannelsApi.getInstance().Callresponse(getApplicationContext(), this.authenticationString, PreferenceHandler.getInstance(getApplicationContext()).getUserUUID(), new C04104());
    }

    private void TaskVizsafeChannels() {
        VizsafeChannelsApi.getInstance().Callresponse(getApplicationContext(), this.authenticationString, "VIZSAFE", new C04115());
    }

    private void TaskAllChannels() {
        AllChannelsApi.getInstance().Callresponse(getApplicationContext(), this.authenticationString, new C04126());
    }

    public static java.lang.String getBase64DatafromImage(java.lang.String r13) {
        /*
        r8 = "";
        r11 = android.os.Build.VERSION.SDK_INT;
        r12 = 24;
        if (r11 <= r12) goto L_0x008e;
    L_0x0008:
        r3 = 0;
        r4 = new android.media.ExifInterface;	 Catch:{ IOException -> 0x006a }
        r4.<init>(r13);	 Catch:{ IOException -> 0x006a }
        r3 = r4;
    L_0x000f:
        r0 = 0;
        r11 = "Orientation";
        r12 = 0;
        r6 = r3.getAttributeInt(r11, r12);	 Catch:{ NullPointerException -> 0x0084 }
        r0 = com.vizsafe.app.Utils.CommonMember.showBitmapFromFile(r13);	 Catch:{ NullPointerException -> 0x0084 }
        switch(r6) {
            case 3: goto L_0x0076;
            case 4: goto L_0x001e;
            case 5: goto L_0x001e;
            case 6: goto L_0x006f;
            case 7: goto L_0x001e;
            case 8: goto L_0x007d;
            default: goto L_0x001e;
        };
    L_0x001e:
        if (r0 == 0) goto L_0x0069;
    L_0x0020:
        r5 = "sample.png";
        r9 = android.os.Environment.getExternalStorageDirectory();
        r1 = new java.io.File;
        r11 = new java.lang.StringBuilder;
        r11.<init>();
        r11 = r11.append(r9);
        r12 = "/VizsafeImages";
        r11 = r11.append(r12);
        r11 = r11.toString();
        r1.<init>(r11);
        r1.mkdirs();
        r10 = new java.io.File;
        r10.<init>(r1, r5);
        r11 = r10.exists();
        if (r11 == 0) goto L_0x004f;
    L_0x004c:
        r10.delete();
    L_0x004f:
        r7 = new java.io.FileOutputStream;	 Catch:{ Exception -> 0x0089 }
        r7.<init>(r10);	 Catch:{ Exception -> 0x0089 }
        r11 = android.graphics.Bitmap.CompressFormat.PNG;	 Catch:{ Exception -> 0x0089 }
        r12 = 90;
        r0.compress(r11, r12, r7);	 Catch:{ Exception -> 0x0089 }
        r7.flush();	 Catch:{ Exception -> 0x0089 }
        r7.close();	 Catch:{ Exception -> 0x0089 }
    L_0x0061:
        r11 = r10.getPath();
        r8 = getBase64DatafromImage1(r11);
    L_0x0069:
        return r8;
    L_0x006a:
        r2 = move-exception;
        r2.printStackTrace();
        goto L_0x000f;
    L_0x006f:
        r11 = 1119092736; // 0x42b40000 float:90.0 double:5.529052754E-315;
        r0 = rotateImage(r0, r11);	 Catch:{ NullPointerException -> 0x0084 }
        goto L_0x001e;
    L_0x0076:
        r11 = 1127481344; // 0x43340000 float:180.0 double:5.570497984E-315;
        r0 = rotateImage(r0, r11);	 Catch:{ NullPointerException -> 0x0084 }
        goto L_0x001e;
    L_0x007d:
        r11 = 1132920832; // 0x43870000 float:270.0 double:5.597372625E-315;
        r0 = rotateImage(r0, r11);	 Catch:{ NullPointerException -> 0x0084 }
        goto L_0x001e;
    L_0x0084:
        r2 = move-exception;
        r2.printStackTrace();
        goto L_0x001e;
    L_0x0089:
        r2 = move-exception;
        r2.printStackTrace();
        goto L_0x0061;
    L_0x008e:
        r8 = getBase64DatafromImage1(r13);
        goto L_0x0069;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.vizsafe.app.PostReportPages.SelectChannelToPost.getBase64DatafromImage(java.lang.String):java.lang.String");
    }

    private static String getBase64DatafromImage1(String filePath) {
        String ret = "";
        try {
            File queryImg = new File(filePath);
            byte[] imgData = new byte[((int) queryImg.length())];
            FileInputStream fis = new FileInputStream(queryImg);
            fis.read(imgData);
            ret = Base64.encodeToString(imgData, 2);
            fis.close();
            return ret;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return ret;
        } catch (IOException e2) {
            e2.printStackTrace();
            return ret;
        }
    }

    public void broadcastOutboxIntent() {
        Intent intent = new Intent();
        intent.setAction("com.vizsafe.UPDATE_OUTBOX");
        sendBroadcast(intent);
    }

    public void broadcastPostFailed() {
        Intent intent = new Intent();
        intent.setAction("com.vizsafe.POST_FAILED");
        sendBroadcast(intent);
    }

    public static void backupDatabase() throws IOException {
        FileInputStream fis = new FileInputStream(new File("/data/data/com.vizsafe.app/databases/channelDB"));
        OutputStream output = new FileOutputStream(Environment.getExternalStorageDirectory() + "/VizsafeDatabase");
        byte[] buffer = new byte[1024];
        while (true) {
            int length = fis.read(buffer);
            if (length > 0) {
                output.write(buffer, 0, length);
            } else {
                output.flush();
                output.close();
                fis.close();
                return;
            }
        }
    }

    public static Bitmap rotateImage(Bitmap source, float angle) {
        Matrix matrix = new Matrix();
        matrix.postRotate(angle);
        return Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(), matrix, true);
    }
}
