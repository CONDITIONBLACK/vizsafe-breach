package com.vizsafe.app.PostReportPages;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;
import com.vizsafe.app.C0421R;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class TimePickerScreen extends Activity {
    public static String currTime;
    public static boolean inDateTimePicker = false;
    String currentTime;
    private DatePicker datePicker;
    private int hour;
    private int minute;
    private TextView nextBtn;
    private TimePicker timePicker;

    /* renamed from: com.vizsafe.app.PostReportPages.TimePickerScreen$1 */
    class C04171 implements OnClickListener {
        C04171() {
        }

        public void onClick(View v) {
            TimePickerScreen.this.hour = TimePickerScreen.this.timePicker.getCurrentHour().intValue();
            TimePickerScreen.this.minute = TimePickerScreen.this.timePicker.getCurrentMinute().intValue();
            TimePickerScreen.this.currentTime = TimePickerScreen.this.hour + ":" + TimePickerScreen.this.minute;
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
            SimpleDateFormat sdfo = new SimpleDateFormat("hh:mm:ss aa");
            Date dateObj = null;
            try {
                dateObj = sdf.parse(TimePickerScreen.this.currentTime);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            TimePickerScreen.currTime = sdfo.format(dateObj);
            TimePickerScreen.this.startActivity(new Intent(TimePickerScreen.this, SelectLocationScreen.class));
            TimePickerScreen.this.finish();
            TimePickerScreen.inDateTimePicker = true;
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0421R.layout.date_time_picker_screen);
        this.nextBtn = (TextView) findViewById(C0421R.C0419id.action_bar_next);
        this.datePicker = (DatePicker) findViewById(C0421R.C0419id.datePicker1);
        this.timePicker = (TimePicker) findViewById(C0421R.C0419id.timePicker1);
        this.datePicker.setVisibility(8);
        Calendar c = Calendar.getInstance();
        this.hour = c.get(11);
        this.minute = c.get(12);
        this.timePicker.setCurrentHour(Integer.valueOf(this.hour));
        this.timePicker.setCurrentMinute(Integer.valueOf(this.minute));
        this.nextBtn.setOnClickListener(new C04171());
    }
}
