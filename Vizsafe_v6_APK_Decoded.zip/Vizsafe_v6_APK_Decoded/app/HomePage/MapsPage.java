package com.vizsafe.app.HomePage;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender.SendIntentException;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.p001v4.app.ActivityCompat;
import android.support.p001v4.app.Fragment;
import android.support.p001v4.app.FragmentManager;
import android.support.p001v4.app.FragmentTransaction;
import android.support.p001v4.content.ContextCompat;
import android.util.Base64;
import android.util.Log;
import android.view.InflateException;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import com.google.android.gms.analytics.ecommerce.ProductAction;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResult;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.InfoWindowAdapter;
import com.google.android.gms.maps.GoogleMap.OnCameraIdleListener;
import com.google.android.gms.maps.GoogleMap.OnCameraMoveStartedListener;
import com.google.android.gms.maps.GoogleMap.OnInfoWindowClickListener;
import com.google.android.gms.maps.GoogleMap.OnMarkerClickListener;
import com.google.android.gms.maps.GoogleMap.OnMyLocationClickListener;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.nearby.messages.Strategy;
import com.google.android.gms.plus.PlusShare;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.analytics.FirebaseAnalytics.Param;
import com.google.gson.JsonObject;
import com.vizsafe.app.APIClientMethods.GetBOAPins;
import com.vizsafe.app.APIClientMethods.GetCameraPins;
import com.vizsafe.app.APIClientMethods.GetIncidentPinsApi;
import com.vizsafe.app.APIClientMethods.GetIncidentPinsBoundsApi;
import com.vizsafe.app.APIClientMethods.GetPrivateCameraPins;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.CustomViews.SampleWebview;
import com.vizsafe.app.GCMIntentService.GCMClientManager;
import com.vizsafe.app.LiveCameraMethods.CameraLiveScreen;
import com.vizsafe.app.Maps.WebviewLoader;
import com.vizsafe.app.POJO.ChannelsListItem;
import com.vizsafe.app.POJO.FeedListItems;
import com.vizsafe.app.POJO.NotesItems;
import com.vizsafe.app.Utils.CommonMember;
import com.vizsafe.app.Utils.PreferenceHandler;
import com.vizsafe.app.Utils.VizsafeGPSTracker;
import com.vizsafe.app.Utils.Webservice;
import dmax.dialog.SpotsDialog;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Matcher;
import org.apache.http.HttpHeaders;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class MapsPage extends Fragment implements OnMyLocationClickListener, OnMapReadyCallback, ConnectionCallbacks, OnConnectionFailedListener {
    private static final String COURSE_LOCATION = "android.permission.ACCESS_COARSE_LOCATION";
    private static final float DEFAULT_ZOOM = 15.0f;
    private static final String FINE_LOCATION = "android.permission.ACCESS_FINE_LOCATION";
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1234;
    static final int REQUEST_LOCATION_MAP = 115;
    private static final String TAG = "MapsPage";
    public static double latitude;
    public static double longitude;
    private static String mPassedLongitude;
    private static String mPassedlatitude;
    int FEED_CLEARED_MAP = 100;
    String URL;
    ArrayList<FeedListItems> arraylist = new ArrayList();
    private String authenticationString;
    JSONArray boapinsListArray = null;
    JSONObject boapinsListObject = null;
    HashMap<String, String> cameraDetail = new HashMap();
    String cameraIcon;
    String cameraLatitude = null;
    String cameraLongitude = null;
    String cameraName;
    String cameraUuid;
    HashMap<String, String> cameraVideoDetail = new HashMap();
    JSONArray camerasListArray = null;
    JSONObject camerasListObject = null;
    String channelPictureUrl;
    int count = 0;
    int fromDuration = 0;
    private GoogleMap googleMap;
    private VizsafeGPSTracker gps;
    private boolean gps_enabled;
    boolean isFirstTime = true;
    private LocationManager locManager;
    int locationCount = 0;
    private Matcher mDragTimer;
    private FusedLocationProviderClient mFusedLocationProviderClient;
    GoogleApiClient mGoogleApiClient;
    private JSONObject mJsonResponse;
    private Boolean mLocationPermissionsGranted = Boolean.valueOf(false);
    LocationRequest mLocationRequest;
    private String mMicello_floorplan;
    private String mResponse;
    private String mStatic_floorplan;
    private boolean mTimerIsRunning = false;
    private AlertDialog mTransparentProgressDialog;
    private String mUsermanagement_user;
    private ProgressBar mapProgress;
    Button mapStyleBtn;
    String[] mapStyles = new String[0];
    private Context mapTab;
    Marker marker = null;
    HashMap<String, FeedListItems> markerDetails = new HashMap();
    String markerText;
    String marketColor;
    Button myLocationBtn;
    String northLat;
    String northLng;
    PendingResult<LocationSettingsResult> result;
    private SeekBar seekbar;
    int setSelection = 0;
    private TextView showingText;
    String southLat;
    String southLng;
    private ImageView timeIcon;
    View vMapsPage;
    String videoInput = null;

    public interface onGoToReportDetailsPageListener {
        void onGoToReportDetailsPage(Bundle bundle);
    }

    public interface onGoToMicelloIndoorPageListener {
        void onGoToMicelloIndoorPage();
    }

    /* renamed from: com.vizsafe.app.HomePage.MapsPage$10 */
    class C031510 implements Callback<JsonObject> {
        C031510() {
        }

        public void success(JsonObject responseGetIncidentPinsApi, Response response) {
            if (MapsPage.this.mapProgress.getVisibility() == 0) {
                MapsPage.this.mapProgress.setVisibility(8);
            }
            try {
                MapsPage.this.mResponse = String.valueOf(responseGetIncidentPinsApi);
                MapsPage.this.mJsonResponse = new JSONObject(MapsPage.this.mResponse);
                JSONObject mDetail = MapsPage.this.mJsonResponse.getJSONObject(ProductAction.ACTION_DETAIL);
                int total = mDetail.getInt("total");
                if (!MapsPage.this.arraylist.isEmpty()) {
                    MapsPage.this.arraylist.clear();
                }
                if (total > 0) {
                    MapsPage.this.camerasListArray = mDetail.getJSONArray("cameras");
                    if (MapsPage.this.camerasListArray != null) {
                        for (int i = 0; i < MapsPage.this.camerasListArray.length(); i++) {
                            MapsPage.this.camerasListObject = MapsPage.this.camerasListArray.getJSONObject(i);
                            MapsPage.this.cameraName = MapsPage.this.camerasListObject.getString("name");
                            MapsPage.this.cameraLatitude = MapsPage.this.camerasListObject.getString("latitude");
                            MapsPage.this.cameraLongitude = MapsPage.this.camerasListObject.getString("longitude");
                            MapsPage.this.cameraUuid = MapsPage.this.camerasListObject.getString("uuid");
                            MapsPage.this.videoInput = MapsPage.this.camerasListObject.getString("videoinput");
                            MapsPage.this.drawMarker(new LatLng(Double.parseDouble(MapsPage.this.cameraLatitude), Double.parseDouble(MapsPage.this.cameraLongitude)), MapsPage.this.cameraName, "Violet", null, MapsPage.this.cameraUuid, null, MapsPage.this.videoInput);
                        }
                    }
                }
            } catch (NumberFormatException e) {
                e.printStackTrace();
            } catch (JSONException e2) {
                e2.printStackTrace();
            }
        }

        public void failure(RetrofitError error) {
            if (MapsPage.this.mapProgress.getVisibility() == 0) {
                MapsPage.this.mapProgress.setVisibility(8);
            }
            error.printStackTrace();
        }
    }

    /* renamed from: com.vizsafe.app.HomePage.MapsPage$11 */
    class C031611 implements Callback<JsonObject> {
        C031611() {
        }

        public void success(JsonObject responsePrivateCameraListApi, Response response) {
            if (MapsPage.this.mapProgress.getVisibility() == 0) {
                MapsPage.this.mapProgress.setVisibility(8);
            }
            try {
                MapsPage.this.mResponse = String.valueOf(responsePrivateCameraListApi);
                MapsPage.this.mJsonResponse = new JSONObject(MapsPage.this.mResponse);
                JSONObject mDetail = MapsPage.this.mJsonResponse.getJSONObject(ProductAction.ACTION_DETAIL);
                int total = mDetail.getInt("total");
                if (!MapsPage.this.arraylist.isEmpty()) {
                    MapsPage.this.arraylist.clear();
                }
                if (total > 0) {
                    MapsPage.this.camerasListArray = mDetail.getJSONArray("cameras");
                    if (MapsPage.this.camerasListArray != null) {
                        for (int i = 0; i < MapsPage.this.camerasListArray.length(); i++) {
                            MapsPage.this.camerasListObject = MapsPage.this.camerasListArray.getJSONObject(i);
                            MapsPage.this.cameraName = MapsPage.this.camerasListObject.getString("name");
                            MapsPage.this.cameraLatitude = MapsPage.this.camerasListObject.getString("latitude");
                            MapsPage.this.cameraLongitude = MapsPage.this.camerasListObject.getString("longitude");
                            MapsPage.this.cameraUuid = MapsPage.this.camerasListObject.getString("uuid");
                            MapsPage.this.videoInput = MapsPage.this.camerasListObject.getString("videoinput");
                            MapsPage.this.drawMarker(new LatLng(Double.parseDouble(MapsPage.this.cameraLatitude), Double.parseDouble(MapsPage.this.cameraLongitude)), MapsPage.this.cameraName, "Violet", null, MapsPage.this.cameraUuid, null, MapsPage.this.videoInput);
                        }
                    }
                }
            } catch (NumberFormatException e) {
                e.printStackTrace();
            } catch (JSONException e2) {
                e2.printStackTrace();
            }
        }

        public void failure(RetrofitError error) {
            if (MapsPage.this.mapProgress.getVisibility() == 0) {
                MapsPage.this.mapProgress.setVisibility(8);
            }
            error.printStackTrace();
        }
    }

    /* renamed from: com.vizsafe.app.HomePage.MapsPage$12 */
    class C031712 implements Callback<JsonObject> {
        C031712() {
        }

        public void success(JsonObject responseGetIncidentPinsApi, Response response) {
            MapsPage.this.mResponse = String.valueOf(responseGetIncidentPinsApi);
            MapsPage.this.CallResponse(MapsPage.this.mResponse);
        }

        public void failure(RetrofitError error) {
            error.printStackTrace();
        }
    }

    /* renamed from: com.vizsafe.app.HomePage.MapsPage$13 */
    class C031813 implements Callback<JsonObject> {
        C031813() {
        }

        public void success(JsonObject responseGetIncidentPinsApi, Response response) {
            MapsPage.this.mResponse = String.valueOf(responseGetIncidentPinsApi);
            MapsPage.this.CallResponse(MapsPage.this.mResponse);
        }

        public void failure(RetrofitError error) {
            error.printStackTrace();
        }
    }

    /* renamed from: com.vizsafe.app.HomePage.MapsPage$14 */
    class C031914 implements Callback<JsonObject> {
        C031914() {
        }

        public void success(JsonObject responseGetIncidentPinsApi, Response response) {
            if (MapsPage.this.mapProgress.getVisibility() == 0) {
                MapsPage.this.mapProgress.setVisibility(8);
            }
            try {
                MapsPage.this.mResponse = String.valueOf(responseGetIncidentPinsApi);
                MapsPage.this.mJsonResponse = new JSONObject(MapsPage.this.mResponse);
                JSONObject mDetail = MapsPage.this.mJsonResponse.getJSONObject(ProductAction.ACTION_DETAIL);
                int total = mDetail.getInt("total");
                if (!MapsPage.this.arraylist.isEmpty()) {
                    MapsPage.this.arraylist.clear();
                }
                if (total > 0) {
                    MapsPage.this.boapinsListArray = mDetail.getJSONArray("locationpins");
                    if (MapsPage.this.boapinsListArray != null) {
                        for (int i = 0; i < MapsPage.this.boapinsListArray.length(); i++) {
                            MapsPage.this.boapinsListObject = MapsPage.this.boapinsListArray.getJSONObject(i);
                            String locationId = MapsPage.this.boapinsListObject.getString("locationId");
                            String address = MapsPage.this.boapinsListObject.getString("address");
                            String type = MapsPage.this.boapinsListObject.getString("type");
                            String org_uuid = MapsPage.this.boapinsListObject.getString("org_uuid");
                            JSONObject geolocation = MapsPage.this.boapinsListObject.getJSONObject("geolocation").getJSONObject("loc");
                            String longt = geolocation.getString("long");
                            String lat = geolocation.getString("lat");
                            MapsPage.this.videoInput = null;
                            MapsPage.this.drawMarker(new LatLng(Double.parseDouble(lat), Double.parseDouble(longt)), locationId, "BOA", null, null, locationId, MapsPage.this.videoInput);
                        }
                    }
                }
            } catch (NumberFormatException e) {
                e.printStackTrace();
            } catch (JSONException e2) {
                e2.printStackTrace();
            }
        }

        public void failure(RetrofitError error) {
            if (MapsPage.this.mapProgress.getVisibility() == 0) {
                MapsPage.this.mapProgress.setVisibility(8);
            }
            error.printStackTrace();
        }
    }

    /* renamed from: com.vizsafe.app.HomePage.MapsPage$15 */
    class C032015 implements ResultCallback<LocationSettingsResult> {
        C032015() {
        }

        public void onResult(LocationSettingsResult result) {
            Status status = result.getStatus();
            switch (status.getStatusCode()) {
                case 0:
                    MapsPage.this.mLocationPermissionsGranted = Boolean.valueOf(true);
                    if (CommonMember.isNetworkOnline((ConnectivityManager) MapsPage.this.mapTab.getSystemService("connectivity"), MapsPage.this.mapTab)) {
                        MapsPage.this.initMap();
                        return;
                    } else {
                        CommonMember.getErrorDialog(MapsPage.this.getString(C0421R.string.no_internet_access), MapsPage.this.mapTab).show();
                        return;
                    }
                case 6:
                    try {
                        status.startResolutionForResult(MapsPage.this.getActivity(), 115);
                        return;
                    } catch (SendIntentException e) {
                        return;
                    }
                default:
                    return;
            }
        }
    }

    /* renamed from: com.vizsafe.app.HomePage.MapsPage$1 */
    class C03211 implements OnClickListener {

        /* renamed from: com.vizsafe.app.HomePage.MapsPage$1$1 */
        class C03141 implements DialogInterface.OnClickListener {
            C03141() {
            }

            public void onClick(DialogInterface dialog, int which) {
                if (MapsPage.this.getResources().getString(C0421R.string.satellite).equals(MapsPage.this.mapStyles[which])) {
                    MapsPage.this.googleMap.setMapType(2);
                    PreferenceHandler.getInstance(MapsPage.this.mapTab).setMapStyle(MapsPage.this.getResources().getString(C0421R.string.satellite));
                    dialog.dismiss();
                } else if (MapsPage.this.getResources().getString(C0421R.string.dynamicfloorplans).equals(MapsPage.this.mapStyles[which])) {
                    dialog.dismiss();
                    if (CommonMember.isNetworkOnline((ConnectivityManager) MapsPage.this.getContext().getSystemService("connectivity"), MapsPage.this.mapTab)) {
                        PreferenceHandler.getInstance(MapsPage.this.mapTab).setMapStyle(MapsPage.this.getResources().getString(C0421R.string.dynamicfloorplans));
                        ((onGoToMicelloIndoorPageListener) MapsPage.this.mapTab).onGoToMicelloIndoorPage();
                        return;
                    }
                    CommonMember.NetworkStatusAlert(MapsPage.this.mapTab);
                } else if (MapsPage.this.getResources().getString(C0421R.string.staticfloorplans).equals(MapsPage.this.mapStyles[which])) {
                    dialog.dismiss();
                    if (CommonMember.isNetworkOnline((ConnectivityManager) MapsPage.this.getContext().getSystemService("connectivity"), MapsPage.this.mapTab)) {
                        Intent mIntent = new Intent(MapsPage.this.getContext(), WebviewLoader.class);
                        mIntent.putExtra(HttpHeaders.FROM, "MapPage");
                        MapsPage.this.startActivity(mIntent);
                        PreferenceHandler.getInstance(MapsPage.this.mapTab).setMapStyle(MapsPage.this.getResources().getString(C0421R.string.staticfloorplans));
                        return;
                    }
                    CommonMember.NetworkStatusAlert(MapsPage.this.mapTab);
                }
            }
        }

        C03211() {
        }

        public void onClick(View v) {
            if (PreferenceHandler.getInstance(MapsPage.this.mapTab).getMapStyle().equals(MapsPage.this.getResources().getString(C0421R.string.satellite))) {
                MapsPage.this.setSelection = 0;
            } else if (PreferenceHandler.getInstance(MapsPage.this.mapTab).getMapStyle().equals(MapsPage.this.getResources().getString(C0421R.string.dynamicfloorplans))) {
                MapsPage.this.setSelection = 1;
            } else if (PreferenceHandler.getInstance(MapsPage.this.mapTab).getMapStyle().equals(MapsPage.this.getResources().getString(C0421R.string.staticfloorplans))) {
                MapsPage.this.setSelection = 2;
            } else {
                MapsPage.this.setSelection = -1;
            }
            Builder mapStyleDialog = new Builder(MapsPage.this.mapTab);
            mapStyleDialog.setTitle(MapsPage.this.getResources().getString(C0421R.string.map_style));
            mapStyleDialog.setCancelable(true);
            mapStyleDialog.setSingleChoiceItems(MapsPage.this.mapStyles, MapsPage.this.setSelection, new C03141());
            mapStyleDialog.create().show();
        }
    }

    /* renamed from: com.vizsafe.app.HomePage.MapsPage$2 */
    class C03222 implements OnClickListener {
        C03222() {
        }

        public void onClick(View v) {
        }
    }

    /* renamed from: com.vizsafe.app.HomePage.MapsPage$3 */
    class C03233 implements OnSeekBarChangeListener {
        C03233() {
        }

        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        }

        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        public void onStopTrackingTouch(SeekBar seekBar) {
            int progress = seekBar.getProgress();
            if (CommonMember.isNetworkOnline((ConnectivityManager) MapsPage.this.getActivity().getSystemService("connectivity"), MapsPage.this.mapTab)) {
                progress = Math.round((float) (progress / 11)) * 11;
                PreferenceHandler.getInstance(MapsPage.this.mapTab).setProgressLevelMap(progress);
                if (progress == 0) {
                    MapsPage.this.showingText.setText(MapsPage.this.getString(C0421R.string.showing_last_ten_minutes));
                    PreferenceHandler.getInstance(MapsPage.this.mapTab).setProgressLevelMap(0);
                    PreferenceHandler.getInstance(MapsPage.this.mapTab).setProgressTextMap(MapsPage.this.getString(C0421R.string.showing_last_ten_minutes));
                    PreferenceHandler.getInstance(MapsPage.this.mapTab).setFromDuration(600);
                } else if (progress >= 11 && progress <= 20) {
                    MapsPage.this.showingText.setText(MapsPage.this.getString(C0421R.string.showing_last_thirty_minutes));
                    PreferenceHandler.getInstance(MapsPage.this.mapTab).setProgressLevelMap(11);
                    PreferenceHandler.getInstance(MapsPage.this.mapTab).setProgressTextMap(MapsPage.this.getString(C0421R.string.showing_last_thirty_minutes));
                    PreferenceHandler.getInstance(MapsPage.this.mapTab).setFromDuration(1800);
                } else if (progress >= 21 && progress <= 30) {
                    MapsPage.this.showingText.setText(MapsPage.this.getString(C0421R.string.showing_last_hour));
                    PreferenceHandler.getInstance(MapsPage.this.mapTab).setProgressLevelMap(22);
                    PreferenceHandler.getInstance(MapsPage.this.mapTab).setProgressTextMap(MapsPage.this.getString(C0421R.string.showing_last_hour));
                    PreferenceHandler.getInstance(MapsPage.this.mapTab).setFromDuration(3600);
                } else if (progress >= 31 && progress <= 40) {
                    MapsPage.this.showingText.setText(MapsPage.this.getString(C0421R.string.showing_last_three_hours));
                    PreferenceHandler.getInstance(MapsPage.this.mapTab).setProgressLevelMap(33);
                    PreferenceHandler.getInstance(MapsPage.this.mapTab).setProgressTextMap(MapsPage.this.getString(C0421R.string.showing_last_three_hours));
                    PreferenceHandler.getInstance(MapsPage.this.mapTab).setFromDuration(10800);
                } else if (progress >= 41 && progress <= 50) {
                    MapsPage.this.showingText.setText(MapsPage.this.getString(C0421R.string.showing_last_six_hours));
                    PreferenceHandler.getInstance(MapsPage.this.mapTab).setProgressLevelMap(44);
                    PreferenceHandler.getInstance(MapsPage.this.mapTab).setProgressTextMap(MapsPage.this.getString(C0421R.string.showing_last_six_hours));
                    PreferenceHandler.getInstance(MapsPage.this.mapTab).setFromDuration(21600);
                } else if (progress >= 51 && progress <= 60) {
                    MapsPage.this.showingText.setText(MapsPage.this.getString(C0421R.string.showing_last_twelve_hours));
                    PreferenceHandler.getInstance(MapsPage.this.mapTab).setProgressLevelMap(55);
                    PreferenceHandler.getInstance(MapsPage.this.mapTab).setProgressTextMap(MapsPage.this.getString(C0421R.string.showing_last_twelve_hours));
                    PreferenceHandler.getInstance(MapsPage.this.mapTab).setFromDuration(43200);
                } else if (progress >= 61 && progress <= 70) {
                    MapsPage.this.showingText.setText(MapsPage.this.getString(C0421R.string.showing_last_tewntyfour_hours));
                    PreferenceHandler.getInstance(MapsPage.this.mapTab).setProgressLevelMap(66);
                    PreferenceHandler.getInstance(MapsPage.this.mapTab).setProgressTextMap(MapsPage.this.getString(C0421R.string.showing_last_tewntyfour_hours));
                    PreferenceHandler.getInstance(MapsPage.this.mapTab).setFromDuration(Strategy.TTL_SECONDS_MAX);
                } else if (progress >= 71 && progress <= 80) {
                    MapsPage.this.showingText.setText(MapsPage.this.getString(C0421R.string.showing_last_seven_days));
                    PreferenceHandler.getInstance(MapsPage.this.mapTab).setProgressLevelMap(77);
                    PreferenceHandler.getInstance(MapsPage.this.mapTab).setProgressTextMap(MapsPage.this.getString(C0421R.string.showing_last_seven_days));
                    PreferenceHandler.getInstance(MapsPage.this.mapTab).setFromDuration(604800);
                } else if (progress < 81 || progress > 90) {
                    MapsPage.this.showingText.setText(MapsPage.this.getString(C0421R.string.showing_all));
                    PreferenceHandler.getInstance(MapsPage.this.mapTab).setProgressLevelMap(99);
                    PreferenceHandler.getInstance(MapsPage.this.mapTab).setProgressTextMap(MapsPage.this.getString(C0421R.string.showing_all));
                    PreferenceHandler.getInstance(MapsPage.this.mapTab).setFromDuration(0);
                } else {
                    MapsPage.this.showingText.setText(MapsPage.this.getString(C0421R.string.showing_last_month));
                    PreferenceHandler.getInstance(MapsPage.this.mapTab).setProgressLevelMap(88);
                    PreferenceHandler.getInstance(MapsPage.this.mapTab).setProgressTextMap(MapsPage.this.getString(C0421R.string.showing_last_month));
                    PreferenceHandler.getInstance(MapsPage.this.mapTab).setFromDuration(2628000);
                }
                if (progress == 0 || progress <= 70) {
                    MapsPage.this.timeIcon.setImageResource(C0421R.C0418drawable.clock_blue);
                } else {
                    MapsPage.this.timeIcon.setImageResource(C0421R.C0418drawable.calender_blue);
                }
                MapsPage.this.googleMap.clear();
                MapsPage.this.markerDetails.clear();
                MapsPage.this.cameraDetail.clear();
                MapsPage.this.cameraVideoDetail.clear();
                MapsPage.this.fromDuration = PreferenceHandler.getInstance(MapsPage.this.mapTab).getFromDuration();
                MapsPage.this.TaskGetIncidentPinsInMap(String.valueOf(MapsPage.this.fromDuration));
                MapsPage.this.TaskGetCameraPinsInMap();
                MapsPage.this.TaskGetBOAPinsInMap();
                return;
            }
            CommonMember.NetworkStatusAlert(MapsPage.this.mapTab);
        }
    }

    /* renamed from: com.vizsafe.app.HomePage.MapsPage$4 */
    class C03244 implements OnCameraMoveStartedListener {
        C03244() {
        }

        public void onCameraMoveStarted(int i) {
            MapsPage.this.mTimerIsRunning = true;
        }
    }

    /* renamed from: com.vizsafe.app.HomePage.MapsPage$5 */
    class C03255 implements OnCameraIdleListener {
        C03255() {
        }

        public void onCameraIdle() {
            if (MapsPage.this.googleMap != null) {
                MapsPage.this.googleMap.clear();
            }
            LatLng mPosition = MapsPage.this.googleMap.getCameraPosition().target;
            float mZoom = MapsPage.this.googleMap.getCameraPosition().zoom;
            LatLngBounds curScreen = MapsPage.this.googleMap.getProjection().getVisibleRegion().latLngBounds;
            MapsPage.this.southLat = String.valueOf(curScreen.southwest.latitude);
            MapsPage.this.southLng = String.valueOf(curScreen.southwest.longitude);
            MapsPage.this.northLat = String.valueOf(curScreen.northeast.latitude);
            MapsPage.this.northLng = String.valueOf(curScreen.northeast.longitude);
            if (CommonMember.isNetworkOnline((ConnectivityManager) MapsPage.this.mapTab.getSystemService("connectivity"), MapsPage.this.mapTab)) {
                MapsPage.this.googleMap.clear();
                MapsPage.this.markerDetails.clear();
                MapsPage.this.cameraDetail.clear();
                MapsPage.this.cameraVideoDetail.clear();
                MapsPage.this.mapProgress.setVisibility(0);
                MapsPage.this.fromDuration = PreferenceHandler.getInstance(MapsPage.this.mapTab).getFromDuration();
                MapsPage.this.TaskGetIncidentPinsInMap(String.valueOf(MapsPage.this.fromDuration));
                MapsPage.this.TaskGetCameraPinsInMap();
                MapsPage.this.TaskGetBOAPinsInMap();
            }
            if (MapsPage.this.mTimerIsRunning) {
            }
        }
    }

    /* renamed from: com.vizsafe.app.HomePage.MapsPage$6 */
    class C03266 implements OnMarkerClickListener {
        C03266() {
        }

        public boolean onMarkerClick(Marker arg0) {
            arg0.showInfoWindow();
            return true;
        }
    }

    /* renamed from: com.vizsafe.app.HomePage.MapsPage$7 */
    class C03277 implements InfoWindowAdapter {
        C03277() {
        }

        public View getInfoWindow(Marker arg0) {
            return null;
        }

        public View getInfoContents(Marker arg0) {
            View v = MapsPage.this.getLayoutInflater().inflate(C0421R.layout.info_window_layout, null);
            ImageView infoIcon = (ImageView) v.findViewById(C0421R.C0419id.info_icon);
            ((TextView) v.findViewById(C0421R.C0419id.info_title)).setText(arg0.getTitle());
            infoIcon.setImageResource(C0421R.C0418drawable.info_icon);
            return v;
        }
    }

    /* renamed from: com.vizsafe.app.HomePage.MapsPage$8 */
    class C03288 implements OnInfoWindowClickListener {
        C03288() {
        }

        public void onInfoWindowClick(Marker arg0) {
            try {
                String uploadedByString = "";
                FeedListItems feedListItems = (FeedListItems) MapsPage.this.markerDetails.get(arg0.getId());
                if (feedListItems != null) {
                    if (feedListItems.getFeedPostedBy() != null) {
                        uploadedByString = MapsPage.this.getResources().getString(C0421R.string.report_by) + " " + feedListItems.getFeedPostedBy();
                    } else {
                        uploadedByString = MapsPage.this.getResources().getString(C0421R.string.report_by_anonymous);
                    }
                    String feedInfoString = feedListItems.getFeedDetail();
                    String feedSeverityString = feedListItems.getSeverityLevel();
                    String feedTimeStampString = feedListItems.getFeedUploadedTime();
                    String feedIconString = feedListItems.getFeedIcon();
                    String feedAbuseOrNotString = feedListItems.getFeedAbuseOrNot();
                    String feedLatitudeString = feedListItems.getFeedLatitude();
                    String feedLongitudeString = feedListItems.getFeedLongitude();
                    String feedType = feedListItems.getFeedType();
                    String incidentState = feedListItems.getIncidentState();
                    String incidentClearedBy = feedListItems.getIncidentClearedBy();
                    String incidentClearedTimeStamp = feedListItems.getIncidentClearedTimeStamp();
                    String feedPostedBy = feedListItems.getFeedPostedBy();
                    int CommunityId = feedListItems.getCommunityId();
                    int Drawingid = feedListItems.getDrawingid();
                    int LevelId = feedListItems.getLevelId();
                    int channelSize = feedListItems.getFeedChannels().size();
                    ArrayList<NotesItems> notesItem = feedListItems.getFeedNotes();
                    ArrayList<ChannelsListItem> mChannelsList = feedListItems.getFeedChannels();
                    boolean isSecretChannel = false;
                    int i = 0;
                    while (i < channelSize) {
                        if (((ChannelsListItem) feedListItems.getFeedChannels().get(i)).isSecret) {
                            isSecretChannel = true;
                            break;
                        } else {
                            isSecretChannel = false;
                            i++;
                        }
                    }
                    boolean isPrivateChannel = false;
                    i = 0;
                    while (i < channelSize) {
                        if (((ChannelsListItem) feedListItems.getFeedChannels().get(i)).isPrivate) {
                            isPrivateChannel = true;
                            break;
                        } else {
                            isPrivateChannel = false;
                            i++;
                        }
                    }
                    int feedRatings = feedListItems.getFeedRatings();
                    boolean feedRatingsByMe = feedListItems.getIsFeedRatingsByMe();
                    Bundle markerInfoDetail = new Bundle();
                    markerInfoDetail.putString("feed_uploadedBy", uploadedByString);
                    markerInfoDetail.putString("feed_description", feedInfoString);
                    markerInfoDetail.putString("feed_timestamp", feedTimeStampString);
                    markerInfoDetail.putString("feed_imageUrl", feedIconString);
                    markerInfoDetail.putString("feed_abuse", feedAbuseOrNotString);
                    markerInfoDetail.putString("feed_latitude", feedLatitudeString);
                    markerInfoDetail.putString("feed_longitude", feedLongitudeString);
                    markerInfoDetail.putInt("feed_ratings", feedRatings);
                    markerInfoDetail.putBoolean("feed_rating_by_me", feedRatingsByMe);
                    markerInfoDetail.putString("feed_type", feedType);
                    markerInfoDetail.putString("incident_state", incidentState);
                    markerInfoDetail.putString("incident_cleared_by", incidentClearedBy);
                    markerInfoDetail.putString("incident_cleared_timestamp", incidentClearedTimeStamp);
                    markerInfoDetail.putString("feed_posted_by", feedPostedBy);
                    markerInfoDetail.putBoolean("is_channel_secret", isSecretChannel);
                    markerInfoDetail.putBoolean("is_channel_private", isPrivateChannel);
                    markerInfoDetail.putSerializable("notes_data_list", notesItem);
                    markerInfoDetail.putSerializable("channel_list", mChannelsList);
                    markerInfoDetail.putString("from", "Map");
                    markerInfoDetail.putInt("CommunityId", CommunityId);
                    markerInfoDetail.putInt("Drawingid", Drawingid);
                    markerInfoDetail.putInt("LevelId", LevelId);
                    markerInfoDetail.putString("severity", feedSeverityString);
                    markerInfoDetail.putString("Context", MapsPage.this.mapTab.toString());
                    ((onGoToReportDetailsPageListener) MapsPage.this.mapTab).onGoToReportDetailsPage(markerInfoDetail);
                    return;
                }
                String cameraUuid = (String) MapsPage.this.cameraDetail.get(arg0.getId());
                String videoInput = (String) MapsPage.this.cameraVideoDetail.get(arg0.getId());
                Intent intent;
                if (!CommonMember.isNetworkOnline((ConnectivityManager) MapsPage.this.mapTab.getSystemService("connectivity"), MapsPage.this.mapTab)) {
                    CommonMember.getErrorDialog(MapsPage.this.mapTab.getString(C0421R.string.no_internet_access), MapsPage.this.mapTab).show();
                } else if (VERSION.SDK_INT >= 23) {
                    if (videoInput == null) {
                        intent = new Intent(MapsPage.this.mapTab, SampleWebview.class);
                        intent.putExtra("camera_uuid", cameraUuid);
                        intent.putExtra("camera_pass", "true");
                        MapsPage.this.mapTab.startActivity(intent);
                    } else if (!videoInput.equalsIgnoreCase("egs")) {
                        intent = new Intent(MapsPage.this.mapTab, SampleWebview.class);
                        intent.putExtra("camera_uuid", cameraUuid);
                        intent.putExtra("camera_pass", "true");
                        MapsPage.this.mapTab.startActivity(intent);
                    }
                } else if (videoInput == null) {
                    intent = new Intent(MapsPage.this.mapTab, CameraLiveScreen.class);
                    intent.putExtra("camera_uuid", cameraUuid);
                    intent.putExtra("camera_pass", "true");
                    MapsPage.this.mapTab.startActivity(intent);
                } else if (!videoInput.equalsIgnoreCase("egs")) {
                    intent = new Intent(MapsPage.this.mapTab, CameraLiveScreen.class);
                    intent.putExtra("camera_uuid", cameraUuid);
                    intent.putExtra("camera_pass", "true");
                    MapsPage.this.mapTab.startActivity(intent);
                }
            } catch (Exception e) {
            }
        }
    }

    /* renamed from: com.vizsafe.app.HomePage.MapsPage$9 */
    class C03299 implements OnCompleteListener {
        C03299() {
        }

        public void onComplete(@NonNull Task task) {
            if (task.isSuccessful()) {
                Log.d(MapsPage.TAG, "onComplete: found location!");
                Location currentLocation = (Location) task.getResult();
                if (currentLocation != null) {
                    MapsPage.this.moveCamera(new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude()), MapsPage.DEFAULT_ZOOM);
                    return;
                }
                return;
            }
            Log.d(MapsPage.TAG, "onComplete: current location is null");
        }
    }

    private class AsyncEgsStreamResponse extends AsyncTask<String, String, String> {
        JSONObject mResponse = null;
        String mURL = null;
        String response = null;

        private AsyncEgsStreamResponse() {
        }

        protected void onPreExecute() {
            super.onPreExecute();
            MapsPage.this.mTransparentProgressDialog.show();
        }

        protected String doInBackground(String... arg0) {
            this.mResponse = Webservice.GetEGSURL(MapsPage.this.mapTab, arg0[0]);
            return null;
        }

        protected void onPostExecute(String result) {
            if (MapsPage.this.mTransparentProgressDialog.isShowing()) {
                MapsPage.this.mTransparentProgressDialog.dismiss();
            }
            if (this.mResponse != null) {
            }
        }
    }

    public static MapsPage newInstance(String currentLatitudePin, String currentLongitudePin) {
        mPassedlatitude = currentLatitudePin;
        mPassedLongitude = currentLongitudePin;
        return new MapsPage();
    }

    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.clear();
    }

    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        setRetainInstance(true);
    }

    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (savedInstanceState == null || !savedInstanceState.isEmpty()) {
        }
        if (this.vMapsPage != null) {
            ViewGroup parent = (ViewGroup) this.vMapsPage.getParent();
            if (parent != null) {
                parent.removeView(this.vMapsPage);
            }
        }
        try {
            this.vMapsPage = inflater.inflate(C0421R.layout.activity_maps_page, container, false);
            this.mapTab = getContext();
            this.mTransparentProgressDialog = new SpotsDialog(getContext(), getResources().getString(C0421R.string.please_wait_loading));
            this.mTransparentProgressDialog.setCanceledOnTouchOutside(false);
            this.mTransparentProgressDialog.setCancelable(false);
            this.channelPictureUrl = CommonMember.getURL(this.mapTab) + "/picture/";
            this.fromDuration = PreferenceHandler.getInstance(this.mapTab).getFromDuration();
            this.mapStyleBtn = (Button) this.vMapsPage.findViewById(C0421R.C0419id.map_stlye_btn);
            this.showingText = (TextView) this.vMapsPage.findViewById(C0421R.C0419id.showing_text);
            this.seekbar = (SeekBar) this.vMapsPage.findViewById(C0421R.C0419id.seekBar1);
            this.mapProgress = (ProgressBar) this.vMapsPage.findViewById(C0421R.C0419id.mapProgress);
            this.mapProgress.setEnabled(false);
            this.timeIcon = (ImageView) this.vMapsPage.findViewById(C0421R.C0419id.time_icon);
            this.showingText.setText(PreferenceHandler.getInstance(this.mapTab).getProgressTextMap());
            this.seekbar.setProgress(PreferenceHandler.getInstance(this.mapTab).getProgressLevelMap());
            int mProgress = PreferenceHandler.getInstance(this.mapTab).getProgressLevelMap();
            if (mProgress == 0 || mProgress <= 70) {
                this.timeIcon.setImageResource(C0421R.C0418drawable.clock_blue);
            } else {
                this.timeIcon.setImageResource(C0421R.C0418drawable.calender_blue);
            }
            this.mapStyleBtn.setVisibility(4);
            String email = PreferenceHandler.getInstance(this.mapTab).getUserName();
            this.authenticationString = "Basic " + Base64.encodeToString((email + ":" + PreferenceHandler.getInstance(this.mapTab).getPassword()).getBytes(), 2);
            this.setSelection = 0;
            PreferenceHandler.getInstance(this.mapTab).setMapStyle(getResources().getString(C0421R.string.satellite));
            this.seekbar.setProgress(PreferenceHandler.getInstance(this.mapTab).getProgressLevelMap());
            this.showingText.setText(PreferenceHandler.getInstance(this.mapTab).getProgressTextMap());
            this.locManager = (LocationManager) getActivity().getSystemService(Param.LOCATION);
            this.gps_enabled = this.locManager.isProviderEnabled("gps");
            this.mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(getContext());
            this.gps = new VizsafeGPSTracker(getContext());
            setUpGClient();
        } catch (InflateException e) {
        }
        this.mapStyleBtn.setOnClickListener(new C03211());
        this.timeIcon.setOnClickListener(new C03222());
        this.seekbar.setOnSeekBarChangeListener(new C03233());
        return this.vMapsPage;
    }

    public void onMapReady(GoogleMap mMap) {
        Log.d(TAG, "onMapReady: map is ready");
        this.googleMap = mMap;
        this.googleMap.setMapType(4);
        if (this.mLocationPermissionsGranted.booleanValue()) {
            getDeviceLocation();
            if (ContextCompat.checkSelfPermission(getContext(), FINE_LOCATION) == 0 || ContextCompat.checkSelfPermission(getContext(), COURSE_LOCATION) == 0) {
                mMap.setMyLocationEnabled(true);
                mMap.setOnMyLocationClickListener(this);
                this.googleMap.getUiSettings().setZoomControlsEnabled(true);
                this.googleMap.setTrafficEnabled(true);
                this.googleMap.setIndoorEnabled(true);
                this.googleMap.setOnCameraMoveStartedListener(new C03244());
                this.googleMap.setOnCameraIdleListener(new C03255());
                this.googleMap.setOnMarkerClickListener(new C03266());
                this.googleMap.setInfoWindowAdapter(new C03277());
                this.googleMap.setOnInfoWindowClickListener(new C03288());
            }
        }
    }

    private void getDeviceLocation() {
        Log.d(TAG, "getDeviceLocation: getting the devices current location");
        this.mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(getActivity());
        try {
            if (!this.mLocationPermissionsGranted.booleanValue()) {
                return;
            }
            if (mPassedlatitude == null) {
                this.mFusedLocationProviderClient.getLastLocation().addOnCompleteListener(new C03299());
                return;
            }
            moveCamera(new LatLng(Double.valueOf(mPassedlatitude).doubleValue(), Double.valueOf(mPassedLongitude).doubleValue()), 19.0f);
        } catch (SecurityException e) {
            Log.e(TAG, "getDeviceLocation: SecurityException: " + e.getMessage());
        }
    }

    private void moveCamera(LatLng latLng, float zoom) {
        Log.d(TAG, "moveCamera: moving the camera to: lat: " + latLng.latitude + ", lng: " + latLng.longitude);
        this.googleMap.animateCamera(CameraUpdateFactory.newCameraPosition(new CameraPosition.Builder().target(latLng).tilt(0.0f).zoom(zoom).bearing(0.0f).build()));
        latitude = latLng.latitude;
        longitude = latLng.longitude;
        if (this.marker != null) {
            this.marker.remove();
        }
        this.googleMap.clear();
        this.markerDetails.clear();
        this.cameraDetail.clear();
        this.cameraVideoDetail.clear();
        ReportPage.LATITUDE = String.valueOf(latitude);
        ReportPage.LONGITUDE = String.valueOf(longitude);
    }

    public void onMyLocationClick(@NonNull Location location) {
        latitude = location.getLatitude();
        longitude = location.getLongitude();
        if (this.marker != null) {
            this.marker.remove();
        }
        this.googleMap.clear();
        this.markerDetails.clear();
        this.cameraDetail.clear();
        this.cameraVideoDetail.clear();
        ReportPage.LATITUDE = String.valueOf(latitude);
        ReportPage.LONGITUDE = String.valueOf(longitude);
    }

    private void getLocationPermission() {
        Log.d(TAG, "getLocationPermission: getting location permissions");
        String[] permissions = new String[]{FINE_LOCATION, COURSE_LOCATION};
        if (ContextCompat.checkSelfPermission(getContext(), FINE_LOCATION) != 0) {
            ActivityCompat.requestPermissions(getActivity(), permissions, LOCATION_PERMISSION_REQUEST_CODE);
        } else if (ContextCompat.checkSelfPermission(getContext(), COURSE_LOCATION) == 0) {
            this.mLocationPermissionsGranted = Boolean.valueOf(true);
            initMap();
        } else {
            ActivityCompat.requestPermissions(getActivity(), permissions, LOCATION_PERMISSION_REQUEST_CODE);
        }
    }

    private void TaskGetCameraPinsInMap() {
        String mBounds = this.southLng + "," + this.southLat + "," + this.northLng + "," + this.northLat;
        String mLimit = "100000";
        if (PreferenceHandler.getInstance(this.mapTab).getPublicCamraStatus()) {
            AsyncTaskCameraList(mBounds, mLimit);
        } else {
            AsyncTaskGetPrivateCameras(mBounds, mLimit);
        }
    }

    private void AsyncTaskCameraList(String mBounds, String mLimit) {
        GetCameraPins.getInstance().Callresponse(getContext(), this.authenticationString, mBounds, mLimit, new C031510());
    }

    private void AsyncTaskGetPrivateCameras(String mBounds, String mLimit) {
        GetPrivateCameraPins.getInstance().Callresponse(getContext(), this.authenticationString, mBounds, mLimit, "true", new C031611());
    }

    private void TaskGetIncidentPinsInMap(String fromDuration) {
        String mChannels = "FAVORITE";
        String mBounds = this.southLng + "," + this.southLat + "," + this.northLng + "," + this.northLat;
        String mLimit = "100";
        if (fromDuration.equals("0")) {
            GetIncidentPinsBoundsApi.getInstance().Callresponse(getContext(), this.authenticationString, mChannels, mBounds, mLimit, new C031712());
            return;
        }
        GetIncidentPinsApi.getInstance().Callresponse(this.mapTab, this.authenticationString, mChannels, fromDuration, mBounds, mLimit, new C031813());
    }

    private void TaskGetBOAPinsInMap() {
        AsyncTaskBOAPinsList(this.southLng + "," + this.southLat + "," + this.northLng + "," + this.northLat);
    }

    private void AsyncTaskBOAPinsList(String mBounds) {
        GetBOAPins.getInstance().Callresponse(this.mapTab, this.authenticationString, mBounds, new C031914());
    }

    private void CallResponse(String mResponse) {
        if (this.mapProgress.getVisibility() == 0) {
            this.mapProgress.setVisibility(8);
        }
        if (mResponse != null) {
            try {
                this.mJsonResponse = new JSONObject(mResponse);
                String mMessage = this.mJsonResponse.getString(GCMClientManager.EXTRA_MESSAGE);
                JSONObject mDetail = this.mJsonResponse.getJSONObject(ProductAction.ACTION_DETAIL);
                String mTotal = mDetail.getString("total");
                if (mDetail.has("usermanagement")) {
                    try {
                        JSONObject mUsermanagementDetail = mDetail.getJSONObject("usermanagement");
                        if (mUsermanagementDetail == null) {
                            this.mapStyles = new String[]{getResources().getString(C0421R.string.satellite)};
                        } else {
                            this.mMicello_floorplan = mUsermanagementDetail.getString("micello_floorplan");
                            this.mStatic_floorplan = mUsermanagementDetail.getString("static_floorplan");
                            if (this.mMicello_floorplan.equalsIgnoreCase("true") && this.mStatic_floorplan.equalsIgnoreCase("true")) {
                                this.mapStyles = new String[]{getResources().getString(C0421R.string.satellite), getResources().getString(C0421R.string.dynamicfloorplans), getResources().getString(C0421R.string.staticfloorplans)};
                            } else if (this.mMicello_floorplan.equalsIgnoreCase("true") && this.mStatic_floorplan.equalsIgnoreCase("false")) {
                                this.mapStyles = new String[]{getResources().getString(C0421R.string.satellite), getResources().getString(C0421R.string.dynamicfloorplans)};
                            } else if (this.mMicello_floorplan.equalsIgnoreCase("false") && this.mStatic_floorplan.equalsIgnoreCase("true")) {
                                this.mapStyles = new String[]{getResources().getString(C0421R.string.satellite), getResources().getString(C0421R.string.staticfloorplans)};
                            } else {
                                this.mapStyles = new String[]{getResources().getString(C0421R.string.satellite)};
                            }
                        }
                    } catch (Exception e) {
                        Log.d(TAG, "CallResponse: " + e.getStackTrace());
                    }
                } else {
                    this.mapStyles = new String[]{getResources().getString(C0421R.string.satellite)};
                }
                this.mapStyleBtn.setVisibility(0);
                if (Integer.parseInt(mTotal) > 0) {
                    JSONArray mIncidents = mDetail.getJSONArray("incidents");
                    if (this.mJsonResponse != null) {
                        if (!this.arraylist.isEmpty()) {
                            this.arraylist.clear();
                        }
                        if (mIncidents != null) {
                            int i = 0;
                            while (i < mIncidents.length()) {
                                try {
                                    JSONObject feedRatingsObject = null;
                                    String feedPostedBy = null;
                                    String feedUploadedByUuid = null;
                                    String feedLatitude = null;
                                    String feedLongitude = null;
                                    String feedAbuseOrNot = "false";
                                    String incidentState = null;
                                    String incidentClearedBy = null;
                                    String incidentClearedTimeStamp = null;
                                    String severityLevel = "0";
                                    feedAbuseOrNot = "false";
                                    boolean feedRatingByMe = false;
                                    int feedRatings = 0;
                                    int communityid = 0;
                                    int drawingid = 0;
                                    int levelid = 0;
                                    JSONObject feedListObject = mIncidents.getJSONObject(i);
                                    String feedType = feedListObject.getString("type");
                                    String feedIcon = feedListObject.getString("uuid");
                                    try {
                                        if (feedListObject.has("communityid")) {
                                            communityid = feedListObject.getInt("communityid");
                                        }
                                        if (feedListObject.has("drawingid")) {
                                            drawingid = feedListObject.getInt("drawingid");
                                        }
                                        if (feedListObject.has("levelid")) {
                                            levelid = feedListObject.getInt("levelid");
                                        }
                                    } catch (Exception e2) {
                                        Log.e(TAG, "CallResponse: ", e2);
                                    }
                                    if (feedListObject.has("severitylevel")) {
                                        severityLevel = feedListObject.getString("severitylevel");
                                    }
                                    String feedDetail = feedListObject.getString(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_DESCRIPTION);
                                    if (feedListObject.has("uploadedBy")) {
                                        feedUploadedByUuid = feedListObject.getString("uploadedBy");
                                    }
                                    if (feedListObject.has("uploadedByDisplayName")) {
                                        feedPostedBy = feedListObject.getString("uploadedByDisplayName");
                                    }
                                    String feedUploadedTime = feedListObject.getString("uploadedTimestamp") + "000";
                                    if (feedListObject.has("abuseReported")) {
                                        feedAbuseOrNot = feedListObject.getString("abuseReported");
                                    }
                                    if (feedListObject.has("incidentState")) {
                                        incidentState = feedListObject.getString("incidentState");
                                    }
                                    if (feedListObject.has("incidentClearedBy")) {
                                        incidentClearedBy = feedListObject.getString("incidentClearedBy");
                                    }
                                    if (feedListObject.has("incidentClearedTimeStamp")) {
                                        incidentClearedTimeStamp = feedListObject.getString("incidentClearedTimeStamp");
                                    }
                                    JSONObject feedLocationAndGeoObject = feedListObject.getJSONObject(Param.LOCATION);
                                    if (feedLocationAndGeoObject != null) {
                                        JSONObject feedLocationObject = feedLocationAndGeoObject.getJSONObject("loc");
                                        if (feedLocationObject != null) {
                                            feedLatitude = feedLocationObject.getString("lat");
                                            feedLongitude = feedLocationObject.getString("lng");
                                        }
                                    }
                                    if (feedListObject.has("ratings")) {
                                        try {
                                            feedRatingsObject = feedListObject.getJSONObject("ratings");
                                        } catch (Exception e3) {
                                            e3.printStackTrace();
                                        }
                                        if (feedRatingsObject != null) {
                                            feedRatings = feedRatingsObject.length();
                                            if (feedRatingsObject.has(PreferenceHandler.getInstance(this.mapTab).getUserUUID())) {
                                                feedRatingByMe = true;
                                            }
                                        }
                                    }
                                    JSONArray feedChannelsArray = feedListObject.getJSONArray("channels");
                                    ArrayList<ChannelsListItem> channelsInFeed = null;
                                    if (feedChannelsArray != null) {
                                        channelsInFeed = new ArrayList();
                                        for (int j = 0; j < feedChannelsArray.length(); j++) {
                                            JSONObject feedChannelsObject = feedChannelsArray.getJSONObject(j);
                                            boolean channelPrivate = false;
                                            boolean channelSecret = false;
                                            boolean channelMassaged = false;
                                            boolean channelVizsafe = false;
                                            String channelUuid = feedChannelsObject.getString("uuid");
                                            String channelName = feedChannelsObject.getString("name");
                                            String channelDescription = feedChannelsObject.getString(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_DESCRIPTION);
                                            String channelOwner = feedChannelsObject.getString("owner");
                                            String channelPicture = feedChannelsObject.getString("channelPicture");
                                            if (feedChannelsObject.has("owner")) {
                                                channelOwner = feedChannelsObject.getString("owner");
                                            }
                                            if (feedChannelsObject.has("vizsafeChannel")) {
                                                channelVizsafe = Boolean.parseBoolean(feedChannelsObject.getString("vizsafeChannel"));
                                            }
                                            if (feedChannelsObject.has("privateChannel")) {
                                                channelPrivate = Boolean.parseBoolean(feedChannelsObject.getString("privateChannel"));
                                            }
                                            if (feedChannelsObject.has("secretChannel")) {
                                                channelSecret = Boolean.parseBoolean(feedChannelsObject.getString("secretChannel"));
                                            }
                                            if (feedChannelsObject.has("massaged")) {
                                                channelMassaged = Boolean.parseBoolean(feedChannelsObject.getString("massaged"));
                                            }
                                            channelsInFeed.add(new ChannelsListItem(channelName, channelDescription, this.channelPictureUrl + channelPicture, channelUuid, channelOwner, channelVizsafe, channelPrivate, channelSecret, channelMassaged));
                                        }
                                    }
                                    JSONObject feedNotesJsonObject = feedListObject.getJSONObject("notes");
                                    ArrayList<NotesItems> notesItem = null;
                                    if (feedNotesJsonObject.getInt("number") > 0) {
                                        notesItem = new ArrayList();
                                        JSONArray feedNotesArray = feedNotesJsonObject.getJSONArray("notes");
                                        for (int k = 0; k < feedNotesArray.length(); k++) {
                                            JSONObject notesDataObject = feedNotesArray.getJSONObject(k);
                                            notesItem.add(new NotesItems(notesDataObject.getString("uploadedBy"), notesDataObject.getString(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_DESCRIPTION), notesDataObject.getLong("uploadedDate"), notesDataObject.getString("incidentID"), notesDataObject.getString("noteuuid")));
                                        }
                                    }
                                    FeedListItems feedDetails = new FeedListItems(feedType, feedIcon, feedDetail, feedPostedBy, feedUploadedTime, feedUploadedByUuid, channelsInFeed, feedLatitude, feedLongitude, feedAbuseOrNot, feedRatings, feedRatingByMe, incidentState, incidentClearedBy, incidentClearedTimeStamp, notesItem, communityid, drawingid, levelid, severityLevel);
                                    this.videoInput = null;
                                    String str = feedDetail;
                                    String str2 = incidentState;
                                    FeedListItems feedListItems = feedDetails;
                                    drawMarker(new LatLng(Double.parseDouble(feedLatitude), Double.parseDouble(feedLongitude)), str, str2, feedListItems, null, null, this.videoInput);
                                    i++;
                                } catch (NumberFormatException e4) {
                                    e4.printStackTrace();
                                    return;
                                } catch (JSONException e5) {
                                    e5.printStackTrace();
                                    return;
                                }
                            }
                        }
                    }
                }
            } catch (JSONException e52) {
                e52.printStackTrace();
            }
        }
    }

    private void drawMarker(LatLng point, String text, String incidentPinState, FeedListItems feedItems, String cameraUuid, String boaUuid, String videoInput) {
        MarkerOptions markerOptions = new MarkerOptions();
        String str = text;
        if (str.length() > 30) {
            str = str.substring(0, 27) + "...";
        }
        if (incidentPinState == null) {
            feedItems.setIncidentState("open");
            incidentPinState = feedItems.getIncidentState();
        }
        if (incidentPinState.equalsIgnoreCase("open")) {
            markerOptions.position(point).title(text).icon(BitmapDescriptorFactory.fromResource(C0421R.C0418drawable.red_marker));
        } else if (incidentPinState.equals("pending")) {
            markerOptions.position(point).title(text).icon(BitmapDescriptorFactory.fromResource(C0421R.C0418drawable.yellow_marker));
        } else if (incidentPinState.equals("Violet")) {
            markerOptions.position(point).title(text).icon(BitmapDescriptorFactory.fromResource(C0421R.C0418drawable.camera_marker));
        } else if (incidentPinState.equals("BOA")) {
            markerOptions.position(point).title(text).icon(BitmapDescriptorFactory.fromResource(C0421R.C0418drawable.boa_icon_vizsafe));
        } else {
            markerOptions.position(point).title(text).icon(BitmapDescriptorFactory.fromResource(C0421R.C0418drawable.green_marker));
        }
        String markerId = this.googleMap.addMarker(markerOptions).getId();
        if (feedItems != null) {
            this.markerDetails.put(markerId, feedItems);
        } else if (cameraUuid != null) {
            this.cameraDetail.put(markerId, cameraUuid);
            this.cameraVideoDetail.put(markerId, videoInput);
        }
    }

    private void initMap() {
        Log.d(TAG, "initMap: initializing map");
        FragmentManager fm = getChildFragmentManager();
        SupportMapFragment mapFragment = (SupportMapFragment) fm.findFragmentByTag("mapFragment");
        if (mapFragment == null) {
            mapFragment = new SupportMapFragment();
            FragmentTransaction ft = fm.beginTransaction();
            ft.add(C0421R.C0419id.mapFragmentContainer, mapFragment, "mapFragment");
            ft.commit();
            fm.executePendingTransactions();
        }
        mapFragment.getMapAsync(this);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case 115:
                switch (resultCode) {
                    case -1:
                        this.mLocationPermissionsGranted = Boolean.valueOf(true);
                        if (CommonMember.isNetworkOnline((ConnectivityManager) this.mapTab.getSystemService("connectivity"), this.mapTab)) {
                            initMap();
                            return;
                        } else {
                            CommonMember.getErrorDialog(getString(C0421R.string.no_internet_access), this.mapTab).show();
                            return;
                        }
                    default:
                        return;
                }
            default:
                return;
        }
    }

    public void onResume() {
        super.onResume();
        this.setSelection = 0;
        PreferenceHandler.getInstance(this.mapTab).setMapStyle(getResources().getString(C0421R.string.satellite));
        this.showingText.setText(PreferenceHandler.getInstance(this.mapTab).getProgressTextMap());
    }

    public void onPause() {
        super.onPause();
        this.mGoogleApiClient.stopAutoManage(getActivity());
        this.mGoogleApiClient.disconnect();
    }

    public void onLowMemory() {
        super.onLowMemory();
    }

    public void onDestroy() {
        super.onDestroy();
    }

    private synchronized void setUpGClient() {
        this.mGoogleApiClient = new GoogleApiClient.Builder(this.mapTab).enableAutoManage(getActivity(), 1, this).addConnectionCallbacks(this).addOnConnectionFailedListener(this).addApi(LocationServices.API).build();
        this.mGoogleApiClient.connect();
    }

    public void onConnected(@Nullable Bundle bundle) {
        this.mLocationRequest = LocationRequest.create();
        this.mLocationRequest.setPriority(100);
        this.mLocationRequest.setInterval(3000);
        this.mLocationRequest.setFastestInterval(5000);
        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder().addLocationRequest(this.mLocationRequest);
        builder.setAlwaysShow(true);
        this.result = LocationServices.SettingsApi.checkLocationSettings(this.mGoogleApiClient, builder.build());
        this.result.setResultCallback(new C032015());
    }

    public void onConnectionSuspended(int i) {
    }

    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
    }
}
