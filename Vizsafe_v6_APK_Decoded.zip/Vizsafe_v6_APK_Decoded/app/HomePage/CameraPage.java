package com.vizsafe.app.HomePage;

import android.app.AlertDialog;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.Nullable;
import android.support.p001v4.app.Fragment;
import android.support.p001v4.app.FragmentActivity;
import android.support.p001v4.widget.SwipeRefreshLayout;
import android.support.p001v4.widget.SwipeRefreshLayout.OnRefreshListener;
import android.support.p002v7.widget.DefaultItemAnimator;
import android.support.p002v7.widget.LinearLayoutManager;
import android.support.p002v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import com.google.android.gms.analytics.ecommerce.ProductAction;
import com.google.gson.JsonObject;
import com.vizsafe.app.APIClientMethods.LiveCameraListApi;
import com.vizsafe.app.APIClientMethods.PrivateCameraListApi;
import com.vizsafe.app.Adapters.CameraListAdapter;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.POJO.CameraListItems;
import com.vizsafe.app.Utils.CommonMember;
import com.vizsafe.app.Utils.PreferenceHandler;
import dmax.dialog.SpotsDialog;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class CameraPage extends Fragment {
    private static Bundle mBundleRecyclerViewState;
    private final String KEY_RECYCLER_STATE = "recycler_state";
    private final String LIST_COUNT = "listcount";
    private ArrayList<CameraListItems> arraylist = new ArrayList();
    private ArrayList<CameraListItems> arraylist1 = new ArrayList();
    private String authStringinBase64;
    private RecyclerView cameraList;
    private String cameraPass = null;
    JSONArray camerasListArray = null;
    private FragmentActivity camerasTab;
    JSONObject channelListObject = null;
    private boolean firstTime = true;
    Parcelable listState;
    private LinearLayout loadingView;
    private CameraListAdapter mAdapter;
    JSONObject mJsonResponse;
    private boolean mRestoreFlag = false;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private AlertDialog mTransparentProgressDialog;
    private int previousTotal = 0;
    Parcelable scrollState = null;
    private EditText searchText;
    private String successStatus = "yes";
    int total;

    /* renamed from: com.vizsafe.app.HomePage.CameraPage$1 */
    class C02881 implements OnRefreshListener {
        C02881() {
        }

        public void onRefresh() {
            CameraPage.this.firstTime = true;
            if (CommonMember.isNetworkOnline((ConnectivityManager) CameraPage.this.camerasTab.getSystemService("connectivity"), CameraPage.this.camerasTab)) {
                CameraPage.this.searchText.setText("");
                CameraPage.this.AsyncTaskGetPrivateCameras();
                return;
            }
            CommonMember.NetworkStatusAlert(CameraPage.this.camerasTab);
        }
    }

    /* renamed from: com.vizsafe.app.HomePage.CameraPage$2 */
    class C02892 implements TextWatcher {
        C02892() {
        }

        public void onTextChanged(CharSequence s, int start, int before, int count) {
            try {
                CameraPage.this.mAdapter.filter(s.toString().toLowerCase());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        public void afterTextChanged(Editable s) {
        }
    }

    /* renamed from: com.vizsafe.app.HomePage.CameraPage$3 */
    class C02913 implements Callback<JsonObject> {

        /* renamed from: com.vizsafe.app.HomePage.CameraPage$3$1 */
        class C02901 implements Comparator<CameraListItems> {
            C02901() {
            }

            public int compare(CameraListItems v1, CameraListItems v2) {
                return v1.getCameraName().compareTo(v2.getCameraName());
            }
        }

        C02913() {
        }

        public void success(JsonObject responseLiveCameraListApi, Response response) {
            if (CameraPage.this.mTransparentProgressDialog.isShowing()) {
                CameraPage.this.mTransparentProgressDialog.dismiss();
            }
            CameraPage.this.mSwipeRefreshLayout.setRefreshing(false);
            if (responseLiveCameraListApi != null) {
                String mResponse = String.valueOf(responseLiveCameraListApi);
                try {
                    CameraPage.this.mJsonResponse = new JSONObject(mResponse);
                    JSONObject mDetail = CameraPage.this.mJsonResponse.getJSONObject(ProductAction.ACTION_DETAIL);
                    CameraPage.this.total = mDetail.getInt("total");
                    if (!CameraPage.this.arraylist.isEmpty()) {
                        CameraPage.this.arraylist.clear();
                    }
                    if (CameraPage.this.total > 0) {
                        CameraPage.this.camerasListArray = mDetail.getJSONArray("cameras");
                        if (CameraPage.this.camerasListArray != null) {
                            if (CameraPage.this.total >= 8000) {
                                CameraPage.this.total = 8000;
                            }
                            String URL = CommonMember.getURL(CameraPage.this.camerasTab);
                            for (int i = 0; i < CameraPage.this.total; i++) {
                                String cameraLatitude = null;
                                String cameraLongitude = null;
                                String mVideoInput = null;
                                CameraPage.this.channelListObject = CameraPage.this.camerasListArray.getJSONObject(i);
                                String cameraName = CameraPage.this.channelListObject.getString("name");
                                String cameraIcon = URL + "/camera/" + CameraPage.this.channelListObject.getString("uuid") + "/snapshot?width=64";
                                if (CameraPage.this.channelListObject.has("latitude")) {
                                    cameraLatitude = CameraPage.this.channelListObject.getString("latitude");
                                }
                                if (CameraPage.this.channelListObject.has("longitude")) {
                                    cameraLongitude = CameraPage.this.channelListObject.getString("longitude");
                                }
                                if (CameraPage.this.channelListObject.has("videoinput")) {
                                    mVideoInput = CameraPage.this.channelListObject.getString("videoinput");
                                }
                                CameraPage.this.arraylist.add(new CameraListItems(cameraIcon, cameraName, CameraPage.this.channelListObject.getString("uuid"), cameraLatitude, cameraLongitude, mVideoInput));
                            }
                            Collections.sort(CameraPage.this.arraylist, new C02901());
                            CameraPage.this.mAdapter = new CameraListAdapter(CameraPage.this.getActivity(), CameraPage.this.arraylist);
                            CameraPage.this.cameraList.setAdapter(CameraPage.this.mAdapter);
                            if (CameraPage.this.mRestoreFlag) {
                                CameraPage.this.cameraList.getLayoutManager().onRestoreInstanceState(CameraPage.this.listState);
                                return;
                            }
                            return;
                        }
                        return;
                    }
                    Toast.makeText(CameraPage.this.getActivity(), CameraPage.this.getResources().getString(C0421R.string.no_cameras_found), 0).show();
                    if (CameraPage.this.mAdapter != null) {
                        CameraPage.this.mAdapter.notifyDataSetChanged();
                        return;
                    }
                    return;
                } catch (JSONException e) {
                    e.printStackTrace();
                    CameraPage.this.mSwipeRefreshLayout.setRefreshing(false);
                    return;
                }
            }
            CameraPage.this.successStatus = "no";
        }

        public void failure(RetrofitError error) {
            CameraPage.this.mTransparentProgressDialog.dismiss();
            CameraPage.this.successStatus = "no";
            CameraPage.this.mSwipeRefreshLayout.setRefreshing(false);
            CommonMember.getErrorDialog(CameraPage.this.getString(C0421R.string.unable_to_load_cameras), CameraPage.this.camerasTab).show();
            error.printStackTrace();
        }
    }

    /* renamed from: com.vizsafe.app.HomePage.CameraPage$4 */
    class C02934 implements Callback<JsonObject> {

        /* renamed from: com.vizsafe.app.HomePage.CameraPage$4$1 */
        class C02921 implements Comparator<CameraListItems> {
            C02921() {
            }

            public int compare(CameraListItems v1, CameraListItems v2) {
                return v1.getCameraName().compareTo(v2.getCameraName());
            }
        }

        C02934() {
        }

        public void success(JsonObject responsePrivateCameraListApi, Response response) {
            if (CameraPage.this.mTransparentProgressDialog.isShowing()) {
                CameraPage.this.mTransparentProgressDialog.dismiss();
            }
            CameraPage.this.mSwipeRefreshLayout.setRefreshing(false);
            if (responsePrivateCameraListApi != null) {
                String mResponse = String.valueOf(responsePrivateCameraListApi);
                try {
                    CameraPage.this.mJsonResponse = new JSONObject(mResponse);
                    JSONObject mDetail = CameraPage.this.mJsonResponse.getJSONObject(ProductAction.ACTION_DETAIL);
                    CameraPage.this.total = mDetail.getInt("total");
                    if (!CameraPage.this.arraylist.isEmpty()) {
                        CameraPage.this.arraylist.clear();
                    }
                    if (CameraPage.this.total > 0) {
                        CameraPage.this.camerasListArray = mDetail.getJSONArray("cameras");
                        if (CameraPage.this.camerasListArray != null) {
                            if (CameraPage.this.total >= 8000) {
                                CameraPage.this.total = 8000;
                            }
                            String CameraIconUrl = CommonMember.getURL(CameraPage.this.camerasTab);
                            for (int i = 0; i < CameraPage.this.total; i++) {
                                String cameraLatitude = null;
                                String cameraLongitude = null;
                                String mVideoInput = null;
                                CameraPage.this.channelListObject = CameraPage.this.camerasListArray.getJSONObject(i);
                                String cameraName = CameraPage.this.channelListObject.getString("name");
                                String cameraIcon = CameraIconUrl + "/camera/" + CameraPage.this.channelListObject.getString("uuid") + "/snapshot?width=64";
                                if (CameraPage.this.channelListObject.has("latitude")) {
                                    cameraLatitude = CameraPage.this.channelListObject.getString("latitude");
                                }
                                if (CameraPage.this.channelListObject.has("longitude")) {
                                    cameraLongitude = CameraPage.this.channelListObject.getString("longitude");
                                }
                                if (CameraPage.this.channelListObject.has("videoinput")) {
                                    mVideoInput = CameraPage.this.channelListObject.getString("videoinput");
                                }
                                CameraPage.this.arraylist.add(new CameraListItems(cameraIcon, cameraName, CameraPage.this.channelListObject.getString("uuid"), cameraLatitude, cameraLongitude, mVideoInput));
                            }
                            Collections.sort(CameraPage.this.arraylist, new C02921());
                            CameraPage.this.mAdapter = new CameraListAdapter(CameraPage.this.getActivity(), CameraPage.this.arraylist);
                            CameraPage.this.cameraList.setAdapter(CameraPage.this.mAdapter);
                            if (CameraPage.this.mRestoreFlag) {
                                CameraPage.this.cameraList.getLayoutManager().onRestoreInstanceState(CameraPage.this.listState);
                                return;
                            }
                            return;
                        }
                        return;
                    }
                    Toast.makeText(CameraPage.this.getActivity(), CameraPage.this.getResources().getString(C0421R.string.no_cameras_found), 0).show();
                    if (CameraPage.this.mAdapter != null) {
                        CameraPage.this.mAdapter.notifyDataSetChanged();
                        return;
                    }
                    return;
                } catch (JSONException e) {
                    e.printStackTrace();
                    CameraPage.this.mSwipeRefreshLayout.setRefreshing(false);
                    return;
                }
            }
            CameraPage.this.successStatus = "no";
        }

        public void failure(RetrofitError error) {
            CameraPage.this.mTransparentProgressDialog.dismiss();
            CameraPage.this.mSwipeRefreshLayout.setRefreshing(false);
            Toast.makeText(CameraPage.this.camerasTab, CameraPage.this.getResources().getString(C0421R.string.unable_to_process_your_request), 0).show();
            error.printStackTrace();
        }
    }

    public static CameraPage newInstance() {
        return new CameraPage();
    }

    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.clear();
    }

    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        ((InputMethodManager) getActivity().getSystemService("input_method")).hideSoftInputFromWindow(getView().getWindowToken(), 0);
    }

    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ((InputMethodManager) getActivity().getSystemService("input_method")).hideSoftInputFromWindow(getView().getWindowToken(), 0);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getActivity().getWindow().setSoftInputMode(3);
        View vCameraPage = inflater.inflate(C0421R.layout.tab_camera, container, false);
        this.camerasTab = getActivity();
        this.searchText = (EditText) vCameraPage.findViewById(C0421R.C0419id.searchText);
        this.cameraList = (RecyclerView) vCameraPage.findViewById(C0421R.C0419id.camera_list);
        this.loadingView = (LinearLayout) vCameraPage.findViewById(C0421R.C0419id.loading_view);
        this.mSwipeRefreshLayout = (SwipeRefreshLayout) vCameraPage.findViewById(C0421R.C0419id.swipeRefreshLayout);
        this.mSwipeRefreshLayout.setColorSchemeResources(C0421R.color.colorPrimary, C0421R.color.colorPrimaryDark, C0421R.color.blue, 17170451);
        this.mTransparentProgressDialog = new SpotsDialog(this.camerasTab);
        this.mTransparentProgressDialog.setCanceledOnTouchOutside(false);
        this.mTransparentProgressDialog.setCancelable(false);
        this.cameraList.setLayoutManager(new LinearLayoutManager(getActivity()));
        this.cameraList.setItemAnimator(new DefaultItemAnimator());
        this.mAdapter = new CameraListAdapter(getActivity(), this.arraylist);
        this.cameraList.setAdapter(this.mAdapter);
        String email = PreferenceHandler.getInstance(this.camerasTab).getUserName();
        this.authStringinBase64 = "Basic " + Base64.encodeToString((email + ":" + PreferenceHandler.getInstance(this.camerasTab).getPassword()).getBytes(), 2);
        if (SettingsPage.mCameraStatus.equals("true")) {
            this.mRestoreFlag = false;
            SettingsPage.mCameraStatus = "false";
            if (CommonMember.isNetworkOnline((ConnectivityManager) this.camerasTab.getSystemService("connectivity"), this.camerasTab)) {
                AsyncTaskGetPrivateCameras();
            } else {
                CommonMember.NetworkStatusAlert(this.camerasTab);
            }
        } else if (mBundleRecyclerViewState != null) {
            this.mRestoreFlag = true;
            this.listState = mBundleRecyclerViewState.getParcelable("recycler_state");
            PreferenceHandler.getInstance(this.camerasTab).setPublicCamraStatus(mBundleRecyclerViewState.getBoolean("listcount"));
            this.cameraList.getLayoutManager().onRestoreInstanceState(this.listState);
            if (CommonMember.isNetworkOnline((ConnectivityManager) this.camerasTab.getSystemService("connectivity"), this.camerasTab)) {
                AsyncTaskGetPrivateCameras();
            } else {
                CommonMember.NetworkStatusAlert(this.camerasTab);
            }
        } else if (CommonMember.isNetworkOnline((ConnectivityManager) this.camerasTab.getSystemService("connectivity"), this.camerasTab)) {
            AsyncTaskGetPrivateCameras();
        } else {
            CommonMember.NetworkStatusAlert(this.camerasTab);
        }
        this.mSwipeRefreshLayout.setOnRefreshListener(new C02881());
        this.searchText.addTextChangedListener(new C02892());
        return vCameraPage;
    }

    private void AsyncTaskCameraList(String authStringinBase64) {
        this.firstTime = false;
        this.mTransparentProgressDialog.show();
        this.mSwipeRefreshLayout.setRefreshing(false);
        LiveCameraListApi.getInstance().Callresponse(getActivity(), authStringinBase64, new C02913());
    }

    private void AsyncTaskGetPrivateCameras() {
        this.firstTime = false;
        String email = PreferenceHandler.getInstance(this.camerasTab).getUserName();
        this.authStringinBase64 = "Basic " + Base64.encodeToString((email + ":" + PreferenceHandler.getInstance(this.camerasTab).getPassword()).getBytes(), 2);
        this.mTransparentProgressDialog.show();
        PrivateCameraListApi.getInstance().Callresponse(getActivity(), this.authStringinBase64, "true", new C02934());
    }

    public void onResume() {
        super.onResume();
    }

    public void onPause() {
        super.onPause();
        this.firstTime = false;
        boolean listcount = PreferenceHandler.getInstance(this.camerasTab).getPublicCamraStatus();
        mBundleRecyclerViewState = new Bundle();
        this.listState = this.cameraList.getLayoutManager().onSaveInstanceState();
        mBundleRecyclerViewState.putParcelable("recycler_state", this.listState);
        mBundleRecyclerViewState.putBoolean("listcount", listcount);
    }
}
