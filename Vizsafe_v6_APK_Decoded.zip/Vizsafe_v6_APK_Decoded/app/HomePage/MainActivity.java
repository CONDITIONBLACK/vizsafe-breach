package com.vizsafe.app.HomePage;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.design.widget.NavigationView;
import android.support.design.widget.NavigationView.OnNavigationItemSelectedListener;
import android.support.p001v4.app.FragmentManager;
import android.support.p001v4.app.FragmentTransaction;
import android.support.p001v4.app.NavUtils;
import android.support.p001v4.app.NotificationCompat;
import android.support.p001v4.view.MenuItemCompat;
import android.support.p001v4.widget.DrawerLayout;
import android.support.p002v7.app.ActionBarDrawerToggle;
import android.support.p002v7.app.AppCompatActivity;
import android.support.p002v7.widget.Toolbar;
import android.support.p002v7.widget.helper.ItemTouchHelper.Callback;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.vizsafe.app.APIClientMethods.UnregisterDeviceIdApi;
import com.vizsafe.app.APIClientMethods.UnregisterDeviceIdApi.ResponseUnregisterDeviceIdApi;
import com.vizsafe.app.Adapters.CameraListAdapter.onGoToMapPageListener;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.Database.AppDatabase;
import com.vizsafe.app.Feeds.ReportDetails;
import com.vizsafe.app.Feeds.ReportDetails.onGoToFeedPageListener;
import com.vizsafe.app.GeoFence.GeofencesScreen;
import com.vizsafe.app.GeoFence.GeofencesScreen.onGoToSettingsPageListener;
import com.vizsafe.app.HomePage.MapsPage.onGoToMicelloIndoorPageListener;
import com.vizsafe.app.HomePage.MapsPage.onGoToReportDetailsPageListener;
import com.vizsafe.app.HomePage.SettingsPage.onGoToGeofencePageListener;
import com.vizsafe.app.InitialPages.SignInPage;
import com.vizsafe.app.Maps.LoadMicelloFloorPlan;
import com.vizsafe.app.Maps.MicelloIndoor;
import com.vizsafe.app.Maps.MicelloIndoor.onGoToLoadMicelloFloorPlanPageListener;
import com.vizsafe.app.NetworkState.NetworkSchedulerService;
import com.vizsafe.app.Outbox.OutboxSentPostItems;
import com.vizsafe.app.Utils.CommonMember;
import com.vizsafe.app.Utils.PreferenceHandler;
import com.vizsafe.app.Utils.VizsafeGPSTracker;
import com.vizsafe.app.Wallet.CreateWalletAddress.onGoToCreateWalletWebViewPageListener;
import com.vizsafe.app.Wallet.CreateWalletAddress.onGoToImportPublicAddressPageListener;
import com.vizsafe.app.Wallet.CreateWalletWebView.onGoToWalletPageListener;
import dmax.dialog.SpotsDialog;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.HttpStatus;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class MainActivity extends AppCompatActivity implements OnNavigationItemSelectedListener, onGoToMapPageListener, onGoToReportDetailsPageListener, onGoToFeedPageListener, onGoToLoadMicelloFloorPlanPageListener, onGoToMicelloIndoorPageListener, onGoToWalletPageListener, onGoToCreateWalletWebViewPageListener, onGoToImportPublicAddressPageListener, onGoToGeofencePageListener, onGoToSettingsPageListener {
    public static String currentLatitudePin = null;
    public static String currentLongitudePin = null;
    public static String incidentUuid = null;
    public static String incidentUuidFromUser = null;
    public static String mDisplayName = null;
    public static String mMessage;
    private final String KEY_RECYCLER_STATE = "recycler_state";
    private final String LIST_COUNT = "listcount";
    private final String LIST_COUNT1 = "listcount1";
    private final String STATE_FLAG = "stateflag";
    ArrayList<OutboxSentPostItems> arraylist = new ArrayList();
    Builder dialog;
    AlertDialog dialogShow;
    private VizsafeGPSTracker gps;
    private Context mContext;
    private int mCurrentPage = 0;
    private TextView mEmailTitle;
    private MainActivity mMainActivity;
    private MapsPage mMapsPage;
    private TextView mNotificationCountView;
    private boolean mRegistered = false;
    private Bundle mReportDetailsPageBundle = null;
    private ReportPage mReportPage;
    private AlertDialog mTransparentProgressDialog;
    private MenuItem menu1;
    private MenuItem menu2;
    private NavigationView navigationView;
    private final BroadcastReceiver postReceiver = new C03113();
    private final BroadcastReceiver showNotificationDialogReceiver = new C03092();
    private boolean subscreensOnTheStack = false;
    Toolbar toolbar;

    /* renamed from: com.vizsafe.app.HomePage.MainActivity$2 */
    class C03092 extends BroadcastReceiver {

        /* renamed from: com.vizsafe.app.HomePage.MainActivity$2$1 */
        class C03051 implements OnClickListener {
            C03051() {
            }

            public void onClick(DialogInterface dialog, int which) {
                if (MainActivity.incidentUuid != null && !MainActivity.incidentUuid.trim().isEmpty()) {
                    FeedPage.loadFeedPage = true;
                    MainActivity.this.onNavigationDrawerItemSelected(103);
                }
            }
        }

        /* renamed from: com.vizsafe.app.HomePage.MainActivity$2$2 */
        class C03062 implements OnClickListener {
            C03062() {
            }

            public void onClick(DialogInterface dialog, int which) {
            }
        }

        /* renamed from: com.vizsafe.app.HomePage.MainActivity$2$3 */
        class C03073 implements OnClickListener {
            C03073() {
            }

            public void onClick(DialogInterface dialog, int which) {
                if (MainActivity.incidentUuidFromUser != null && !MainActivity.incidentUuidFromUser.trim().isEmpty()) {
                    MainActivity.this.mReportDetailsPageBundle = null;
                    FeedPage.loadFeedPage = true;
                    MainActivity.this.onNavigationDrawerItemSelected(102);
                }
            }
        }

        /* renamed from: com.vizsafe.app.HomePage.MainActivity$2$4 */
        class C03084 implements OnClickListener {
            C03084() {
            }

            public void onClick(DialogInterface dialog, int which) {
            }
        }

        C03092() {
        }

        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            Bundle bundle = intent.getExtras();
            if (bundle != null) {
                MainActivity.incidentUuid = bundle.getString("incident_uuid_from_dialog");
                MainActivity.incidentUuidFromUser = bundle.getString("incident_uuid_from_user_assignment_notification");
                if (MainActivity.incidentUuid != null) {
                    MainActivity.mMessage = bundle.getString(NotificationCompat.CATEGORY_MESSAGE);
                    if (action.equals("com.vizsafe.SHOW_DIALOG") && !MainActivity.this.dialogShow.isShowing()) {
                        MainActivity.this.dialog.setTitle(MainActivity.mMessage);
                        MainActivity.this.dialog.setMessage(MainActivity.this.getResources().getString(C0421R.string.new_report_posted));
                        MainActivity.this.dialog.setPositiveButton(MainActivity.this.getResources().getString(C0421R.string.show_me), new C03051());
                        MainActivity.this.dialog.setNegativeButton(MainActivity.this.getResources().getString(C0421R.string.okTxt), new C03062());
                        MainActivity.this.dialogShow = MainActivity.this.dialog.create();
                        MainActivity.this.dialogShow.setCancelable(false);
                        MainActivity.this.dialogShow.show();
                    }
                } else if (MainActivity.incidentUuidFromUser != null) {
                    MainActivity.mMessage = bundle.getString(NotificationCompat.CATEGORY_MESSAGE);
                    MainActivity.mDisplayName = bundle.getString("DisplayName");
                    if (action.equals("com.vizsafe.SHOW_DIALOG") && !MainActivity.this.dialogShow.isShowing()) {
                        MainActivity.this.dialog.setTitle("New Task");
                        MainActivity.this.dialog.setMessage("@" + MainActivity.mDisplayName + " has assigned the task \"" + MainActivity.mMessage + "\" to you.");
                        MainActivity.this.dialog.setPositiveButton(MainActivity.this.getResources().getString(C0421R.string.show_me), new C03073());
                        MainActivity.this.dialog.setNegativeButton(MainActivity.this.getResources().getString(C0421R.string.okTxt), new C03084());
                        MainActivity.this.dialogShow = MainActivity.this.dialog.create();
                        MainActivity.this.dialogShow.setCancelable(false);
                        MainActivity.this.dialogShow.show();
                    }
                }
            }
        }
    }

    /* renamed from: com.vizsafe.app.HomePage.MainActivity$3 */
    class C03113 extends BroadcastReceiver {

        /* renamed from: com.vizsafe.app.HomePage.MainActivity$3$1 */
        class C03101 extends TypeToken<List<OutboxSentPostItems>> {
            C03101() {
            }
        }

        C03113() {
        }

        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals("com.vizsafe.UPDATE_OUTBOX")) {
                ArrayList<OutboxSentPostItems> arraylist = new ArrayList();
                arraylist = (ArrayList) new Gson().fromJson(PreferenceHandler.getInstance(MainActivity.this).getOutBoxSet(), new C03101().getType());
                if (arraylist == null || arraylist.size() <= 0) {
                    MainActivity.this.mNotificationCountView.setVisibility(8);
                    return;
                }
                MainActivity.this.mNotificationCountView.setVisibility(0);
                MainActivity.this.mNotificationCountView.setText(String.valueOf(arraylist.size()));
            }
        }
    }

    /* renamed from: com.vizsafe.app.HomePage.MainActivity$4 */
    class C03124 extends TypeToken<List<OutboxSentPostItems>> {
        C03124() {
        }
    }

    /* renamed from: com.vizsafe.app.HomePage.MainActivity$5 */
    class C03135 implements OnClickListener {
        C03135() {
        }

        public void onClick(DialogInterface dialog, int id) {
            MainActivity.this.finishAndRemoveTask();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0421R.layout.activity_home_page);
        Log.e("Res LocationService", "MainActivity onCreate");
        this.mMainActivity = this;
        this.mContext = this;
        this.mTransparentProgressDialog = new SpotsDialog(this.mContext, getResources().getString(C0421R.string.please_wait_loading));
        this.mTransparentProgressDialog.setCanceledOnTouchOutside(false);
        this.mTransparentProgressDialog.setCancelable(false);
        this.toolbar = (Toolbar) findViewById(2131689802);
        setSupportActionBar(this.toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        this.dialog = new Builder(this);
        this.dialogShow = this.dialog.create();
        DrawerLayout drawer = (DrawerLayout) findViewById(C0421R.C0419id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, this.toolbar, C0421R.string.navigation_drawer_open, C0421R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        this.navigationView = (NavigationView) findViewById(C0421R.C0419id.nav_view);
        this.navigationView.setNavigationItemSelectedListener(this);
        this.mEmailTitle = (TextView) this.navigationView.getHeaderView(0).findViewById(C0421R.C0419id.header_title);
        String mUserDisplayName = PreferenceHandler.getInstance(this.mMainActivity).getUserDisplayName();
        this.mNotificationCountView = (TextView) MenuItemCompat.getActionView(this.navigationView.getMenu().findItem(C0421R.C0419id.nav_settings));
        scheduleJob();
        initializeCountDrawer();
        LayoutParams lp;
        if (mUserDisplayName == null || mUserDisplayName.isEmpty()) {
            String mUserEmail = PreferenceHandler.getInstance(this.mMainActivity).getUserName();
            if (mUserDisplayName.length() > 9) {
                this.mEmailTitle.setGravity(3);
                lp = (LayoutParams) this.mEmailTitle.getLayoutParams();
                lp.width = HttpStatus.SC_INTERNAL_SERVER_ERROR;
                this.mEmailTitle.setLayoutParams(lp);
            } else {
                this.mEmailTitle.setGravity(17);
                lp = (LayoutParams) this.mEmailTitle.getLayoutParams();
                lp.width = Callback.DEFAULT_SWIPE_ANIMATION_DURATION;
                this.mEmailTitle.setLayoutParams(lp);
            }
            this.mEmailTitle.setText(mUserEmail);
        } else {
            if (mUserDisplayName.length() > 9) {
                this.mEmailTitle.setGravity(3);
                lp = (LayoutParams) this.mEmailTitle.getLayoutParams();
                lp.width = HttpStatus.SC_INTERNAL_SERVER_ERROR;
                this.mEmailTitle.setLayoutParams(lp);
            } else {
                this.mEmailTitle.setGravity(17);
                lp = (LayoutParams) this.mEmailTitle.getLayoutParams();
                lp.width = Callback.DEFAULT_SWIPE_ANIMATION_DURATION;
                this.mEmailTitle.setLayoutParams(lp);
            }
            this.mEmailTitle.setText(mUserDisplayName);
        }
        this.navigationView.setCheckedItem(C0421R.C0419id.nav_report);
        onNavigationItemSelected(this.navigationView.getMenu().findItem(C0421R.C0419id.nav_report));
        AppDatabase.getAppDatabase(this);
        RegisterIntents();
        broadcastOutboxIntent();
        onNewIntent(getIntent());
    }

    private void RegisterIntents() {
        IntentFilter filter = new IntentFilter("android.intent.action.VIEW");
        filter.addAction("com.vizsafe.UPDATE_OUTBOX");
        filter.setPriority(2);
        registerReceiver(this.postReceiver, filter);
        IntentFilter filter1 = new IntentFilter("android.intent.action.VIEW");
        filter1.addAction("com.vizsafe.SHOW_DIALOG");
        filter1.setPriority(0);
        registerReceiver(this.showNotificationDialogReceiver, filter1);
        this.mRegistered = true;
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(C0421R.C0420menu.main, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() != 16908332) {
            return super.onOptionsItemSelected(item);
        }
        NavUtils.navigateUpFromSameTask(this);
        return true;
    }

    private void onNavigationDrawerItemSelected(int position) {
        this.mCurrentPage = position;
        FragmentManager fragmentManager = getSupportFragmentManager();
        switch (position) {
            case 101:
                this.navigationView.setCheckedItem(C0421R.C0419id.nav_map);
                onNavigationItemSelected(this.navigationView.getMenu().findItem(C0421R.C0419id.nav_map));
                this.subscreensOnTheStack = false;
                try {
                    if (this.toolbar != null) {
                        this.toolbar.setVisibility(0);
                    }
                    fragmentManager.popBackStackImmediate(null, 1);
                    FragmentTransaction beginTransaction = fragmentManager.beginTransaction();
                    MapsPage newInstance = MapsPage.newInstance(currentLatitudePin, currentLongitudePin);
                    this.mMapsPage = newInstance;
                    beginTransaction.replace(C0421R.C0419id.frame_container, newInstance).commit();
                    return;
                } catch (IllegalStateException e) {
                    return;
                }
            case 102:
                this.subscreensOnTheStack = true;
                try {
                    fragmentManager.beginTransaction().replace(C0421R.C0419id.frame_container, ReportDetails.newInstance(this.mReportDetailsPageBundle)).commit();
                    if (this.toolbar != null) {
                        this.toolbar.setVisibility(8);
                        return;
                    }
                    return;
                } catch (IllegalStateException e2) {
                    return;
                }
            case 103:
                this.navigationView.setCheckedItem(C0421R.C0419id.nav_feed);
                onNavigationItemSelected(this.navigationView.getMenu().findItem(C0421R.C0419id.nav_feed));
                this.subscreensOnTheStack = false;
                try {
                    if (this.toolbar != null) {
                        this.toolbar.setVisibility(0);
                    }
                    fragmentManager.popBackStackImmediate(null, 1);
                    fragmentManager.beginTransaction().replace(C0421R.C0419id.frame_container, FeedPage.newInstance()).commit();
                    return;
                } catch (IllegalStateException e3) {
                    return;
                }
            case 104:
                this.navigationView.setCheckedItem(C0421R.C0419id.nav_map);
                onNavigationItemSelected(this.navigationView.getMenu().findItem(C0421R.C0419id.nav_map));
                this.subscreensOnTheStack = false;
                try {
                    if (this.toolbar != null) {
                        this.toolbar.setVisibility(8);
                    }
                    fragmentManager.popBackStackImmediate(null, 1);
                    fragmentManager.beginTransaction().replace(C0421R.C0419id.frame_container, LoadMicelloFloorPlan.newInstance(this.mReportDetailsPageBundle)).commit();
                    return;
                } catch (IllegalStateException e4) {
                    return;
                }
            case 105:
                this.navigationView.setCheckedItem(C0421R.C0419id.nav_map);
                onNavigationItemSelected(this.navigationView.getMenu().findItem(C0421R.C0419id.nav_map));
                this.subscreensOnTheStack = true;
                try {
                    if (this.toolbar != null) {
                        this.toolbar.setVisibility(8);
                    }
                    fragmentManager.popBackStackImmediate(null, 1);
                    fragmentManager.beginTransaction().replace(C0421R.C0419id.frame_container, MicelloIndoor.newInstance()).commit();
                    return;
                } catch (IllegalStateException e5) {
                    return;
                }
            case 106:
            case 107:
            case 108:
            case 109:
                this.navigationView.setCheckedItem(C0421R.C0419id.nav_settings);
                onNavigationItemSelected(this.navigationView.getMenu().findItem(C0421R.C0419id.nav_settings));
                this.subscreensOnTheStack = true;
                try {
                    fragmentManager.popBackStackImmediate(null, 1);
                    fragmentManager.beginTransaction().replace(C0421R.C0419id.frame_container, GeofencesScreen.newInstance()).commit();
                    if (this.toolbar != null) {
                        this.toolbar.setVisibility(8);
                        return;
                    }
                    return;
                } catch (IllegalStateException e6) {
                    return;
                }
            case 110:
                this.navigationView.setCheckedItem(C0421R.C0419id.nav_settings);
                onNavigationItemSelected(this.navigationView.getMenu().findItem(C0421R.C0419id.nav_settings));
                this.subscreensOnTheStack = false;
                try {
                    if (this.toolbar != null) {
                        this.toolbar.setVisibility(0);
                    }
                    fragmentManager.popBackStackImmediate(null, 1);
                    fragmentManager.beginTransaction().replace(C0421R.C0419id.frame_container, SettingsPage.newInstance()).commit();
                    return;
                } catch (IllegalStateException e7) {
                    return;
                }
            default:
                return;
        }
    }

    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();
        FragmentManager fragmentManager = getSupportFragmentManager();
        this.subscreensOnTheStack = false;
        if (this.toolbar != null) {
            this.toolbar.setVisibility(0);
        }
        FragmentTransaction beginTransaction;
        if (id == C0421R.C0419id.nav_report) {
            fragmentManager.popBackStackImmediate(null, 1);
            beginTransaction = fragmentManager.beginTransaction();
            ReportPage newInstance = ReportPage.newInstance();
            this.mReportPage = newInstance;
            beginTransaction.replace(C0421R.C0419id.frame_container, newInstance).commit();
        } else if (id == C0421R.C0419id.nav_feed) {
            fragmentManager.popBackStackImmediate(null, 1);
            fragmentManager.beginTransaction().replace(C0421R.C0419id.frame_container, FeedPage.newInstance()).commit();
        } else if (id == C0421R.C0419id.nav_map) {
            try {
                fragmentManager.popBackStackImmediate(null, 1);
                beginTransaction = fragmentManager.beginTransaction();
                MapsPage newInstance2 = MapsPage.newInstance(currentLatitudePin, currentLongitudePin);
                this.mMapsPage = newInstance2;
                beginTransaction.replace(C0421R.C0419id.frame_container, newInstance2).commit();
            } catch (IllegalStateException e) {
            }
        } else if (id == C0421R.C0419id.nav_camera) {
            fragmentManager.popBackStackImmediate(null, 1);
            fragmentManager.beginTransaction().replace(C0421R.C0419id.frame_container, CameraPage.newInstance()).commit();
        } else if (id == C0421R.C0419id.nav_settings) {
            fragmentManager.popBackStackImmediate(null, 1);
            fragmentManager.beginTransaction().replace(C0421R.C0419id.frame_container, SettingsPage.newInstance()).commit();
        } else if (id == C0421R.C0419id.nav_logout) {
            fragmentManager.popBackStackImmediate(null, 1);
            if (CommonMember.isNetworkOnline((ConnectivityManager) getSystemService("connectivity"), this)) {
                TaskUnregisterDeviceId(fragmentManager);
            } else {
                CommonMember.getErrorDialog(getString(C0421R.string.no_internet_access), this).show();
            }
        }
        ((DrawerLayout) findViewById(C0421R.C0419id.drawer_layout)).closeDrawer(8388611);
        return true;
    }

    private void TaskUnregisterDeviceId(final FragmentManager fragmentManager) {
        this.mTransparentProgressDialog.show();
        String registerId = PreferenceHandler.getInstance(this.mContext).getRegisterId();
        String email = PreferenceHandler.getInstance(this.mContext).getUserName();
        UnregisterDeviceIdApi.getInstance().Callresponse(this.mContext, "Basic " + Base64.encodeToString((email + ":" + PreferenceHandler.getInstance(this.mContext).getPassword()).getBytes(), 2), registerId, new retrofit.Callback<ResponseUnregisterDeviceIdApi>() {

            /* renamed from: com.vizsafe.app.HomePage.MainActivity$1$1 */
            class C03031 extends TypeToken<List<OutboxSentPostItems>> {
                C03031() {
                }
            }

            public void success(ResponseUnregisterDeviceIdApi responseUnregisterDeviceIdApi, Response response) {
                MainActivity.this.mTransparentProgressDialog.dismiss();
                Toast.makeText(MainActivity.this.mContext, responseUnregisterDeviceIdApi.getMessage(), 0).show();
                if (responseUnregisterDeviceIdApi.getHttpCode().intValue() == 200) {
                    fragmentManager.popBackStackImmediate(null, 1);
                    PreferenceHandler.getInstance(MainActivity.this).setUserName("");
                    PreferenceHandler.getInstance(MainActivity.this).setPassword("");
                    PreferenceHandler.getInstance(MainActivity.this).setUserUUID("");
                    PreferenceHandler.getInstance(MainActivity.this).setRegisterId(null);
                    PreferenceHandler.getInstance(MainActivity.this).setSuperUser(Boolean.valueOf(false));
                    PreferenceHandler.getInstance(MainActivity.this).setUserDisplayName("");
                    PreferenceHandler.getInstance(MainActivity.this).setServerName("");
                    PreferenceHandler.getInstance(MainActivity.this).setUserEmail("");
                    PreferenceHandler.getInstance(MainActivity.this).setCurrentEthAddress("0");
                    PreferenceHandler.getInstance(MainActivity.this).setVerifyPasswordWallet(0);
                    PreferenceHandler.getInstance(MainActivity.this).setShowVerifyPhrase(0);
                    PreferenceHandler.getInstance(MainActivity.this).setVerifyPhrase(0);
                    PreferenceHandler.getInstance(MainActivity.this).setCheckImportPublicAddress("");
                    PreferenceHandler.getInstance(MainActivity.this.mContext).setMnemonicPhrase("");
                    PreferenceHandler.getInstance(MainActivity.this.mContext).setPrivateEthAddress("");
                    PreferenceHandler.getInstance(MainActivity.this.mContext).setPublicEthAddress("");
                    PreferenceHandler.getInstance(MainActivity.this.mContext).setLoginTypeSignIn(Boolean.valueOf(false));
                    PreferenceHandler.getInstance(MainActivity.this.mContext).setVerifiedOTPForSignUp(Boolean.valueOf(false));
                    PreferenceHandler.getInstance(MainActivity.this.mContext).setMobileNumber("");
                    PreferenceHandler.getInstance(MainActivity.this.mContext).setListByCountFeed(2);
                    PreferenceHandler.getInstance(MainActivity.this.mContext).setListByCountFeedState(0);
                    FeedPage.mBundleRecyclerViewState = new Bundle();
                    FeedPage.mBundleRecyclerViewState.putParcelable("recycler_state", null);
                    FeedPage.mBundleRecyclerViewState.putInt("listcount", 2);
                    FeedPage.mBundleRecyclerViewState.putInt("listcount1", 0);
                    FeedPage.mBundleRecyclerViewState.putBoolean("stateflag", false);
                    ReportPage.handler.removeCallbacksAndMessages(null);
                    Gson gson = new Gson();
                    String jsonCars = PreferenceHandler.getInstance(MainActivity.this.getApplicationContext()).getOutBoxSet();
                    Type type = new C03031().getType();
                    MainActivity.this.arraylist = (ArrayList) gson.fromJson(jsonCars, type);
                    if (MainActivity.this.arraylist != null) {
                        for (int position = 0; position < MainActivity.this.arraylist.size(); position++) {
                            MainActivity.this.arraylist.remove(position);
                            try {
                                PreferenceHandler.getInstance(MainActivity.this.mContext).setOutBoxSet(new Gson().toJson(MainActivity.this.arraylist));
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }
                    PreferenceHandler.getInstance(MainActivity.this.getApplicationContext()).setOutBoxSet("");
                    Intent i = new Intent(MainActivity.this, SignInPage.class);
                    i.addFlags(603979776);
                    MainActivity.this.startActivity(i);
                    MainActivity.this.finish();
                }
            }

            public void failure(RetrofitError error) {
                MainActivity.this.mTransparentProgressDialog.dismiss();
                error.printStackTrace();
            }
        });
    }

    public void broadcastOutboxIntent() {
        Intent intent = new Intent();
        intent.setAction("com.vizsafe.UPDATE_OUTBOX");
        sendBroadcast(intent);
    }

    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Bundle bundle = intent.getExtras();
        if (bundle != null) {
            incidentUuid = bundle.getString("incident_uuid_from_dialog");
            incidentUuidFromUser = bundle.getString("incident_uuid_from_user_assignment_notification");
            if (incidentUuid != null && !incidentUuid.trim().isEmpty()) {
                FeedPage.loadFeedPage = true;
                onNavigationDrawerItemSelected(103);
            } else if (incidentUuidFromUser != null) {
                this.mReportDetailsPageBundle = null;
                FeedPage.loadFeedPage = true;
                onNavigationDrawerItemSelected(102);
            }
        }
    }

    private void initializeCountDrawer() {
        this.mNotificationCountView.setGravity(16);
        this.mNotificationCountView.setTypeface(null, 1);
        this.mNotificationCountView.setTextColor(getResources().getColor(C0421R.color.colorAccent));
        ArrayList<OutboxSentPostItems> arraylist = new ArrayList();
        arraylist = (ArrayList) new Gson().fromJson(PreferenceHandler.getInstance(this).getOutBoxSet(), new C03124().getType());
        if (arraylist == null || arraylist.size() <= 0) {
            this.mNotificationCountView.setVisibility(8);
            return;
        }
        this.mNotificationCountView.setVisibility(0);
        this.mNotificationCountView.setText(String.valueOf(arraylist.size()));
    }

    public void onGoToMapPage(String Lat, String Longt) {
        currentLatitudePin = Lat;
        currentLongitudePin = Longt;
        onNavigationDrawerItemSelected(101);
    }

    public void onGoToReportDetailsPage(Bundle bundle) {
        this.mReportDetailsPageBundle = bundle;
        onNavigationDrawerItemSelected(102);
    }

    public void onGoToFeedPage() {
        onNavigationDrawerItemSelected(103);
    }

    public void onGoToLoadMicelloFloorPlanPage(Bundle bundle) {
        this.mReportDetailsPageBundle = bundle;
        onNavigationDrawerItemSelected(104);
    }

    public void onGoToMicelloIndoorPage() {
        onNavigationDrawerItemSelected(105);
    }

    public void onGoToWalletPage() {
        onNavigationDrawerItemSelected(106);
    }

    public void ImportPublicAddressPage() {
        onNavigationDrawerItemSelected(107);
    }

    public void onGoToCreateWalletWebViewPage() {
        onNavigationDrawerItemSelected(108);
    }

    public void onGoToGeofencePage() {
        onNavigationDrawerItemSelected(109);
    }

    public void onGoToSettingsPage() {
        onNavigationDrawerItemSelected(110);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 105) {
            this.mReportPage.onActivityResult(requestCode, resultCode, data);
        } else if (requestCode == 115) {
            this.mMapsPage.onActivityResult(requestCode, resultCode, data);
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @RequiresApi(api = 21)
    private void scheduleJob() {
        ((JobScheduler) getSystemService("jobscheduler")).schedule(new JobInfo.Builder(0, new ComponentName(this, NetworkSchedulerService.class)).setRequiresCharging(true).setMinimumLatency(1000).setOverrideDeadline(2000).setRequiredNetworkType(1).setPersisted(true).build());
    }

    protected void onStop() {
        super.onStop();
    }

    protected void onStart() {
        super.onStart();
        startService(new Intent(this, NetworkSchedulerService.class));
    }

    protected void onDestroy() {
        super.onDestroy();
        if (this.mRegistered) {
            unregisterReceiver(this.postReceiver);
            unregisterReceiver(this.showNotificationDialogReceiver);
            this.mRegistered = false;
        }
    }

    protected void onResume() {
        super.onResume();
        initializeCountDrawer();
        startService(new Intent(this, NetworkSchedulerService.class));
    }

    public void onBackPressed() {
        if (!this.subscreensOnTheStack) {
            new android.support.p002v7.app.AlertDialog.Builder(this).setMessage((CharSequence) "Are you sure you want to exit?").setCancelable(false).setPositiveButton(getResources().getString(C0421R.string.okTxt), new C03135()).setNegativeButton(getResources().getString(C0421R.string.cancel), null).show();
        }
    }
}
