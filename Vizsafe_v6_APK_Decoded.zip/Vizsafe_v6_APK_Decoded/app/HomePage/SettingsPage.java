package com.vizsafe.app.HomePage;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.p001v4.app.Fragment;
import android.support.p001v4.app.FragmentActivity;
import android.util.Base64;
import android.view.InflateException;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import com.google.android.gms.analytics.ecommerce.ProductAction;
import com.google.android.gms.plus.PlusShare;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.vizsafe.app.APIClientMethods.UnregisterDeviceIdApi;
import com.vizsafe.app.APIClientMethods.UnregisterDeviceIdApi.ResponseUnregisterDeviceIdApi;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.GCMIntentService.GCMClientManager;
import com.vizsafe.app.InitialPages.ChangePasswordScreen;
import com.vizsafe.app.InitialPages.SignInPage;
import com.vizsafe.app.InitialPages.VerifyMobileFromSignIn;
import com.vizsafe.app.Maps.WebviewLoader;
import com.vizsafe.app.Outbox.OutboxScreen;
import com.vizsafe.app.Outbox.OutboxSentPostItems;
import com.vizsafe.app.Utils.CommonMember;
import com.vizsafe.app.Utils.Constants;
import com.vizsafe.app.Utils.PreferenceHandler;
import com.vizsafe.app.Utils.Webservice;
import dmax.dialog.SpotsDialog;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.HttpHeaders;
import org.apache.http.protocol.HTTP;
import org.json.JSONException;
import org.json.JSONObject;
import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class SettingsPage extends Fragment implements OnClickListener {
    public static String mCameraStatus = "false";
    private String authenticationString;
    boolean cameraStatus = false;
    private LinearLayout changePassowrd;
    private LinearLayout disclaimer;
    private LinearLayout frequentlyAskedQuestions;
    private LinearLayout geofencesLayout;
    boolean isSuperUser;
    private LinearLayout logOutBtn;
    private Context mContext;
    private AlertDialog mTransparentProgressDialog;
    private TextView mVerifyMobile;
    private TextView outboxCount;
    private LinearLayout outboxLayout;
    private LinearLayout privacyPolicy;
    private ToggleButton publicCameraToggle;
    private LinearLayout rulesOfConduct;
    private FragmentActivity settingsTab;
    private LinearLayout shareApplication;
    private LinearLayout termeOfUse;
    private TextView txtMaxVideoDuration;
    private TextView txtNotificationStatus;
    private TextView txtversioninfo;
    private String url = "";
    private TextView userEmail;
    View vSettingsPage;

    public interface onGoToGeofencePageListener {
        void onGoToGeofencePage();
    }

    /* renamed from: com.vizsafe.app.HomePage.SettingsPage$1 */
    class C03361 implements OnClickListener {
        C03361() {
        }

        public void onClick(View v) {
            SettingsPage.this.startActivity(new Intent(SettingsPage.this.settingsTab, VerifyMobileFromSignIn.class));
        }
    }

    /* renamed from: com.vizsafe.app.HomePage.SettingsPage$2 */
    class C03372 implements OnCheckedChangeListener {
        C03372() {
        }

        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            if (isChecked) {
                PreferenceHandler.getInstance(SettingsPage.this.settingsTab).setPublicCamraStatus(true);
                SettingsPage.mCameraStatus = "true";
                return;
            }
            SettingsPage.mCameraStatus = "true";
            PreferenceHandler.getInstance(SettingsPage.this.settingsTab).setPublicCamraStatus(false);
        }
    }

    /* renamed from: com.vizsafe.app.HomePage.SettingsPage$3 */
    class C03383 extends TypeToken<List<OutboxSentPostItems>> {
        C03383() {
        }
    }

    /* renamed from: com.vizsafe.app.HomePage.SettingsPage$4 */
    class C03394 implements Callback<ResponseUnregisterDeviceIdApi> {
        C03394() {
        }

        public void success(ResponseUnregisterDeviceIdApi responseUnregisterDeviceIdApi, Response response) {
            SettingsPage.this.mTransparentProgressDialog.dismiss();
            Toast.makeText(SettingsPage.this.mContext, responseUnregisterDeviceIdApi.getMessage(), 0).show();
            if (responseUnregisterDeviceIdApi.getHttpCode().intValue() == 200) {
                Intent logoutAction = new Intent(SettingsPage.this.settingsTab, SignInPage.class);
                PreferenceHandler.getInstance(SettingsPage.this.settingsTab).setUserName("");
                PreferenceHandler.getInstance(SettingsPage.this.settingsTab).setPassword("");
                PreferenceHandler.getInstance(SettingsPage.this.settingsTab).setUserUUID("");
                PreferenceHandler.getInstance(SettingsPage.this.settingsTab).setRegisterId(null);
                PreferenceHandler.getInstance(SettingsPage.this.settingsTab).setSuperUser(Boolean.valueOf(false));
                PreferenceHandler.getInstance(SettingsPage.this.settingsTab).setUserDisplayName("");
                PreferenceHandler.getInstance(SettingsPage.this.settingsTab).setCurrentEthAddress("0");
                PreferenceHandler.getInstance(SettingsPage.this.settingsTab).setVerifyPasswordWallet(0);
                PreferenceHandler.getInstance(SettingsPage.this.settingsTab).setShowVerifyPhrase(0);
                PreferenceHandler.getInstance(SettingsPage.this.settingsTab).setVerifyPhrase(0);
                PreferenceHandler.getInstance(SettingsPage.this.settingsTab).setCheckImportPublicAddress("");
                SettingsPage.this.startActivity(logoutAction);
                SettingsPage.this.getActivity().finish();
                ReportPage.handler.removeCallbacksAndMessages(null);
            }
        }

        public void failure(RetrofitError error) {
            SettingsPage.this.mTransparentProgressDialog.dismiss();
            error.printStackTrace();
        }
    }

    private class AsyncTaskSignIn extends AsyncTask<String, String, String> {
        JSONObject mJsonResponse;
        JSONObject response;

        private AsyncTaskSignIn() {
        }

        /* synthetic */ AsyncTaskSignIn(SettingsPage x0, C03361 x1) {
            this();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            SettingsPage.this.mTransparentProgressDialog.show();
        }

        protected String doInBackground(String... arg0) {
            this.response = new Webservice().LoginUser(SettingsPage.this.mContext, PreferenceHandler.getInstance(SettingsPage.this.mContext).getUserName(), PreferenceHandler.getInstance(SettingsPage.this.mContext).getPassword(), PreferenceHandler.getInstance(SettingsPage.this.mContext).getServerName());
            return null;
        }

        protected void onPostExecute(String result) {
            if (SettingsPage.this.mTransparentProgressDialog.isShowing()) {
                SettingsPage.this.mTransparentProgressDialog.dismiss();
            }
            if (this.response != null) {
                try {
                    this.mJsonResponse = new JSONObject(String.valueOf(this.response));
                    SettingsPage.this.DoBackgroundProcess(this.mJsonResponse);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static SettingsPage newInstance() {
        return new SettingsPage();
    }

    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.clear();
    }

    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @SuppressLint({"StringFormatInvalid"})
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (this.vSettingsPage != null) {
            ViewGroup parent = (ViewGroup) this.vSettingsPage.getParent();
            if (parent != null) {
                parent.removeView(this.vSettingsPage);
            }
        }
        try {
            getActivity().getWindow().setSoftInputMode(3);
            this.vSettingsPage = inflater.inflate(C0421R.layout.tab_settings, container, false);
            this.settingsTab = getActivity();
            this.mContext = getContext();
            PackageInfo pInfo = null;
            try {
                pInfo = this.mContext.getPackageManager().getPackageInfo(this.mContext.getPackageName(), 0);
            } catch (NameNotFoundException e) {
                e.printStackTrace();
            }
            String version = pInfo.versionName;
            this.mTransparentProgressDialog = new SpotsDialog(this.settingsTab);
            this.mTransparentProgressDialog.setCanceledOnTouchOutside(false);
            this.mTransparentProgressDialog.setCancelable(false);
            this.frequentlyAskedQuestions = (LinearLayout) this.vSettingsPage.findViewById(C0421R.C0419id.frequently_asked_question);
            this.termeOfUse = (LinearLayout) this.vSettingsPage.findViewById(C0421R.C0419id.terms_of_use);
            this.privacyPolicy = (LinearLayout) this.vSettingsPage.findViewById(C0421R.C0419id.privacy_policy);
            this.rulesOfConduct = (LinearLayout) this.vSettingsPage.findViewById(C0421R.C0419id.rules_of_conduct);
            this.disclaimer = (LinearLayout) this.vSettingsPage.findViewById(C0421R.C0419id.disclaimer);
            this.shareApplication = (LinearLayout) this.vSettingsPage.findViewById(C0421R.C0419id.share_application);
            this.logOutBtn = (LinearLayout) this.vSettingsPage.findViewById(C0421R.C0419id.logout_action);
            this.changePassowrd = (LinearLayout) this.vSettingsPage.findViewById(C0421R.C0419id.change_password);
            this.geofencesLayout = (LinearLayout) this.vSettingsPage.findViewById(C0421R.C0419id.geofences_layout);
            this.outboxLayout = (LinearLayout) this.vSettingsPage.findViewById(C0421R.C0419id.outbox_layout);
            this.txtNotificationStatus = (TextView) this.vSettingsPage.findViewById(C0421R.C0419id.txt_notification_status);
            this.outboxCount = (TextView) this.vSettingsPage.findViewById(C0421R.C0419id.outboxCount);
            this.userEmail = (TextView) this.vSettingsPage.findViewById(C0421R.C0419id.user_email);
            this.publicCameraToggle = (ToggleButton) this.vSettingsPage.findViewById(C0421R.C0419id.public_camera_toggle);
            this.txtMaxVideoDuration = (TextView) this.vSettingsPage.findViewById(C0421R.C0419id.txtMaxVideoDuration);
            this.txtversioninfo = (TextView) this.vSettingsPage.findViewById(C0421R.C0419id.versioninfo);
            this.mVerifyMobile = (TextView) this.vSettingsPage.findViewById(C0421R.C0419id.verify_mobile);
            initializeCountDrawer();
            this.txtversioninfo.setText(getResources().getString(C0421R.string.version) + " " + version);
            String email = PreferenceHandler.getInstance(this.settingsTab).getUserName();
            this.authenticationString = "Basic " + Base64.encodeToString((email + ":" + PreferenceHandler.getInstance(this.settingsTab).getPassword()).getBytes(), 2);
            this.publicCameraToggle.setChecked(PreferenceHandler.getInstance(this.settingsTab).getPublicCamraStatus());
            this.userEmail.setText(PreferenceHandler.getInstance(this.settingsTab).getUserName());
            this.isSuperUser = PreferenceHandler.getInstance(this.settingsTab).getSuperUser().booleanValue();
            this.txtMaxVideoDuration.setText(String.format(getString(C0421R.string.max_video_length), new Object[]{Integer.valueOf(PreferenceHandler.getInstance(this.settingsTab).getMaxVideoDuration())}));
            this.frequentlyAskedQuestions.setOnClickListener(this);
            this.termeOfUse.setOnClickListener(this);
            this.privacyPolicy.setOnClickListener(this);
            this.rulesOfConduct.setOnClickListener(this);
            this.disclaimer.setOnClickListener(this);
            this.shareApplication.setOnClickListener(this);
            this.logOutBtn.setOnClickListener(this);
            this.changePassowrd.setOnClickListener(this);
            this.geofencesLayout.setOnClickListener(this);
            this.outboxLayout.setOnClickListener(this);
        } catch (InflateException e2) {
        }
        this.mVerifyMobile.setOnClickListener(new C03361());
        this.publicCameraToggle.setOnCheckedChangeListener(new C03372());
        return this.vSettingsPage;
    }

    private void initializeCountDrawer() {
        ArrayList<OutboxSentPostItems> arraylist = new ArrayList();
        arraylist = (ArrayList) new Gson().fromJson(PreferenceHandler.getInstance(this.mContext).getOutBoxSet(), new C03383().getType());
        if (arraylist == null || arraylist.size() <= 0) {
            this.outboxCount.setText(String.valueOf(0));
        } else {
            this.outboxCount.setText(String.valueOf(arraylist.size()));
        }
    }

    public void onClick(View v) {
        int id = v.getId();
        this.url = "";
        String title = null;
        switch (id) {
            case C0421R.C0419id.outbox_layout /*2131689996*/:
                startActivity(new Intent(this.settingsTab, OutboxScreen.class));
                break;
            case C0421R.C0419id.geofences_layout /*2131690040*/:
                ((onGoToGeofencePageListener) this.mContext).onGoToGeofencePage();
                break;
            case C0421R.C0419id.share_application /*2131690044*/:
                try {
                    Intent i = new Intent("android.intent.action.SEND");
                    i.setType(HTTP.PLAIN_TEXT_TYPE);
                    i.putExtra("android.intent.extra.SUBJECT", "VizSafe:");
                    i.putExtra("android.intent.extra.TEXT", (getResources().getString(C0421R.string.recommend) + "\n\n") + Constants.SHARE_URL);
                    startActivity(Intent.createChooser(i, getString(C0421R.string.share_app)));
                    break;
                } catch (Exception e) {
                    break;
                }
            case C0421R.C0419id.frequently_asked_question /*2131690045*/:
                this.url = Constants.WEBSITE_URL + "faq";
                title = getResources().getString(C0421R.string.faq);
                break;
            case C0421R.C0419id.terms_of_use /*2131690046*/:
                this.url = Constants.WEBSITE_URL + "terms";
                title = getResources().getString(C0421R.string.terms_of_use);
                break;
            case C0421R.C0419id.privacy_policy /*2131690047*/:
                this.url = Constants.WEBSITE_URL + "privacy";
                title = getResources().getString(C0421R.string.privacy_policy);
                break;
            case C0421R.C0419id.rules_of_conduct /*2131690048*/:
                this.url = Constants.WEBSITE_URL + "rules";
                title = getResources().getString(C0421R.string.rules_of_couduct);
                break;
            case C0421R.C0419id.disclaimer /*2131690049*/:
                this.url = Constants.WEBSITE_URL + "disclaimer";
                title = getResources().getString(C0421R.string.disclaimer);
                break;
            case C0421R.C0419id.logout_action /*2131690050*/:
                if (!CommonMember.isNetworkOnline((ConnectivityManager) this.mContext.getSystemService("connectivity"), this.settingsTab)) {
                    CommonMember.getErrorDialog(getString(C0421R.string.no_internet_access), this.settingsTab).show();
                    break;
                } else {
                    TaskUnregisterDeviceId();
                    break;
                }
            case C0421R.C0419id.change_password /*2131690053*/:
                startActivity(new Intent(this.settingsTab, ChangePasswordScreen.class));
                break;
        }
        if (!this.url.trim().toString().isEmpty()) {
            Intent mIntent = new Intent(getContext(), WebviewLoader.class);
            mIntent.putExtra(HttpHeaders.FROM, "SettingsPage");
            mIntent.putExtra(PlusShare.KEY_CALL_TO_ACTION_URL, this.url);
            mIntent.putExtra(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_TITLE, title);
            startActivity(mIntent);
        }
    }

    private void DoBackgroundProcess(JSONObject mJsonResponse) {
        try {
            int httpCode = mJsonResponse.getInt("httpCode");
            String mMessage = mJsonResponse.getString(GCMClientManager.EXTRA_MESSAGE);
            if (httpCode == 200) {
                String mMobileNumber = null;
                String mAuthyId = null;
                JSONObject mDetail = mJsonResponse.getJSONObject(ProductAction.ACTION_DETAIL);
                if (mDetail.has("mobilenumber")) {
                    mMobileNumber = mDetail.getString("mobilenumber");
                }
                if (mDetail.has("authyid")) {
                    mAuthyId = mDetail.getString("authyid");
                }
                if (mAuthyId == null) {
                    if (getActivity() != null) {
                        this.mVerifyMobile.setText(getResources().getString(C0421R.string.verify_existing_mobile));
                    }
                } else if (mMobileNumber == null) {
                    this.mVerifyMobile.setText(getResources().getString(C0421R.string.verify_existing_mobile));
                } else if (!mMobileNumber.isEmpty()) {
                    this.mVerifyMobile.setEnabled(false);
                    PreferenceHandler.getInstance(this.mContext).setMobileNumber(mMobileNumber);
                    if (isAdded()) {
                        this.mVerifyMobile.setText(String.format(getResources().getString(C0421R.string.verified_mobile), new Object[]{mMobileNumber}));
                    }
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void TaskUnregisterDeviceId() {
        this.mTransparentProgressDialog.show();
        UnregisterDeviceIdApi.getInstance().Callresponse(this.mContext, this.authenticationString, PreferenceHandler.getInstance(this.settingsTab).getRegisterId(), new C03394());
    }

    public void onResume() {
        super.onResume();
        initializeCountDrawer();
        String mMobileNumber = PreferenceHandler.getInstance(this.mContext).getMobileNumber();
        new AsyncTaskSignIn(this, null).execute(new String[0]);
    }
}
