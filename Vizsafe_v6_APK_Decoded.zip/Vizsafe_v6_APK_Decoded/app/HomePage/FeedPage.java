package com.vizsafe.app.HomePage;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.graphics.Bitmap;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.Parcelable;
import android.provider.ContactsContract.Contacts;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.p001v4.app.Fragment;
import android.support.p001v4.content.ContextCompat;
import android.support.p001v4.widget.SwipeRefreshLayout;
import android.support.p001v4.widget.SwipeRefreshLayout.OnRefreshListener;
import android.support.p002v7.widget.LinearLayoutManager;
import android.support.p002v7.widget.RecyclerView;
import android.util.Base64;
import android.util.Log;
import android.view.InflateException;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import com.google.android.gms.analytics.ecommerce.ProductAction;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.plus.PlusOneDummyView;
import com.google.android.gms.plus.PlusShare;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.analytics.FirebaseAnalytics.Param;
import com.google.gson.JsonObject;
import com.vizsafe.app.APIClientMethods.FeedListGeoZoneApi;
import com.vizsafe.app.APIClientMethods.FeedListMoreApi;
import com.vizsafe.app.APIClientMethods.FeedListMyWorldApi;
import com.vizsafe.app.APIClientMethods.FeedListNearByApi;
import com.vizsafe.app.Adapters.FeedListAdapter;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.Channels.ChannelsScreen;
import com.vizsafe.app.Feeds.ReportDetails;
import com.vizsafe.app.POJO.ChannelsListItem;
import com.vizsafe.app.POJO.FeedListItems;
import com.vizsafe.app.POJO.NotesItems;
import com.vizsafe.app.Utils.CommonMember;
import com.vizsafe.app.Utils.PreferenceHandler;
import dmax.dialog.SpotsDialog;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class FeedPage extends Fragment {
    public static final int PICK_CONTACT = 200;
    public static Bitmap assignToContactBitmap = null;
    public static Context feedTab;
    public static FeedPage feedpage;
    public static boolean loadFeedPage = false;
    public static Bundle mBundleRecyclerViewState;
    int FEED_CLEARED = 100;
    private final String KEY_RECYCLER_STATE = "recycler_state";
    private final String LIST_COUNT = "listcount";
    private final String LIST_COUNT1 = "listcount1";
    String MORE_FEED_URL = null;
    private final String STATE_FLAG = "stateflag";
    private FeedListAdapter adapter;
    ArrayList<FeedListItems> arraylist = new ArrayList();
    String authenticationString;
    String channelPictureUrl;
    String email;
    private RecyclerView feedList;
    private boolean firstTime = true;
    private boolean gps_enabled;
    String latitude;
    Parcelable listState;
    String longitude;
    ConnectivityManager mConnectivityManager;
    private boolean mFeedFilterFlag = false;
    private boolean mFeedFilterStateFlag = false;
    private FusedLocationProviderClient mFusedLocationProviderClient;
    JSONObject mJsonResponse;
    private Location mLastLocation;
    private boolean mRestoreFlag = false;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private AlertDialog mTransparentProgressDialog;
    private Menu menu;
    String password;
    int setSelection = 2;
    int setSelection1 = 0;
    int totalFeeds;
    private View vFeedPage;

    /* renamed from: com.vizsafe.app.HomePage.FeedPage$1 */
    class C02941 implements OnRefreshListener {
        C02941() {
        }

        public void onRefresh() {
            if (CommonMember.isNetworkOnline(FeedPage.this.mConnectivityManager, FeedPage.feedTab)) {
                FeedPage.this.firstTime = true;
                FeedPage.this.MORE_FEED_URL = null;
                if (!FeedPage.this.arraylist.isEmpty()) {
                    FeedPage.this.arraylist.clear();
                }
                FeedPage.this.adapter.notifyDataSetChanged();
                FeedPage.this.TaskGetFeed();
                return;
            }
            CommonMember.NetworkStatusAlert(FeedPage.feedTab);
        }
    }

    /* renamed from: com.vizsafe.app.HomePage.FeedPage$2 */
    class C02952 implements OnCompleteListener {
        C02952() {
        }

        public void onComplete(@NonNull Task task) {
            if (task.isSuccessful()) {
                String url;
                Location currentLocation = (Location) task.getResult();
                if (currentLocation != null) {
                    FeedPage.this.longitude = String.valueOf(currentLocation.getLongitude());
                    FeedPage.this.latitude = String.valueOf(currentLocation.getLatitude());
                    FeedPage.this.mLastLocation = currentLocation;
                } else {
                    FeedPage.this.longitude = String.valueOf(ReportPage.GPSLongitudeValue);
                    FeedPage.this.latitude = String.valueOf(ReportPage.GPSLatitudeValue);
                }
                if (PreferenceHandler.getInstance(FeedPage.feedTab).getMyBubbleStatus()) {
                    url = FeedPage.this.latitude + "," + FeedPage.this.longitude + ",10000";
                } else {
                    url = FeedPage.this.latitude + "," + FeedPage.this.longitude + ",10000";
                }
                FeedPage.this.FeedListNearBy(FeedPage.this.authenticationString, "incident?channels=FAVORITE&limit=20&near=" + url);
            }
        }
    }

    /* renamed from: com.vizsafe.app.HomePage.FeedPage$5 */
    class C02985 implements Callback<JsonObject> {
        C02985() {
        }

        public void success(JsonObject responseFeedListMoreApi, Response response) {
            FeedPage.this.mTransparentProgressDialog.dismiss();
            if (responseFeedListMoreApi != null) {
                String mResponse = String.valueOf(responseFeedListMoreApi);
                try {
                    FeedPage.this.mJsonResponse = new JSONObject(mResponse);
                    FeedPage.this.DoBackgroundProcess(FeedPage.this.mJsonResponse);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }

        public void failure(RetrofitError error) {
            FeedPage.this.mTransparentProgressDialog.dismiss();
            error.printStackTrace();
        }
    }

    /* renamed from: com.vizsafe.app.HomePage.FeedPage$6 */
    class C02996 implements Callback<JsonObject> {
        C02996() {
        }

        public void success(JsonObject responseFeedListMyWorldApi, Response response) {
            FeedPage.this.mTransparentProgressDialog.dismiss();
            if (responseFeedListMyWorldApi != null) {
                String mResponse = String.valueOf(responseFeedListMyWorldApi);
                try {
                    FeedPage.this.mJsonResponse = new JSONObject(mResponse);
                    FeedPage.this.DoBackgroundProcess(FeedPage.this.mJsonResponse);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }

        public void failure(RetrofitError error) {
            FeedPage.this.mTransparentProgressDialog.dismiss();
            error.printStackTrace();
        }
    }

    /* renamed from: com.vizsafe.app.HomePage.FeedPage$7 */
    class C03007 implements Callback<JsonObject> {
        C03007() {
        }

        public void success(JsonObject responseFeedListNearByApi, Response response) {
            FeedPage.this.mTransparentProgressDialog.dismiss();
            if (responseFeedListNearByApi != null) {
                String mResponse = String.valueOf(responseFeedListNearByApi);
                try {
                    FeedPage.this.mJsonResponse = new JSONObject(mResponse);
                    FeedPage.this.DoBackgroundProcess(FeedPage.this.mJsonResponse);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }

        public void failure(RetrofitError error) {
            FeedPage.this.mTransparentProgressDialog.dismiss();
            error.printStackTrace();
        }
    }

    /* renamed from: com.vizsafe.app.HomePage.FeedPage$8 */
    class C03018 implements Callback<JsonObject> {
        C03018() {
        }

        public void success(JsonObject responseFeedListGeoZoneApi, Response response) {
            FeedPage.this.mTransparentProgressDialog.dismiss();
            if (responseFeedListGeoZoneApi != null) {
                String mResponse = String.valueOf(responseFeedListGeoZoneApi);
                try {
                    FeedPage.this.mJsonResponse = new JSONObject(mResponse);
                    FeedPage.this.DoBackgroundProcess(FeedPage.this.mJsonResponse);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }

        public void failure(RetrofitError error) {
            FeedPage.this.mTransparentProgressDialog.dismiss();
            error.printStackTrace();
        }
    }

    public static FeedPage newInstance() {
        return new FeedPage();
    }

    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        this.menu = menu;
    }

    public void onPrepareOptionsMenu(Menu menu) {
        super.onPrepareOptionsMenu(menu);
        this.menu = menu;
        if (loadFeedPage) {
            PreferenceHandler.getInstance(feedTab).setListByCountFeed(2);
            PreferenceHandler.getInstance(feedTab).setListByCountFeedState(0);
            if (PreferenceHandler.getInstance(feedTab).getListByCountFeed() == 0) {
                menu.getItem(0).setIcon(ContextCompat.getDrawable(feedTab, C0421R.C0418drawable.my_geo_white));
            } else if (PreferenceHandler.getInstance(feedTab).getListByCountFeed() == 1) {
                menu.getItem(0).setIcon(ContextCompat.getDrawable(feedTab, C0421R.C0418drawable.my_bubble_white));
            } else {
                menu.getItem(0).setIcon(ContextCompat.getDrawable(feedTab, C0421R.C0418drawable.my_world_white));
            }
            if (PreferenceHandler.getInstance(feedTab).getListByCountFeedState() == 0) {
                menu.getItem(1).setIcon(ContextCompat.getDrawable(feedTab, C0421R.C0418drawable.all_pins_white));
            } else if (PreferenceHandler.getInstance(feedTab).getListByCountFeedState() == 1) {
                menu.getItem(1).setIcon(ContextCompat.getDrawable(feedTab, C0421R.C0418drawable.red_marker));
            } else if (PreferenceHandler.getInstance(feedTab).getListByCountFeedState() == 2) {
                menu.getItem(1).setIcon(ContextCompat.getDrawable(feedTab, C0421R.C0418drawable.yellow_marker));
            } else {
                menu.getItem(1).setIcon(ContextCompat.getDrawable(feedTab, C0421R.C0418drawable.green_marker));
            }
            this.mRestoreFlag = false;
            if (CommonMember.isNetworkOnline(this.mConnectivityManager, feedTab)) {
                this.MORE_FEED_URL = null;
                TaskGetFeed();
                return;
            }
            CommonMember.getErrorDialog(getString(C0421R.string.no_internet_access), feedTab).show();
        } else if (mBundleRecyclerViewState != null) {
            this.mRestoreFlag = true;
            this.listState = mBundleRecyclerViewState.getParcelable("recycler_state");
            int listcount = mBundleRecyclerViewState.getInt("listcount");
            int listcount1 = mBundleRecyclerViewState.getInt("listcount1");
            this.mFeedFilterStateFlag = mBundleRecyclerViewState.getBoolean("stateflag");
            PreferenceHandler.getInstance(feedTab).setListByCountFeed(listcount);
            PreferenceHandler.getInstance(feedTab).setListByCountFeedState(listcount1);
            if (PreferenceHandler.getInstance(feedTab).getListByCountFeed() == 0) {
                menu.getItem(0).setIcon(ContextCompat.getDrawable(feedTab, C0421R.C0418drawable.my_geo_white));
            } else if (PreferenceHandler.getInstance(feedTab).getListByCountFeed() == 1) {
                menu.getItem(0).setIcon(ContextCompat.getDrawable(feedTab, C0421R.C0418drawable.my_bubble_white));
            } else {
                menu.getItem(0).setIcon(ContextCompat.getDrawable(feedTab, C0421R.C0418drawable.my_world_white));
            }
            if (PreferenceHandler.getInstance(feedTab).getListByCountFeedState() == 0) {
                menu.getItem(1).setIcon(ContextCompat.getDrawable(feedTab, C0421R.C0418drawable.all_pins_white));
            } else if (PreferenceHandler.getInstance(feedTab).getListByCountFeedState() == 1) {
                menu.getItem(1).setIcon(ContextCompat.getDrawable(feedTab, C0421R.C0418drawable.red_marker));
            } else if (PreferenceHandler.getInstance(feedTab).getListByCountFeedState() == 2) {
                menu.getItem(1).setIcon(ContextCompat.getDrawable(feedTab, C0421R.C0418drawable.yellow_marker));
            } else {
                menu.getItem(1).setIcon(ContextCompat.getDrawable(feedTab, C0421R.C0418drawable.green_marker));
            }
            if (CommonMember.isNetworkOnline(this.mConnectivityManager, feedTab)) {
                this.MORE_FEED_URL = null;
                TaskGetFeed();
                return;
            }
            CommonMember.getErrorDialog(getString(C0421R.string.no_internet_access), feedTab).show();
        } else {
            PreferenceHandler.getInstance(feedTab).setListByCountFeed(2);
            PreferenceHandler.getInstance(feedTab).setListByCountFeedState(0);
            if (PreferenceHandler.getInstance(feedTab).getListByCountFeed() == 0) {
                menu.getItem(0).setIcon(ContextCompat.getDrawable(feedTab, C0421R.C0418drawable.my_geo_white));
            } else if (PreferenceHandler.getInstance(feedTab).getListByCountFeed() == 1) {
                menu.getItem(0).setIcon(ContextCompat.getDrawable(feedTab, C0421R.C0418drawable.my_bubble_white));
            } else {
                menu.getItem(0).setIcon(ContextCompat.getDrawable(feedTab, C0421R.C0418drawable.my_world_white));
            }
            if (PreferenceHandler.getInstance(feedTab).getListByCountFeedState() == 0) {
                menu.getItem(1).setIcon(ContextCompat.getDrawable(feedTab, C0421R.C0418drawable.all_pins_white));
            } else if (PreferenceHandler.getInstance(feedTab).getListByCountFeedState() == 1) {
                menu.getItem(1).setIcon(ContextCompat.getDrawable(feedTab, C0421R.C0418drawable.red_marker));
            } else if (PreferenceHandler.getInstance(feedTab).getListByCountFeedState() == 2) {
                menu.getItem(1).setIcon(ContextCompat.getDrawable(feedTab, C0421R.C0418drawable.yellow_marker));
            } else {
                menu.getItem(1).setIcon(ContextCompat.getDrawable(feedTab, C0421R.C0418drawable.green_marker));
            }
            this.mRestoreFlag = false;
            if (CommonMember.isNetworkOnline(this.mConnectivityManager, feedTab)) {
                TaskGetFeed();
            } else {
                CommonMember.getErrorDialog(getString(C0421R.string.no_internet_access), feedTab).show();
            }
        }
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case C0421R.C0419id.channel_icon /*2131689850*/:
                startActivity(new Intent(feedTab, ChannelsScreen.class));
                return true;
            case C0421R.C0419id.select_feed_list /*2131690091*/:
                ShowFilterMenu();
                return true;
            case C0421R.C0419id.feedstatefilter /*2131690092*/:
                ShowFilterTypeMenu();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (this.vFeedPage != null) {
            ViewGroup parent = (ViewGroup) this.vFeedPage.getParent();
            if (parent != null) {
                parent.removeView(this.vFeedPage);
            }
        }
        try {
            this.vFeedPage = inflater.inflate(C0421R.layout.activity_feed_screen, container, false);
            feedTab = getContext();
        } catch (InflateException e) {
        }
        this.gps_enabled = ((LocationManager) getActivity().getSystemService(Param.LOCATION)).isProviderEnabled("gps");
        this.channelPictureUrl = CommonMember.getURL(feedTab) + "/picture/";
        this.mConnectivityManager = (ConnectivityManager) feedTab.getSystemService("connectivity");
        this.mTransparentProgressDialog = new SpotsDialog(feedTab);
        this.mTransparentProgressDialog.setCanceledOnTouchOutside(false);
        this.mTransparentProgressDialog.setCancelable(false);
        this.feedList = (RecyclerView) this.vFeedPage.findViewById(C0421R.C0419id.feed_list);
        this.feedList.setLayoutManager(new LinearLayoutManager(feedTab));
        this.mSwipeRefreshLayout = (SwipeRefreshLayout) this.vFeedPage.findViewById(C0421R.C0419id.swipeRefreshLayout);
        this.mSwipeRefreshLayout.setColorSchemeResources(C0421R.color.colorPrimary, C0421R.color.colorPrimaryDark, C0421R.color.blue, 17170451);
        this.email = PreferenceHandler.getInstance(feedTab).getUserName();
        this.password = PreferenceHandler.getInstance(feedTab).getPassword();
        this.authenticationString = "Basic " + Base64.encodeToString((this.email + ":" + this.password).getBytes(), 2);
        this.mSwipeRefreshLayout.setOnRefreshListener(new C02941());
        return this.vFeedPage;
    }

    private void TaskGetFeed() {
        this.firstTime = false;
        String mFavorite = "FAVORITE";
        String mLimit = "50";
        String mGeozone = "ALL";
        String mNear = "near";
        LocationManager manager = (LocationManager) feedTab.getSystemService(Param.LOCATION);
        if (ContextCompat.checkSelfPermission(feedTab, "android.permission.ACCESS_FINE_LOCATION") != 0 && ContextCompat.checkSelfPermission(feedTab, "android.permission.ACCESS_COARSE_LOCATION") != 0) {
            return;
        }
        if (this.MORE_FEED_URL != null) {
            if (!this.MORE_FEED_URL.contains("incident?")) {
                this.MORE_FEED_URL = "incident?" + this.MORE_FEED_URL;
            }
            FeedListMore(this.authenticationString, this.MORE_FEED_URL);
        } else if (this.mFeedFilterStateFlag) {
            if (PreferenceHandler.getInstance(feedTab).getListByCountFeedState() == 0) {
                FeedListMyWorld(this.authenticationString, mFavorite, mLimit);
                PreferenceHandler.getInstance(feedTab).setListByCountFeed(2);
                this.menu.getItem(0).setIcon(ContextCompat.getDrawable(feedTab, C0421R.C0418drawable.my_world_white));
            } else if (PreferenceHandler.getInstance(feedTab).getListByCountFeedState() == 1) {
                FeedListGeoZone(this.authenticationString, "incident?channels=FAVORITE&feedstate=open&limit=20");
            } else if (PreferenceHandler.getInstance(feedTab).getListByCountFeedState() == 2) {
                FeedListGeoZone(this.authenticationString, "incident?channels=FAVORITE&feedstate=pending&limit=20");
            } else {
                FeedListGeoZone(this.authenticationString, "incident?channels=FAVORITE&feedstate=clear&limit=20");
            }
        } else if (PreferenceHandler.getInstance(feedTab).getListByCountFeed() == 0) {
            FeedListGeoZone(this.authenticationString, "incident?channels=FAVORITE&limit=20&geozones=ALL");
        } else if (PreferenceHandler.getInstance(feedTab).getListByCountFeed() == 1) {
            try {
                this.mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(getActivity());
                this.mFusedLocationProviderClient.getLastLocation().addOnCompleteListener(new C02952());
            } catch (SecurityException e) {
                Log.e(PlusOneDummyView.TAG, "getDeviceLocation: SecurityException: " + e.getMessage());
            }
        } else {
            FeedListMyWorld(this.authenticationString, mFavorite, mLimit);
        }
    }

    private void ShowFilterTypeMenu() {
        this.mFeedFilterStateFlag = true;
        int listcount = PreferenceHandler.getInstance(feedTab).getListByCountFeed();
        int listcount1 = PreferenceHandler.getInstance(feedTab).getListByCountFeedState();
        mBundleRecyclerViewState = new Bundle();
        this.listState = this.feedList.getLayoutManager().onSaveInstanceState();
        this.listState = null;
        mBundleRecyclerViewState.putParcelable("recycler_state", this.listState);
        mBundleRecyclerViewState.putInt("listcount", listcount);
        mBundleRecyclerViewState.putInt("listcount1", listcount1);
        mBundleRecyclerViewState.putBoolean("stateflag", this.mFeedFilterStateFlag);
        final String[] mapStyles = new String[]{getResources().getString(C0421R.string.all_state), getResources().getString(C0421R.string.open_state), getResources().getString(C0421R.string.pend_state), getResources().getString(C0421R.string.cleared_state)};
        if (PreferenceHandler.getInstance(feedTab).getListByCountFeedState() == 0) {
            this.setSelection1 = 0;
        } else if (PreferenceHandler.getInstance(feedTab).getListByCountFeedState() == 1) {
            this.setSelection1 = 1;
        } else if (PreferenceHandler.getInstance(feedTab).getListByCountFeedState() == 2) {
            this.setSelection1 = 2;
        } else if (PreferenceHandler.getInstance(feedTab).getListByCountFeedState() == 3) {
            this.setSelection1 = 3;
        } else {
            this.setSelection1 = -1;
        }
        Builder mapStyleDialog = new Builder(feedTab);
        mapStyleDialog.setTitle(getResources().getString(C0421R.string.spinner_title_feed_type));
        mapStyleDialog.setCancelable(true);
        mapStyleDialog.setSingleChoiceItems(mapStyles, this.setSelection1, new OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                if (FeedPage.this.getResources().getString(C0421R.string.all_state).equals(mapStyles[which])) {
                    dialog.dismiss();
                    PreferenceHandler.getInstance(FeedPage.feedTab).setListByCountFeedState(0);
                    FeedPage.this.menu.getItem(1).setIcon(ContextCompat.getDrawable(FeedPage.feedTab, C0421R.C0418drawable.all_pins_white));
                    if (CommonMember.isNetworkOnline(FeedPage.this.mConnectivityManager, FeedPage.feedTab)) {
                        FeedPage.this.MORE_FEED_URL = null;
                        FeedPage.this.TaskGetFeed();
                        return;
                    }
                    CommonMember.getErrorDialog(FeedPage.this.getString(C0421R.string.no_internet_access), FeedPage.feedTab).show();
                } else if (FeedPage.this.getResources().getString(C0421R.string.open_state).equals(mapStyles[which])) {
                    dialog.dismiss();
                    PreferenceHandler.getInstance(FeedPage.feedTab).setListByCountFeedState(1);
                    FeedPage.this.menu.getItem(1).setIcon(ContextCompat.getDrawable(FeedPage.feedTab, C0421R.C0418drawable.red_marker));
                    if (CommonMember.isNetworkOnline(FeedPage.this.mConnectivityManager, FeedPage.feedTab)) {
                        FeedPage.this.MORE_FEED_URL = null;
                        FeedPage.this.TaskGetFeed();
                        return;
                    }
                    CommonMember.getErrorDialog(FeedPage.this.getString(C0421R.string.no_internet_access), FeedPage.feedTab).show();
                } else if (FeedPage.this.getResources().getString(C0421R.string.pend_state).equals(mapStyles[which])) {
                    dialog.dismiss();
                    PreferenceHandler.getInstance(FeedPage.feedTab).setListByCountFeedState(2);
                    FeedPage.this.menu.getItem(1).setIcon(ContextCompat.getDrawable(FeedPage.feedTab, C0421R.C0418drawable.yellow_marker));
                    if (CommonMember.isNetworkOnline(FeedPage.this.mConnectivityManager, FeedPage.feedTab)) {
                        FeedPage.this.MORE_FEED_URL = null;
                        FeedPage.this.TaskGetFeed();
                        return;
                    }
                    CommonMember.getErrorDialog(FeedPage.this.getString(C0421R.string.no_internet_access), FeedPage.feedTab).show();
                } else if (FeedPage.this.getResources().getString(C0421R.string.cleared_state).equals(mapStyles[which])) {
                    dialog.dismiss();
                    PreferenceHandler.getInstance(FeedPage.feedTab).setListByCountFeedState(3);
                    FeedPage.this.menu.getItem(1).setIcon(ContextCompat.getDrawable(FeedPage.feedTab, C0421R.C0418drawable.green_marker));
                    if (CommonMember.isNetworkOnline(FeedPage.this.mConnectivityManager, FeedPage.feedTab)) {
                        FeedPage.this.MORE_FEED_URL = null;
                        FeedPage.this.TaskGetFeed();
                        return;
                    }
                    CommonMember.getErrorDialog(FeedPage.this.getString(C0421R.string.no_internet_access), FeedPage.feedTab).show();
                }
            }
        });
        mapStyleDialog.create().show();
    }

    private void ShowFilterMenu() {
        this.mFeedFilterStateFlag = false;
        int listcount = PreferenceHandler.getInstance(feedTab).getListByCountFeed();
        int listcount1 = PreferenceHandler.getInstance(feedTab).getListByCountFeedState();
        if (PreferenceHandler.getInstance(feedTab).getListByCountFeed() == 0) {
            this.menu.getItem(0).setIcon(ContextCompat.getDrawable(feedTab, C0421R.C0418drawable.my_geo_white));
        } else if (PreferenceHandler.getInstance(feedTab).getListByCountFeed() == 1) {
            this.menu.getItem(0).setIcon(ContextCompat.getDrawable(feedTab, C0421R.C0418drawable.my_bubble_white));
        } else {
            this.menu.getItem(0).setIcon(ContextCompat.getDrawable(feedTab, C0421R.C0418drawable.my_world_white));
        }
        mBundleRecyclerViewState = new Bundle();
        this.listState = this.feedList.getLayoutManager().onSaveInstanceState();
        this.listState = null;
        mBundleRecyclerViewState.putParcelable("recycler_state", this.listState);
        mBundleRecyclerViewState.putInt("listcount", listcount);
        mBundleRecyclerViewState.putInt("listcount1", listcount1);
        mBundleRecyclerViewState.putBoolean("stateflag", this.mFeedFilterStateFlag);
        final String[] mapStyles = new String[]{getResources().getString(C0421R.string.my_geo), getResources().getString(C0421R.string.my_bubble), getResources().getString(C0421R.string.my_world)};
        if (PreferenceHandler.getInstance(feedTab).getListByCountFeed() == 0) {
            this.setSelection = 0;
        } else if (PreferenceHandler.getInstance(feedTab).getListByCountFeed() == 1) {
            this.setSelection = 1;
        } else if (PreferenceHandler.getInstance(feedTab).getListByCountFeed() == 2) {
            this.setSelection = 2;
        } else {
            this.setSelection = -1;
        }
        Builder mapStyleDialog = new Builder(feedTab);
        mapStyleDialog.setTitle(getResources().getString(C0421R.string.spinner_title_feed_type));
        mapStyleDialog.setCancelable(true);
        mapStyleDialog.setSingleChoiceItems(mapStyles, this.setSelection, new OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                if (FeedPage.this.getResources().getString(C0421R.string.my_geo).equals(mapStyles[which])) {
                    dialog.dismiss();
                    PreferenceHandler.getInstance(FeedPage.feedTab).setListByCountFeed(0);
                    FeedPage.this.menu.getItem(0).setIcon(ContextCompat.getDrawable(FeedPage.feedTab, C0421R.C0418drawable.my_geo_white));
                    PreferenceHandler.getInstance(FeedPage.feedTab).setListByCountFeedState(0);
                    FeedPage.this.menu.getItem(1).setIcon(ContextCompat.getDrawable(FeedPage.feedTab, C0421R.C0418drawable.all_pins_white));
                    if (CommonMember.isNetworkOnline(FeedPage.this.mConnectivityManager, FeedPage.feedTab)) {
                        FeedPage.this.MORE_FEED_URL = null;
                        FeedPage.this.TaskGetFeed();
                        return;
                    }
                    CommonMember.getErrorDialog(FeedPage.this.getString(C0421R.string.no_internet_access), FeedPage.feedTab).show();
                } else if (FeedPage.this.getResources().getString(C0421R.string.my_bubble).equals(mapStyles[which])) {
                    dialog.dismiss();
                    PreferenceHandler.getInstance(FeedPage.feedTab).setListByCountFeed(1);
                    FeedPage.this.menu.getItem(0).setIcon(ContextCompat.getDrawable(FeedPage.feedTab, C0421R.C0418drawable.my_bubble_white));
                    PreferenceHandler.getInstance(FeedPage.feedTab).setListByCountFeedState(0);
                    FeedPage.this.menu.getItem(1).setIcon(ContextCompat.getDrawable(FeedPage.feedTab, C0421R.C0418drawable.all_pins_white));
                    if (CommonMember.isNetworkOnline(FeedPage.this.mConnectivityManager, FeedPage.feedTab)) {
                        FeedPage.this.MORE_FEED_URL = null;
                        FeedPage.this.TaskGetFeed();
                        return;
                    }
                    CommonMember.getErrorDialog(FeedPage.this.getString(C0421R.string.no_internet_access), FeedPage.feedTab).show();
                } else if (FeedPage.this.getResources().getString(C0421R.string.my_world).equals(mapStyles[which])) {
                    dialog.dismiss();
                    PreferenceHandler.getInstance(FeedPage.feedTab).setListByCountFeed(2);
                    FeedPage.this.menu.getItem(0).setIcon(ContextCompat.getDrawable(FeedPage.feedTab, C0421R.C0418drawable.my_world_white));
                    PreferenceHandler.getInstance(FeedPage.feedTab).setListByCountFeedState(0);
                    FeedPage.this.menu.getItem(1).setIcon(ContextCompat.getDrawable(FeedPage.feedTab, C0421R.C0418drawable.all_pins_white));
                    if (CommonMember.isNetworkOnline(FeedPage.this.mConnectivityManager, FeedPage.feedTab)) {
                        FeedPage.this.MORE_FEED_URL = null;
                        FeedPage.this.TaskGetFeed();
                        return;
                    }
                    CommonMember.getErrorDialog(FeedPage.this.getString(C0421R.string.no_internet_access), FeedPage.feedTab).show();
                }
            }
        });
        mapStyleDialog.create().show();
    }

    private void DoBackgroundProcess(JSONObject mJsonResponse) throws JSONException {
        this.mSwipeRefreshLayout.setRefreshing(false);
        if (mJsonResponse != null) {
            if (this.MORE_FEED_URL == null && !this.arraylist.isEmpty()) {
                this.arraylist.clear();
            }
            JSONObject mDetail = mJsonResponse.getJSONObject(ProductAction.ACTION_DETAIL);
            this.totalFeeds = mDetail.getInt("total");
            if (this.totalFeeds > 0) {
                JSONArray incidentsArray = mDetail.getJSONArray("incidents");
                if (mDetail.has("more")) {
                    this.MORE_FEED_URL = mDetail.getString("more");
                } else {
                    this.MORE_FEED_URL = null;
                }
                if (incidentsArray != null) {
                    for (int i = 0; i < incidentsArray.length(); i++) {
                        JSONObject feedRatingsObject = null;
                        String feedPostedBy = null;
                        String feedUploadedByUuid = null;
                        String feedLatitude = null;
                        String feedLongitude = null;
                        String feedAbuseOrNot = "false";
                        String incidentState = null;
                        String incidentClearedBy = null;
                        String incidentClearedTimeStamp = null;
                        String severityLevel = "0";
                        int communityid = 0;
                        int drawingid = 0;
                        int levelid = 0;
                        feedAbuseOrNot = "false";
                        boolean feedRatingByMe = false;
                        int feedRatings = 0;
                        JSONObject singleIncidentObject = incidentsArray.getJSONObject(i);
                        String feedType = singleIncidentObject.getString("type");
                        String feedIcon = singleIncidentObject.getString("uuid");
                        if (singleIncidentObject.has("communityid")) {
                            try {
                                communityid = Integer.parseInt(singleIncidentObject.getString("communityid"));
                            } catch (Exception e) {
                                Log.i("Feed Tab", e.toString());
                            }
                        }
                        if (singleIncidentObject.has("drawingid")) {
                            try {
                                drawingid = singleIncidentObject.getInt("drawingid");
                            } catch (Exception e2) {
                                Log.i("Feed Tab", e2.toString());
                            }
                        }
                        if (singleIncidentObject.has("levelid")) {
                            try {
                                levelid = singleIncidentObject.getInt("levelid");
                            } catch (Exception e22) {
                                Log.i("Feed Tab", e22.toString());
                            }
                        }
                        if (singleIncidentObject.has("severitylevel")) {
                            severityLevel = singleIncidentObject.getString("severitylevel");
                        }
                        if (singleIncidentObject.has("incidentState")) {
                            incidentState = singleIncidentObject.getString("incidentState");
                        }
                        if (singleIncidentObject.has("incidentClearedBy")) {
                            incidentClearedBy = singleIncidentObject.getString("incidentClearedBy");
                        }
                        if (singleIncidentObject.has("incidentClearedTimeStamp")) {
                            incidentClearedTimeStamp = singleIncidentObject.getString("incidentClearedTimeStamp");
                        }
                        String feedDetail = singleIncidentObject.getString(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_DESCRIPTION);
                        if (singleIncidentObject.has("uploadedBy")) {
                            feedUploadedByUuid = singleIncidentObject.getString("uploadedBy");
                        }
                        if (singleIncidentObject.has("uploadedByDisplayName")) {
                            feedPostedBy = singleIncidentObject.getString("uploadedByDisplayName");
                        }
                        if (singleIncidentObject.has("abuseReported")) {
                            feedAbuseOrNot = singleIncidentObject.getString("abuseReported");
                        }
                        String feedUploadedTime = singleIncidentObject.getLong("uploadedTimestamp") + "000";
                        JSONObject feedLocationAndGeoObject = singleIncidentObject.getJSONObject(Param.LOCATION);
                        if (feedLocationAndGeoObject != null) {
                            JSONObject feedLocationObject = feedLocationAndGeoObject.getJSONObject("loc");
                            if (feedLocationObject != null) {
                                feedLatitude = feedLocationObject.getString("lat");
                                feedLongitude = feedLocationObject.getString("lng");
                            }
                        }
                        if (singleIncidentObject.has("ratings")) {
                            try {
                                feedRatingsObject = singleIncidentObject.getJSONObject("ratings");
                            } catch (Exception e222) {
                                e222.printStackTrace();
                            }
                            if (feedRatingsObject != null) {
                                feedRatings = feedRatingsObject.length();
                                if (feedRatingsObject.has(PreferenceHandler.getInstance(feedTab).getUserUUID())) {
                                    feedRatingByMe = true;
                                }
                            }
                        }
                        JSONArray feedChannelsArray = singleIncidentObject.getJSONArray("channels");
                        ArrayList<ChannelsListItem> channelsInFeed = null;
                        if (feedChannelsArray != null) {
                            channelsInFeed = new ArrayList();
                            for (int j = 0; j < feedChannelsArray.length(); j++) {
                                JSONObject feedChannelsObject = feedChannelsArray.getJSONObject(j);
                                boolean channelPrivate = false;
                                boolean channelSecret = false;
                                boolean channelMassaged = false;
                                boolean channelVizsafe = false;
                                String channelUuid = feedChannelsObject.getString("uuid");
                                String channelName = feedChannelsObject.getString("name");
                                String channelDescription = feedChannelsObject.getString(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_DESCRIPTION);
                                String channelOwner = feedChannelsObject.getString("owner");
                                String channelPicture = feedChannelsObject.getString("channelPicture");
                                if (feedChannelsObject.has("owner")) {
                                    channelOwner = feedChannelsObject.getString("owner");
                                }
                                if (feedChannelsObject.has("vizsafeChannel")) {
                                    channelVizsafe = Boolean.parseBoolean(feedChannelsObject.getString("vizsafeChannel"));
                                }
                                if (feedChannelsObject.has("privateChannel")) {
                                    channelPrivate = Boolean.parseBoolean(feedChannelsObject.getString("privateChannel"));
                                }
                                if (feedChannelsObject.has("secretChannel")) {
                                    channelSecret = Boolean.parseBoolean(feedChannelsObject.getString("secretChannel"));
                                }
                                if (feedChannelsObject.has("massaged")) {
                                    channelMassaged = Boolean.parseBoolean(feedChannelsObject.getString("massaged"));
                                }
                                channelsInFeed.add(new ChannelsListItem(channelName, channelDescription, this.channelPictureUrl + channelPicture, channelUuid, channelOwner, channelVizsafe, channelPrivate, channelSecret, channelMassaged));
                            }
                        }
                        JSONObject feedNotesJsonObject = singleIncidentObject.getJSONObject("notes");
                        ArrayList<NotesItems> notesItem = null;
                        if (feedNotesJsonObject.getInt("number") > 0) {
                            notesItem = new ArrayList();
                            JSONArray feedNotesArray = feedNotesJsonObject.getJSONArray("notes");
                            for (int k = 0; k < feedNotesArray.length(); k++) {
                                JSONObject notesDataObject = feedNotesArray.getJSONObject(k);
                                String noteuuid = "null";
                                String noteUploadedBy = notesDataObject.getString("uploadedBy");
                                String noteDescription = notesDataObject.getString(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_DESCRIPTION);
                                long noteUploadedDate = notesDataObject.getLong("uploadedDate");
                                String noteIncidentID = notesDataObject.getString("incidentID");
                                if (notesDataObject.has("noteuuid")) {
                                    noteuuid = notesDataObject.getString("noteuuid");
                                }
                                notesItem.add(new NotesItems(noteUploadedBy, noteDescription, noteUploadedDate, noteIncidentID, noteuuid));
                            }
                        }
                        this.arraylist.add(new FeedListItems(feedType, feedIcon, feedDetail, feedPostedBy, feedUploadedTime, feedUploadedByUuid, channelsInFeed, feedLatitude, feedLongitude, feedAbuseOrNot, feedRatings, feedRatingByMe, incidentState, incidentClearedBy, incidentClearedTimeStamp, notesItem, communityid, drawingid, levelid, severityLevel));
                        this.mFeedFilterFlag = false;
                    }
                }
            } else {
                Toast.makeText(feedTab, getResources().getString(C0421R.string.no_feeds_found), 0).show();
            }
            if (this.arraylist != null) {
                this.adapter = new FeedListAdapter(feedTab, this.arraylist);
                this.feedList.setAdapter(this.adapter);
                if (this.mRestoreFlag) {
                    this.feedList.getLayoutManager().onRestoreInstanceState(this.listState);
                    return;
                }
                return;
            }
            CommonMember.getErrorDialog(getString(C0421R.string.unable_to_load_feed), feedTab).show();
        }
    }

    private void FeedListMore(String authenticationString, String more_feed_url) {
        this.mTransparentProgressDialog.show();
        FeedListMoreApi.getInstance().Callresponse(feedTab, authenticationString, more_feed_url, new C02985());
    }

    private void FeedListMyWorld(String authenticationString, String mFavorite, String mLimit) {
        this.mTransparentProgressDialog.show();
        FeedListMyWorldApi.getInstance().Callresponse(feedTab, authenticationString, mFavorite, mLimit, new C02996());
    }

    private void FeedListNearBy(String authenticationString, String url) {
        this.mTransparentProgressDialog.show();
        FeedListNearByApi.getInstance().Callresponse(feedTab, authenticationString, url, new C03007());
    }

    private void FeedListGeoZone(String authenticationString, String url) {
        this.mTransparentProgressDialog.show();
        FeedListGeoZoneApi.getInstance().Callresponse(feedTab, authenticationString, url, new C03018());
    }

    public static void assignToContact(final Bitmap downloadImageUrl) {
        try {
            new Thread(new Runnable() {
                public void run() {
                    try {
                        FeedPage.assignToContactBitmap = downloadImageUrl;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }).start();
            if (FeedListAdapter.downloadImageDialog == null || !FeedListAdapter.downloadImageDialog.isShowing()) {
                ReportDetails.downloadImageDialog.dismiss();
            } else {
                FeedListAdapter.downloadImageDialog.dismiss();
            }
            feedpage.startActivityForResult(new Intent("android.intent.action.PICK", Contacts.CONTENT_URI), 200);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void onResume() {
        super.onResume();
        if (mBundleRecyclerViewState != null) {
            this.feedList.getLayoutManager().onRestoreInstanceState(mBundleRecyclerViewState.getParcelable("recycler_state"));
        }
    }

    public void onDestroy() {
        super.onDestroy();
    }

    public void onPause() {
        super.onPause();
        this.firstTime = false;
        int listcount = PreferenceHandler.getInstance(feedTab).getListByCountFeed();
        int listcount1 = PreferenceHandler.getInstance(feedTab).getListByCountFeedState();
        mBundleRecyclerViewState = new Bundle();
        this.listState = this.feedList.getLayoutManager().onSaveInstanceState();
        mBundleRecyclerViewState.putParcelable("recycler_state", this.listState);
        mBundleRecyclerViewState.putInt("listcount", listcount);
        mBundleRecyclerViewState.putInt("listcount1", listcount1);
        mBundleRecyclerViewState.putBoolean("stateflag", this.mFeedFilterStateFlag);
    }
}
