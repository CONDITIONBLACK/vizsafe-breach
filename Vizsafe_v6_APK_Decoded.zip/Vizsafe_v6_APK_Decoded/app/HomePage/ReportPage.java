package com.vizsafe.app.HomePage;

import android.annotation.SuppressLint;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender.SendIntentException;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationManager;
import android.media.ExifInterface;
import android.media.MediaMetadataRetriever;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.os.StrictMode.ThreadPolicy.Builder;
import android.provider.DocumentsContract;
import android.provider.MediaStore.Audio;
import android.provider.MediaStore.Images.Media;
import android.provider.MediaStore.Video;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.p001v4.app.Fragment;
import android.support.p001v4.app.FragmentActivity;
import android.support.p001v4.content.ContextCompat;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.analytics.ecommerce.ProductAction;
import com.google.android.gms.cast.framework.media.NotificationOptions;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.zzahn;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResult;
import com.google.android.gms.nearby.messages.Strategy;
import com.google.android.gms.plus.PlusOneDummyView;
import com.google.firebase.analytics.FirebaseAnalytics.Param;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import com.google.gson.JsonObject;
import com.vizsafe.app.APIClientMethods.GetLocationAddressApi;
import com.vizsafe.app.APIClientMethods.GetLocationAddressApi.ResponseGetLocationAddressApi;
import com.vizsafe.app.APIClientMethods.UserTrackingApi;
import com.vizsafe.app.APIClientMethods.UserTrackingPostApi;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.POJO.Incident;
import com.vizsafe.app.PostReportPages.DatePickerScreen;
import com.vizsafe.app.PostReportPages.PostFeedScreen;
import com.vizsafe.app.PostReportPages.SelectLocationScreen;
import com.vizsafe.app.Utils.CommonMember;
import com.vizsafe.app.Utils.PreferenceHandler;
import com.vizsafe.app.Utils.VizsafeGPSTracker;
import com.vizsafe.app.Utils.Webservice;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.json.JSONObject;
import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class ReportPage extends Fragment implements OnClickListener, ConnectionCallbacks, OnConnectionFailedListener {
    public static String ALTITUDE = "Altitude";
    private static final int CALL_PERMISSION_CODE = 123;
    public static final int CAMERA_REQUEST = 102;
    public static String CURRENT_DATE = "current_date";
    public static String CURRENT_TIME = "current_time";
    public static Double FinalAltitudeValue = Double.valueOf(FirebaseRemoteConfig.DEFAULT_VALUE_FOR_DOUBLE);
    public static final int GALLERY_REQUEST = 103;
    public static Double GPSLatitudeValue = null;
    public static Double GPSLongitudeValue = null;
    private static final int INTERVAL = 30000;
    public static String KEY_FOR_POST_FEED = "";
    public static String LATITUDE = "latitude";
    private static final float LOCATION_DISTANCE = 0.0f;
    private static final int LOCATION_INTERVAL = 30000;
    public static String LONGITUDE = "longitude";
    public static int MAX_VIDEO_DURATION = 0;
    public static int MAX_VIDEO_FILE_SIZE = 51200;
    public static String PATH = "";
    static final int REQUEST_LOCATION = 105;
    public static final int REQUEST_VIDEO_CAPTURE = 104;
    public static final int RequestPermissionCode = 101;
    public static boolean TEXT_ONLY = false;
    private static final String TYPE_IMAGE = "photo";
    private static final String TYPE_VIDEO = "video";
    public static int VIDEO_SECONDS;
    public static final Handler handler = new Handler();
    public static double mAltitudeValue;
    public static String userChoosenTask = null;
    private String authStringinBase64;
    private TextView callPolice;
    private TextView callPoliceEmergencyText;
    private LinearLayout cameraRoll;
    String currentDate;
    String currentTime;
    private Uri fileUri;
    ExifInterface getDetailFromGallery = null;
    VizsafeGPSTracker gps;
    private boolean gps_enabled;
    private Incident incident;
    private long lastUpdate;
    String latitudeGoogleMap = null;
    private LocationManager locManager;
    private Location location;
    String longitudeGoogleMap = null;
    private FragmentActivity mActivity;
    private boolean mAlreadyStartedService = false;
    private String mCity;
    private Context mContext;
    private String mCountry;
    private String mCountryNumber = null;
    private String mCountrycode;
    private boolean mFirstTIme = true;
    private FusedLocationProviderClient mFusedLocationProviderClient;
    private GoogleApiClient mGoogleApiClient;
    private JSONObject mJsonResponse;
    private LocationListener[] mLocationListeners;
    private LocationRequest mLocationRequest;
    private String mNumber;
    private String mState;
    private String mUserId;
    private boolean mUserTrackingFlag;
    private String path;
    private String postalCode;
    private PendingResult<LocationSettingsResult> result;
    private SensorManager sensorManager;
    private LinearLayout takePhoto;
    private LinearLayout takeVideo;
    private LinearLayout textOnly;
    private View vReportPage;

    /* renamed from: com.vizsafe.app.HomePage.ReportPage$1 */
    class C03301 implements Runnable {
        C03301() {
        }

        public void run() {
            if (!(!CommonMember.isNetworkOnline((ConnectivityManager) ReportPage.this.mContext.getSystemService("connectivity"), ReportPage.this.mContext) || ReportPage.GPSLatitudeValue == null || ReportPage.GPSLongitudeValue == null || ReportPage.GPSLatitudeValue.doubleValue() == FirebaseRemoteConfig.DEFAULT_VALUE_FOR_DOUBLE || ReportPage.GPSLongitudeValue.doubleValue() == FirebaseRemoteConfig.DEFAULT_VALUE_FOR_DOUBLE)) {
                ReportPage.this.AsyncTaskGetUserTrackingResponse();
            }
            ReportPage.handler.postDelayed(this, NotificationOptions.SKIP_STEP_THIRTY_SECONDS_IN_MS);
        }
    }

    /* renamed from: com.vizsafe.app.HomePage.ReportPage$2 */
    class C03312 implements Callback<JsonObject> {
        C03312() {
        }

        public void success(JsonObject jsonObject, Response response) {
            if (jsonObject != null) {
                try {
                    ReportPage.this.mJsonResponse = new JSONObject(String.valueOf(jsonObject));
                    JSONObject mDetail = ReportPage.this.mJsonResponse.getJSONObject(ProductAction.ACTION_DETAIL);
                    if (mDetail.has("usertracking")) {
                        ReportPage.this.mUserTrackingFlag = Boolean.parseBoolean(mDetail.getString("usertracking"));
                    }
                    if (ReportPage.this.mUserTrackingFlag && ReportPage.GPSLatitudeValue.doubleValue() != FirebaseRemoteConfig.DEFAULT_VALUE_FOR_DOUBLE && ReportPage.GPSLongitudeValue.doubleValue() != FirebaseRemoteConfig.DEFAULT_VALUE_FOR_DOUBLE && CommonMember.isNetworkOnline((ConnectivityManager) ReportPage.this.mContext.getSystemService("connectivity"), ReportPage.this.mContext)) {
                        ReportPage.this.AsyncTaskSendUserTrackingResponse();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        public void failure(RetrofitError error) {
            error.printStackTrace();
        }
    }

    /* renamed from: com.vizsafe.app.HomePage.ReportPage$3 */
    class C03323 implements Callback<JsonObject> {
        C03323() {
        }

        public void success(JsonObject jsonObject, Response response) {
            if (jsonObject != null) {
                try {
                    ReportPage.this.mJsonResponse = new JSONObject(String.valueOf(jsonObject));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        public void failure(RetrofitError error) {
            error.printStackTrace();
        }
    }

    /* renamed from: com.vizsafe.app.HomePage.ReportPage$4 */
    class C03334 implements Callback<ResponseGetLocationAddressApi> {
        C03334() {
        }

        public void success(ResponseGetLocationAddressApi responseGetLocationAddressApi, Response response) {
            if (responseGetLocationAddressApi != null) {
                ReportPage.this.mCountry = responseGetLocationAddressApi.getDetail().getCountry();
                ReportPage.this.mState = responseGetLocationAddressApi.getDetail().getState();
                ReportPage.this.mCity = responseGetLocationAddressApi.getDetail().getCity();
                ReportPage.this.postalCode = responseGetLocationAddressApi.getDetail().getZipcode();
                ReportPage.this.mCountrycode = responseGetLocationAddressApi.getDetail().getCountrycode();
                try {
                    String[] mCountryList = ReportPage.this.getResources().getStringArray(C0421R.array.country_name_array);
                    String[] mCountryNumberList = ReportPage.this.getResources().getStringArray(C0421R.array.country_number_array);
                    for (int count = 0; count < mCountryList.length; count++) {
                        if (mCountryList[count].equalsIgnoreCase(ReportPage.this.mCountry)) {
                            ReportPage.this.mNumber = mCountryNumberList[count];
                            ReportPage.this.mCountryNumber = ReportPage.this.mNumber;
                            ReportPage.this.setCountryNumber(ReportPage.this.mCountryNumber);
                            return;
                        }
                    }
                } catch (Exception e) {
                    e.getStackTrace();
                }
            }
        }

        public void failure(RetrofitError error) {
            error.printStackTrace();
        }
    }

    /* renamed from: com.vizsafe.app.HomePage.ReportPage$5 */
    class C03345 implements ResultCallback<LocationSettingsResult> {
        C03345() {
        }

        public void onResult(LocationSettingsResult result) {
            Status status = result.getStatus();
            switch (status.getStatusCode()) {
                case 0:
                    ReportPage.this.checkPermissions();
                    return;
                case 6:
                    try {
                        status.startResolutionForResult(ReportPage.this.getActivity(), 105);
                        return;
                    } catch (SendIntentException e) {
                        return;
                    }
                default:
                    return;
            }
        }
    }

    /* renamed from: com.vizsafe.app.HomePage.ReportPage$6 */
    class C03356 implements Runnable {
        C03356() {
        }

        public void run() {
            if (CommonMember.isNetworkOnline((ConnectivityManager) ReportPage.this.getActivity().getSystemService("connectivity"), ReportPage.this.getActivity())) {
                ReportPage.this.CallEmergencyNumber();
            } else {
                CommonMember.getErrorDialog(ReportPage.this.getString(C0421R.string.no_internet_access), ReportPage.this.mContext).show();
            }
        }
    }

    private class LocationListener implements android.location.LocationListener {
        Location mLastLocation;

        public LocationListener(String provider) {
            this.mLastLocation = new Location(provider);
        }

        public void onLocationChanged(Location location) {
            this.mLastLocation.set(location);
            if (location != null && ReportPage.this.mFirstTIme) {
                ReportPage.this.mFirstTIme = false;
                ReportPage.GPSLatitudeValue = Double.valueOf(location.getLatitude());
                ReportPage.GPSLongitudeValue = Double.valueOf(location.getLongitude());
                if (!(ReportPage.GPSLatitudeValue.doubleValue() == FirebaseRemoteConfig.DEFAULT_VALUE_FOR_DOUBLE || ReportPage.GPSLongitudeValue.doubleValue() == FirebaseRemoteConfig.DEFAULT_VALUE_FOR_DOUBLE)) {
                    ReportPage.this.GetLocationToAddress(ReportPage.GPSLatitudeValue, ReportPage.GPSLongitudeValue);
                }
                try {
                    ReportPage.mAltitudeValue = Webservice.getElevationFromGoogleMaps(ReportPage.GPSLongitudeValue.doubleValue(), ReportPage.GPSLatitudeValue.doubleValue());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else if (this.mLastLocation != null && ReportPage.this.mFirstTIme) {
                ReportPage.GPSLatitudeValue = Double.valueOf(location.getLatitude());
                ReportPage.GPSLongitudeValue = Double.valueOf(location.getLongitude());
                if (!(ReportPage.GPSLatitudeValue.doubleValue() == FirebaseRemoteConfig.DEFAULT_VALUE_FOR_DOUBLE || ReportPage.GPSLongitudeValue.doubleValue() == FirebaseRemoteConfig.DEFAULT_VALUE_FOR_DOUBLE)) {
                    ReportPage.this.GetLocationToAddress(ReportPage.GPSLatitudeValue, ReportPage.GPSLongitudeValue);
                }
                try {
                    ReportPage.mAltitudeValue = Webservice.getElevationFromGoogleMaps(ReportPage.GPSLongitudeValue.doubleValue(), ReportPage.GPSLatitudeValue.doubleValue());
                } catch (IOException e2) {
                    e2.printStackTrace();
                }
            }
        }

        public void onStatusChanged(String provider, int status, Bundle extras) {
        }

        public void onProviderDisabled(String provider) {
        }

        public void onProviderEnabled(String provider) {
        }
    }

    public static ReportPage newInstance() {
        return new ReportPage();
    }

    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        GetTextOnlyImage();
        CommonMember.GetKeyString();
        this.mUserId = PreferenceHandler.getInstance(getActivity()).getUserUUID();
        String email = PreferenceHandler.getInstance(getActivity()).getUserName();
        this.authStringinBase64 = "Basic " + Base64.encodeToString((email + ":" + PreferenceHandler.getInstance(getActivity()).getPassword()).getBytes(), 2);
        this.takePhoto = (LinearLayout) this.vReportPage.findViewById(C0421R.C0419id.take_photo_layout);
        this.takeVideo = (LinearLayout) this.vReportPage.findViewById(C0421R.C0419id.take_video_layout);
        this.cameraRoll = (LinearLayout) this.vReportPage.findViewById(C0421R.C0419id.camera_roll_layout);
        this.callPolice = (TextView) this.vReportPage.findViewById(C0421R.C0419id.call_police);
        this.textOnly = (LinearLayout) this.vReportPage.findViewById(C0421R.C0419id.text_only_layout);
        this.callPoliceEmergencyText = (TextView) this.vReportPage.findViewById(C0421R.C0419id.textView5);
        this.takePhoto.setOnClickListener(this);
        this.takeVideo.setOnClickListener(this);
        this.cameraRoll.setOnClickListener(this);
        this.textOnly.setOnClickListener(this);
        this.callPolice.setOnClickListener(this);
        this.callPolice.setVisibility(4);
        this.callPoliceEmergencyText.setVisibility(4);
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.clear();
    }

    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        this.vReportPage = inflater.inflate(C0421R.layout.activity_report_screen, container, false);
        this.mContext = getContext();
        this.mActivity = getActivity();
        TEXT_ONLY = false;
        PreferenceHandler.getInstance(getActivity()).setPublicCamraStatus(false);
        PreferenceHandler.getInstance(getActivity()).setProgressLevelMap(66);
        PreferenceHandler.getInstance(getActivity()).setProgressTextMap(getString(C0421R.string.showing_last_tewntyfour_hours));
        PreferenceHandler.getInstance(getActivity()).setFromDuration(Strategy.TTL_SECONDS_MAX);
        if (VERSION.SDK_INT > 8) {
            StrictMode.setThreadPolicy(new Builder().permitAll().build());
        }
        this.locManager = (LocationManager) getActivity().getSystemService(Param.LOCATION);
        this.gps_enabled = this.locManager.isProviderEnabled("gps");
        this.mLocationListeners = new LocationListener[]{new LocationListener("gps"), new LocationListener("network")};
        initializeLocationManager();
        this.mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this.mContext);
        if (this.gps_enabled) {
            GotoCallEmergency();
        } else {
            setUpGClient();
        }
        return this.vReportPage;
    }

    public void UserTracking() {
        handler.postDelayed(new C03301(), NotificationOptions.SKIP_STEP_THIRTY_SECONDS_IN_MS);
    }

    public void AsyncTaskGetUserTrackingResponse() {
        UserTrackingApi.getInstance().Callresponse(this.mContext, this.authStringinBase64, new C03312());
    }

    public void AsyncTaskSendUserTrackingResponse() {
        UserTrackingPostApi.getInstance().Callresponse(this.mContext, this.authStringinBase64, String.valueOf(GPSLatitudeValue), String.valueOf(GPSLongitudeValue), this.mUserId, new C03323());
    }

    private void GetLocationToAddress(Double gpsLatitudeValue, Double gpsLongitudeValue) {
        GetLocationAddressApi.getInstance().Callresponse(getActivity(), gpsLatitudeValue.doubleValue(), gpsLongitudeValue.doubleValue(), new C03334());
    }

    private synchronized void setUpGClient() {
        this.mGoogleApiClient = new GoogleApiClient.Builder(this.mContext).enableAutoManage(this.mActivity, 0, this).addConnectionCallbacks(this).addOnConnectionFailedListener(this).addApi(LocationServices.API).build();
        this.mGoogleApiClient.connect();
    }

    public void onConnected(@Nullable Bundle bundle) {
        this.mLocationRequest = LocationRequest.create();
        this.mLocationRequest.setPriority(100);
        this.mLocationRequest.setInterval(3000);
        this.mLocationRequest.setFastestInterval(5000);
        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder().addLocationRequest(this.mLocationRequest);
        builder.setAlwaysShow(true);
        this.result = LocationServices.SettingsApi.checkLocationSettings(this.mGoogleApiClient, builder.build());
        this.result.setResultCallback(new C03345());
    }

    public void onConnectionSuspended(int i) {
    }

    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
    }

    private void checkPermissions() {
        requestPermissions(new String[]{"android.permission.ACCESS_COARSE_LOCATION", "android.permission.ACCESS_FINE_LOCATION"}, 105);
    }

    @SuppressLint({"StringFormatInvalid"})
    private void setCountryNumber(String mCountryNumber) {
        this.callPolice.setVisibility(0);
        this.callPoliceEmergencyText.setVisibility(0);
        this.callPolice.setText(String.format(getResources().getString(C0421R.string.call_immediately), new Object[]{mCountryNumber}));
    }

    private void GetTextOnlyImage() {
        Bitmap myBitmap = BitmapFactory.decodeResource(getResources(), C0421R.C0418drawable.text_vizsafe_new);
        File directory = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/VizsafeImages");
        directory.mkdirs();
        File yourFile = new File(directory, "TextOnlyImageNew.PNG");
        try {
            FileOutputStream outStream = new FileOutputStream(yourFile);
            myBitmap.compress(CompressFormat.PNG, 100, outStream);
            outStream.flush();
            outStream.close();
            String pathOfFile = yourFile.getPath();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case C0421R.C0419id.take_photo_layout /*2131689758*/:
                TEXT_ONLY = false;
                userChoosenTask = "Take Photo";
                this.fileUri = getOutputMediaFileUri(102);
                cameraIntent();
                return;
            case C0421R.C0419id.take_video_layout /*2131689761*/:
                TEXT_ONLY = false;
                VIDEO_SECONDS = PreferenceHandler.getInstance(getActivity()).getMaxVideoDuration();
                MAX_VIDEO_DURATION = VIDEO_SECONDS * 1000;
                this.fileUri = getOutputMediaFileUri(104);
                userChoosenTask = "Take Video";
                videoIntent();
                return;
            case C0421R.C0419id.camera_roll_layout /*2131689764*/:
                TEXT_ONLY = false;
                VIDEO_SECONDS = PreferenceHandler.getInstance(getActivity()).getMaxVideoDuration();
                MAX_VIDEO_DURATION = VIDEO_SECONDS * 1000;
                userChoosenTask = "Choose from Library";
                galleryIntent();
                return;
            case C0421R.C0419id.text_only_layout /*2131689767*/:
                TEXT_ONLY = true;
                SimpleDateFormat currDate = new SimpleDateFormat("MMM dd, yyyy");
                SimpleDateFormat currTime = new SimpleDateFormat("HH:mm:ss");
                this.currentDate = currDate.format(new Date());
                this.currentTime = currTime.format(new Date());
                userChoosenTask = "text only";
                if (GPSLongitudeValue == null || GPSLatitudeValue == null) {
                    Intent goToSelectLocation = new Intent(getActivity(), SelectLocationScreen.class);
                    goToSelectLocation.putExtra(CURRENT_DATE, this.currentDate);
                    goToSelectLocation.putExtra(CURRENT_TIME, this.currentTime);
                    this.mContext.startActivity(goToSelectLocation);
                    return;
                }
                LATITUDE = String.valueOf(GPSLatitudeValue);
                LONGITUDE = String.valueOf(GPSLongitudeValue);
                Intent mIntent = new Intent(getActivity(), PostFeedScreen.class);
                mIntent.putExtra(LATITUDE, GPSLatitudeValue);
                mIntent.putExtra(LONGITUDE, GPSLongitudeValue);
                mIntent.putExtra(CURRENT_DATE, this.currentDate);
                mIntent.putExtra(CURRENT_TIME, this.currentTime);
                this.mContext.startActivity(mIntent);
                return;
            case C0421R.C0419id.call_police /*2131689771*/:
                if (this.mCountryNumber != null) {
                    Intent callIntent = new Intent("android.intent.action.CALL");
                    callIntent.setData(Uri.parse("tel:" + this.mCountryNumber));
                    startActivity(callIntent);
                    return;
                }
                Toast.makeText(getActivity(), getResources().getString(C0421R.string.unknown_location), 1).show();
                return;
            default:
                return;
        }
    }

    private void CallEmergencyNumber() {
        try {
            Location bestLocation = null;
            for (String provider : this.locManager.getProviders(true)) {
                if (ContextCompat.checkSelfPermission(this.mContext, "android.permission.ACCESS_FINE_LOCATION") == 0 || ContextCompat.checkSelfPermission(this.mContext, "android.permission.ACCESS_COARSE_LOCATION") == 0) {
                    Location currentLocation = this.locManager.getLastKnownLocation(provider);
                    if (currentLocation != null) {
                        GPSLongitudeValue = Double.valueOf(currentLocation.getLongitude());
                        GPSLatitudeValue = Double.valueOf(currentLocation.getLatitude());
                        if (!(GPSLatitudeValue == null || GPSLongitudeValue == null)) {
                            GPSLongitudeValue = Double.valueOf(currentLocation.getLongitude());
                            GPSLatitudeValue = Double.valueOf(currentLocation.getLatitude());
                            if (!CommonMember.isNetworkOnline((ConnectivityManager) getActivity().getSystemService("connectivity"), getActivity())) {
                                CommonMember.NetworkStatusAlert(getActivity());
                            } else if (!(GPSLatitudeValue.doubleValue() == FirebaseRemoteConfig.DEFAULT_VALUE_FOR_DOUBLE || GPSLongitudeValue.doubleValue() == FirebaseRemoteConfig.DEFAULT_VALUE_FOR_DOUBLE || !this.mFirstTIme)) {
                                this.mFirstTIme = false;
                                GetLocationToAddress(GPSLatitudeValue, GPSLongitudeValue);
                            }
                            try {
                                mAltitudeValue = Webservice.getElevationFromGoogleMaps(GPSLongitudeValue.doubleValue(), GPSLatitudeValue.doubleValue());
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                    if (currentLocation != null) {
                        if (bestLocation != null) {
                            if (currentLocation.getAccuracy() >= bestLocation.getAccuracy()) {
                            }
                        }
                        bestLocation = currentLocation;
                    }
                } else {
                    return;
                }
            }
            if (bestLocation == null) {
            }
        } catch (SecurityException e2) {
            Log.e(PlusOneDummyView.TAG, "getDeviceLocation: SecurityException: " + e2.getMessage());
        }
    }

    private void onVideoCaptureResult(Intent data) throws IOException {
        if (data != null) {
            SimpleDateFormat currDate = new SimpleDateFormat("MMM dd, yyyy");
            SimpleDateFormat currTime = new SimpleDateFormat("HH:mm:ss");
            this.currentDate = currDate.format(new Date());
            this.currentTime = currTime.format(new Date());
            if (data.getData() != null) {
                this.fileUri = data.getData();
                this.path = getPath(getActivity(), this.fileUri);
                if (this.path == null) {
                    this.path = this.fileUri.getPath();
                }
                int file_size = Integer.parseInt(String.valueOf(new File(this.path).length() / 1024));
                long timeInmillisec = 0;
                if (this.path.endsWith(".mp4") || this.path.endsWith(".3gp") || this.path.endsWith(".mkv") || this.path.endsWith(".avi")) {
                    MediaMetadataRetriever retriever = new MediaMetadataRetriever();
                    retriever.setDataSource(this.path);
                    timeInmillisec = Long.parseLong(retriever.extractMetadata(9));
                }
                if (file_size > 0 && file_size < MAX_VIDEO_FILE_SIZE && timeInmillisec < ((long) MAX_VIDEO_DURATION)) {
                    createNewIncident(TYPE_VIDEO, this.path);
                    KEY_FOR_POST_FEED = "videofile";
                    PATH = this.path;
                    if (GPSLongitudeValue == null || GPSLatitudeValue == null) {
                        MediaMetadataRetriever dataRetriever = new MediaMetadataRetriever();
                        dataRetriever.setDataSource(PATH);
                        String locationString = dataRetriever.extractMetadata(23);
                        dataRetriever.release();
                        String latitudeString = null;
                        String longitudeString = null;
                        if (locationString != null) {
                            if (locationString.startsWith("+")) {
                                if (locationString.substring(1).contains("+")) {
                                    latitudeString = locationString.substring(1, locationString.lastIndexOf("+"));
                                    longitudeString = locationString.substring(locationString.lastIndexOf("+") + 1);
                                } else {
                                    latitudeString = locationString.substring(1, locationString.lastIndexOf("-"));
                                    longitudeString = locationString.substring(locationString.lastIndexOf("-"));
                                }
                            } else if (locationString.substring(1).contains("+")) {
                                latitudeString = locationString.substring(0, locationString.lastIndexOf("+"));
                                longitudeString = locationString.substring(locationString.lastIndexOf("+") + 1);
                            } else {
                                latitudeString = locationString.substring(0, locationString.lastIndexOf("-"));
                                longitudeString = locationString.substring(locationString.lastIndexOf("-"));
                            }
                            if (!(latitudeString == null || longitudeString == null)) {
                                mAltitudeValue = Webservice.getElevationFromGoogleMaps(Double.parseDouble(longitudeString), Double.parseDouble(latitudeString));
                            }
                        }
                        if (GPSLongitudeValue == null || GPSLatitudeValue == null) {
                            Intent goToSelectLocation = new Intent(getActivity(), SelectLocationScreen.class);
                            goToSelectLocation.putExtra(KEY_FOR_POST_FEED, PATH);
                            goToSelectLocation.putExtra(CURRENT_DATE, this.currentDate);
                            goToSelectLocation.putExtra(CURRENT_TIME, this.currentTime);
                            startActivity(goToSelectLocation);
                            return;
                        }
                        LATITUDE = String.valueOf(GPSLatitudeValue);
                        LONGITUDE = String.valueOf(GPSLongitudeValue);
                        Intent goToPostFeed = new Intent(getActivity(), PostFeedScreen.class);
                        goToPostFeed.putExtra(KEY_FOR_POST_FEED, PATH);
                        goToPostFeed.putExtra(LATITUDE, latitudeString);
                        goToPostFeed.putExtra(LONGITUDE, longitudeString);
                        goToPostFeed.putExtra(ALTITUDE, String.valueOf(FinalAltitudeValue));
                        goToPostFeed.putExtra(CURRENT_DATE, this.currentDate);
                        goToPostFeed.putExtra(CURRENT_TIME, this.currentTime);
                        startActivity(goToPostFeed);
                        return;
                    }
                    LATITUDE = String.valueOf(GPSLatitudeValue);
                    LONGITUDE = String.valueOf(GPSLongitudeValue);
                    Intent intent = new Intent(getActivity(), PostFeedScreen.class);
                    intent.putExtra(KEY_FOR_POST_FEED, PATH);
                    intent.putExtra(LATITUDE, this.latitudeGoogleMap);
                    intent.putExtra(LONGITUDE, this.longitudeGoogleMap);
                    intent.putExtra(ALTITUDE, String.valueOf(FinalAltitudeValue));
                    intent.putExtra(CURRENT_DATE, this.currentDate);
                    intent.putExtra(CURRENT_TIME, this.currentTime);
                    startActivity(intent);
                } else if (file_size == 0) {
                    CommonMember.getErrorDialog(getResources().getString(C0421R.string.media_not_valid), getActivity()).show();
                } else {
                    CommonMember.getErrorDialog(getResources().getString(C0421R.string.file_size_more) + " " + VIDEO_SECONDS + " " + getResources().getString(C0421R.string.seconds_or_less), getActivity()).show();
                }
            }
        }
    }

    private void onSelectFromGalleryResult(Intent data) {
        if (data != null) {
            this.fileUri = data.getData();
            String path = getPath(getActivity(), this.fileUri);
            File filenew = null;
            try {
                filenew = new File(path);
            } catch (NullPointerException e) {
                e.printStackTrace();
            }
            if (filenew != null) {
                String exif = "Exif: " + path;
                ExifInterface exifInterface = null;
                try {
                    exifInterface = new ExifInterface(path);
                } catch (IOException e2) {
                    e2.printStackTrace();
                } catch (IllegalArgumentException e3) {
                    e3.printStackTrace();
                }
                exif = (((((((((exif + "\nIMAGE_LENGTH: " + exifInterface.getAttribute("ImageLength")) + "\nIMAGE_WIDTH: " + exifInterface.getAttribute("ImageWidth")) + "\n DATETIME: " + exifInterface.getAttribute("DateTime")) + "\n TAG_MAKE: " + exifInterface.getAttribute("Make")) + "\n TAG_MODEL: " + exifInterface.getAttribute("Model")) + "\n TAG_ORIENTATION: " + exifInterface.getAttribute("Orientation")) + "\n TAG_WHITE_BALANCE: " + exifInterface.getAttribute("WhiteBalance")) + "\n TAG_FOCAL_LENGTH: " + exifInterface.getAttribute("FocalLength")) + "\n TAG_FLASH: " + exifInterface.getAttribute("Flash")) + "\nGPS related:";
                float[] LatLong = new float[2];
                if (exifInterface.getLatLong(LatLong)) {
                    String lat = "\n latitude= " + LatLong[0];
                    String longt = "\n longitude= " + LatLong[1];
                } else {
                    exif = exif + "Exif tags are not available!";
                }
                int file_size = Integer.parseInt(String.valueOf(filenew.length() / 1024));
                long timeInmillisec = 0;
                if (path.endsWith(".mp4") || path.endsWith(".3gp") || path.endsWith(".mkv") || path.endsWith(".avi")) {
                    MediaMetadataRetriever retriever = new MediaMetadataRetriever();
                    retriever.setDataSource(path);
                    timeInmillisec = Long.parseLong(retriever.extractMetadata(9));
                }
                if (file_size > 0 && file_size < MAX_VIDEO_FILE_SIZE && timeInmillisec < ((long) MAX_VIDEO_DURATION)) {
                    createNewIncident(TYPE_IMAGE, path);
                    KEY_FOR_POST_FEED = "imagefromsdcard";
                    PATH = path;
                    String latitude = null;
                    String longitude = null;
                    String dateStr = null;
                    String timeStr = null;
                    try {
                        this.getDetailFromGallery = new ExifInterface(PATH);
                        if (this.getDetailFromGallery != null) {
                            try {
                                String dateAndTime = this.getDetailFromGallery.getAttribute("DateTime");
                                String attrLATITUDE = this.getDetailFromGallery.getAttribute("GPSLatitude");
                                String attrLATITUDE_REF = this.getDetailFromGallery.getAttribute("GPSLatitudeRef");
                                String attrLONGITUDE = this.getDetailFromGallery.getAttribute("GPSLongitude");
                                String attrLONGITUDE_REF = this.getDetailFromGallery.getAttribute("GPSLongitudeRef");
                                if (!(attrLATITUDE == null || attrLATITUDE_REF == null || attrLONGITUDE == null || attrLONGITUDE_REF == null)) {
                                    if (attrLATITUDE_REF.equals("N")) {
                                        latitude = String.valueOf(convertToDegree(attrLATITUDE));
                                    } else {
                                        latitude = String.valueOf(FirebaseRemoteConfig.DEFAULT_VALUE_FOR_DOUBLE - convertToDegree(attrLATITUDE).doubleValue());
                                    }
                                    if (attrLONGITUDE_REF.equals("E")) {
                                        longitude = String.valueOf(convertToDegree(attrLONGITUDE));
                                    } else {
                                        longitude = String.valueOf(FirebaseRemoteConfig.DEFAULT_VALUE_FOR_DOUBLE - convertToDegree(attrLONGITUDE).doubleValue());
                                    }
                                    if (!(latitude == null || longitude == null)) {
                                        mAltitudeValue = Webservice.getElevationFromGoogleMaps(Double.parseDouble(longitude), Double.parseDouble(latitude));
                                    }
                                }
                                if (dateAndTime != null) {
                                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy:MM:dd HH:mm:ss");
                                    Date date = simpleDateFormat.parse(dateAndTime);
                                    simpleDateFormat.applyPattern("MMM dd, yyyy");
                                    dateStr = simpleDateFormat.format(date);
                                    simpleDateFormat = new SimpleDateFormat("yyyy:MM:dd HH:mm:ss");
                                    Date time = simpleDateFormat.parse(dateAndTime);
                                    simpleDateFormat.applyPattern("HH:mm:ss");
                                    timeStr = simpleDateFormat.format(time);
                                }
                                Intent intent;
                                if (dateAndTime != null && latitude != null && longitude != null && timeStr != null && dateStr != null) {
                                    LATITUDE = String.valueOf(latitude);
                                    LONGITUDE = String.valueOf(longitude);
                                    intent = new Intent(getActivity(), PostFeedScreen.class);
                                    intent.putExtra(KEY_FOR_POST_FEED, PATH);
                                    intent.putExtra(LATITUDE, latitude);
                                    intent.putExtra(LONGITUDE, longitude);
                                    intent.putExtra(ALTITUDE, String.valueOf(FinalAltitudeValue));
                                    intent.putExtra(CURRENT_DATE, dateStr);
                                    intent.putExtra(CURRENT_TIME, timeStr);
                                    startActivity(intent);
                                    return;
                                } else if (dateAndTime == null || timeStr == null || dateStr == null) {
                                    Long dateTime = Long.valueOf(new File(PATH).lastModified());
                                    String date2 = getFormattedDateFromTimestamp(dateTime.longValue());
                                    String time2 = getFormattedTimeFromTimestamp(dateTime.longValue());
                                    if (date2 == null || time2 == null) {
                                        intent = new Intent(getActivity(), DatePickerScreen.class);
                                        intent.putExtra(KEY_FOR_POST_FEED, PATH);
                                        startActivity(intent);
                                        return;
                                    }
                                    intent = new Intent(getActivity(), SelectLocationScreen.class);
                                    intent.putExtra(KEY_FOR_POST_FEED, PATH);
                                    intent.putExtra(CURRENT_DATE, date2);
                                    intent.putExtra(CURRENT_TIME, time2);
                                    startActivity(intent);
                                    return;
                                } else {
                                    intent = new Intent(getActivity(), SelectLocationScreen.class);
                                    intent.putExtra(KEY_FOR_POST_FEED, PATH);
                                    intent.putExtra(CURRENT_DATE, dateStr);
                                    intent.putExtra(CURRENT_TIME, timeStr);
                                    startActivity(intent);
                                    return;
                                }
                            } catch (Exception e4) {
                                e4.printStackTrace();
                                return;
                            }
                        }
                        return;
                    } catch (Exception e42) {
                        e42.printStackTrace();
                        return;
                    }
                } else if (file_size == 0) {
                    CommonMember.getErrorDialog(getResources().getString(C0421R.string.media_not_valid), getActivity()).show();
                    return;
                } else {
                    CommonMember.getErrorDialog(getResources().getString(C0421R.string.file_size_more) + " " + VIDEO_SECONDS + getResources().getString(C0421R.string.seconds_or_less), getActivity()).show();
                    return;
                }
            }
            CommonMember.getErrorDialog(getResources().getString(C0421R.string.media_not_valid), getActivity()).show();
        }
    }

    public static Uri getImageUri(Context inContext, Bitmap inImage) {
        inImage.compress(CompressFormat.JPEG, 100, new ByteArrayOutputStream());
        return Uri.parse(Media.insertImage(inContext.getContentResolver(), inImage, "Title", null));
    }

    private void onCaptureImageResult(Intent data) {
        if (data != null && data.getExtras() != null) {
            this.fileUri = getImageUri(getActivity(), (Bitmap) data.getExtras().get("data"));
            this.path = getPath(getActivity(), this.fileUri);
            if (this.path == null) {
                this.path = this.fileUri.getPath();
            }
            SimpleDateFormat currDate = new SimpleDateFormat("MMM dd, yyyy");
            SimpleDateFormat currTime = new SimpleDateFormat("HH:mm:ss");
            this.currentDate = currDate.format(new Date());
            this.currentTime = currTime.format(new Date());
            createNewIncident(TYPE_IMAGE, this.path);
            KEY_FOR_POST_FEED = "imagepath";
            PATH = this.path;
            if (GPSLongitudeValue == null || GPSLatitudeValue == null) {
                Intent goToSelectLocation = new Intent(getActivity(), SelectLocationScreen.class);
                goToSelectLocation.putExtra(KEY_FOR_POST_FEED, PATH);
                goToSelectLocation.putExtra(CURRENT_DATE, this.currentDate);
                goToSelectLocation.putExtra(CURRENT_TIME, this.currentTime);
                startActivity(goToSelectLocation);
                return;
            }
            LATITUDE = String.valueOf(GPSLatitudeValue);
            LONGITUDE = String.valueOf(GPSLongitudeValue);
            Intent intent = new Intent(getActivity(), PostFeedScreen.class);
            intent.putExtra(KEY_FOR_POST_FEED, PATH);
            intent.putExtra(LATITUDE, GPSLatitudeValue);
            intent.putExtra(LONGITUDE, GPSLongitudeValue);
            intent.putExtra(ALTITUDE, String.valueOf(FinalAltitudeValue));
            intent.putExtra(CURRENT_DATE, this.currentDate);
            intent.putExtra(CURRENT_TIME, this.currentTime);
            startActivity(intent);
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case 102:
                onCaptureImageResult(data);
                return;
            case 103:
                onSelectFromGalleryResult(data);
                return;
            case 104:
                try {
                    onVideoCaptureResult(data);
                    return;
                } catch (IOException e) {
                    e.printStackTrace();
                    return;
                }
            case 105:
                switch (resultCode) {
                    case -1:
                        initializeLocationManager();
                        return;
                    default:
                        return;
                }
            default:
                return;
        }
    }

    private void cameraIntent() {
        Intent picIntent = new Intent("android.media.action.IMAGE_CAPTURE");
        if (picIntent.resolveActivity(getActivity().getPackageManager()) != null) {
            startActivityForResult(picIntent, 102);
        }
    }

    private void videoIntent() {
        Intent takeVideoIntent = new Intent("android.media.action.VIDEO_CAPTURE");
        if (takeVideoIntent.resolveActivity(getActivity().getPackageManager()) != null) {
            takeVideoIntent.putExtra("android.intent.extra.durationLimit", VIDEO_SECONDS);
            takeVideoIntent.putExtra("android.intent.extra.videoQuality", 0);
            takeVideoIntent.putExtra("android.intent.extra.sizeLimit", 20971520);
            startActivityForResult(takeVideoIntent, 104);
        }
    }

    private void galleryIntent() {
        Intent photoPickerIntent = new Intent("android.intent.action.PICK");
        photoPickerIntent.setType("*/*");
        photoPickerIntent.putExtra("android.intent.extra.MIME_TYPES", new String[]{"image/*", "video/*"});
        startActivityForResult(photoPickerIntent, 103);
    }

    private Uri getOutputMediaFileUri(int type) {
        File directory = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/VizsafeImages");
        directory.mkdirs();
        PreferenceHandler.getInstance(getActivity()).setImageName(PreferenceHandler.getInstance(getActivity()).getImageName() + 1);
        return Uri.fromFile(new File(directory, String.format("image%08d.jpeg", new Object[]{Integer.valueOf(photonum)})));
    }

    public static Double convertToDegree(String stringDMS) {
        String[] DMS = stringDMS.split(",", 3);
        String[] stringD = DMS[0].split("/", 2);
        Double FloatD = Double.valueOf(new Double(stringD[0]).doubleValue() / new Double(stringD[1]).doubleValue());
        String[] stringM = DMS[1].split("/", 2);
        Double FloatM = Double.valueOf(new Double(stringM[0]).doubleValue() / new Double(stringM[1]).doubleValue());
        String[] stringS = DMS[2].split("/", 2);
        return new Double((FloatD.doubleValue() + (FloatM.doubleValue() / 60.0d)) + (Double.valueOf(new Double(stringS[0]).doubleValue() / new Double(stringS[1]).doubleValue()).doubleValue() / 3600.0d));
    }

    public static String getPath(Context context, Uri uri) {
        boolean isKitKat;
        if (VERSION.SDK_INT >= 19) {
            isKitKat = true;
        } else {
            isKitKat = false;
        }
        if (VERSION.SDK_INT >= 19) {
            if (isKitKat && DocumentsContract.isDocumentUri(context, uri)) {
                String[] split;
                if (isExternalStorageDocument(uri)) {
                    split = DocumentsContract.getDocumentId(uri).split(":");
                    if ("primary".equalsIgnoreCase(split[0])) {
                        return Environment.getExternalStorageDirectory() + "/" + split[1];
                    }
                } else if (isDownloadsDocument(uri)) {
                    return getDataColumn(context, ContentUris.withAppendedId(Uri.parse("content://downloads/public_downloads"), Long.valueOf(DocumentsContract.getDocumentId(uri)).longValue()), null, null);
                } else if (isMediaDocument(uri)) {
                    String type = DocumentsContract.getDocumentId(uri).split(":")[0];
                    Uri contentUri = null;
                    if ("image".equals(type)) {
                        contentUri = Media.EXTERNAL_CONTENT_URI;
                    } else if (TYPE_VIDEO.equals(type)) {
                        contentUri = Video.Media.EXTERNAL_CONTENT_URI;
                    } else if ("audio".equals(type)) {
                        contentUri = Audio.Media.EXTERNAL_CONTENT_URI;
                    }
                    String selection = "_id=?";
                    return getDataColumn(context, contentUri, "_id=?", new String[]{split[1]});
                }
            } else if (Param.CONTENT.equalsIgnoreCase(uri.getScheme())) {
                return getDataColumn(context, uri, null, null);
            } else {
                if ("file".equalsIgnoreCase(uri.getScheme())) {
                    return uri.getPath();
                }
            }
        }
        return null;
    }

    public static String getDataColumn(Context context, Uri uri, String selection, String[] selectionArgs) {
        Cursor cursor = null;
        String column = "_data";
        try {
            cursor = context.getContentResolver().query(uri, new String[]{"_data"}, selection, selectionArgs, null);
            if (cursor == null || !cursor.moveToFirst()) {
                if (cursor != null) {
                    cursor.close();
                }
                return null;
            }
            String string = cursor.getString(cursor.getColumnIndexOrThrow("_data"));
            return string;
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    public static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    public static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    public static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }

    public static String getFormattedDateFromTimestamp(long timestampInMilliSeconds) {
        Date date = new Date();
        date.setTime(timestampInMilliSeconds);
        return new SimpleDateFormat("MMM dd, yyyy").format(date);
    }

    public static String getFormattedTimeFromTimestamp(long timestampInMilliSeconds) {
        Date date = new Date();
        date.setTime(timestampInMilliSeconds);
        return new SimpleDateFormat("hh:mm:ss").format(date);
    }

    private void createNewIncident(String type, String path) {
        this.incident = Incident.create(type, path);
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        int permissionLocation = ContextCompat.checkSelfPermission(this.mContext, "android.permission.ACCESS_FINE_LOCATION");
        int permissionLocation1 = ContextCompat.checkSelfPermission(this.mContext, "android.permission.ACCESS_COARSE_LOCATION");
        if (permissionLocation == 0) {
            this.gps = new VizsafeGPSTracker(getContext());
            GotoCallEmergency();
        } else if (permissionLocation1 == 0) {
            GotoCallEmergency();
            this.gps = new VizsafeGPSTracker(getContext());
        }
    }

    private void initializeLocationManager() {
        try {
            this.locManager.requestLocationUpdates("network", NotificationOptions.SKIP_STEP_THIRTY_SECONDS_IN_MS, 0.0f, this.mLocationListeners[1]);
        } catch (SecurityException ex) {
            Log.i(PlusOneDummyView.TAG, "fail to request location update, ignore", ex);
        } catch (IllegalArgumentException ex2) {
            Log.d(PlusOneDummyView.TAG, "network provider does not exist, " + ex2.getMessage());
        }
        try {
            this.locManager.requestLocationUpdates("gps", NotificationOptions.SKIP_STEP_THIRTY_SECONDS_IN_MS, 0.0f, this.mLocationListeners[0]);
        } catch (SecurityException ex3) {
            Log.i(PlusOneDummyView.TAG, "fail to request location update, ignore", ex3);
        } catch (IllegalArgumentException ex22) {
            Log.d(PlusOneDummyView.TAG, "gps provider does not exist " + ex22.getMessage());
        }
    }

    private void GotoCallEmergency() {
        if (getActivity() != null) {
            zzahn.runOnUiThread(new C03356());
        }
    }

    public void onPause() {
        super.onPause();
    }

    public void onStop() {
        super.onStop();
    }

    public void onResume() {
        super.onResume();
    }

    public void onDestroy() {
        super.onDestroy();
        if (this.mGoogleApiClient != null) {
            this.mGoogleApiClient.stopAutoManage(getActivity());
            this.mGoogleApiClient.disconnect();
        }
        if (this.locManager != null) {
            for (android.location.LocationListener removeUpdates : this.mLocationListeners) {
                try {
                    this.locManager.removeUpdates(removeUpdates);
                } catch (Exception ex) {
                    Log.i(PlusOneDummyView.TAG, "fail to remove location listners, ignore", ex);
                }
            }
        }
    }
}
