package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.vizsafe.app.Utils.CommonMember;
import retrofit.Callback;
import retrofit.http.Body;
import retrofit.http.Header;
import retrofit.http.POST;

public class PostFeedWebServiceApi {
    private static PostFeedWebServiceApi ourInstance = new PostFeedWebServiceApi();

    public class ResponsePostFeedWebServiceApi {
    }

    public interface myPostFeedWebServiceApi {
        @POST("/incident")
        void myPostFeedWebServiceApi(@Header("Authorization") String str, @Body String str2, Callback<ResponsePostFeedWebServiceApi> callback);
    }

    public static PostFeedWebServiceApi getInstance() {
        return ourInstance;
    }

    private PostFeedWebServiceApi() {
    }

    public void Callresponse(Context context, String authString, String postData, Callback<ResponsePostFeedWebServiceApi> mCallback) {
        ((myPostFeedWebServiceApi) CommonMember.getInstance(context).getApiBuilder().create(myPostFeedWebServiceApi.class)).myPostFeedWebServiceApi(authString, postData, mCallback);
    }
}
