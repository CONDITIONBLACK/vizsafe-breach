package com.vizsafe.app.APIClientMethods;

import com.google.gson.JsonObject;
import com.vizsafe.app.Utils.CommonMember;
import java.util.HashMap;
import java.util.Map;
import retrofit.Callback;
import retrofit.http.POST;
import retrofit.http.Query;

public class SignUpSubmitUserApi {
    private static SignUpSubmitUserApi ourInstance = new SignUpSubmitUserApi();

    public class Detail {
        private Map<String, Object> additionalProperties = new HashMap();
        private String created;
        private String displayname;
        private String email;
        private String maxVideoDuration;
        private String notificationSounds;
        private String superuser;
        private String username;
        private String uuid;

        public String getDisplayname() {
            return this.displayname;
        }

        public void setDisplayname(String displayname) {
            this.displayname = displayname;
        }

        public String getEmail() {
            return this.email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getMaxVideoDuration() {
            return this.maxVideoDuration;
        }

        public void setMaxVideoDuration(String maxVideoDuration) {
            this.maxVideoDuration = maxVideoDuration;
        }

        public String getNotificationSounds() {
            return this.notificationSounds;
        }

        public void setNotificationSounds(String notificationSounds) {
            this.notificationSounds = notificationSounds;
        }

        public String getSuperuser() {
            return this.superuser;
        }

        public void setSuperuser(String superuser) {
            this.superuser = superuser;
        }

        public String getUsername() {
            return this.username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getUuid() {
            return this.uuid;
        }

        public void setUuid(String uuid) {
            this.uuid = uuid;
        }

        public String getCreated() {
            return this.created;
        }

        public void setCreated(String created) {
            this.created = created;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public class ResponseSignUpSubmitUserApi {
        private Map<String, Object> additionalProperties = new HashMap();
        private Detail detail;
        private Integer httpCode;
        private String message;

        public Integer getHttpCode() {
            return this.httpCode;
        }

        public void setHttpCode(Integer httpCode) {
            this.httpCode = httpCode;
        }

        public String getMessage() {
            return this.message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public Detail getDetail() {
            return this.detail;
        }

        public void setDetail(Detail detail) {
            this.detail = detail;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public interface mySignUpSubmitUserApi {
        @POST("/user")
        void mySignUpSubmitUserApi(@Query("displayname") String str, @Query("email") String str2, @Query("password") String str3, @Query("username") String str4, Callback<JsonObject> callback);
    }

    public static SignUpSubmitUserApi getInstance() {
        return ourInstance;
    }

    private SignUpSubmitUserApi() {
    }

    public void Callresponse(String mDisplayname, String mEmail, String mPassword, String Email, Callback<JsonObject> mCallback) {
        ((mySignUpSubmitUserApi) CommonMember.getInstanceZone().getApiBuilder().create(mySignUpSubmitUserApi.class)).mySignUpSubmitUserApi(mDisplayname, mEmail, mPassword, Email, mCallback);
    }
}
