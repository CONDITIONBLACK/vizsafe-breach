package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.vizsafe.app.Utils.CommonMember;
import java.util.HashMap;
import java.util.Map;
import retrofit.Callback;
import retrofit.http.Header;
import retrofit.http.POST;
import retrofit.http.Path;
import retrofit.http.Query;

public class AddNotesApi {
    private static AddNotesApi ourInstance = new AddNotesApi();

    public class Detail {
        private Map<String, Object> additionalProperties = new HashMap();
        private String description;
        private String incidentID;
        private String notesId;
        private String notesuuid;
        private String uploadedBy;
        private Integer uploadedDate;

        public String getNotesUuid() {
            return this.notesuuid;
        }

        public void setNotesUuid(String notesuuid) {
            this.notesuuid = notesuuid;
        }

        public String getIncidentID() {
            return this.incidentID;
        }

        public void setIncidentID(String incidentID) {
            this.incidentID = incidentID;
        }

        public String getDescription() {
            return this.description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public String getUploadedBy() {
            return this.uploadedBy;
        }

        public void setUploadedBy(String uploadedBy) {
            this.uploadedBy = uploadedBy;
        }

        public Integer getUploadedDate() {
            return this.uploadedDate;
        }

        public void setUploadedDate(Integer uploadedDate) {
            this.uploadedDate = uploadedDate;
        }

        public String getNotesId() {
            return this.notesId;
        }

        public void setNotesId(String notesId) {
            this.notesId = notesId;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public class ResponseAddNotesApi {
        private Map<String, Object> additionalProperties = new HashMap();
        private Detail detail;
        private Integer httpCode;
        private String message;

        public Integer getHttpCode() {
            return this.httpCode;
        }

        public void setHttpCode(Integer httpCode) {
            this.httpCode = httpCode;
        }

        public String getMessage() {
            return this.message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public Detail getDetail() {
            return this.detail;
        }

        public void setDetail(Detail detail) {
            this.detail = detail;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public interface myAddNotesApi {
        @POST("/incidents/{data}/AddNotes")
        void myAddNotesApi(@Header("Authorization") String str, @Path("data") String str2, @Query("note") String str3, @Query("iID") String str4, Callback<ResponseAddNotesApi> callback);
    }

    public static AddNotesApi getInstance() {
        return ourInstance;
    }

    private AddNotesApi() {
    }

    public void Callresponse(Context context, String authenticationString, String userUUID, String userNote, String feedUUID, Callback<ResponseAddNotesApi> mCallback) {
        ((myAddNotesApi) CommonMember.getInstance(context).getApiBuilder().create(myAddNotesApi.class)).myAddNotesApi(authenticationString, userUUID, userNote, feedUUID, mCallback);
    }
}
