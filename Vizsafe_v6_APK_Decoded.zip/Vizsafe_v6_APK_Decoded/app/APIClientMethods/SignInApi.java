package com.vizsafe.app.APIClientMethods;

import com.google.gson.JsonObject;
import com.vizsafe.app.Utils.CommonMember;
import java.util.HashMap;
import java.util.Map;
import retrofit.Callback;
import retrofit.http.EncodedPath;
import retrofit.http.GET;
import retrofit.http.Header;

public class SignInApi {
    private static SignInApi ourInstance = new SignInApi();

    public class Detail {
        private Map<String, Object> additionalProperties = new HashMap();
        private String created;
        private String displayname;
        private String email;
        private Integer maxVideoDuration;
        private Boolean notificationSounds;
        private Boolean superuser;
        private String username;
        private String uuid;

        public String getDisplayname() {
            return this.displayname;
        }

        public void setDisplayname(String displayname) {
            this.displayname = displayname;
        }

        public String getEmail() {
            return this.email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public Integer getMaxVideoDuration() {
            return this.maxVideoDuration;
        }

        public void setMaxVideoDuration(Integer maxVideoDuration) {
            this.maxVideoDuration = maxVideoDuration;
        }

        public Boolean getNotificationSounds() {
            return this.notificationSounds;
        }

        public void setNotificationSounds(Boolean notificationSounds) {
            this.notificationSounds = notificationSounds;
        }

        public Boolean getSuperuser() {
            return this.superuser;
        }

        public void setSuperuser(Boolean superuser) {
            this.superuser = superuser;
        }

        public String getUsername() {
            return this.username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getUuid() {
            return this.uuid;
        }

        public void setUuid(String uuid) {
            this.uuid = uuid;
        }

        public String getCreated() {
            return this.created;
        }

        public void setCreated(String created) {
            this.created = created;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public class ResponseSignInApi {
        private Map<String, Object> additionalProperties = new HashMap();
        private Detail detail;
        private Integer httpCode;
        private String message;

        public Integer getHttpCode() {
            return this.httpCode;
        }

        public void setHttpCode(Integer httpCode) {
            this.httpCode = httpCode;
        }

        public String getMessage() {
            return this.message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public Detail getDetail() {
            return this.detail;
        }

        public void setDetail(Detail detail) {
            this.detail = detail;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public interface mySignInApi {
        @GET("/{data}")
        void mySignInApi(@Header("Authorization") String str, @EncodedPath("data") String str2, Callback<JsonObject> callback);
    }

    public static SignInApi getInstance() {
        return ourInstance;
    }

    private SignInApi() {
    }

    public void Callresponse(String authString, String path, Callback<JsonObject> mCallback) {
        ((mySignInApi) CommonMember.getInstanceZone().getApiBuilder().create(mySignInApi.class)).mySignInApi(authString, path, mCallback);
    }
}
