package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.google.gson.JsonObject;
import com.vizsafe.app.Utils.CommonMember;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Header;
import retrofit.http.Query;

public class GetCameraPins {
    private static GetCameraPins ourInstance = new GetCameraPins();

    public interface myGetCameraPinsApi {
        @GET("/camera")
        void myGetCameraPinsApi(@Header("Authorization") String str, @Query("bounds") String str2, @Query("limit") String str3, Callback<JsonObject> callback);
    }

    public static GetCameraPins getInstance() {
        return ourInstance;
    }

    private GetCameraPins() {
    }

    public void Callresponse(Context context, String authenticationString, String mBounds, String mLimit, Callback<JsonObject> mCallback) {
        ((myGetCameraPinsApi) CommonMember.getInstance(context).getApiBuilder().create(myGetCameraPinsApi.class)).myGetCameraPinsApi(authenticationString, mBounds, mLimit, mCallback);
    }
}
