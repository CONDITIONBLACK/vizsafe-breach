package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.vizsafe.app.Utils.CommonMember;
import java.util.HashMap;
import java.util.Map;
import retrofit.Callback;
import retrofit.http.DELETE;
import retrofit.http.Header;
import retrofit.http.Path;

public class LeaveChannelApi {
    private static LeaveChannelApi ourInstance = new LeaveChannelApi();

    public class ResponseLeaveChannelApi {
        private Map<String, Object> additionalProperties = new HashMap();
        private String detail;
        private Integer httpCode;
        private String message;

        public Integer getHttpCode() {
            return this.httpCode;
        }

        public void setHttpCode(Integer httpCode) {
            this.httpCode = httpCode;
        }

        public String getMessage() {
            return this.message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public String getDetail() {
            return this.detail;
        }

        public void setDetail(String detail) {
            this.detail = detail;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public interface myLeaveChannelApi {
        @DELETE("/membership/{data}")
        void myLeaveChannelApi(@Header("Authorization") String str, @Path("data") String str2, Callback<ResponseLeaveChannelApi> callback);
    }

    public static LeaveChannelApi getInstance() {
        return ourInstance;
    }

    private LeaveChannelApi() {
    }

    public void Callresponse(Context context, String authString, String mMemberId, Callback<ResponseLeaveChannelApi> mCallback) {
        ((myLeaveChannelApi) CommonMember.getInstance(context).getApiBuilder().create(myLeaveChannelApi.class)).myLeaveChannelApi(authString, mMemberId, mCallback);
    }
}
