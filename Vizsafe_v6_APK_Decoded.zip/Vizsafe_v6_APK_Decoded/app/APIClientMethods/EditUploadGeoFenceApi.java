package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.vizsafe.app.Utils.CommonMember;
import java.util.HashMap;
import java.util.Map;
import retrofit.Callback;
import retrofit.http.Header;
import retrofit.http.PUT;
import retrofit.http.Path;
import retrofit.http.Query;

public class EditUploadGeoFenceApi {
    private static EditUploadGeoFenceApi ourInstance = new EditUploadGeoFenceApi();

    public class Detail {
        private Map<String, Object> additionalProperties = new HashMap();
        private String country;
        private String countrycode;
        private Location location;
        private Integer locationLevel;
        private String name;
        private String useruuid;
        private String uuid;

        public String getCountrycode() {
            return this.countrycode;
        }

        public void setCountrycode(String countrycode) {
            this.countrycode = countrycode;
        }

        public String getCountry() {
            return this.country;
        }

        public void setCountry(String country) {
            this.country = country;
        }

        public Location getLocation() {
            return this.location;
        }

        public void setLocation(Location location) {
            this.location = location;
        }

        public Integer getLocationLevel() {
            return this.locationLevel;
        }

        public void setLocationLevel(Integer locationLevel) {
            this.locationLevel = locationLevel;
        }

        public String getName() {
            return this.name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getUuid() {
            return this.uuid;
        }

        public void setUuid(String uuid) {
            this.uuid = uuid;
        }

        public String getUseruuid() {
            return this.useruuid;
        }

        public void setUseruuid(String useruuid) {
            this.useruuid = useruuid;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public class Loc {
        private Map<String, Object> additionalProperties = new HashMap();
        private Double lat;
        private Double lng;

        public Double getLat() {
            return this.lat;
        }

        public void setLat(Double lat) {
            this.lat = lat;
        }

        public Double getLng() {
            return this.lng;
        }

        public void setLng(Double lng) {
            this.lng = lng;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public class Location {
        private Map<String, Object> additionalProperties = new HashMap();
        private Loc loc;

        public Loc getLoc() {
            return this.loc;
        }

        public void setLoc(Loc loc) {
            this.loc = loc;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public class ResponseEditUploadGeoFenceApi {
        private Map<String, Object> additionalProperties = new HashMap();
        private Detail detail;
        private Integer httpCode;
        private String message;

        public Integer getHttpCode() {
            return this.httpCode;
        }

        public void setHttpCode(Integer httpCode) {
            this.httpCode = httpCode;
        }

        public String getMessage() {
            return this.message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public Detail getDetail() {
            return this.detail;
        }

        public void setDetail(Detail detail) {
            this.detail = detail;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public interface myAddUploadGeoFenceApi {
        @PUT("/notification/filter/{data}")
        void myAddUploadGeoFenceApi(@Path("data") String str, @Header("Authorization") String str2, @Query("uuid") String str3, @Query("name") String str4, @Query("type") String str5, @Query("latitude") String str6, @Query("longitude") String str7, @Query("locationLevel") String str8, Callback<ResponseEditUploadGeoFenceApi> callback);
    }

    public static EditUploadGeoFenceApi getInstance() {
        return ourInstance;
    }

    private EditUploadGeoFenceApi() {
    }

    public void Callresponse(Context context, String geoFenceUuid, String authString, String mUserUuid, String mLocationText, String mType, String mLatitude, String mLongitude, String mLocationLevel, Callback<ResponseEditUploadGeoFenceApi> mCallback) {
        ((myAddUploadGeoFenceApi) CommonMember.getInstance(context).getApiBuilder().create(myAddUploadGeoFenceApi.class)).myAddUploadGeoFenceApi(geoFenceUuid, authString, mUserUuid, mLocationText, mType, mLatitude, mLongitude, mLocationLevel, mCallback);
    }
}
