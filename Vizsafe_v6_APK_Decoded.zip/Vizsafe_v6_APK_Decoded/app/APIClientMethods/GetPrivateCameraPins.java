package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.google.gson.JsonObject;
import com.vizsafe.app.Utils.CommonMember;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Header;
import retrofit.http.Query;

public class GetPrivateCameraPins {
    private static final GetPrivateCameraPins ourInstance = new GetPrivateCameraPins();

    public interface myGetPrivateCameraPinsApi {
        @GET("/camera")
        void myGetPrivateCameraPinsApi(@Header("Authorization") String str, @Query("bounds") String str2, @Query("limit") String str3, @Query("hidepublic") String str4, Callback<JsonObject> callback);
    }

    public static GetPrivateCameraPins getInstance() {
        return ourInstance;
    }

    private GetPrivateCameraPins() {
    }

    public void Callresponse(Context context, String authString, String mBounds, String mLimit, String favorite, Callback<JsonObject> mCallback) {
        ((myGetPrivateCameraPinsApi) CommonMember.getInstance(context).getApiBuilder().create(myGetPrivateCameraPinsApi.class)).myGetPrivateCameraPinsApi(authString, mBounds, mLimit, favorite, mCallback);
    }
}
