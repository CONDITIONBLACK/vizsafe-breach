package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.vizsafe.app.Utils.CommonMember;
import java.util.HashMap;
import java.util.Map;
import retrofit.Callback;
import retrofit.http.Header;
import retrofit.http.POST;
import retrofit.http.Query;

public class ChangePasswordApi {
    private static ChangePasswordApi ourInstance = new ChangePasswordApi();

    public class Detail {
        private Map<String, Object> additionalProperties = new HashMap();
        private Integer created;
        private String displayname;
        private String email;
        private String password;
        private String username;
        private String uuid;

        public String getPassword() {
            return this.password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public String getEmail() {
            return this.email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getUsername() {
            return this.username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getDisplayname() {
            return this.displayname;
        }

        public void setDisplayname(String displayname) {
            this.displayname = displayname;
        }

        public String getUuid() {
            return this.uuid;
        }

        public void setUuid(String uuid) {
            this.uuid = uuid;
        }

        public Integer getCreated() {
            return this.created;
        }

        public void setCreated(Integer created) {
            this.created = created;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public class ResponseChangePasswordApi {
        private Map<String, Object> additionalProperties = new HashMap();
        private Detail detail;
        private Integer httpCode;
        private String message;

        public Integer getHttpCode() {
            return this.httpCode;
        }

        public void setHttpCode(Integer httpCode) {
            this.httpCode = httpCode;
        }

        public String getMessage() {
            return this.message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public Detail getDetail() {
            return this.detail;
        }

        public void setDetail(Detail detail) {
            this.detail = detail;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public interface myChangePasswordApi {
        @POST("/passwordreset")
        void myChangePasswordApi(@Header("Authorization") String str, @Query("oldpassword") String str2, @Query("newpassword") String str3, Callback<ResponseChangePasswordApi> callback);
    }

    public static ChangePasswordApi getInstance() {
        return ourInstance;
    }

    private ChangePasswordApi() {
    }

    public void Callresponse(Context context, String authString, String oldPassword, String newpassword, Callback<ResponseChangePasswordApi> mCallback) {
        ((myChangePasswordApi) CommonMember.getInstance(context).getApiBuilder().create(myChangePasswordApi.class)).myChangePasswordApi(authString, oldPassword, newpassword, mCallback);
    }
}
