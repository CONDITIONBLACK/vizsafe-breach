package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.vizsafe.app.Utils.CommonMember;
import java.util.HashMap;
import java.util.Map;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;

public class GetLocationAddressApi {
    private static GetLocationAddressApi ourInstance = new GetLocationAddressApi();

    public class Detail {
        private Map<String, Object> additionalProperties = new HashMap();
        private String city;
        private String country;
        private String countrycode;
        private String state;
        private String zipcode;

        public String getCity() {
            return this.city;
        }

        public void setCity(String city) {
            this.city = city;
        }

        public String getState() {
            return this.state;
        }

        public void setState(String state) {
            this.state = state;
        }

        public String getZipcode() {
            return this.zipcode;
        }

        public void setZipcode(String zipcode) {
            this.zipcode = zipcode;
        }

        public String getCountrycode() {
            return this.countrycode;
        }

        public void setCountrycode(String countrycode) {
            this.countrycode = countrycode;
        }

        public String getCountry() {
            return this.country;
        }

        public void setCountry(String country) {
            this.country = country;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public class ResponseGetLocationAddressApi {
        private Map<String, Object> additionalProperties = new HashMap();
        private Detail detail;
        private Integer httpCode;
        private String message;

        public Integer getHttpCode() {
            return this.httpCode;
        }

        public void setHttpCode(Integer httpCode) {
            this.httpCode = httpCode;
        }

        public String getMessage() {
            return this.message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public Detail getDetail() {
            return this.detail;
        }

        public void setDetail(Detail detail) {
            this.detail = detail;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public interface myGetLocationAddressApi {
        @GET("/geocode")
        void myGetLocationAddressApi(@Query("latitude") double d, @Query("longitude") double d2, Callback<ResponseGetLocationAddressApi> callback);
    }

    public static GetLocationAddressApi getInstance() {
        return ourInstance;
    }

    private GetLocationAddressApi() {
    }

    public void Callresponse(Context context, double latitudeValue, double longitudeValue, Callback<ResponseGetLocationAddressApi> mCallback) {
        ((myGetLocationAddressApi) CommonMember.getInstance(context).getApiBuilder().create(myGetLocationAddressApi.class)).myGetLocationAddressApi(latitudeValue, longitudeValue, mCallback);
    }
}
