package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.vizsafe.app.Utils.CommonMember;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Header;
import retrofit.http.Query;

public class FavouriteChannelsApi {
    private static FavouriteChannelsApi ourInstance = new FavouriteChannelsApi();

    public class Channel {
        private Map<String, Object> additionalProperties = new HashMap();
        private String channelPicture;
        private String description;
        private Boolean massaged;
        private String name;
        private String owner;
        private Boolean privateChannel;
        private Boolean secretChannel;
        private Boolean tips;
        private String uuid;
        private Boolean vizsafeChannel;

        public String getName() {
            return this.name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getOwner() {
            return this.owner;
        }

        public void setOwner(String owner) {
            this.owner = owner;
        }

        public String getDescription() {
            return this.description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public String getChannelPicture() {
            return this.channelPicture;
        }

        public void setChannelPicture(String channelPicture) {
            this.channelPicture = channelPicture;
        }

        public String getUuid() {
            return this.uuid;
        }

        public void setUuid(String uuid) {
            this.uuid = uuid;
        }

        public Boolean getMassaged() {
            return this.massaged;
        }

        public void setMassaged(Boolean massaged) {
            this.massaged = massaged;
        }

        public Boolean getPrivateChannel() {
            return this.privateChannel;
        }

        public void setPrivateChannel(Boolean privateChannel) {
            this.privateChannel = privateChannel;
        }

        public Boolean getVizsafeChannel() {
            return this.vizsafeChannel;
        }

        public void setVizsafeChannel(Boolean vizsafeChannel) {
            this.vizsafeChannel = vizsafeChannel;
        }

        public Boolean getSecretChannel() {
            return this.secretChannel;
        }

        public void setSecretChannel(Boolean secretChannel) {
            this.secretChannel = secretChannel;
        }

        public Boolean getTips() {
            return this.tips;
        }

        public void setTips(Boolean tips) {
            this.tips = tips;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public class Detail {
        private Map<String, Object> additionalProperties = new HashMap();
        private List<Channel> channels = new ArrayList();
        private Integer total;

        public Integer getTotal() {
            return this.total;
        }

        public void setTotal(Integer total) {
            this.total = total;
        }

        public List<Channel> getChannels() {
            return this.channels;
        }

        public void setChannels(List<Channel> channels) {
            this.channels = channels;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public class ResponseFavouriteChannelsApi {
        private Map<String, Object> additionalProperties = new HashMap();
        private Detail detail;
        private Integer httpCode;
        private String message;

        public Integer getHttpCode() {
            return this.httpCode;
        }

        public void setHttpCode(Integer httpCode) {
            this.httpCode = httpCode;
        }

        public String getMessage() {
            return this.message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public Detail getDetail() {
            return this.detail;
        }

        public void setDetail(Detail detail) {
            this.detail = detail;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public interface myFavouriteChannelsApi {
        @GET("/membershipTips")
        void myFavouriteChannelsApi(@Header("Authorization") String str, @Query("user") String str2, Callback<ResponseFavouriteChannelsApi> callback);
    }

    public static FavouriteChannelsApi getInstance() {
        return ourInstance;
    }

    private FavouriteChannelsApi() {
    }

    public void Callresponse(Context context, String authString, String favorite, Callback<ResponseFavouriteChannelsApi> mCallback) {
        ((myFavouriteChannelsApi) CommonMember.getInstance(context).getApiBuilder().create(myFavouriteChannelsApi.class)).myFavouriteChannelsApi(authString, favorite, mCallback);
    }
}
