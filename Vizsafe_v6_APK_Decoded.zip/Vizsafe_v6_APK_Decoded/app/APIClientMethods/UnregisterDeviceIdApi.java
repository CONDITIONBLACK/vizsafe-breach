package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.vizsafe.app.Utils.CommonMember;
import java.util.HashMap;
import java.util.Map;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Header;
import retrofit.http.Query;

public class UnregisterDeviceIdApi {
    private static UnregisterDeviceIdApi ourInstance = new UnregisterDeviceIdApi();

    public class Detail {
        private Map<String, Object> additionalProperties = new HashMap();
        private String device_token;

        public String getDevice_token() {
            return this.device_token;
        }

        public void setDevice_token(String device_token) {
            this.device_token = device_token;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public class ResponseUnregisterDeviceIdApi {
        private Map<String, Object> additionalProperties = new HashMap();
        private Detail detail;
        private Integer httpCode;
        private String message;

        public Integer getHttpCode() {
            return this.httpCode;
        }

        public void setHttpCode(Integer httpCode) {
            this.httpCode = httpCode;
        }

        public String getMessage() {
            return this.message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public Detail getDetail() {
            return this.detail;
        }

        public void setDetail(Detail detail) {
            this.detail = detail;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public interface myUnregisterDeviceIdApi {
        @GET("/notification/register")
        void myUnregisterDeviceIdApi(@Header("Authorization") String str, @Query("devicetoken") String str2, Callback<ResponseUnregisterDeviceIdApi> callback);
    }

    public static UnregisterDeviceIdApi getInstance() {
        return ourInstance;
    }

    private UnregisterDeviceIdApi() {
    }

    public void Callresponse(Context context, String authString, String registerId, Callback<ResponseUnregisterDeviceIdApi> mCallback) {
        ((myUnregisterDeviceIdApi) CommonMember.getInstance(context).getApiBuilder().create(myUnregisterDeviceIdApi.class)).myUnregisterDeviceIdApi(authString, registerId, mCallback);
    }
}
