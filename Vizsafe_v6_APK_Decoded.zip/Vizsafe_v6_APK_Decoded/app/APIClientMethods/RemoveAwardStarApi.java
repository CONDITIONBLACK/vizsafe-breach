package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.google.gson.JsonObject;
import com.vizsafe.app.Utils.CommonMember;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import retrofit.Callback;
import retrofit.http.DELETE;
import retrofit.http.Header;
import retrofit.http.Path;

public class RemoveAwardStarApi {
    private static RemoveAwardStarApi ourInstance = new RemoveAwardStarApi();

    public class ResponseRemoveAwardStarApi {
        private Map<String, Object> additionalProperties = new HashMap();
        private List<Object> detail = new ArrayList();
        private Integer httpCode;
        private String message;

        public Integer getHttpCode() {
            return this.httpCode;
        }

        public void setHttpCode(Integer httpCode) {
            this.httpCode = httpCode;
        }

        public String getMessage() {
            return this.message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public List<Object> getDetail() {
            return this.detail;
        }

        public void setDetail(List<Object> detail) {
            this.detail = detail;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public interface myAddAwardStarApi {
        @DELETE("/incident/{data}/rating")
        void myAddAwardStarApi(@Header("Authorization") String str, @Path("data") String str2, Callback<JsonObject> callback);
    }

    public static RemoveAwardStarApi getInstance() {
        return ourInstance;
    }

    private RemoveAwardStarApi() {
    }

    public void Callresponse(Context context, String authenticationString, String feedUUID, Callback<JsonObject> mCallback) {
        ((myAddAwardStarApi) CommonMember.getInstance(context).getApiBuilder().create(myAddAwardStarApi.class)).myAddAwardStarApi(authenticationString, feedUUID, mCallback);
    }
}
