package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.vizsafe.app.APIClientMethods.FavouriteChannelsApi.Detail;
import com.vizsafe.app.Utils.CommonMember;
import java.util.HashMap;
import java.util.Map;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Header;

public class AllChannelsApi {
    private static AllChannelsApi ourInstance = new AllChannelsApi();

    public class ResponseAllChannelsApi {
        private Map<String, Object> additionalProperties = new HashMap();
        private Detail detail;
        private Integer httpCode;
        private String message;

        public Integer getHttpCode() {
            return this.httpCode;
        }

        public void setHttpCode(Integer httpCode) {
            this.httpCode = httpCode;
        }

        public String getMessage() {
            return this.message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public Detail getDetail() {
            return this.detail;
        }

        public void setDetail(Detail detail) {
            this.detail = detail;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public interface myAllChannelsApi {
        @GET("/channel")
        void myAllChannelsApi(@Header("Authorization") String str, Callback<ResponseAllChannelsApi> callback);
    }

    public static AllChannelsApi getInstance() {
        return ourInstance;
    }

    private AllChannelsApi() {
    }

    public void Callresponse(Context context, String authString, Callback<ResponseAllChannelsApi> mCallback) {
        ((myAllChannelsApi) CommonMember.getInstance(context).getApiBuilder().create(myAllChannelsApi.class)).myAllChannelsApi(authString, mCallback);
    }
}
