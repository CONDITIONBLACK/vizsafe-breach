package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.google.gson.JsonObject;
import com.vizsafe.app.Utils.CommonMember;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Header;
import retrofit.http.Query;

public class GetIncidentPinsBoundsApi {
    private static GetIncidentPinsBoundsApi ourInstance = new GetIncidentPinsBoundsApi();

    public interface myGetIncidentPinsApi {
        @GET("/incident")
        void myGetIncidentPinsApi(@Header("Authorization") String str, @Query("channels") String str2, @Query("bounds") String str3, @Query("limit") String str4, Callback<JsonObject> callback);
    }

    public static GetIncidentPinsBoundsApi getInstance() {
        return ourInstance;
    }

    private GetIncidentPinsBoundsApi() {
    }

    public void Callresponse(Context context, String authenticationString, String mChannels, String mBounds, String mLimit, Callback<JsonObject> mCallback) {
        ((myGetIncidentPinsApi) CommonMember.getInstance(context).getApiBuilder().create(myGetIncidentPinsApi.class)).myGetIncidentPinsApi(authenticationString, mChannels, mBounds, mLimit, mCallback);
    }
}
