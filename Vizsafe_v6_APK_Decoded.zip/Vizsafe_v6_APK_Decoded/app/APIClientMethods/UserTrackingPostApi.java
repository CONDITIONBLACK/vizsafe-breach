package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.google.gson.JsonObject;
import com.vizsafe.app.Utils.CommonMember;
import retrofit.Callback;
import retrofit.http.Header;
import retrofit.http.POST;
import retrofit.http.Query;

public class UserTrackingPostApi {
    private static UserTrackingPostApi ourInstance = new UserTrackingPostApi();

    public interface myUserTrackingPostApi {
        @POST("/usertracking")
        void myUserTrackingPostApi(@Header("Authorization") String str, @Query("lat") String str2, @Query("long") String str3, @Query("useruuid") String str4, Callback<JsonObject> callback);
    }

    public static UserTrackingPostApi getInstance() {
        return ourInstance;
    }

    private UserTrackingPostApi() {
    }

    public void Callresponse(Context context, String authenticationString, String mLatitude, String mLongitude, String mUserId, Callback<JsonObject> mCallback) {
        ((myUserTrackingPostApi) CommonMember.getInstance(context).getApiBuilder().create(myUserTrackingPostApi.class)).myUserTrackingPostApi(authenticationString, mLatitude, mLongitude, mUserId, mCallback);
    }
}
