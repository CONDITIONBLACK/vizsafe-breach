package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.vizsafe.app.Utils.CommonMember;
import retrofit.Callback;
import retrofit.http.Header;
import retrofit.http.POST;
import retrofit.http.Path;

public class PostFeedApi {
    private static PostFeedApi ourInstance = new PostFeedApi();

    public class ResponsePostFeedApi {
    }

    public interface myPostFeedApi {
        @POST("/incident/{data}")
        void myPostFeedApi(@Path("data") String str, @Header("Authorization") String str2, Callback<ResponsePostFeedApi> callback);
    }

    public static PostFeedApi getInstance() {
        return ourInstance;
    }

    private PostFeedApi() {
    }

    public void Callresponse(Context context, String data, String authString, Callback<ResponsePostFeedApi> mCallback) {
        ((myPostFeedApi) CommonMember.getInstance(context).getApiBuilder().create(myPostFeedApi.class)).myPostFeedApi(data, authString, mCallback);
    }
}
