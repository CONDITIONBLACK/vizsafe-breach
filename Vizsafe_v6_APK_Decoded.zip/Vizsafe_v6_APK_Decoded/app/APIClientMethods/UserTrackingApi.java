package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.google.gson.JsonObject;
import com.vizsafe.app.Utils.CommonMember;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Header;

public class UserTrackingApi {
    private static UserTrackingApi ourInstance = new UserTrackingApi();

    public interface myUserTrackingApi {
        @GET("/usertracking")
        void myUserTrackingApi(@Header("Authorization") String str, Callback<JsonObject> callback);
    }

    public static UserTrackingApi getInstance() {
        return ourInstance;
    }

    private UserTrackingApi() {
    }

    public void Callresponse(Context context, String authenticationString, Callback<JsonObject> mCallback) {
        ((myUserTrackingApi) CommonMember.getInstance(context).getApiBuilder().create(myUserTrackingApi.class)).myUserTrackingApi(authenticationString, mCallback);
    }
}
