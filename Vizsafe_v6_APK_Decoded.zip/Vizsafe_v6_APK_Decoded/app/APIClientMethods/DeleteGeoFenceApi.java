package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.vizsafe.app.Utils.CommonMember;
import java.util.HashMap;
import java.util.Map;
import retrofit.Callback;
import retrofit.http.DELETE;
import retrofit.http.Header;
import retrofit.http.Path;

public class DeleteGeoFenceApi {
    private static DeleteGeoFenceApi ourInstance = new DeleteGeoFenceApi();

    public class ResponseDeleteGeoFenceApi {
        private Map<String, Object> additionalProperties = new HashMap();
        private Object detail;
        private Integer httpCode;
        private String message;

        public Integer getHttpCode() {
            return this.httpCode;
        }

        public void setHttpCode(Integer httpCode) {
            this.httpCode = httpCode;
        }

        public String getMessage() {
            return this.message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public Object getDetail() {
            return this.detail;
        }

        public void setDetail(Object detail) {
            this.detail = detail;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public interface myDeleteGeoFenceApi {
        @DELETE("/notification/filter/{data}")
        void myDeleteGeoFenceApi(@Header("Authorization") String str, @Path("data") String str2, Callback<ResponseDeleteGeoFenceApi> callback);
    }

    public static DeleteGeoFenceApi getInstance() {
        return ourInstance;
    }

    private DeleteGeoFenceApi() {
    }

    public void Callresponse(Context context, String authenticationString, String GeoUUID, Callback<ResponseDeleteGeoFenceApi> mCallback) {
        ((myDeleteGeoFenceApi) CommonMember.getInstance(context).getApiBuilder().create(myDeleteGeoFenceApi.class)).myDeleteGeoFenceApi(authenticationString, GeoUUID, mCallback);
    }
}
