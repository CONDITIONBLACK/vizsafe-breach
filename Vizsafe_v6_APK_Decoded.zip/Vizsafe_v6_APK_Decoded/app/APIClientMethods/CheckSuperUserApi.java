package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.google.gson.annotations.SerializedName;
import com.vizsafe.app.Utils.CommonMember;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import retrofit.Callback;
import retrofit.http.Header;
import retrofit.http.POST;
import retrofit.http.Path;

public class CheckSuperUserApi {
    private static CheckSuperUserApi ourInstance = new CheckSuperUserApi();

    public class ResponseCheckSuperUserApi implements Serializable {
        @SerializedName("super")
        private Integer _super;
        private Map<String, Object> additionalProperties = new HashMap();

        public Integer getSuper() {
            return this._super;
        }

        public void setSuper(Integer _super) {
            this._super = _super;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public interface myCheckSuperUserApi {
        @POST("/user/{uuid}")
        void myCheckSuperUserApi(@Path("uuid") String str, @Header("Authorization") String str2, Callback<ResponseCheckSuperUserApi> callback);
    }

    public static CheckSuperUserApi getInstance() {
        return ourInstance;
    }

    private CheckSuperUserApi() {
    }

    public void Callresponse(Context context, String uuid, String authString, Callback<ResponseCheckSuperUserApi> mCallback) {
        ((myCheckSuperUserApi) CommonMember.getInstance(context).getApiBuilder().create(myCheckSuperUserApi.class)).myCheckSuperUserApi(uuid, authString, mCallback);
    }
}
