package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.google.gson.JsonObject;
import com.vizsafe.app.Utils.CommonMember;
import retrofit.Callback;
import retrofit.http.EncodedPath;
import retrofit.http.GET;
import retrofit.http.Header;

public class FeedListGeoZoneApi {
    private static FeedListGeoZoneApi ourInstance = new FeedListGeoZoneApi();

    public interface myFeedListGeoZoneApi {
        @GET("/{data}")
        void myFeedListGeoZoneApi(@Header("Authorization") String str, @EncodedPath("data") String str2, Callback<JsonObject> callback);
    }

    public static FeedListGeoZoneApi getInstance() {
        return ourInstance;
    }

    private FeedListGeoZoneApi() {
    }

    public void Callresponse(Context context, String authenticationString, String url, Callback<JsonObject> mCallback) {
        ((myFeedListGeoZoneApi) CommonMember.getInstance(context).getApiBuilder().create(myFeedListGeoZoneApi.class)).myFeedListGeoZoneApi(authenticationString, url, mCallback);
    }
}
