package com.vizsafe.app.APIClientMethods;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.vizsafe.app.Utils.CommonMember;
import java.util.HashMap;
import java.util.Map;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;

public class ForgotPasswordApi {
    private static ForgotPasswordApi ourInstance = new ForgotPasswordApi();

    public class Detail {
        @SerializedName("authyid")
        @Expose
        private Integer authyid;
        @SerializedName("countrycode")
        @Expose
        private String countrycode;
        @SerializedName("created")
        @Expose
        private Integer created;
        @SerializedName("displayname")
        @Expose
        private String displayname;
        @SerializedName("email")
        @Expose
        private String email;
        @SerializedName("mobilenumber")
        @Expose
        private String mobilenumber;
        @SerializedName("username")
        @Expose
        private String username;
        @SerializedName("uuid")
        @Expose
        private String uuid;
        @SerializedName("zone")
        @Expose
        private String zone;

        public String getEmail() {
            return this.email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getDisplayname() {
            return this.displayname;
        }

        public void setDisplayname(String displayname) {
            this.displayname = displayname;
        }

        public String getUsername() {
            return this.username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getZone() {
            return this.zone;
        }

        public void setZone(String zone) {
            this.zone = zone;
        }

        public String getMobilenumber() {
            return this.mobilenumber;
        }

        public void setMobilenumber(String mobilenumber) {
            this.mobilenumber = mobilenumber;
        }

        public String getCountrycode() {
            return this.countrycode;
        }

        public void setCountrycode(String countrycode) {
            this.countrycode = countrycode;
        }

        public Integer getAuthyid() {
            return this.authyid;
        }

        public void setAuthyid(Integer authyid) {
            this.authyid = authyid;
        }

        public String getUuid() {
            return this.uuid;
        }

        public void setUuid(String uuid) {
            this.uuid = uuid;
        }

        public Integer getCreated() {
            return this.created;
        }

        public void setCreated(Integer created) {
            this.created = created;
        }
    }

    public class ResponseForgotPasswordApi {
        private Map<String, Object> additionalProperties = new HashMap();
        private Detail detail;
        private Integer httpCode;
        private String message;

        public Integer getHttpCode() {
            return this.httpCode;
        }

        public void setHttpCode(Integer httpCode) {
            this.httpCode = httpCode;
        }

        public String getMessage() {
            return this.message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public Detail getDetail() {
            return this.detail;
        }

        public void setDetail(Detail detail) {
            this.detail = detail;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public interface myForgotPasswordApi {
        @GET("/passwordreset")
        void myForgotPasswordApi(@Query("email") String str, Callback<ResponseForgotPasswordApi> callback);
    }

    public static ForgotPasswordApi getInstance() {
        return ourInstance;
    }

    private ForgotPasswordApi() {
    }

    public void Callresponse(String emailValue, Callback<ResponseForgotPasswordApi> mCallback) {
        ((myForgotPasswordApi) CommonMember.getInstanceZone().getApiBuilder().create(myForgotPasswordApi.class)).myForgotPasswordApi(emailValue, mCallback);
    }
}
