package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.google.gson.JsonObject;
import com.vizsafe.app.Utils.CommonMember;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Header;
import retrofit.http.Query;

public class GetGeoFenceListAPI {
    private static final GetGeoFenceListAPI ourInstance = new GetGeoFenceListAPI();

    public interface myGetGeoFenceListApi {
        @GET("/notification/filter")
        void myGetGeoFenceListApi(@Header("Authorization") String str, @Query("devicetoken") String str2, @Query("useruuid") String str3, Callback<JsonObject> callback);
    }

    public static GetGeoFenceListAPI getInstance() {
        return ourInstance;
    }

    private GetGeoFenceListAPI() {
    }

    public void Callresponse(Context context, String authString, String devicetoken, String useruuid, Callback<JsonObject> mCallback) {
        ((myGetGeoFenceListApi) CommonMember.getInstance(context).getApiBuilder().create(myGetGeoFenceListApi.class)).myGetGeoFenceListApi(authString, devicetoken, useruuid, mCallback);
    }
}
