package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.vizsafe.app.Utils.CommonMember;
import java.util.HashMap;
import java.util.Map;
import retrofit.Callback;
import retrofit.http.FormUrlEncoded;
import retrofit.http.Header;
import retrofit.http.POST;
import retrofit.http.Path;
import retrofit.http.Query;

public class AddNotesWithAttachment {
    private static final AddNotesWithAttachment ourInstance = new AddNotesWithAttachment();

    public class Detail {
        private Map<String, Object> additionalProperties = new HashMap();
        private String description;
        private String incidentID;
        private String notesId;
        private String notesuuid;
        private String uploadedBy;
        private Integer uploadedDate;

        public String getNotesUuid() {
            return this.notesuuid;
        }

        public void setNotesUuid(String notesuuid) {
            this.notesuuid = notesuuid;
        }

        public String getIncidentID() {
            return this.incidentID;
        }

        public void setIncidentID(String incidentID) {
            this.incidentID = incidentID;
        }

        public String getDescription() {
            return this.description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public String getUploadedBy() {
            return this.uploadedBy;
        }

        public void setUploadedBy(String uploadedBy) {
            this.uploadedBy = uploadedBy;
        }

        public Integer getUploadedDate() {
            return this.uploadedDate;
        }

        public void setUploadedDate(Integer uploadedDate) {
            this.uploadedDate = uploadedDate;
        }

        public String getNotesId() {
            return this.notesId;
        }

        public void setNotesId(String notesId) {
            this.notesId = notesId;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public class ResponseAddNotesWithAttachmentApi {
        private Map<String, Object> additionalProperties = new HashMap();
        private Detail detail;
        private Integer httpCode;
        private String message;

        public Integer getHttpCode() {
            return this.httpCode;
        }

        public void setHttpCode(Integer httpCode) {
            this.httpCode = httpCode;
        }

        public String getMessage() {
            return this.message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public Detail getDetail() {
            return this.detail;
        }

        public void setDetail(Detail detail) {
            this.detail = detail;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public interface myAddNotesWithAttachmentApi {
        @FormUrlEncoded
        @POST("/incidents/{data}/AddNotes")
        void myAddNotesWithAttachmentApi(@Header("Authorization") String str, @Path("data") String str2, @Query("note") String str3, @Query("iID") String str4, @Query("noteMedia") String str5, Callback<ResponseAddNotesWithAttachmentApi> callback);
    }

    public static AddNotesWithAttachment getInstance() {
        return ourInstance;
    }

    private AddNotesWithAttachment() {
    }

    public void Callresponse(Context context, String authenticationString, String userUUID, String userNote, String feedUUID, String noteMedia, Callback<ResponseAddNotesWithAttachmentApi> mCallback) {
        ((myAddNotesWithAttachmentApi) CommonMember.getInstance(context).getApiBuilder().create(myAddNotesWithAttachmentApi.class)).myAddNotesWithAttachmentApi(authenticationString, userUUID, userNote, feedUUID, noteMedia, mCallback);
    }
}
