package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.vizsafe.app.Utils.CommonMember;
import java.util.HashMap;
import java.util.Map;
import retrofit.Callback;
import retrofit.http.Header;
import retrofit.http.PUT;
import retrofit.http.Path;
import retrofit.http.Query;

public class AddAwardStarApi {
    private static AddAwardStarApi ourInstance = new AddAwardStarApi();

    public class Detail {
        private Map<String, Object> additionalProperties = new HashMap();
        private String user_569356b7655cb005959463;

        public String getUser_569356b7655cb005959463() {
            return this.user_569356b7655cb005959463;
        }

        public void setUser_569356b7655cb005959463(String user_569356b7655cb005959463) {
            this.user_569356b7655cb005959463 = user_569356b7655cb005959463;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public class ResponseAddAwardStarApi {
        private Map<String, Object> additionalProperties = new HashMap();
        private Detail detail;
        private Integer httpCode;
        private String message;

        public Integer getHttpCode() {
            return this.httpCode;
        }

        public void setHttpCode(Integer httpCode) {
            this.httpCode = httpCode;
        }

        public String getMessage() {
            return this.message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public Detail getDetail() {
            return this.detail;
        }

        public void setDetail(Detail detail) {
            this.detail = detail;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public interface myAddAwardStarApi {
        @PUT("/incident/{data}/rating")
        void myAddAwardStarApi(@Header("Authorization") String str, @Path("data") String str2, @Query("rating") String str3, Callback<ResponseAddAwardStarApi> callback);
    }

    public static AddAwardStarApi getInstance() {
        return ourInstance;
    }

    private AddAwardStarApi() {
    }

    public void Callresponse(Context context, String authenticationString, String feedUUID, String rating, Callback<ResponseAddAwardStarApi> mCallback) {
        ((myAddAwardStarApi) CommonMember.getInstance(context).getApiBuilder().create(myAddAwardStarApi.class)).myAddAwardStarApi(authenticationString, feedUUID, rating, mCallback);
    }
}
