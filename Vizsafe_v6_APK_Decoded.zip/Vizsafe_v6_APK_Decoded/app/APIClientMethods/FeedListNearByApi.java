package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.google.gson.JsonObject;
import com.vizsafe.app.Utils.CommonMember;
import retrofit.Callback;
import retrofit.http.EncodedPath;
import retrofit.http.GET;
import retrofit.http.Header;

public class FeedListNearByApi {
    private static FeedListNearByApi ourInstance = new FeedListNearByApi();

    public interface myFeedListNearByApi {
        @GET("/{data}")
        void myFeedListNearByApi(@Header("Authorization") String str, @EncodedPath("data") String str2, Callback<JsonObject> callback);
    }

    public static FeedListNearByApi getInstance() {
        return ourInstance;
    }

    private FeedListNearByApi() {
    }

    public void Callresponse(Context context, String authenticationString, String mUrl, Callback<JsonObject> mCallback) {
        ((myFeedListNearByApi) CommonMember.getInstance(context).getApiBuilder().create(myFeedListNearByApi.class)).myFeedListNearByApi(authenticationString, mUrl, mCallback);
    }
}
