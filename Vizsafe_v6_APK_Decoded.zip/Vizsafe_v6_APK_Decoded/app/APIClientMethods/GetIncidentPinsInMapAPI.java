package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.vizsafe.app.Utils.CommonMember;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Header;
import retrofit.http.Query;

public class GetIncidentPinsInMapAPI {
    private static GetIncidentPinsInMapAPI ourInstance = new GetIncidentPinsInMapAPI();

    public class Channel {
        /* renamed from: Id */
        private C0186Id f21Id;
        private Boolean _private;
        private Map<String, Object> additionalProperties = new HashMap();
        private String channelPicture;
        private String description;
        private Boolean massaged;
        private String name;
        private String owner;
        private Boolean secret;
        private Boolean tips;
        private String uuid;
        private Boolean vizsafe;

        public C0186Id getId() {
            return this.f21Id;
        }

        public void setId(C0186Id Id) {
            this.f21Id = Id;
        }

        public String getName() {
            return this.name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getOwner() {
            return this.owner;
        }

        public void setOwner(String owner) {
            this.owner = owner;
        }

        public String getDescription() {
            return this.description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public Boolean getPrivate() {
            return this._private;
        }

        public void setPrivate(Boolean _private) {
            this._private = _private;
        }

        public Boolean getVizsafe() {
            return this.vizsafe;
        }

        public void setVizsafe(Boolean vizsafe) {
            this.vizsafe = vizsafe;
        }

        public Boolean getSecret() {
            return this.secret;
        }

        public void setSecret(Boolean secret) {
            this.secret = secret;
        }

        public Boolean getTips() {
            return this.tips;
        }

        public void setTips(Boolean tips) {
            this.tips = tips;
        }

        public String getChannelPicture() {
            return this.channelPicture;
        }

        public void setChannelPicture(String channelPicture) {
            this.channelPicture = channelPicture;
        }

        public String getUuid() {
            return this.uuid;
        }

        public void setUuid(String uuid) {
            this.uuid = uuid;
        }

        public Boolean getMassaged() {
            return this.massaged;
        }

        public void setMassaged(Boolean massaged) {
            this.massaged = massaged;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public class Geocode {
        private Map<String, Object> additionalProperties = new HashMap();
        private String city;
        private String country;
        private String countrycode;
        private String state;
        private String zipcode;

        public String getCity() {
            return this.city;
        }

        public void setCity(String city) {
            this.city = city;
        }

        public String getState() {
            return this.state;
        }

        public void setState(String state) {
            this.state = state;
        }

        public String getZipcode() {
            return this.zipcode;
        }

        public void setZipcode(String zipcode) {
            this.zipcode = zipcode;
        }

        public String getCountrycode() {
            return this.countrycode;
        }

        public void setCountrycode(String countrycode) {
            this.countrycode = countrycode;
        }

        public String getCountry() {
            return this.country;
        }

        public void setCountry(String country) {
            this.country = country;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    /* renamed from: com.vizsafe.app.APIClientMethods.GetIncidentPinsInMapAPI$Id */
    public class C0186Id {
        private String $id;
        private Map<String, Object> additionalProperties = new HashMap();

        public String get$id() {
            return this.$id;
        }

        public void set$id(String $id) {
            this.$id = $id;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public class Id_ {
        private String $id;
        private Map<String, Object> additionalProperties = new HashMap();

        public String get$id() {
            return this.$id;
        }

        public void set$id(String $id) {
            this.$id = $id;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public class Incident {
        private Map<String, Object> additionalProperties = new HashMap();
        private Boolean anonymous;
        private List<Channel> channels = new ArrayList();
        private String description;
        private String format;
        private Integer height;
        private String incidentClearedBy;
        private Integer incidentClearedTimeStamp;
        private String incidentState;
        private String ipaddress;
        private Double latitude;
        private Location location;
        private Double longitude;
        private Boolean massaged;
        private String mediaHash;
        private String metadataHash;
        private Notes notes;
        private Boolean notificationNeeded;
        private Integer orientation;
        private List<Object> ratings = new ArrayList();
        private Integer timestamp;
        private String type;
        private String uploadedByDisplayName;
        private Integer uploadedTimestamp;
        private String uuid;
        private Integer width;

        public String getType() {
            return this.type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public Double getLatitude() {
            return this.latitude;
        }

        public void setLatitude(Double latitude) {
            this.latitude = latitude;
        }

        public Double getLongitude() {
            return this.longitude;
        }

        public void setLongitude(Double longitude) {
            this.longitude = longitude;
        }

        public String getDescription() {
            return this.description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public Integer getTimestamp() {
            return this.timestamp;
        }

        public void setTimestamp(Integer timestamp) {
            this.timestamp = timestamp;
        }

        public Boolean getAnonymous() {
            return this.anonymous;
        }

        public void setAnonymous(Boolean anonymous) {
            this.anonymous = anonymous;
        }

        public List<Channel> getChannels() {
            return this.channels;
        }

        public void setChannels(List<Channel> channels) {
            this.channels = channels;
        }

        public Integer getUploadedTimestamp() {
            return this.uploadedTimestamp;
        }

        public void setUploadedTimestamp(Integer uploadedTimestamp) {
            this.uploadedTimestamp = uploadedTimestamp;
        }

        public String getIncidentState() {
            return this.incidentState;
        }

        public void setIncidentState(String incidentState) {
            this.incidentState = incidentState;
        }

        public String getIpaddress() {
            return this.ipaddress;
        }

        public void setIpaddress(String ipaddress) {
            this.ipaddress = ipaddress;
        }

        public Integer getWidth() {
            return this.width;
        }

        public void setWidth(Integer width) {
            this.width = width;
        }

        public Integer getHeight() {
            return this.height;
        }

        public void setHeight(Integer height) {
            this.height = height;
        }

        public String getFormat() {
            return this.format;
        }

        public void setFormat(String format) {
            this.format = format;
        }

        public Integer getOrientation() {
            return this.orientation;
        }

        public void setOrientation(Integer orientation) {
            this.orientation = orientation;
        }

        public String getUuid() {
            return this.uuid;
        }

        public void setUuid(String uuid) {
            this.uuid = uuid;
        }

        public Location getLocation() {
            return this.location;
        }

        public void setLocation(Location location) {
            this.location = location;
        }

        public String getMediaHash() {
            return this.mediaHash;
        }

        public void setMediaHash(String mediaHash) {
            this.mediaHash = mediaHash;
        }

        public Boolean getNotificationNeeded() {
            return this.notificationNeeded;
        }

        public void setNotificationNeeded(Boolean notificationNeeded) {
            this.notificationNeeded = notificationNeeded;
        }

        public String getMetadataHash() {
            return this.metadataHash;
        }

        public void setMetadataHash(String metadataHash) {
            this.metadataHash = metadataHash;
        }

        public List<Object> getRatings() {
            return this.ratings;
        }

        public void setRatings(List<Object> ratings) {
            this.ratings = ratings;
        }

        public String getIncidentClearedBy() {
            return this.incidentClearedBy;
        }

        public void setIncidentClearedBy(String incidentClearedBy) {
            this.incidentClearedBy = incidentClearedBy;
        }

        public Integer getIncidentClearedTimeStamp() {
            return this.incidentClearedTimeStamp;
        }

        public void setIncidentClearedTimeStamp(Integer incidentClearedTimeStamp) {
            this.incidentClearedTimeStamp = incidentClearedTimeStamp;
        }

        public Boolean getMassaged() {
            return this.massaged;
        }

        public void setMassaged(Boolean massaged) {
            this.massaged = massaged;
        }

        public String getUploadedByDisplayName() {
            return this.uploadedByDisplayName;
        }

        public void setUploadedByDisplayName(String uploadedByDisplayName) {
            this.uploadedByDisplayName = uploadedByDisplayName;
        }

        public Notes getNotes() {
            return this.notes;
        }

        public void setNotes(Notes notes) {
            this.notes = notes;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public class Loc {
        private Map<String, Object> additionalProperties = new HashMap();
        private Double lat;
        private Double lng;

        public Double getLng() {
            return this.lng;
        }

        public void setLng(Double lng) {
            this.lng = lng;
        }

        public Double getLat() {
            return this.lat;
        }

        public void setLat(Double lat) {
            this.lat = lat;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public class Location {
        private Map<String, Object> additionalProperties = new HashMap();
        private Geocode geocode;
        private Loc loc;

        public Loc getLoc() {
            return this.loc;
        }

        public void setLoc(Loc loc) {
            this.loc = loc;
        }

        public Geocode getGeocode() {
            return this.geocode;
        }

        public void setGeocode(Geocode geocode) {
            this.geocode = geocode;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public class Note {
        /* renamed from: Id */
        private Id_ f22Id;
        private Map<String, Object> additionalProperties = new HashMap();
        private String description;
        private String incidentID;
        private String uploadedBy;
        private Integer uploadedDate;

        public Id_ getId() {
            return this.f22Id;
        }

        public void setId(Id_ Id) {
            this.f22Id = Id;
        }

        public String getIncidentID() {
            return this.incidentID;
        }

        public void setIncidentID(String incidentID) {
            this.incidentID = incidentID;
        }

        public String getDescription() {
            return this.description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public String getUploadedBy() {
            return this.uploadedBy;
        }

        public void setUploadedBy(String uploadedBy) {
            this.uploadedBy = uploadedBy;
        }

        public Integer getUploadedDate() {
            return this.uploadedDate;
        }

        public void setUploadedDate(Integer uploadedDate) {
            this.uploadedDate = uploadedDate;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public class Notes {
        private Map<String, Object> additionalProperties = new HashMap();
        private List<Note> notes = new ArrayList();
        private Integer number;

        public Integer getNumber() {
            return this.number;
        }

        public void setNumber(Integer number) {
            this.number = number;
        }

        public List<Note> getNotes() {
            return this.notes;
        }

        public void setNotes(List<Note> notes) {
            this.notes = notes;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public class ResponseGetIncidentPinsInMapAPI {
        private Map<String, Object> additionalProperties = new HashMap();
        private List<Incident> incidents = new ArrayList();
        private Integer total;
        private Integer totalResult;

        public Integer getTotalResult() {
            return this.totalResult;
        }

        public void setTotalResult(Integer totalResult) {
            this.totalResult = totalResult;
        }

        public Integer getTotal() {
            return this.total;
        }

        public void setTotal(Integer total) {
            this.total = total;
        }

        public List<Incident> getIncidents() {
            return this.incidents;
        }

        public void setIncidents(List<Incident> incidents) {
            this.incidents = incidents;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public interface myGetIncidentPinsInMapAPI {
        @GET("/incident")
        void myGetIncidentPinsInMapAPI(@Header("Authorization") String str, @Query("channels") String str2, @Query("bounds") String str3, Callback<ResponseGetIncidentPinsInMapAPI> callback);
    }

    public static GetIncidentPinsInMapAPI getInstance() {
        return ourInstance;
    }

    private GetIncidentPinsInMapAPI() {
    }

    public void Callresponse(Context context, String authString, String FavotiteString, String LocationString, Callback<ResponseGetIncidentPinsInMapAPI> mCallback) {
        ((myGetIncidentPinsInMapAPI) CommonMember.getInstance(context).getApiBuilder().create(myGetIncidentPinsInMapAPI.class)).myGetIncidentPinsInMapAPI(authString, FavotiteString, LocationString, mCallback);
    }
}
