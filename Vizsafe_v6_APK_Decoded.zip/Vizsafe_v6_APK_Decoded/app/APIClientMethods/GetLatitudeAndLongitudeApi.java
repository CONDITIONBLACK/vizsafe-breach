package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.google.gson.JsonObject;
import com.vizsafe.app.Utils.CommonMember;
import retrofit.Callback;
import retrofit.http.POST;
import retrofit.http.Path;

public class GetLatitudeAndLongitudeApi {
    private static GetLatitudeAndLongitudeApi ourInstance = new GetLatitudeAndLongitudeApi();

    public interface myGetLatitudeAndLongitudeApi {
        @POST("/incident/{data}")
        void myGetLatitudeAndLongitudeApi(@Path("data") String str, Callback<JsonObject> callback);
    }

    public static GetLatitudeAndLongitudeApi getInstance() {
        return ourInstance;
    }

    private GetLatitudeAndLongitudeApi() {
    }

    public void Callresponse(Context context, String incidentUuid, Callback<JsonObject> mCallback) {
        ((myGetLatitudeAndLongitudeApi) CommonMember.getInstance(context).getApiBuilder().create(myGetLatitudeAndLongitudeApi.class)).myGetLatitudeAndLongitudeApi(incidentUuid, mCallback);
    }
}
