package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.google.gson.JsonObject;
import com.vizsafe.app.Utils.CommonMember;
import java.util.HashMap;
import java.util.Map;
import retrofit.Callback;
import retrofit.http.Header;
import retrofit.http.POST;
import retrofit.http.Query;

public class JoinChannelApi {
    private static JoinChannelApi ourInstance = new JoinChannelApi();

    public class Detail {
        private Map<String, Object> additionalProperties = new HashMap();
        private String channel;
        private Boolean massaged;
        private String user;
        private String uuid;

        public String getUser() {
            return this.user;
        }

        public void setUser(String user) {
            this.user = user;
        }

        public String getChannel() {
            return this.channel;
        }

        public void setChannel(String channel) {
            this.channel = channel;
        }

        public String getUuid() {
            return this.uuid;
        }

        public void setUuid(String uuid) {
            this.uuid = uuid;
        }

        public Boolean getMassaged() {
            return this.massaged;
        }

        public void setMassaged(Boolean massaged) {
            this.massaged = massaged;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public class ResponseJoinChannelApi {
        private Map<String, Object> additionalProperties = new HashMap();
        private Detail detail;
        private Integer httpCode;
        private String message;

        public Integer getHttpCode() {
            return this.httpCode;
        }

        public void setHttpCode(Integer httpCode) {
            this.httpCode = httpCode;
        }

        public String getMessage() {
            return this.message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public Detail getDetail() {
            return this.detail;
        }

        public void setDetail(Detail detail) {
            this.detail = detail;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public interface myJoinChannelApi {
        @POST("/membership")
        void myJoinChannelApi(@Header("Authorization") String str, @Query("user") String str2, @Query("channel") String str3, Callback<JsonObject> callback);
    }

    public static JoinChannelApi getInstance() {
        return ourInstance;
    }

    private JoinChannelApi() {
    }

    public void Callresponse(Context context, String authString, String mUserUuid, String ChannelId, Callback<JsonObject> mCallback) {
        ((myJoinChannelApi) CommonMember.getInstance(context).getApiBuilder().create(myJoinChannelApi.class)).myJoinChannelApi(authString, mUserUuid, ChannelId, mCallback);
    }
}
