package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.vizsafe.app.Utils.CommonMember;
import java.util.HashMap;
import java.util.Map;
import retrofit.Callback;
import retrofit.http.Header;
import retrofit.http.POST;
import retrofit.http.Query;

public class AddUploadGeoFenceApi {
    private static AddUploadGeoFenceApi ourInstance = new AddUploadGeoFenceApi();

    public class Detail {
        private Map<String, Object> additionalProperties = new HashMap();
        private String city;
        private String country;
        private String countrycode;
        private Location location;
        private Integer locationLevel;
        private String name;
        private String state;
        private String useruuid;
        private String uuid;
        private String zipcode;

        public String getCity() {
            return this.city;
        }

        public void setCity(String city) {
            this.city = city;
        }

        public String getState() {
            return this.state;
        }

        public void setState(String state) {
            this.state = state;
        }

        public String getZipcode() {
            return this.zipcode;
        }

        public void setZipcode(String zipcode) {
            this.zipcode = zipcode;
        }

        public String getCountrycode() {
            return this.countrycode;
        }

        public void setCountrycode(String countrycode) {
            this.countrycode = countrycode;
        }

        public String getCountry() {
            return this.country;
        }

        public void setCountry(String country) {
            this.country = country;
        }

        public Location getLocation() {
            return this.location;
        }

        public void setLocation(Location location) {
            this.location = location;
        }

        public Integer getLocationLevel() {
            return this.locationLevel;
        }

        public void setLocationLevel(Integer locationLevel) {
            this.locationLevel = locationLevel;
        }

        public String getName() {
            return this.name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getUuid() {
            return this.uuid;
        }

        public void setUuid(String uuid) {
            this.uuid = uuid;
        }

        public String getUseruuid() {
            return this.useruuid;
        }

        public void setUseruuid(String useruuid) {
            this.useruuid = useruuid;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public class Loc {
        private Map<String, Object> additionalProperties = new HashMap();
        private Double lat;
        private Double lng;

        public Double getLat() {
            return this.lat;
        }

        public void setLat(Double lat) {
            this.lat = lat;
        }

        public Double getLng() {
            return this.lng;
        }

        public void setLng(Double lng) {
            this.lng = lng;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public class Location {
        private Map<String, Object> additionalProperties = new HashMap();
        private Loc loc;

        public Loc getLoc() {
            return this.loc;
        }

        public void setLoc(Loc loc) {
            this.loc = loc;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public class ResponseAddUploadGeoFenceApi {
        private Map<String, Object> additionalProperties = new HashMap();
        private Detail detail;
        private Integer httpCode;
        private String message;

        public Integer getHttpCode() {
            return this.httpCode;
        }

        public void setHttpCode(Integer httpCode) {
            this.httpCode = httpCode;
        }

        public String getMessage() {
            return this.message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public Detail getDetail() {
            return this.detail;
        }

        public void setDetail(Detail detail) {
            this.detail = detail;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public interface myAddUploadGeoFenceApi {
        @POST("/notification/filter")
        void myAddUploadGeoFenceApi(@Header("Authorization") String str, @Query("uuid") String str2, @Query("name") String str3, @Query("type") String str4, @Query("latitude") String str5, @Query("longitude") String str6, @Query("locationLevel") String str7, Callback<ResponseAddUploadGeoFenceApi> callback);
    }

    public static AddUploadGeoFenceApi getInstance() {
        return ourInstance;
    }

    private AddUploadGeoFenceApi() {
    }

    public void Callresponse(Context context, String authString, String mUserUuid, String mLocationText, String mType, String mLatitude, String mLongitude, String mLocationLevel, Callback<ResponseAddUploadGeoFenceApi> mCallback) {
        ((myAddUploadGeoFenceApi) CommonMember.getInstance(context).getApiBuilder().create(myAddUploadGeoFenceApi.class)).myAddUploadGeoFenceApi(authString, mUserUuid, mLocationText, mType, mLatitude, mLongitude, mLocationLevel, mCallback);
    }
}
