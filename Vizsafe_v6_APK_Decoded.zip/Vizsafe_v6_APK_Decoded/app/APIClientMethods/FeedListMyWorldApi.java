package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.google.gson.JsonObject;
import com.vizsafe.app.Utils.CommonMember;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Header;
import retrofit.http.Query;

public class FeedListMyWorldApi {
    private static FeedListMyWorldApi ourInstance = new FeedListMyWorldApi();

    public interface myFeedListMyWorldApi {
        @GET("/incident")
        void myFeedListMyWorldApi(@Header("Authorization") String str, @Query("channels") String str2, @Query("limit") String str3, Callback<JsonObject> callback);
    }

    public static FeedListMyWorldApi getInstance() {
        return ourInstance;
    }

    private FeedListMyWorldApi() {
    }

    public void Callresponse(Context context, String authenticationString, String mFavorite, String mLimit, Callback<JsonObject> mCallback) {
        ((myFeedListMyWorldApi) CommonMember.getInstance(context).getApiBuilder().create(myFeedListMyWorldApi.class)).myFeedListMyWorldApi(authenticationString, mFavorite, mLimit, mCallback);
    }
}
