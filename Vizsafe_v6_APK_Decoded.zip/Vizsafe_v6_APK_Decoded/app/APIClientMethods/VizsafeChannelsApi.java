package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.vizsafe.app.APIClientMethods.FavouriteChannelsApi.Detail;
import com.vizsafe.app.Utils.CommonMember;
import java.util.HashMap;
import java.util.Map;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Header;
import retrofit.http.Query;

public class VizsafeChannelsApi {
    private static VizsafeChannelsApi ourInstance = new VizsafeChannelsApi();

    public class ResponseVizsafeChannelsApi {
        private Map<String, Object> additionalProperties = new HashMap();
        private Detail detail;
        private Integer httpCode;
        private String message;

        public Integer getHttpCode() {
            return this.httpCode;
        }

        public void setHttpCode(Integer httpCode) {
            this.httpCode = httpCode;
        }

        public String getMessage() {
            return this.message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public Detail getDetail() {
            return this.detail;
        }

        public void setDetail(Detail detail) {
            this.detail = detail;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public interface myVizsafeChannelsApi {
        @GET("/channel")
        void myVizsafeChannelsApi(@Header("Authorization") String str, @Query("channels") String str2, Callback<ResponseVizsafeChannelsApi> callback);
    }

    public static VizsafeChannelsApi getInstance() {
        return ourInstance;
    }

    private VizsafeChannelsApi() {
    }

    public void Callresponse(Context context, String authString, String favorite, Callback<ResponseVizsafeChannelsApi> mCallback) {
        ((myVizsafeChannelsApi) CommonMember.getInstance(context).getApiBuilder().create(myVizsafeChannelsApi.class)).myVizsafeChannelsApi(authString, favorite, mCallback);
    }
}
