package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.google.gson.JsonObject;
import com.vizsafe.app.Utils.CommonMember;
import retrofit.Callback;
import retrofit.http.EncodedPath;
import retrofit.http.GET;
import retrofit.http.Header;

public class FeedListMoreApi {
    private static FeedListMoreApi ourInstance = new FeedListMoreApi();

    public interface myFeedListMoreApi {
        @GET("/{data}")
        void myFeedListMoreApi(@Header("Authorization") String str, @EncodedPath("data") String str2, Callback<JsonObject> callback);
    }

    public static FeedListMoreApi getInstance() {
        return ourInstance;
    }

    private FeedListMoreApi() {
    }

    public void Callresponse(Context context, String authenticationString, String mMore_feed_url, Callback<JsonObject> mCallback) {
        ((myFeedListMoreApi) CommonMember.getInstance(context).getApiBuilder().create(myFeedListMoreApi.class)).myFeedListMoreApi(authenticationString, mMore_feed_url, mCallback);
    }
}
