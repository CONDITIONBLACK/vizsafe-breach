package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.vizsafe.app.Utils.CommonMember;
import java.util.HashMap;
import java.util.Map;
import retrofit.Callback;
import retrofit.http.Header;
import retrofit.http.POST;
import retrofit.http.Path;

public class ReportAbuseApi {
    private static ReportAbuseApi ourInstance = new ReportAbuseApi();

    public class ResponseReportAbuseApi {
        private Map<String, Object> additionalProperties = new HashMap();
        private String detail;
        private Integer httpCode;
        private String message;

        public Integer getHttpCode() {
            return this.httpCode;
        }

        public void setHttpCode(Integer httpCode) {
            this.httpCode = httpCode;
        }

        public String getMessage() {
            return this.message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public String getDetail() {
            return this.detail;
        }

        public void setDetail(String detail) {
            this.detail = detail;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public interface myReportAbuseApi {
        @POST("/incident/{data}/reportabuse")
        void myReportAbuseApi(@Header("Authorization") String str, @Path("data") String str2, Callback<ResponseReportAbuseApi> callback);
    }

    public static ReportAbuseApi getInstance() {
        return ourInstance;
    }

    private ReportAbuseApi() {
    }

    public void Callresponse(Context context, String authenticationString, String feedUUID, Callback<ResponseReportAbuseApi> mCallback) {
        ((myReportAbuseApi) CommonMember.getInstance(context).getApiBuilder().create(myReportAbuseApi.class)).myReportAbuseApi(authenticationString, feedUUID, mCallback);
    }
}
