package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.google.gson.JsonObject;
import com.vizsafe.app.Utils.CommonMember;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Header;
import retrofit.http.Query;

public class GetBOAPins {
    private static final GetBOAPins ourInstance = new GetBOAPins();

    public interface myGetBOAPins {
        @GET("/orglocationmarkers?")
        void myGetBOAPins(@Header("Authorization") String str, @Query("bounds") String str2, Callback<JsonObject> callback);
    }

    public static GetBOAPins getInstance() {
        return ourInstance;
    }

    private GetBOAPins() {
    }

    public void Callresponse(Context context, String authenticationString, String mBounds, Callback<JsonObject> mCallback) {
        ((myGetBOAPins) CommonMember.getInstance(context).getApiBuilder().create(myGetBOAPins.class)).myGetBOAPins(authenticationString, mBounds, mCallback);
    }
}
