package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.google.gson.JsonObject;
import com.vizsafe.app.Utils.CommonMember;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Header;
import retrofit.http.Query;

public class PrivateCameraListApi {
    private static PrivateCameraListApi ourInstance = new PrivateCameraListApi();

    public class Camera {
        private Map<String, Object> additionalProperties = new HashMap();
        private Double latitude;
        private Location location;
        private Double longitude;
        private Boolean massaged;
        private String name;
        private Integer refreshRate;
        private String source;
        private String type;
        private String url;
        private String uuid;

        public String getUuid() {
            return this.uuid;
        }

        public void setUuid(String uuid) {
            this.uuid = uuid;
        }

        public String getSource() {
            return this.source;
        }

        public void setSource(String source) {
            this.source = source;
        }

        public String getType() {
            return this.type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public Integer getRefreshRate() {
            return this.refreshRate;
        }

        public void setRefreshRate(Integer refreshRate) {
            this.refreshRate = refreshRate;
        }

        public Double getLatitude() {
            return this.latitude;
        }

        public void setLatitude(Double latitude) {
            this.latitude = latitude;
        }

        public Double getLongitude() {
            return this.longitude;
        }

        public void setLongitude(Double longitude) {
            this.longitude = longitude;
        }

        public Location getLocation() {
            return this.location;
        }

        public void setLocation(Location location) {
            this.location = location;
        }

        public String getName() {
            return this.name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getUrl() {
            return this.url;
        }

        public void setUrl(String url) {
            this.url = url;
        }

        public Boolean getMassaged() {
            return this.massaged;
        }

        public void setMassaged(Boolean massaged) {
            this.massaged = massaged;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public class Loc {
        private Map<String, Object> additionalProperties = new HashMap();
        private Double lat;
        private Double lng;

        public Double getLng() {
            return this.lng;
        }

        public void setLng(Double lng) {
            this.lng = lng;
        }

        public Double getLat() {
            return this.lat;
        }

        public void setLat(Double lat) {
            this.lat = lat;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public class Location {
        private Map<String, Object> additionalProperties = new HashMap();
        private Loc loc;

        public Loc getLoc() {
            return this.loc;
        }

        public void setLoc(Loc loc) {
            this.loc = loc;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public class ResponsePrivateCameraListApi {
        private Map<String, Object> additionalProperties = new HashMap();
        private List<Camera> cameras = new ArrayList();
        private Integer total;

        public Integer getTotal() {
            return this.total;
        }

        public void setTotal(Integer total) {
            this.total = total;
        }

        public List<Camera> getCameras() {
            return this.cameras;
        }

        public void setCameras(List<Camera> cameras) {
            this.cameras = cameras;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public interface myPrivateCameraListApi {
        @GET("/camera")
        void myPrivateCameraListApi(@Header("Authorization") String str, @Query("hidepublic") String str2, Callback<JsonObject> callback);
    }

    public static PrivateCameraListApi getInstance() {
        return ourInstance;
    }

    private PrivateCameraListApi() {
    }

    public void Callresponse(Context context, String authString, String favorite, Callback<JsonObject> mCallback) {
        ((myPrivateCameraListApi) CommonMember.getInstance(context).getApiBuilder().create(myPrivateCameraListApi.class)).myPrivateCameraListApi(authString, favorite, mCallback);
    }
}
