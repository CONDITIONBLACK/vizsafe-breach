package com.vizsafe.app.APIClientMethods;

import android.content.Context;
import com.vizsafe.app.Utils.CommonMember;
import java.util.HashMap;
import java.util.Map;
import retrofit.Callback;
import retrofit.http.Header;
import retrofit.http.POST;
import retrofit.http.Path;

public class ReportClearedStateApi {
    private static ReportClearedStateApi ourInstance = new ReportClearedStateApi();

    public class Detail {
        private Map<String, Object> additionalProperties = new HashMap();
        private String incidentClearedBy;
        private Integer incidentClearedTimeStamp;

        public String getIncidentClearedBy() {
            return this.incidentClearedBy;
        }

        public void setIncidentClearedBy(String incidentClearedBy) {
            this.incidentClearedBy = incidentClearedBy;
        }

        public Integer getIncidentClearedTimeStamp() {
            return this.incidentClearedTimeStamp;
        }

        public void setIncidentClearedTimeStamp(Integer incidentClearedTimeStamp) {
            this.incidentClearedTimeStamp = incidentClearedTimeStamp;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public class ResponseReportClearedStateApi {
        private Map<String, Object> additionalProperties = new HashMap();
        private Detail detail;
        private Integer httpCode;
        private String message;

        public Integer getHttpCode() {
            return this.httpCode;
        }

        public void setHttpCode(Integer httpCode) {
            this.httpCode = httpCode;
        }

        public String getMessage() {
            return this.message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public Detail getDetail() {
            return this.detail;
        }

        public void setDetail(Detail detail) {
            this.detail = detail;
        }

        public Map<String, Object> getAdditionalProperties() {
            return this.additionalProperties;
        }

        public void setAdditionalProperty(String name, Object value) {
            this.additionalProperties.put(name, value);
        }
    }

    public interface myReportClearedStateApi {
        @POST("/incidents/{data}/State")
        void myReportClearedStateApi(@Header("Authorization") String str, @Path("data") String str2, Callback<ResponseReportClearedStateApi> callback);
    }

    public static ReportClearedStateApi getInstance() {
        return ourInstance;
    }

    private ReportClearedStateApi() {
    }

    public void Callresponse(Context context, String authenticationString, String feedUUID, Callback<ResponseReportClearedStateApi> mCallback) {
        ((myReportClearedStateApi) CommonMember.getInstance(context).getApiBuilder().create(myReportClearedStateApi.class)).myReportClearedStateApi(authenticationString, feedUUID, mCallback);
    }
}
