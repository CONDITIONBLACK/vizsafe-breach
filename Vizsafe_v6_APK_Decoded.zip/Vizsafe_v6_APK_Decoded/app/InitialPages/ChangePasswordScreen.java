package com.vizsafe.app.InitialPages;

import android.app.AlertDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.support.p002v7.app.AppCompatActivity;
import android.util.Base64;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.vizsafe.app.APIClientMethods.ChangePasswordApi;
import com.vizsafe.app.APIClientMethods.ChangePasswordApi.ResponseChangePasswordApi;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.Utils.CommonMember;
import com.vizsafe.app.Utils.PreferenceHandler;
import dmax.dialog.SpotsDialog;
import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class ChangePasswordScreen extends AppCompatActivity {
    ImageView cancelBtn;
    ChangePasswordScreen changePasswordScreen;
    EditText edtConfirmPassowrd;
    EditText edtCurrentPassowrd;
    EditText edtNewPassword;
    AlertDialog mTransparentProgressDialog;
    TextView saveBtn;

    /* renamed from: com.vizsafe.app.InitialPages.ChangePasswordScreen$1 */
    class C03411 implements OnClickListener {
        C03411() {
        }

        public void onClick(View v) {
            ChangePasswordScreen.this.finish();
        }
    }

    /* renamed from: com.vizsafe.app.InitialPages.ChangePasswordScreen$2 */
    class C03432 implements OnClickListener {

        /* renamed from: com.vizsafe.app.InitialPages.ChangePasswordScreen$2$1 */
        class C03421 implements Callback<ResponseChangePasswordApi> {
            C03421() {
            }

            public void success(ResponseChangePasswordApi responseChangePasswordApi, Response response) {
                ChangePasswordScreen.this.mTransparentProgressDialog.dismiss();
                if (responseChangePasswordApi.getHttpCode().intValue() == 200) {
                    PreferenceHandler.getInstance(ChangePasswordScreen.this.changePasswordScreen).setPassword(ChangePasswordScreen.this.edtNewPassword.getText().toString().trim());
                    Toast.makeText(ChangePasswordScreen.this, ChangePasswordScreen.this.getResources().getString(C0421R.string.password_updated_successfully), 0).show();
                    ChangePasswordScreen.this.finish();
                    return;
                }
                Toast.makeText(ChangePasswordScreen.this, ChangePasswordScreen.this.getResources().getString(C0421R.string.unable_to_process_your_request), 0).show();
            }

            public void failure(RetrofitError error) {
                ChangePasswordScreen.this.mTransparentProgressDialog.dismiss();
                Toast.makeText(ChangePasswordScreen.this, ChangePasswordScreen.this.getResources().getString(C0421R.string.unable_to_process_your_request), 0).show();
                error.printStackTrace();
            }
        }

        C03432() {
        }

        public void onClick(View v) {
            if (ChangePasswordScreen.this.edtCurrentPassowrd.getText().toString().trim().isEmpty()) {
                ChangePasswordScreen.this.edtCurrentPassowrd.setError(ChangePasswordScreen.this.getString(C0421R.string.enter_current_password));
            } else if (!ChangePasswordScreen.this.edtCurrentPassowrd.getText().toString().trim().equals(PreferenceHandler.getInstance(ChangePasswordScreen.this.changePasswordScreen).getPassword())) {
                ChangePasswordScreen.this.edtCurrentPassowrd.setError(ChangePasswordScreen.this.getString(C0421R.string.enter_current_password));
            } else if (ChangePasswordScreen.this.edtNewPassword.getText().toString().trim().isEmpty()) {
                ChangePasswordScreen.this.edtNewPassword.setError(ChangePasswordScreen.this.getString(C0421R.string.error_enter_password));
            } else if (ChangePasswordScreen.this.edtConfirmPassowrd.getText().toString().trim().isEmpty()) {
                ChangePasswordScreen.this.edtConfirmPassowrd.setError(ChangePasswordScreen.this.getString(C0421R.string.error_enter_password));
            } else if (ChangePasswordScreen.this.edtNewPassword.getText().toString().trim().length() < 7) {
                ChangePasswordScreen.this.edtNewPassword.setError(ChangePasswordScreen.this.getString(C0421R.string.error_password_length));
            } else if (ChangePasswordScreen.this.edtConfirmPassowrd.getText().toString().trim().equals(ChangePasswordScreen.this.edtNewPassword.getText().toString().trim())) {
                String email = PreferenceHandler.getInstance(ChangePasswordScreen.this).getUserName();
                String password = PreferenceHandler.getInstance(ChangePasswordScreen.this).getPassword();
                String authStringinBase64 = "Basic " + Base64.encodeToString((email + ":" + password).getBytes(), 2);
                CommonMember.hideKeyboard(ChangePasswordScreen.this);
                if (CommonMember.isNetworkOnline((ConnectivityManager) ChangePasswordScreen.this.getSystemService("connectivity"), ChangePasswordScreen.this)) {
                    ChangePasswordScreen.this.mTransparentProgressDialog.show();
                    ChangePasswordApi.getInstance().Callresponse(ChangePasswordScreen.this.getApplicationContext(), authStringinBase64, password, ChangePasswordScreen.this.edtNewPassword.getText().toString().trim(), new C03421());
                    return;
                }
                CommonMember.NetworkStatusAlert(ChangePasswordScreen.this);
            } else {
                ChangePasswordScreen.this.edtConfirmPassowrd.setError(ChangePasswordScreen.this.getString(C0421R.string.error_enter_new_password_again));
            }
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0421R.layout.change_password_screen);
        this.changePasswordScreen = this;
        this.cancelBtn = (ImageView) findViewById(C0421R.C0419id.action_bar_back);
        this.saveBtn = (TextView) findViewById(C0421R.C0419id.action_bar_next);
        this.edtCurrentPassowrd = (EditText) findViewById(C0421R.C0419id.edt_current_password);
        this.edtNewPassword = (EditText) findViewById(C0421R.C0419id.edt_new_password);
        this.edtConfirmPassowrd = (EditText) findViewById(C0421R.C0419id.edt_confirm_password);
        this.mTransparentProgressDialog = new SpotsDialog((Context) this, getResources().getString(C0421R.string.please_wait_loading));
        this.mTransparentProgressDialog.setCanceledOnTouchOutside(false);
        this.mTransparentProgressDialog.setCancelable(false);
        this.saveBtn.setVisibility(0);
        this.saveBtn.setText(getResources().getText(C0421R.string.done));
        this.cancelBtn.setOnClickListener(new C03411());
        this.saveBtn.setOnClickListener(new C03432());
    }
}
