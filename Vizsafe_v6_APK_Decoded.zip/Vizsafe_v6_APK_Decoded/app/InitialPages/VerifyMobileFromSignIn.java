package com.vizsafe.app.InitialPages;

import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.p001v4.content.ContextCompat;
import android.support.p001v4.content.LocalBroadcastManager;
import android.support.p002v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.analytics.ecommerce.ProductAction;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.GCMIntentService.GCMClientManager;
import com.vizsafe.app.Utils.CommonMember;
import com.vizsafe.app.Utils.PreferenceHandler;
import com.vizsafe.app.Utils.Webservice;
import dmax.dialog.SpotsDialog;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONException;
import org.json.JSONObject;

public class VerifyMobileFromSignIn extends AppCompatActivity {
    private static final String FILE_NAME = "countrycode.txt";
    private boolean AllPermissionGranted = false;
    ArrayList<String> CountryCodeList;
    ArrayList<String> CountryList;
    EditText OTPtext;
    private ImageView cancelBtn;
    private EditText emailEditText;
    private String mAuthyid;
    private boolean mCallPermission = false;
    private boolean mCameraPermission = false;
    private VerifyMobileFromSignIn mContext;
    private String mCountryCode = null;
    private String mCountryName;
    private Spinner mCountrySpinnerSignUp;
    private String mEmail;
    private boolean mGallerypermission = false;
    private JSONObject mJsonResponse;
    private boolean mLocationPermissionsGranted = false;
    private String mMobileNumber;
    private EditText mMobileSignUp;
    private String mOtp;
    private boolean mOtpClicked = false;
    private String mPhoneNumber;
    private boolean mReadSMSpermission = false;
    private boolean mReceiveSMSpermission = false;
    private TextView mTitle;
    private AlertDialog mTransparentProgressDialog;
    private String mUserid;
    private boolean mVideoPermission = false;
    private Button nextBtn;
    private BroadcastReceiver receiver = new C03737();

    /* renamed from: com.vizsafe.app.InitialPages.VerifyMobileFromSignIn$1 */
    class C03671 implements OnItemSelectedListener {
        C03671() {
        }

        public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
            VerifyMobileFromSignIn.this.mCountryName = (String) VerifyMobileFromSignIn.this.CountryList.get(position);
            VerifyMobileFromSignIn.this.mCountryCode = (String) VerifyMobileFromSignIn.this.CountryCodeList.get(position);
            ((TextView) view).setTextColor(VerifyMobileFromSignIn.this.getResources().getColor(C0421R.color.colorPrimary));
        }

        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    /* renamed from: com.vizsafe.app.InitialPages.VerifyMobileFromSignIn$2 */
    class C03682 implements OnClickListener {
        C03682() {
        }

        public void onClick(View v) {
            VerifyMobileFromSignIn.this.finish();
        }
    }

    /* renamed from: com.vizsafe.app.InitialPages.VerifyMobileFromSignIn$3 */
    class C03693 implements OnClickListener {
        C03693() {
        }

        public void onClick(View v) {
            VerifyMobileFromSignIn.this.mEmail = VerifyMobileFromSignIn.this.emailEditText.getText().toString().trim();
            VerifyMobileFromSignIn.this.mPhoneNumber = VerifyMobileFromSignIn.this.mMobileSignUp.getText().toString().trim();
            if (VerifyMobileFromSignIn.this.mEmail.isEmpty() || VerifyMobileFromSignIn.this.mEmail == null) {
                VerifyMobileFromSignIn.this.emailEditText.setError(VerifyMobileFromSignIn.this.getString(C0421R.string.error_enter_email));
            } else if (VerifyMobileFromSignIn.this.mPhoneNumber.length() != 10 || VerifyMobileFromSignIn.this.mPhoneNumber.isEmpty()) {
                VerifyMobileFromSignIn.this.mMobileSignUp.setError(VerifyMobileFromSignIn.this.getString(C0421R.string.error_enter_phone_number));
            } else if (VerifyMobileFromSignIn.this.mCountryCode.isEmpty() || VerifyMobileFromSignIn.this.mCountryCode == null) {
                ((TextView) VerifyMobileFromSignIn.this.mCountrySpinnerSignUp.getSelectedView()).setError(VerifyMobileFromSignIn.this.getString(C0421R.string.error_enter_country));
            } else if (!CommonMember.isNetworkOnline((ConnectivityManager) VerifyMobileFromSignIn.this.getSystemService("connectivity"), VerifyMobileFromSignIn.this)) {
                CommonMember.NetworkStatusAlert(VerifyMobileFromSignIn.this);
            } else if (VerifyMobileFromSignIn.this.AllPermissionGranted) {
                new AsyncTaskVerifyAccount(VerifyMobileFromSignIn.this, null).execute(new String[0]);
            } else if (VerifyMobileFromSignIn.this.checkPermission()) {
                VerifyMobileFromSignIn.this.AllPermissionGranted = true;
                new AsyncTaskVerifyAccount(VerifyMobileFromSignIn.this, null).execute(new String[0]);
            } else {
                Toast.makeText(VerifyMobileFromSignIn.this.getApplicationContext(), "Permission needed", 1).show();
                VerifyMobileFromSignIn.this.requestPermission();
            }
        }
    }

    /* renamed from: com.vizsafe.app.InitialPages.VerifyMobileFromSignIn$7 */
    class C03737 extends BroadcastReceiver {
        C03737() {
        }

        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equalsIgnoreCase("otp")) {
                String code = VerifyMobileFromSignIn.this.parseCode(intent.getStringExtra(GCMClientManager.EXTRA_MESSAGE));
                if (VerifyMobileFromSignIn.this.OTPtext != null) {
                    VerifyMobileFromSignIn.this.OTPtext.setText(code);
                    VerifyMobileFromSignIn.this.OTPtext.setSelection(VerifyMobileFromSignIn.this.OTPtext.getText().length());
                }
            }
        }
    }

    private class AsyncTaskResend extends AsyncTask<String, String, String> {
        JSONObject response;

        private AsyncTaskResend() {
        }

        /* synthetic */ AsyncTaskResend(VerifyMobileFromSignIn x0, C03671 x1) {
            this();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            VerifyMobileFromSignIn.this.mTransparentProgressDialog.show();
        }

        protected String doInBackground(String... arg0) {
            Webservice mWebservice = new Webservice();
            this.response = Webservice.ResendOtp(VerifyMobileFromSignIn.this.mAuthyid);
            return null;
        }

        protected void onPostExecute(String result) {
            if (VerifyMobileFromSignIn.this.mTransparentProgressDialog.isShowing()) {
                VerifyMobileFromSignIn.this.mTransparentProgressDialog.dismiss();
            }
            if (this.response != null) {
                try {
                    JSONObject mJsonResponse = new JSONObject(String.valueOf(this.response));
                    try {
                        VerifyMobileFromSignIn.this.showOTPDialog();
                        return;
                    } catch (Exception e) {
                        e.printStackTrace();
                        return;
                    }
                } catch (JSONException e2) {
                    e2.printStackTrace();
                    return;
                }
            }
            Toast.makeText(VerifyMobileFromSignIn.this.getApplicationContext(), VerifyMobileFromSignIn.this.getResources().getString(C0421R.string.unable_to_process_your_request), 1).show();
        }
    }

    private class AsyncTaskVerifyAccount extends AsyncTask<String, String, String> {
        JSONObject response;

        private AsyncTaskVerifyAccount() {
        }

        /* synthetic */ AsyncTaskVerifyAccount(VerifyMobileFromSignIn x0, C03671 x1) {
            this();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            VerifyMobileFromSignIn.this.mTransparentProgressDialog.show();
        }

        protected String doInBackground(String... arg0) {
            String mUserid = PreferenceHandler.getInstance(VerifyMobileFromSignIn.this.mContext).getUserUUID();
            this.response = new Webservice().VerifyMobileFromSignIn(VerifyMobileFromSignIn.this.getApplicationContext(), VerifyMobileFromSignIn.this.mEmail, VerifyMobileFromSignIn.this.mPhoneNumber, VerifyMobileFromSignIn.this.mCountryCode);
            return null;
        }

        protected void onPostExecute(String result) {
            if (VerifyMobileFromSignIn.this.mTransparentProgressDialog.isShowing()) {
                VerifyMobileFromSignIn.this.mTransparentProgressDialog.dismiss();
            }
            if (this.response != null) {
                try {
                    JSONObject mJsonResponse = new JSONObject(String.valueOf(this.response));
                    try {
                        int httpCode = mJsonResponse.getInt("httpCode");
                        String mMessage = mJsonResponse.getString(GCMClientManager.EXTRA_MESSAGE);
                        if (httpCode == 200) {
                            JSONObject mDetail = mJsonResponse.getJSONObject(ProductAction.ACTION_DETAIL);
                            VerifyMobileFromSignIn.this.mAuthyid = mDetail.getString("authyid");
                            VerifyMobileFromSignIn.this.mMobileNumber = mDetail.getString("mobilenumber");
                            VerifyMobileFromSignIn.this.showOTPDialog();
                            return;
                        }
                        Toast.makeText(VerifyMobileFromSignIn.this.mContext, mMessage, 0).show();
                        return;
                    } catch (Exception e) {
                        e.printStackTrace();
                        return;
                    }
                } catch (JSONException e2) {
                    e2.printStackTrace();
                    return;
                }
            }
            Toast.makeText(VerifyMobileFromSignIn.this.getApplicationContext(), VerifyMobileFromSignIn.this.getResources().getString(C0421R.string.unable_to_process_your_request), 1).show();
        }
    }

    private class AsyncTaskVerifyOtp extends AsyncTask<String, String, String> {
        JSONObject response;

        private AsyncTaskVerifyOtp() {
        }

        /* synthetic */ AsyncTaskVerifyOtp(VerifyMobileFromSignIn x0, C03671 x1) {
            this();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            VerifyMobileFromSignIn.this.mTransparentProgressDialog.show();
        }

        protected String doInBackground(String... arg0) {
            VerifyMobileFromSignIn.this.mUserid = PreferenceHandler.getInstance(VerifyMobileFromSignIn.this.mContext).getUserUUID();
            VerifyMobileFromSignIn.this.mOtp = "o" + VerifyMobileFromSignIn.this.mOtp;
            this.response = new Webservice().VerifyOtpFromSignIn(VerifyMobileFromSignIn.this.getApplicationContext(), VerifyMobileFromSignIn.this.mEmail, VerifyMobileFromSignIn.this.mOtp, VerifyMobileFromSignIn.this.mAuthyid, VerifyMobileFromSignIn.this.mPhoneNumber, VerifyMobileFromSignIn.this.mCountryCode);
            return null;
        }

        protected void onPostExecute(String result) {
            if (VerifyMobileFromSignIn.this.mTransparentProgressDialog.isShowing()) {
                VerifyMobileFromSignIn.this.mTransparentProgressDialog.dismiss();
            }
            if (this.response != null) {
                try {
                    VerifyMobileFromSignIn.this.mJsonResponse = new JSONObject(String.valueOf(this.response));
                    try {
                        int httpCode = VerifyMobileFromSignIn.this.mJsonResponse.getInt("httpCode");
                        String mMessage = VerifyMobileFromSignIn.this.mJsonResponse.getString(GCMClientManager.EXTRA_MESSAGE);
                        if (httpCode == 200) {
                            Toast.makeText(VerifyMobileFromSignIn.this.getApplicationContext(), mMessage, 1).show();
                            VerifyMobileFromSignIn.this.mOtpClicked = false;
                            if (!(VerifyMobileFromSignIn.this.mAuthyid == null || VerifyMobileFromSignIn.this.mAuthyid.isEmpty())) {
                                PreferenceHandler.getInstance(VerifyMobileFromSignIn.this.mContext).setAuthyId(VerifyMobileFromSignIn.this.mAuthyid);
                            }
                            if (VerifyMobileFromSignIn.this.mMobileNumber == null) {
                                PreferenceHandler.getInstance(VerifyMobileFromSignIn.this.mContext).setMobileNumber("");
                            } else if (!VerifyMobileFromSignIn.this.mMobileNumber.isEmpty()) {
                                PreferenceHandler.getInstance(VerifyMobileFromSignIn.this.mContext).setMobileNumber(VerifyMobileFromSignIn.this.mMobileNumber);
                            }
                            VerifyMobileFromSignIn.this.finish();
                            return;
                        }
                        Toast.makeText(VerifyMobileFromSignIn.this.mContext, mMessage, 0).show();
                        return;
                    } catch (Exception e) {
                        e.printStackTrace();
                        return;
                    }
                } catch (JSONException e2) {
                    e2.printStackTrace();
                    return;
                }
            }
            Toast.makeText(VerifyMobileFromSignIn.this.getApplicationContext(), VerifyMobileFromSignIn.this.getResources().getString(C0421R.string.unable_to_process_your_request), 1).show();
        }
    }

    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0421R.layout.verify_mobile_signin);
        this.mContext = this;
        this.mTransparentProgressDialog = new SpotsDialog((Context) this, getResources().getString(C0421R.string.please_wait_loading));
        this.mTransparentProgressDialog.setCanceledOnTouchOutside(false);
        this.mTransparentProgressDialog.setCancelable(false);
        this.nextBtn = (Button) findViewById(C0421R.C0419id.next_btn);
        this.cancelBtn = (ImageView) findViewById(C0421R.C0419id.action_bar_back);
        this.mTitle = (TextView) findViewById(2131689653);
        this.emailEditText = (EditText) findViewById(C0421R.C0419id.email_verify);
        this.mMobileSignUp = (EditText) findViewById(C0421R.C0419id.mobile_verify);
        this.mCountrySpinnerSignUp = (Spinner) findViewById(C0421R.C0419id.country_spinner_verify);
        String email = PreferenceHandler.getInstance(this.mContext).getUserEmail();
        if (!email.isEmpty()) {
            this.emailEditText.setText(email);
            this.emailEditText.setEnabled(false);
        }
        ReadFile(FILE_NAME);
        this.mTitle.setText(getResources().getString(C0421R.string.verify_mobile));
        this.mCountrySpinnerSignUp.setOnItemSelectedListener(new C03671());
        this.cancelBtn.setOnClickListener(new C03682());
        this.nextBtn.setOnClickListener(new C03693());
    }

    /* JADX WARNING: Unknown top exception splitter block from list: {B:16:0x00df=Splitter:B:16:0x00df, B:23:0x011f=Splitter:B:23:0x011f} */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x00e4 A:{SYNTHETIC, Splitter:B:19:0x00e4} */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x0124 A:{SYNTHETIC, Splitter:B:26:0x0124} */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x0161 A:{SYNTHETIC, Splitter:B:31:0x0161} */
    public void ReadFile(java.lang.String r24) {
        /*
        r23 = this;
        r0 = r23;
        r0 = r0.CountryList;
        r19 = r0;
        if (r19 == 0) goto L_0x001a;
    L_0x0008:
        r0 = r23;
        r0 = r0.CountryList;
        r19 = r0;
        r19.clear();
        r0 = r23;
        r0 = r0.CountryCodeList;
        r19 = r0;
        r19.clear();
    L_0x001a:
        r19 = new java.util.ArrayList;
        r19.<init>();
        r0 = r19;
        r1 = r23;
        r1.CountryList = r0;
        r19 = new java.util.ArrayList;
        r19.<init>();
        r0 = r19;
        r1 = r23;
        r1.CountryCodeList = r0;
        r14 = 0;
        r19 = r23.getAssets();	 Catch:{ IOException -> 0x00de, NullPointerException -> 0x011e }
        r0 = r19;
        r1 = r24;
        r9 = r0.open(r1);	 Catch:{ IOException -> 0x00de, NullPointerException -> 0x011e }
        r15 = new java.io.BufferedReader;	 Catch:{ IOException -> 0x00de, NullPointerException -> 0x011e }
        r19 = new java.io.InputStreamReader;	 Catch:{ IOException -> 0x00de, NullPointerException -> 0x011e }
        r0 = r19;
        r0.<init>(r9);	 Catch:{ IOException -> 0x00de, NullPointerException -> 0x011e }
        r0 = r19;
        r15.<init>(r0);	 Catch:{ IOException -> 0x00de, NullPointerException -> 0x011e }
        r13 = r15.readLine();	 Catch:{ IOException -> 0x01ac, NullPointerException -> 0x01a8, all -> 0x01a5 }
        r11 = 0;
    L_0x0050:
        if (r13 == 0) goto L_0x00a1;
    L_0x0052:
        r13 = r15.readLine();	 Catch:{ IOException -> 0x01ac, NullPointerException -> 0x01a8, all -> 0x01a5 }
        r19 = "number=";
        r0 = r19;
        r17 = r13.split(r0);	 Catch:{ IOException -> 0x01ac, NullPointerException -> 0x01a8, all -> 0x01a5 }
        r19 = 1;
        r16 = r17[r19];	 Catch:{ IOException -> 0x01ac, NullPointerException -> 0x01a8, all -> 0x01a5 }
        r19 = "</option>";
        r0 = r16;
        r1 = r19;
        r18 = r0.split(r1);	 Catch:{ IOException -> 0x01ac, NullPointerException -> 0x01a8, all -> 0x01a5 }
        r19 = 0;
        r10 = r18[r19];	 Catch:{ IOException -> 0x01ac, NullPointerException -> 0x01a8, all -> 0x01a5 }
        r0 = r23;
        r0 = r0.CountryList;	 Catch:{ IOException -> 0x01ac, NullPointerException -> 0x01a8, all -> 0x01a5 }
        r19 = r0;
        r0 = r19;
        r0.add(r10);	 Catch:{ IOException -> 0x01ac, NullPointerException -> 0x01a8, all -> 0x01a5 }
        r19 = "\\+";
        r0 = r19;
        r4 = r10.split(r0);	 Catch:{ IOException -> 0x01ac, NullPointerException -> 0x01a8, all -> 0x01a5 }
        r19 = 1;
        r6 = r4[r19];	 Catch:{ IOException -> 0x01ac, NullPointerException -> 0x01a8, all -> 0x01a5 }
        r19 = "\\)";
        r0 = r19;
        r5 = r6.split(r0);	 Catch:{ IOException -> 0x01ac, NullPointerException -> 0x01a8, all -> 0x01a5 }
        r19 = 0;
        r7 = r5[r19];	 Catch:{ IOException -> 0x01ac, NullPointerException -> 0x01a8, all -> 0x01a5 }
        r0 = r23;
        r0 = r0.CountryCodeList;	 Catch:{ IOException -> 0x01ac, NullPointerException -> 0x01a8, all -> 0x01a5 }
        r19 = r0;
        r0 = r19;
        r0.add(r7);	 Catch:{ IOException -> 0x01ac, NullPointerException -> 0x01a8, all -> 0x01a5 }
        r11 = r11 + 1;
        goto L_0x0050;
    L_0x00a1:
        if (r15 == 0) goto L_0x00a6;
    L_0x00a3:
        r15.close();	 Catch:{ IOException -> 0x019b }
    L_0x00a6:
        r3 = new android.widget.ArrayAdapter;
        r19 = r23.getApplicationContext();
        r20 = 17367048; // 0x1090008 float:2.5162948E-38 double:8.580462E-317;
        r0 = r23;
        r0 = r0.CountryList;
        r21 = r0;
        r0 = r19;
        r1 = r20;
        r2 = r21;
        r3.<init>(r0, r1, r2);
        r19 = 17367049; // 0x1090009 float:2.516295E-38 double:8.5804623E-317;
        r0 = r19;
        r3.setDropDownViewResource(r0);
        r0 = r23;
        r0 = r0.mCountrySpinnerSignUp;
        r19 = r0;
        r0 = r19;
        r0.setAdapter(r3);
        r0 = r23;
        r0 = r0.mCountrySpinnerSignUp;
        r19 = r0;
        r20 = 0;
        r19.setSelection(r20);
        r14 = r15;
    L_0x00dd:
        return;
    L_0x00de:
        r12 = move-exception;
    L_0x00df:
        r12.printStackTrace();	 Catch:{ all -> 0x015e }
        if (r14 == 0) goto L_0x00e7;
    L_0x00e4:
        r14.close();	 Catch:{ IOException -> 0x019e }
    L_0x00e7:
        r3 = new android.widget.ArrayAdapter;
        r19 = r23.getApplicationContext();
        r20 = 17367048; // 0x1090008 float:2.5162948E-38 double:8.580462E-317;
        r0 = r23;
        r0 = r0.CountryList;
        r21 = r0;
        r0 = r19;
        r1 = r20;
        r2 = r21;
        r3.<init>(r0, r1, r2);
        r19 = 17367049; // 0x1090009 float:2.516295E-38 double:8.5804623E-317;
        r0 = r19;
        r3.setDropDownViewResource(r0);
        r0 = r23;
        r0 = r0.mCountrySpinnerSignUp;
        r19 = r0;
        r0 = r19;
        r0.setAdapter(r3);
        r0 = r23;
        r0 = r0.mCountrySpinnerSignUp;
        r19 = r0;
        r20 = 0;
        r19.setSelection(r20);
        goto L_0x00dd;
    L_0x011e:
        r8 = move-exception;
    L_0x011f:
        r8.printStackTrace();	 Catch:{ all -> 0x015e }
        if (r14 == 0) goto L_0x0127;
    L_0x0124:
        r14.close();	 Catch:{ IOException -> 0x01a1 }
    L_0x0127:
        r3 = new android.widget.ArrayAdapter;
        r19 = r23.getApplicationContext();
        r20 = 17367048; // 0x1090008 float:2.5162948E-38 double:8.580462E-317;
        r0 = r23;
        r0 = r0.CountryList;
        r21 = r0;
        r0 = r19;
        r1 = r20;
        r2 = r21;
        r3.<init>(r0, r1, r2);
        r19 = 17367049; // 0x1090009 float:2.516295E-38 double:8.5804623E-317;
        r0 = r19;
        r3.setDropDownViewResource(r0);
        r0 = r23;
        r0 = r0.mCountrySpinnerSignUp;
        r19 = r0;
        r0 = r19;
        r0.setAdapter(r3);
        r0 = r23;
        r0 = r0.mCountrySpinnerSignUp;
        r19 = r0;
        r20 = 0;
        r19.setSelection(r20);
        goto L_0x00dd;
    L_0x015e:
        r19 = move-exception;
    L_0x015f:
        if (r14 == 0) goto L_0x0164;
    L_0x0161:
        r14.close();	 Catch:{ IOException -> 0x01a3 }
    L_0x0164:
        r3 = new android.widget.ArrayAdapter;
        r20 = r23.getApplicationContext();
        r21 = 17367048; // 0x1090008 float:2.5162948E-38 double:8.580462E-317;
        r0 = r23;
        r0 = r0.CountryList;
        r22 = r0;
        r0 = r20;
        r1 = r21;
        r2 = r22;
        r3.<init>(r0, r1, r2);
        r20 = 17367049; // 0x1090009 float:2.516295E-38 double:8.5804623E-317;
        r0 = r20;
        r3.setDropDownViewResource(r0);
        r0 = r23;
        r0 = r0.mCountrySpinnerSignUp;
        r20 = r0;
        r0 = r20;
        r0.setAdapter(r3);
        r0 = r23;
        r0 = r0.mCountrySpinnerSignUp;
        r20 = r0;
        r21 = 0;
        r20.setSelection(r21);
        throw r19;
    L_0x019b:
        r19 = move-exception;
        goto L_0x00a6;
    L_0x019e:
        r19 = move-exception;
        goto L_0x00e7;
    L_0x01a1:
        r19 = move-exception;
        goto L_0x0127;
    L_0x01a3:
        r20 = move-exception;
        goto L_0x0164;
    L_0x01a5:
        r19 = move-exception;
        r14 = r15;
        goto L_0x015f;
    L_0x01a8:
        r8 = move-exception;
        r14 = r15;
        goto L_0x011f;
    L_0x01ac:
        r12 = move-exception;
        r14 = r15;
        goto L_0x00df;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.vizsafe.app.InitialPages.VerifyMobileFromSignIn.ReadFile(java.lang.String):void");
    }

    public boolean checkPermission() {
        int camera = ContextCompat.checkSelfPermission(getApplicationContext(), "android.permission.CAMERA");
        int read_external = ContextCompat.checkSelfPermission(getApplicationContext(), "android.permission.READ_EXTERNAL_STORAGE");
        int call_per = ContextCompat.checkSelfPermission(getApplicationContext(), "android.permission.CALL_PHONE");
        int write_external = ContextCompat.checkSelfPermission(getApplicationContext(), "android.permission.WRITE_EXTERNAL_STORAGE");
        int record_video = ContextCompat.checkSelfPermission(getApplicationContext(), "android.permission.RECORD_AUDIO");
        int Coarse_loc = ContextCompat.checkSelfPermission(getApplicationContext(), "android.permission.ACCESS_COARSE_LOCATION");
        int fine_loc = ContextCompat.checkSelfPermission(getApplicationContext(), "android.permission.ACCESS_FINE_LOCATION");
        int receive_sms = ContextCompat.checkSelfPermission(getApplicationContext(), "android.permission.RECEIVE_SMS");
        int read_sms = ContextCompat.checkSelfPermission(getApplicationContext(), "android.permission.READ_SMS");
        if (fine_loc == 0) {
            this.mLocationPermissionsGranted = true;
        }
        if (call_per == 0) {
            this.mCallPermission = true;
        }
        if (camera == 0 && write_external == 0) {
            this.mCameraPermission = true;
        }
        if (camera == 0 && write_external == 0 && record_video == 0) {
            this.mVideoPermission = true;
        }
        if (read_external == 0 && write_external == 0) {
            this.mGallerypermission = true;
        }
        if (read_sms == 0 && write_external == 0) {
            this.mReadSMSpermission = true;
        }
        if (receive_sms == 0 && write_external == 0) {
            this.mReceiveSMSpermission = true;
        }
        if (camera == 0 && read_external == 0 && call_per == 0 && write_external == 0 && record_video == 0 && Coarse_loc == 0 && fine_loc == 0 && read_sms == 0 && receive_sms == 0) {
            return true;
        }
        return false;
    }

    @TargetApi(23)
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case 101:
                if (grantResults.length > 0) {
                    boolean CameraPermission;
                    boolean CallPermission;
                    boolean AccessFineLocationPermission;
                    boolean ReadSMSPermission;
                    boolean ReceiveSMSPermission;
                    if (grantResults[0] == 0) {
                        CameraPermission = true;
                    } else {
                        CameraPermission = false;
                    }
                    boolean ReadExternalPermission;
                    if (grantResults[1] == 0) {
                        ReadExternalPermission = true;
                    } else {
                        ReadExternalPermission = false;
                    }
                    if (grantResults[2] == 0) {
                        CallPermission = true;
                    } else {
                        CallPermission = false;
                    }
                    boolean WriteExternalPermission;
                    if (grantResults[3] == 0) {
                        WriteExternalPermission = true;
                    } else {
                        WriteExternalPermission = false;
                    }
                    boolean RecordAudioPermission;
                    if (grantResults[4] == 0) {
                        RecordAudioPermission = true;
                    } else {
                        RecordAudioPermission = false;
                    }
                    if (grantResults[5] == 0) {
                        boolean AccessCoarseLocationPermission = true;
                    } else {
                        int i = 0;
                    }
                    if (grantResults[6] == 0) {
                        AccessFineLocationPermission = true;
                    } else {
                        AccessFineLocationPermission = false;
                    }
                    if (grantResults[7] == 0) {
                        ReadSMSPermission = true;
                    } else {
                        ReadSMSPermission = false;
                    }
                    if (grantResults[8] == 0) {
                        ReceiveSMSPermission = true;
                    } else {
                        ReceiveSMSPermission = false;
                    }
                    if (AccessFineLocationPermission) {
                        this.mLocationPermissionsGranted = true;
                        return;
                    } else if (CameraPermission && ReadExternalPermission && WriteExternalPermission) {
                        this.mCameraPermission = true;
                        return;
                    } else if (CameraPermission && RecordAudioPermission && ReadExternalPermission && WriteExternalPermission) {
                        this.mVideoPermission = true;
                        return;
                    } else if (CallPermission) {
                        this.mCallPermission = true;
                        return;
                    } else if (ReadSMSPermission) {
                        this.mReadSMSpermission = true;
                        return;
                    } else if (ReceiveSMSPermission) {
                        this.mReceiveSMSpermission = true;
                        return;
                    } else {
                        Toast.makeText(getApplicationContext(), "Permission Denied", 1).show();
                        return;
                    }
                }
                return;
            default:
                return;
        }
    }

    @TargetApi(23)
    private void requestPermission() {
        requestPermissions(new String[]{"android.permission.CAMERA", "android.permission.READ_EXTERNAL_STORAGE", "android.permission.CALL_PHONE", "android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.RECORD_AUDIO", "android.permission.ACCESS_COARSE_LOCATION", "android.permission.ACCESS_FINE_LOCATION", "android.permission.READ_SMS", "android.permission.RECEIVE_SMS"}, 101);
    }

    public void showOTPDialog() {
        final Dialog dialog = new Dialog(this.mContext);
        dialog.requestWindowFeature(1);
        dialog.setCancelable(false);
        dialog.setContentView(C0421R.layout.otp_layout);
        dialog.setTitle(getResources().getString(C0421R.string.app_name));
        this.OTPtext = (EditText) dialog.findViewById(C0421R.C0419id.otp_signup);
        Button dialogButton = (Button) dialog.findViewById(C0421R.C0419id.verify_otp_btn);
        ImageView cancelButton = (ImageView) dialog.findViewById(C0421R.C0419id.close_button);
        ((TextView) dialog.findViewById(C0421R.C0419id.resend_otp)).setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                dialog.dismiss();
                new AsyncTaskResend(VerifyMobileFromSignIn.this, null).execute(new String[0]);
            }
        });
        dialogButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                if (VerifyMobileFromSignIn.this.OTPtext.getText().toString().isEmpty()) {
                    VerifyMobileFromSignIn.this.OTPtext.setError("Please enter valid OTP code");
                    return;
                }
                dialog.dismiss();
                VerifyMobileFromSignIn.this.mOtp = VerifyMobileFromSignIn.this.OTPtext.getText().toString();
                new AsyncTaskVerifyOtp(VerifyMobileFromSignIn.this, null).execute(new String[0]);
            }
        });
        cancelButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                VerifyMobileFromSignIn.this.mOtpClicked = false;
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private String parseCode(String message) {
        Matcher m = Pattern.compile("\\b\\d{7}\\b").matcher(message);
        String code = "";
        while (m.find()) {
            code = m.group(0);
        }
        return code;
    }

    protected void onStart() {
        super.onStart();
    }

    protected void onDestroy() {
        super.onDestroy();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(this.receiver);
    }

    public void onResume() {
        super.onResume();
        LocalBroadcastManager.getInstance(this).registerReceiver(this.receiver, new IntentFilter("otp"));
    }

    public void onPause() {
        super.onPause();
    }

    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
