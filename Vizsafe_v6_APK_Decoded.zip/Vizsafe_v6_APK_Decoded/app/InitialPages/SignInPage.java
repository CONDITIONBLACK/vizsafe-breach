package com.vizsafe.app.InitialPages;

import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.p001v4.app.ActivityCompat;
import android.support.p001v4.content.ContextCompat;
import android.support.p002v7.app.AppCompatActivity;
import android.support.p002v7.media.SystemMediaRouteProvider;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.analytics.ecommerce.ProductAction;
import com.google.android.gms.drive.DriveFile;
import com.google.android.gms.gcm.GoogleCloudMessaging;
import com.google.firebase.analytics.FirebaseAnalytics.Param;
import com.vizsafe.app.APIClientMethods.RegisterGCMIdApi;
import com.vizsafe.app.APIClientMethods.RegisterGCMIdApi.ResponseRegisterGCMIdApi;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.GCMIntentService.GCMClientManager;
import com.vizsafe.app.HomePage.FeedPage;
import com.vizsafe.app.HomePage.MainActivity;
import com.vizsafe.app.Utils.CommonMember;
import com.vizsafe.app.Utils.Constants;
import com.vizsafe.app.Utils.PreferenceHandler;
import com.vizsafe.app.Utils.VizsafeGPSTracker;
import com.vizsafe.app.Utils.Webservice;
import dmax.dialog.SpotsDialog;
import java.io.IOException;
import org.json.JSONException;
import org.json.JSONObject;
import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class SignInPage extends AppCompatActivity {
    private static final String COURSE_LOCATION = "android.permission.ACCESS_COARSE_LOCATION";
    private static final String FINE_LOCATION = "android.permission.ACCESS_FINE_LOCATION";
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1234;
    private static final String TAG = "SignInPage";
    private boolean AllPermissionGranted = false;
    private ImageView cancelBtn;
    private Context context = null;
    private String email;
    private EditText emailSignIn;
    private Button forgotPasswordBtn;
    private GoogleCloudMessaging gcm = null;
    private VizsafeGPSTracker gps;
    private boolean gps_enabled;
    String mAuthyId = null;
    private boolean mCallPermission = false;
    private boolean mCameraPermission = false;
    Boolean mClicked = Boolean.valueOf(false);
    String mDisplayName;
    String mEmailResponse = null;
    private boolean mGallerypermission = false;
    private JSONObject mJsonResponse;
    private boolean mLocationPermissionsGranted = false;
    String mMaxDuration;
    String mMobileNumber = null;
    private String mServerName = "";
    String mSuperUser = "false";
    private TextView mTitle;
    private AlertDialog mTransparentProgressDialog;
    String mUserName = "null";
    String mUuid;
    private TextView mVerifyMobile;
    private boolean mVideoPermission = false;
    private EditText mZoneSignIn;
    private EditText passwordSignIn;
    private String regid = null;
    private Button signInBtn;
    SignInPage signInScreen;
    private Button signupBtn;
    Boolean successStatus = Boolean.valueOf(false);

    /* renamed from: com.vizsafe.app.InitialPages.SignInPage$1 */
    class C03511 implements OnClickListener {
        C03511() {
        }

        public void onClick(View v) {
            if (SignInPage.this.emailSignIn.getText().toString().trim().isEmpty()) {
                SignInPage.this.emailSignIn.setError(SignInPage.this.getString(C0421R.string.error_enter_email));
            } else if (SignInPage.this.passwordSignIn.getText().toString().trim().isEmpty()) {
                SignInPage.this.passwordSignIn.setError(SignInPage.this.getString(C0421R.string.error_enter_password));
            } else if (SignInPage.this.passwordSignIn.getText().toString().trim().length() < 4) {
                SignInPage.this.passwordSignIn.setError(SignInPage.this.getString(C0421R.string.error_password_length));
            } else {
                CommonMember.hideKeyboard(SignInPage.this);
                if (!SignInPage.this.mZoneSignIn.getText().toString().trim().isEmpty()) {
                    SignInPage.this.mServerName = SignInPage.this.mZoneSignIn.getText().toString().trim();
                }
                if (CommonMember.isNetworkOnline((ConnectivityManager) SignInPage.this.getSystemService("connectivity"), SignInPage.this)) {
                    SignInPage.this.email = SignInPage.this.emailSignIn.getText().toString().trim();
                    String password = SignInPage.this.passwordSignIn.getText().toString().trim();
                    if (SignInPage.this.AllPermissionGranted) {
                        if (!SignInPage.this.mClicked.booleanValue()) {
                            SignInPage.this.mClicked = Boolean.valueOf(true);
                            new AsyncTaskSignIn(SignInPage.this, null).execute(new String[0]);
                            return;
                        }
                        return;
                    } else if (SignInPage.this.checkPermission()) {
                        SignInPage.this.AllPermissionGranted = true;
                        new AsyncTaskSignIn(SignInPage.this, null).execute(new String[0]);
                        return;
                    } else {
                        Toast.makeText(SignInPage.this.getApplicationContext(), "Permission needed", 1).show();
                        SignInPage.this.requestPermission();
                        return;
                    }
                }
                CommonMember.getErrorDialog(SignInPage.this.getString(C0421R.string.no_internet_access), SignInPage.this.signInScreen).show();
            }
        }
    }

    /* renamed from: com.vizsafe.app.InitialPages.SignInPage$2 */
    class C03522 implements OnClickListener {
        C03522() {
        }

        public void onClick(View v) {
            SignInPage.this.startActivity(new Intent(SignInPage.this, SignUpPage.class));
        }
    }

    /* renamed from: com.vizsafe.app.InitialPages.SignInPage$3 */
    class C03533 implements OnClickListener {
        C03533() {
        }

        public void onClick(View v) {
            SignInPage.this.startActivity(new Intent(SignInPage.this, ForgotPasswordScreen.class));
        }
    }

    /* renamed from: com.vizsafe.app.InitialPages.SignInPage$4 */
    class C03544 implements Callback<ResponseRegisterGCMIdApi> {
        C03544() {
        }

        public void success(ResponseRegisterGCMIdApi responseRegisterGCMIdApi, Response response) {
            if (SignInPage.this.mTransparentProgressDialog != null && SignInPage.this.mTransparentProgressDialog.isShowing()) {
                SignInPage.this.mTransparentProgressDialog.dismiss();
            }
            if (responseRegisterGCMIdApi.getHttpCode().intValue() == 200) {
                Toast.makeText(SignInPage.this.getApplicationContext(), responseRegisterGCMIdApi.getMessage(), 0).show();
                PreferenceHandler.getInstance(SignInPage.this.signInScreen).setLoginTypeSignIn(Boolean.valueOf(true));
                PreferenceHandler.getInstance(SignInPage.this.signInScreen).setUserDisplayName(SignInPage.this.mDisplayName);
                PreferenceHandler.getInstance(SignInPage.this.signInScreen).setUserUUID(SignInPage.this.mUuid);
                PreferenceHandler.getInstance(SignInPage.this.signInScreen).setPassword(SignInPage.this.passwordSignIn.getText().toString().trim());
                PreferenceHandler.getInstance(SignInPage.this).setSuperUser(SignInPage.this.successStatus);
                PreferenceHandler.getInstance(SignInPage.this).setUserName(SignInPage.this.mUserName);
                PreferenceHandler.getInstance(SignInPage.this.signInScreen).setMaxVideoDuration(Integer.parseInt(SignInPage.this.mMaxDuration));
                PreferenceHandler.getInstance(SignInPage.this.signInScreen).setUserEmail(SignInPage.this.mEmailResponse);
                if (!(SignInPage.this.mAuthyId == null || SignInPage.this.mAuthyId.isEmpty())) {
                    PreferenceHandler.getInstance(SignInPage.this).setAuthyId(SignInPage.this.mAuthyId);
                }
                if (!(SignInPage.this.mMobileNumber == null || SignInPage.this.mAuthyId == null || SignInPage.this.mMobileNumber.isEmpty() || SignInPage.this.mAuthyId.isEmpty())) {
                    PreferenceHandler.getInstance(SignInPage.this).setMobileNumber(SignInPage.this.mMobileNumber);
                }
                FeedPage.loadFeedPage = true;
                SignInPage.this.startActivity(new Intent(SignInPage.this, MainActivity.class));
                SignInPage.this.finish();
                return;
            }
            SignInPage.this.mClicked = Boolean.valueOf(false);
            if (SignInPage.this.mTransparentProgressDialog != null && SignInPage.this.mTransparentProgressDialog.isShowing()) {
                SignInPage.this.mTransparentProgressDialog.dismiss();
            }
            Toast.makeText(SignInPage.this.getApplicationContext(), responseRegisterGCMIdApi.getMessage(), 0).show();
        }

        public void failure(RetrofitError error) {
            SignInPage.this.mClicked = Boolean.valueOf(false);
            if (SignInPage.this.mTransparentProgressDialog != null && SignInPage.this.mTransparentProgressDialog.isShowing()) {
                SignInPage.this.mTransparentProgressDialog.dismiss();
            }
            error.printStackTrace();
        }
    }

    /* renamed from: com.vizsafe.app.InitialPages.SignInPage$5 */
    class C03555 extends AsyncTask {
        C03555() {
        }

        protected Object doInBackground(Object[] objects) {
            String msg = "";
            try {
                if (SignInPage.this.gcm == null) {
                    SignInPage.this.gcm = GoogleCloudMessaging.getInstance(SignInPage.this.context);
                }
                SignInPage.this.regid = SignInPage.this.gcm.register(Constants.PROJECT_NUMBER);
                msg = "Device registered, registration ID=" + SignInPage.this.regid;
                PreferenceHandler.getInstance(SignInPage.this).setRegisterId(SignInPage.this.regid);
                SignInPage.this.AsyncTaskRegister();
                return msg;
            } catch (IOException ex) {
                return "Error :" + ex.getMessage();
            }
        }
    }

    private class AsyncTaskSignIn extends AsyncTask<String, String, String> {
        JSONObject response;

        private AsyncTaskSignIn() {
        }

        /* synthetic */ AsyncTaskSignIn(SignInPage x0, C03511 x1) {
            this();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            SignInPage.this.mTransparentProgressDialog.show();
        }

        protected String doInBackground(String... arg0) {
            this.response = new Webservice().LoginUser(SignInPage.this.getApplicationContext(), SignInPage.this.emailSignIn.getText().toString().trim(), SignInPage.this.passwordSignIn.getText().toString().trim(), SignInPage.this.mServerName);
            return null;
        }

        protected void onPostExecute(String result) {
            if (this.response != null) {
                try {
                    SignInPage.this.mJsonResponse = new JSONObject(String.valueOf(this.response));
                    SignInPage.this.DoBackgroundProcess(SignInPage.this.mJsonResponse);
                    return;
                } catch (JSONException e) {
                    e.printStackTrace();
                    return;
                }
            }
            if (SignInPage.this.mTransparentProgressDialog != null && SignInPage.this.mTransparentProgressDialog.isShowing()) {
                SignInPage.this.mTransparentProgressDialog.dismiss();
            }
            SignInPage.this.mClicked = Boolean.valueOf(false);
            Toast.makeText(SignInPage.this.getApplicationContext(), SignInPage.this.getResources().getString(C0421R.string.invalidusernameandpassword), 1).show();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0421R.layout.activity_sign_in_screen);
        this.signInScreen = this;
        this.signInScreen = this;
        this.context = getApplicationContext();
        this.signInBtn = (Button) findViewById(C0421R.C0419id.signin_btn);
        this.emailSignIn = (EditText) findViewById(C0421R.C0419id.email_signin);
        this.passwordSignIn = (EditText) findViewById(C0421R.C0419id.password_signin);
        this.forgotPasswordBtn = (Button) findViewById(C0421R.C0419id.btn_forgot_password);
        this.signupBtn = (Button) findViewById(C0421R.C0419id.signup_btn);
        this.mZoneSignIn = (EditText) findViewById(C0421R.C0419id.zone_signin);
        this.mTransparentProgressDialog = new SpotsDialog((Context) this, getResources().getString(C0421R.string.please_wait_loading));
        this.mTransparentProgressDialog.setCanceledOnTouchOutside(false);
        this.mTransparentProgressDialog.setCancelable(false);
        this.gps = new VizsafeGPSTracker(this);
        this.gps_enabled = ((LocationManager) getApplicationContext().getSystemService(Param.LOCATION)).isProviderEnabled("gps");
        this.signInBtn.setOnClickListener(new C03511());
        this.signupBtn.setOnClickListener(new C03522());
        this.forgotPasswordBtn.setOnClickListener(new C03533());
    }

    @TargetApi(23)
    private void requestPermission() {
        requestPermissions(new String[]{"android.permission.CAMERA", "android.permission.READ_EXTERNAL_STORAGE", "android.permission.CALL_PHONE", "android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.RECORD_AUDIO", COURSE_LOCATION, FINE_LOCATION}, 101);
    }

    private void getLocationPermission() {
        Log.d(TAG, "getLocationPermission: getting location permissions");
        String[] permissions = new String[]{FINE_LOCATION, COURSE_LOCATION};
        if (ContextCompat.checkSelfPermission(getApplicationContext(), FINE_LOCATION) != 0) {
            ActivityCompat.requestPermissions(this, permissions, LOCATION_PERMISSION_REQUEST_CODE);
        } else if (ContextCompat.checkSelfPermission(getApplicationContext(), COURSE_LOCATION) == 0) {
            this.mLocationPermissionsGranted = true;
            if (checkPermission()) {
                this.AllPermissionGranted = true;
            } else {
                requestPermission();
            }
        } else {
            ActivityCompat.requestPermissions(this, permissions, LOCATION_PERMISSION_REQUEST_CODE);
        }
    }

    public boolean checkPermission() {
        int camera = ContextCompat.checkSelfPermission(getApplicationContext(), "android.permission.CAMERA");
        int read_external = ContextCompat.checkSelfPermission(getApplicationContext(), "android.permission.READ_EXTERNAL_STORAGE");
        int call_per = ContextCompat.checkSelfPermission(getApplicationContext(), "android.permission.CALL_PHONE");
        int write_external = ContextCompat.checkSelfPermission(getApplicationContext(), "android.permission.WRITE_EXTERNAL_STORAGE");
        int record_video = ContextCompat.checkSelfPermission(getApplicationContext(), "android.permission.RECORD_AUDIO");
        int Coarse_loc = ContextCompat.checkSelfPermission(getApplicationContext(), COURSE_LOCATION);
        int fine_loc = ContextCompat.checkSelfPermission(getApplicationContext(), FINE_LOCATION);
        if (fine_loc == 0) {
            this.mLocationPermissionsGranted = true;
        }
        if (call_per == 0) {
            this.mCallPermission = true;
        }
        if (camera == 0 && write_external == 0) {
            this.mCameraPermission = true;
        }
        if (camera == 0 && write_external == 0 && record_video == 0) {
            this.mVideoPermission = true;
        }
        if (read_external == 0 && write_external == 0) {
            this.mGallerypermission = true;
        }
        if (camera == 0 && read_external == 0 && call_per == 0 && write_external == 0 && record_video == 0 && Coarse_loc == 0 && fine_loc == 0) {
            return true;
        }
        return false;
    }

    private void DoBackgroundProcess(JSONObject mJsonResponse) {
        try {
            int httpCode = mJsonResponse.getInt("httpCode");
            String mMessage = mJsonResponse.getString(GCMClientManager.EXTRA_MESSAGE);
            if (httpCode == 200) {
                JSONObject mDetail = mJsonResponse.getJSONObject(ProductAction.ACTION_DETAIL);
                this.mDisplayName = mDetail.getString("displayname");
                this.mUuid = mDetail.getString("uuid");
                if (mDetail.has("maxVideoDuration")) {
                    this.mMaxDuration = mDetail.getString("maxVideoDuration");
                    if (this.mMaxDuration == null || this.mMaxDuration.isEmpty()) {
                        this.mMaxDuration = "60";
                    } else {
                        this.mMaxDuration = this.mMaxDuration;
                    }
                } else {
                    this.mMaxDuration = "60";
                }
                if (mDetail.has("superuser")) {
                    this.mSuperUser = mDetail.getString("superuser");
                    if (this.mSuperUser == null || !this.mSuperUser.equals("true")) {
                        this.successStatus = Boolean.valueOf(false);
                    } else {
                        this.successStatus = Boolean.valueOf(true);
                    }
                } else {
                    this.successStatus = Boolean.valueOf(false);
                }
                if (mDetail.has("username")) {
                    this.mUserName = mDetail.getString("username");
                } else {
                    this.mUserName = this.emailSignIn.getText().toString().trim();
                }
                if (mDetail.has("mobilenumber")) {
                    this.mMobileNumber = mDetail.getString("mobilenumber");
                }
                if (mDetail.has("email")) {
                    this.mEmailResponse = mDetail.getString("email");
                }
                if (mDetail.has("authyid")) {
                    this.mAuthyId = mDetail.getString("authyid");
                }
                if (this.mZoneSignIn.getText().toString().trim().isEmpty()) {
                    this.mServerName = Constants.INITIALSERVER;
                } else {
                    this.mServerName = this.mZoneSignIn.getText().toString().trim();
                }
                PreferenceHandler.getInstance(this.signInScreen).setServerName(this.mServerName.trim());
                AsyncTaskRegister();
                return;
            }
            if (this.mTransparentProgressDialog != null && this.mTransparentProgressDialog.isShowing()) {
                this.mTransparentProgressDialog.dismiss();
            }
            Toast.makeText(getApplicationContext(), mMessage, 1).show();
            this.mClicked = Boolean.valueOf(false);
        } catch (JSONException e) {
            this.mClicked = Boolean.valueOf(false);
            if (this.mTransparentProgressDialog != null && this.mTransparentProgressDialog.isShowing()) {
                this.mTransparentProgressDialog.dismiss();
            }
            Toast.makeText(getApplicationContext(), getResources().getString(C0421R.string.invalidusernameandpassword), 1).show();
            e.printStackTrace();
        }
    }

    private void AsyncTaskRegister() {
        String uuid = this.mUuid;
        String mRegisterId = PreferenceHandler.getInstance(this.signInScreen).getRegisterId();
        String mDeviceType = SystemMediaRouteProvider.PACKAGE_NAME;
        if (mRegisterId == null || mRegisterId.isEmpty() || mRegisterId.equals("null")) {
            new C03555().execute(new Object[]{null, null, null});
            return;
        }
        RegisterGCMIdApi.getInstance().Callresponse(this.signInScreen, uuid, mRegisterId, mDeviceType, new C03544());
    }

    @TargetApi(23)
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case 101:
                if (grantResults.length > 0) {
                    boolean CameraPermission;
                    boolean CallPermission;
                    boolean AccessFineLocationPermission;
                    if (grantResults[0] == 0) {
                        CameraPermission = true;
                    } else {
                        CameraPermission = false;
                    }
                    boolean ReadExternalPermission;
                    if (grantResults[1] == 0) {
                        ReadExternalPermission = true;
                    } else {
                        ReadExternalPermission = false;
                    }
                    if (grantResults[2] == 0) {
                        CallPermission = true;
                    } else {
                        CallPermission = false;
                    }
                    boolean WriteExternalPermission;
                    if (grantResults[3] == 0) {
                        WriteExternalPermission = true;
                    } else {
                        WriteExternalPermission = false;
                    }
                    boolean RecordAudioPermission;
                    if (grantResults[4] == 0) {
                        RecordAudioPermission = true;
                    } else {
                        RecordAudioPermission = false;
                    }
                    if (grantResults[5] == 0) {
                        boolean AccessCoarseLocationPermission = true;
                    } else {
                        int i = 0;
                    }
                    if (grantResults[6] == 0) {
                        AccessFineLocationPermission = true;
                    } else {
                        AccessFineLocationPermission = false;
                    }
                    if (AccessFineLocationPermission) {
                        this.mLocationPermissionsGranted = true;
                        return;
                    } else if (CameraPermission && ReadExternalPermission && WriteExternalPermission) {
                        this.mCameraPermission = true;
                        return;
                    } else if (CameraPermission && RecordAudioPermission && ReadExternalPermission && WriteExternalPermission) {
                        this.mVideoPermission = true;
                        return;
                    } else if (CallPermission) {
                        this.mCallPermission = true;
                        return;
                    } else {
                        Toast.makeText(getApplicationContext(), "Permission Denied", 1).show();
                        return;
                    }
                }
                return;
            default:
                return;
        }
    }

    public void onBackPressed() {
        super.onBackPressed();
        Intent startMain = new Intent("android.intent.action.MAIN");
        startMain.addCategory("android.intent.category.HOME");
        startMain.setFlags(DriveFile.MODE_READ_ONLY);
        startActivity(startMain);
        finish();
    }
}
