package com.vizsafe.app.InitialPages;

import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.p001v4.app.ActivityCompat;
import android.support.p001v4.content.ContextCompat;
import android.support.p001v4.content.LocalBroadcastManager;
import android.support.p002v7.app.AppCompatActivity;
import android.support.p002v7.media.SystemMediaRouteProvider;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.analytics.ecommerce.ProductAction;
import com.google.android.gms.gcm.GoogleCloudMessaging;
import com.google.firebase.analytics.FirebaseAnalytics.Param;
import com.vizsafe.app.APIClientMethods.RegisterGCMIdApi;
import com.vizsafe.app.APIClientMethods.RegisterGCMIdApi.ResponseRegisterGCMIdApi;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.GCMIntentService.GCMClientManager;
import com.vizsafe.app.HomePage.MainActivity;
import com.vizsafe.app.Utils.CommonMember;
import com.vizsafe.app.Utils.Constants;
import com.vizsafe.app.Utils.PreferenceHandler;
import com.vizsafe.app.Utils.VizsafeGPSTracker;
import com.vizsafe.app.Utils.Webservice;
import dmax.dialog.SpotsDialog;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONException;
import org.json.JSONObject;
import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class SignUpPage extends AppCompatActivity {
    private static final String COURSE_LOCATION = "android.permission.ACCESS_COARSE_LOCATION";
    private static final String FILE_NAME = "countrycode.txt";
    private static final String FINE_LOCATION = "android.permission.ACCESS_FINE_LOCATION";
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1234;
    private static final String TAG = "SignUp";
    private boolean AllPermissionGranted = false;
    ArrayList<String> CountryCodeList;
    ArrayList<String> CountryList;
    EditText OTPtext;
    private ImageView cancelBtn;
    private EditText confirmpasswordEditText;
    private Dialog dialog;
    private EditText displayNameEditText;
    private EditText emailEditText;
    private GoogleCloudMessaging gcm = null;
    private VizsafeGPSTracker gps;
    private boolean gps_enabled;
    private String mAuthyid;
    private boolean mCallPermission = false;
    private boolean mCameraPermission = false;
    private String mConfirmPassword;
    private String mCountryCode = null;
    private String mCountryName;
    private Spinner mCountrySpinnerSignUp;
    String mDisplayName;
    private String mDisplayname;
    private String mEmail;
    private String mEmailResponse = null;
    private boolean mGallerypermission = false;
    private JSONObject mJsonResponse;
    private boolean mLocationPermissionsGranted = false;
    String mMaxDuration;
    private String mMobileNumber = null;
    private EditText mMobileSignUp;
    private String mOtp;
    private boolean mOtpClicked = false;
    private String mPassword;
    private String mPhoneNumber;
    private boolean mReadSMSpermission = false;
    private boolean mReceiveSMSpermission = false;
    private String mServerName = "";
    private SignUpPage mSignup;
    String mSuperUser = "false";
    private TextView mTitle;
    private AlertDialog mTransparentProgressDialog;
    private String mUserid;
    String mUuid;
    private boolean mVideoPermission = false;
    private EditText mZoneSignUp;
    private EditText passwordEditText;
    private BroadcastReceiver receiver = new C03649();
    private String regid;
    private Button signUpBtn;
    Boolean successStatus = Boolean.valueOf(false);
    HashMap<String, String> userValues;

    /* renamed from: com.vizsafe.app.InitialPages.SignUpPage$1 */
    class C03561 implements OnItemSelectedListener {
        C03561() {
        }

        public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
            SignUpPage.this.mCountryName = (String) SignUpPage.this.CountryList.get(position);
            SignUpPage.this.mCountryCode = (String) SignUpPage.this.CountryCodeList.get(position);
            ((TextView) view).setTextColor(SignUpPage.this.getResources().getColor(C0421R.color.colorPrimary));
        }

        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    /* renamed from: com.vizsafe.app.InitialPages.SignUpPage$2 */
    class C03572 implements OnClickListener {
        C03572() {
        }

        public void onClick(View v) {
            SignUpPage.this.finish();
        }
    }

    /* renamed from: com.vizsafe.app.InitialPages.SignUpPage$3 */
    class C03583 implements OnClickListener {
        C03583() {
        }

        public void onClick(View v) {
            SignUpPage.this.mDisplayname = SignUpPage.this.displayNameEditText.getText().toString().trim();
            SignUpPage.this.mEmail = SignUpPage.this.emailEditText.getText().toString().trim();
            SignUpPage.this.mPassword = SignUpPage.this.passwordEditText.getText().toString().trim();
            SignUpPage.this.mConfirmPassword = SignUpPage.this.confirmpasswordEditText.getText().toString().trim();
            SignUpPage.this.mPhoneNumber = SignUpPage.this.mMobileSignUp.getText().toString().trim();
            if (SignUpPage.this.mDisplayname.isEmpty() || SignUpPage.this.mDisplayname == null) {
                SignUpPage.this.displayNameEditText.setError(SignUpPage.this.getString(C0421R.string.error_enter_display_name));
            } else if (SignUpPage.this.mDisplayname.length() < 2) {
                SignUpPage.this.displayNameEditText.setError(SignUpPage.this.getString(C0421R.string.error_display_name_length));
            } else if (SignUpPage.this.mEmail.isEmpty() || SignUpPage.this.mEmail == null) {
                SignUpPage.this.emailEditText.setError(SignUpPage.this.getString(C0421R.string.error_enter_email));
            } else if (!SignUpPage.this.mEmail.matches(Constants.emailPattern)) {
                SignUpPage.this.emailEditText.setError(SignUpPage.this.getString(C0421R.string.error_enter_email));
            } else if (SignUpPage.this.mPassword.isEmpty() || SignUpPage.this.mPassword == null) {
                SignUpPage.this.passwordEditText.setError(SignUpPage.this.getString(C0421R.string.error_enter_password));
            } else if (SignUpPage.this.mPassword.length() < 7) {
                SignUpPage.this.passwordEditText.setError(SignUpPage.this.getString(C0421R.string.error_password_length));
            } else if (SignUpPage.this.mConfirmPassword.isEmpty() || SignUpPage.this.mConfirmPassword == null) {
                SignUpPage.this.confirmpasswordEditText.setError(SignUpPage.this.getString(C0421R.string.error_enter_confirm_password));
            } else if (!SignUpPage.this.mPassword.equals(SignUpPage.this.mConfirmPassword)) {
                SignUpPage.this.confirmpasswordEditText.setError(SignUpPage.this.getString(C0421R.string.error_enter_password));
            } else if (SignUpPage.this.mPhoneNumber.length() != 10 || SignUpPage.this.mPhoneNumber.isEmpty()) {
                SignUpPage.this.mMobileSignUp.setError(SignUpPage.this.getString(C0421R.string.error_enter_phone_number));
            } else if (SignUpPage.this.mCountryCode.isEmpty() || SignUpPage.this.mCountryCode == null) {
                ((TextView) SignUpPage.this.mCountrySpinnerSignUp.getSelectedView()).setError(SignUpPage.this.getString(C0421R.string.error_enter_country));
            } else {
                if (SignUpPage.this.mZoneSignUp.getText().toString().trim().isEmpty()) {
                    SignUpPage.this.mServerName = "";
                } else {
                    SignUpPage.this.mServerName = SignUpPage.this.mZoneSignUp.getText().toString().trim();
                }
                CommonMember.hideKeyboard(SignUpPage.this);
                if (!CommonMember.isNetworkOnline((ConnectivityManager) SignUpPage.this.getSystemService("connectivity"), SignUpPage.this)) {
                    CommonMember.NetworkStatusAlert(SignUpPage.this);
                } else if (SignUpPage.this.AllPermissionGranted) {
                    new AsyncTaskSignUp(SignUpPage.this, null).execute(new String[0]);
                } else if (SignUpPage.this.checkPermission()) {
                    SignUpPage.this.AllPermissionGranted = true;
                    new AsyncTaskSignUp(SignUpPage.this, null).execute(new String[0]);
                } else {
                    Toast.makeText(SignUpPage.this.getApplicationContext(), "Permission needed", 1).show();
                    SignUpPage.this.requestPermission();
                }
            }
        }
    }

    /* renamed from: com.vizsafe.app.InitialPages.SignUpPage$4 */
    class C03594 implements Callback<ResponseRegisterGCMIdApi> {
        C03594() {
        }

        public void success(ResponseRegisterGCMIdApi responseRegisterGCMIdApi, Response response) {
            SignUpPage.this.mTransparentProgressDialog.dismiss();
            if (responseRegisterGCMIdApi.getHttpCode().intValue() == 200) {
                Toast.makeText(SignUpPage.this.getApplicationContext(), responseRegisterGCMIdApi.getMessage(), 0).show();
                SignUpPage.this.startActivity(new Intent(SignUpPage.this.mSignup, MainActivity.class));
                SignUpPage.this.finish();
                return;
            }
            SignUpPage.this.mTransparentProgressDialog.dismiss();
            Toast.makeText(SignUpPage.this.getApplicationContext(), responseRegisterGCMIdApi.getMessage(), 0).show();
        }

        public void failure(RetrofitError error) {
            SignUpPage.this.mTransparentProgressDialog.dismiss();
            error.printStackTrace();
        }
    }

    /* renamed from: com.vizsafe.app.InitialPages.SignUpPage$5 */
    class C03605 extends AsyncTask {
        C03605() {
        }

        protected Object doInBackground(Object[] objects) {
            String msg = "";
            try {
                if (SignUpPage.this.gcm == null) {
                    SignUpPage.this.gcm = GoogleCloudMessaging.getInstance(SignUpPage.this.mSignup);
                }
                SignUpPage.this.regid = SignUpPage.this.gcm.register(Constants.PROJECT_NUMBER);
                msg = "Device registered, registration ID=" + SignUpPage.this.regid;
                PreferenceHandler.getInstance(SignUpPage.this).setRegisterId(SignUpPage.this.regid);
                SignUpPage.this.AsyncTaskRegister();
                return msg;
            } catch (IOException ex) {
                return "Error :" + ex.getMessage();
            }
        }
    }

    /* renamed from: com.vizsafe.app.InitialPages.SignUpPage$6 */
    class C03616 implements OnClickListener {
        C03616() {
        }

        public void onClick(View v) {
            SignUpPage.this.dialog.dismiss();
            new AsyncTaskResend(SignUpPage.this, null).execute(new String[0]);
        }
    }

    /* renamed from: com.vizsafe.app.InitialPages.SignUpPage$7 */
    class C03627 implements OnClickListener {
        C03627() {
        }

        public void onClick(View v) {
            if (SignUpPage.this.OTPtext.getText().toString().isEmpty()) {
                SignUpPage.this.OTPtext.setError("Please enter valid OTP code");
                return;
            }
            SignUpPage.this.mOtp = SignUpPage.this.OTPtext.getText().toString();
            new AsyncTaskVerifyOtp(SignUpPage.this, null).execute(new String[0]);
        }
    }

    /* renamed from: com.vizsafe.app.InitialPages.SignUpPage$8 */
    class C03638 implements OnClickListener {
        C03638() {
        }

        public void onClick(View v) {
            SignUpPage.this.mOtpClicked = false;
            SignUpPage.this.dialog.dismiss();
        }
    }

    /* renamed from: com.vizsafe.app.InitialPages.SignUpPage$9 */
    class C03649 extends BroadcastReceiver {
        C03649() {
        }

        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equalsIgnoreCase("otp")) {
                String code = SignUpPage.this.parseCode(intent.getStringExtra(GCMClientManager.EXTRA_MESSAGE));
                if (SignUpPage.this.OTPtext != null) {
                    SignUpPage.this.OTPtext.setText(code);
                    SignUpPage.this.OTPtext.setSelection(SignUpPage.this.OTPtext.getText().length());
                }
            }
        }
    }

    private class AsyncTaskResend extends AsyncTask<String, String, String> {
        JSONObject response;

        private AsyncTaskResend() {
        }

        /* synthetic */ AsyncTaskResend(SignUpPage x0, C03561 x1) {
            this();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            SignUpPage.this.mTransparentProgressDialog.show();
        }

        protected String doInBackground(String... arg0) {
            Webservice mWebservice = new Webservice();
            this.response = Webservice.ResendOtp(SignUpPage.this.mAuthyid);
            return null;
        }

        protected void onPostExecute(String result) {
            if (SignUpPage.this.mTransparentProgressDialog.isShowing()) {
                SignUpPage.this.mTransparentProgressDialog.dismiss();
            }
            if (this.response != null) {
                try {
                    SignUpPage.this.mJsonResponse = new JSONObject(String.valueOf(this.response));
                    try {
                        SignUpPage.this.showOTPDialog();
                        return;
                    } catch (Exception e) {
                        e.printStackTrace();
                        return;
                    }
                } catch (JSONException e2) {
                    e2.printStackTrace();
                    return;
                }
            }
            Toast.makeText(SignUpPage.this.getApplicationContext(), SignUpPage.this.getResources().getString(C0421R.string.unable_to_process_your_request), 1).show();
        }
    }

    private class AsyncTaskSignUp extends AsyncTask<String, String, String> {
        JSONObject response;

        private AsyncTaskSignUp() {
        }

        /* synthetic */ AsyncTaskSignUp(SignUpPage x0, C03561 x1) {
            this();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            SignUpPage.this.mTransparentProgressDialog.show();
        }

        protected String doInBackground(String... arg0) {
            String mEmail = SignUpPage.this.emailEditText.getText().toString().trim();
            String mPassword = SignUpPage.this.passwordEditText.getText().toString().trim();
            String mDisplayname = SignUpPage.this.displayNameEditText.getText().toString().trim();
            String base64email = Base64.encodeToString(mEmail.getBytes(), 10);
            String base64mPassword = Base64.encodeToString(mPassword.toString().getBytes(), 10);
            this.response = new Webservice().submitUser(SignUpPage.this.getApplicationContext(), base64email, Base64.encodeToString(mDisplayname.toString().getBytes(), 10), base64mPassword, Base64.encodeToString(SignUpPage.this.mServerName.toString().getBytes(), 10), Base64.encodeToString(SignUpPage.this.mPhoneNumber.toString().getBytes(), 10), Base64.encodeToString(SignUpPage.this.mCountryCode.toString().getBytes(), 10));
            return null;
        }

        protected void onPostExecute(String result) {
            if (SignUpPage.this.mTransparentProgressDialog.isShowing()) {
                SignUpPage.this.mTransparentProgressDialog.dismiss();
            }
            if (this.response != null) {
                try {
                    SignUpPage.this.mJsonResponse = new JSONObject(String.valueOf(this.response));
                    int httpCode = SignUpPage.this.mJsonResponse.getInt("httpCode");
                    String mMessage = SignUpPage.this.mJsonResponse.getString(GCMClientManager.EXTRA_MESSAGE);
                    Toast.makeText(SignUpPage.this.getApplicationContext(), mMessage, 0).show();
                    if (httpCode == 200) {
                        JSONObject mDetail = SignUpPage.this.mJsonResponse.getJSONObject(ProductAction.ACTION_DETAIL);
                        SignUpPage.this.mDisplayName = mDetail.getString("displayname");
                        SignUpPage.this.mUuid = mDetail.getString("uuid");
                        if (mDetail.has("superuser")) {
                            SignUpPage.this.mSuperUser = mDetail.getString("superuser");
                            if (SignUpPage.this.mSuperUser == null || !SignUpPage.this.mSuperUser.equals("true")) {
                                SignUpPage.this.successStatus = Boolean.valueOf(false);
                            } else {
                                SignUpPage.this.successStatus = Boolean.valueOf(true);
                            }
                        } else {
                            SignUpPage.this.successStatus = Boolean.valueOf(false);
                        }
                        if (mDetail.has("maxVideoDuration")) {
                            SignUpPage.this.mMaxDuration = mDetail.getString("maxVideoDuration");
                            if (SignUpPage.this.mMaxDuration == null || SignUpPage.this.mMaxDuration.isEmpty()) {
                                SignUpPage.this.mMaxDuration = "60";
                            } else {
                                SignUpPage.this.mMaxDuration = SignUpPage.this.mMaxDuration;
                            }
                        } else {
                            SignUpPage.this.mMaxDuration = "60";
                        }
                        if (mDetail.has("authyid")) {
                            SignUpPage.this.mAuthyid = mDetail.getString("authyid");
                        }
                        if (mDetail.has("mobilenumber")) {
                            SignUpPage.this.mMobileNumber = mDetail.getString("mobilenumber");
                        }
                        if (mDetail.has("email")) {
                            SignUpPage.this.mEmailResponse = mDetail.getString("email");
                        }
                        if (SignUpPage.this.mZoneSignUp.getText().toString().trim().isEmpty()) {
                            SignUpPage.this.mServerName = Constants.INITIALSERVER;
                        } else {
                            SignUpPage.this.mServerName = SignUpPage.this.mZoneSignUp.getText().toString().trim();
                        }
                        PreferenceHandler.getInstance(SignUpPage.this).setServerName(SignUpPage.this.mServerName);
                        SignUpPage.this.showOTPDialog();
                        return;
                    }
                    Toast.makeText(SignUpPage.this.getApplicationContext(), mMessage, 1).show();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private class AsyncTaskVerifyOtp extends AsyncTask<String, String, String> {
        JSONObject response;

        private AsyncTaskVerifyOtp() {
        }

        /* synthetic */ AsyncTaskVerifyOtp(SignUpPage x0, C03561 x1) {
            this();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            SignUpPage.this.mTransparentProgressDialog.show();
        }

        protected String doInBackground(String... arg0) {
            SignUpPage.this.mUserid = SignUpPage.this.mUuid;
            SignUpPage.this.mOtp = "o" + SignUpPage.this.mOtp;
            this.response = new Webservice().VerifyOtp(SignUpPage.this.getApplicationContext(), SignUpPage.this.mUserid, SignUpPage.this.mOtp, SignUpPage.this.mAuthyid);
            return null;
        }

        protected void onPostExecute(String result) {
            if (SignUpPage.this.mTransparentProgressDialog.isShowing()) {
                SignUpPage.this.mTransparentProgressDialog.dismiss();
            }
            InputMethodManager imm = (InputMethodManager) SignUpPage.this.getSystemService("input_method");
            View view = SignUpPage.this.getCurrentFocus();
            if (view == null) {
                view = new View(SignUpPage.this.getApplicationContext());
            }
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
            if (this.response != null) {
                try {
                    SignUpPage.this.mJsonResponse = new JSONObject(String.valueOf(this.response));
                    try {
                        int httpCode = SignUpPage.this.mJsonResponse.getInt("httpCode");
                        String mMessage = SignUpPage.this.mJsonResponse.getString(GCMClientManager.EXTRA_MESSAGE);
                        if (httpCode == 200) {
                            SignUpPage.this.dialog.dismiss();
                            JSONObject mDetail = SignUpPage.this.mJsonResponse.getJSONObject(ProductAction.ACTION_DETAIL);
                            SignUpPage.this.mDisplayName = mDetail.getString("displayname");
                            SignUpPage.this.mUuid = mDetail.getString("uuid");
                            if (mDetail.has("authyid")) {
                                SignUpPage.this.mAuthyid = mDetail.getString("authyid");
                            }
                            if (mDetail.has("mobilenumber")) {
                                SignUpPage.this.mMobileNumber = mDetail.getString("mobilenumber");
                            }
                            if (mDetail.has("email")) {
                                SignUpPage.this.mEmailResponse = mDetail.getString("email");
                            }
                            PreferenceHandler.getInstance(SignUpPage.this).setVerifiedOTPForSignUp(Boolean.valueOf(true));
                            PreferenceHandler.getInstance(SignUpPage.this).setUserName(SignUpPage.this.emailEditText.getText().toString().trim());
                            PreferenceHandler.getInstance(SignUpPage.this).setUserDisplayName(SignUpPage.this.mDisplayName);
                            PreferenceHandler.getInstance(SignUpPage.this).setPassword(SignUpPage.this.passwordEditText.getText().toString().trim());
                            PreferenceHandler.getInstance(SignUpPage.this).setUserUUID(SignUpPage.this.mUuid);
                            PreferenceHandler.getInstance(SignUpPage.this).setSuperUser(SignUpPage.this.successStatus);
                            PreferenceHandler.getInstance(SignUpPage.this).setMaxVideoDuration(Integer.parseInt(SignUpPage.this.mMaxDuration));
                            PreferenceHandler.getInstance(SignUpPage.this).setLoginTypeSignIn(Boolean.valueOf(true));
                            PreferenceHandler.getInstance(SignUpPage.this).setUserEmail(SignUpPage.this.mEmailResponse);
                            if (!(SignUpPage.this.mAuthyid == null || SignUpPage.this.mAuthyid.isEmpty())) {
                                PreferenceHandler.getInstance(SignUpPage.this).setAuthyId(SignUpPage.this.mAuthyid);
                            }
                            if (!(SignUpPage.this.mMobileNumber == null || SignUpPage.this.mAuthyid == null)) {
                                if (!(SignUpPage.this.mMobileNumber.isEmpty() || SignUpPage.this.mAuthyid.isEmpty())) {
                                    PreferenceHandler.getInstance(SignUpPage.this).setMobileNumber(SignUpPage.this.mMobileNumber);
                                }
                            }
                            SignUpPage.this.mOtpClicked = false;
                            SignUpPage.this.AsyncTaskRegister();
                            return;
                        }
                        Toast.makeText(SignUpPage.this.mSignup, mMessage, 0).show();
                        return;
                    } catch (Exception e) {
                        e.printStackTrace();
                        return;
                    }
                } catch (JSONException e2) {
                    e2.printStackTrace();
                    return;
                }
            }
            Toast.makeText(SignUpPage.this.getApplicationContext(), SignUpPage.this.getResources().getString(C0421R.string.unable_to_process_your_request), 1).show();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0421R.layout.activity_sign_up_screen);
        this.mSignup = this;
        this.mTransparentProgressDialog = new SpotsDialog((Context) this, getResources().getString(C0421R.string.please_wait_loading));
        this.mTransparentProgressDialog.setCanceledOnTouchOutside(false);
        this.mTransparentProgressDialog.setCancelable(false);
        this.signUpBtn = (Button) findViewById(C0421R.C0419id.signup_btn);
        this.cancelBtn = (ImageView) findViewById(C0421R.C0419id.action_bar_back);
        this.displayNameEditText = (EditText) findViewById(C0421R.C0419id.display_name_signup);
        this.mTitle = (TextView) findViewById(2131689653);
        this.emailEditText = (EditText) findViewById(C0421R.C0419id.email_signup);
        this.passwordEditText = (EditText) findViewById(C0421R.C0419id.password_signup);
        this.confirmpasswordEditText = (EditText) findViewById(C0421R.C0419id.confirm_password_signup);
        this.mZoneSignUp = (EditText) findViewById(C0421R.C0419id.zone_signup);
        this.mMobileSignUp = (EditText) findViewById(C0421R.C0419id.mobile_signup);
        this.mCountrySpinnerSignUp = (Spinner) findViewById(C0421R.C0419id.country_spinner_signup);
        this.gps = new VizsafeGPSTracker(this);
        this.gps_enabled = ((LocationManager) getApplicationContext().getSystemService(Param.LOCATION)).isProviderEnabled("gps");
        ReadFile(FILE_NAME);
        this.mTitle.setText(getString(C0421R.string.signup));
        this.mCountrySpinnerSignUp.setOnItemSelectedListener(new C03561());
        this.cancelBtn.setOnClickListener(new C03572());
        this.signUpBtn.setOnClickListener(new C03583());
    }

    /* JADX WARNING: Unknown top exception splitter block from list: {B:16:0x00df=Splitter:B:16:0x00df, B:23:0x011f=Splitter:B:23:0x011f} */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x00e4 A:{SYNTHETIC, Splitter:B:19:0x00e4} */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x0124 A:{SYNTHETIC, Splitter:B:26:0x0124} */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x0161 A:{SYNTHETIC, Splitter:B:31:0x0161} */
    public void ReadFile(java.lang.String r24) {
        /*
        r23 = this;
        r0 = r23;
        r0 = r0.CountryList;
        r19 = r0;
        if (r19 == 0) goto L_0x001a;
    L_0x0008:
        r0 = r23;
        r0 = r0.CountryList;
        r19 = r0;
        r19.clear();
        r0 = r23;
        r0 = r0.CountryCodeList;
        r19 = r0;
        r19.clear();
    L_0x001a:
        r19 = new java.util.ArrayList;
        r19.<init>();
        r0 = r19;
        r1 = r23;
        r1.CountryList = r0;
        r19 = new java.util.ArrayList;
        r19.<init>();
        r0 = r19;
        r1 = r23;
        r1.CountryCodeList = r0;
        r14 = 0;
        r19 = r23.getAssets();	 Catch:{ IOException -> 0x00de, NullPointerException -> 0x011e }
        r0 = r19;
        r1 = r24;
        r9 = r0.open(r1);	 Catch:{ IOException -> 0x00de, NullPointerException -> 0x011e }
        r15 = new java.io.BufferedReader;	 Catch:{ IOException -> 0x00de, NullPointerException -> 0x011e }
        r19 = new java.io.InputStreamReader;	 Catch:{ IOException -> 0x00de, NullPointerException -> 0x011e }
        r0 = r19;
        r0.<init>(r9);	 Catch:{ IOException -> 0x00de, NullPointerException -> 0x011e }
        r0 = r19;
        r15.<init>(r0);	 Catch:{ IOException -> 0x00de, NullPointerException -> 0x011e }
        r13 = r15.readLine();	 Catch:{ IOException -> 0x01ac, NullPointerException -> 0x01a8, all -> 0x01a5 }
        r11 = 0;
    L_0x0050:
        if (r13 == 0) goto L_0x00a1;
    L_0x0052:
        r13 = r15.readLine();	 Catch:{ IOException -> 0x01ac, NullPointerException -> 0x01a8, all -> 0x01a5 }
        r19 = "number=";
        r0 = r19;
        r17 = r13.split(r0);	 Catch:{ IOException -> 0x01ac, NullPointerException -> 0x01a8, all -> 0x01a5 }
        r19 = 1;
        r16 = r17[r19];	 Catch:{ IOException -> 0x01ac, NullPointerException -> 0x01a8, all -> 0x01a5 }
        r19 = "</option>";
        r0 = r16;
        r1 = r19;
        r18 = r0.split(r1);	 Catch:{ IOException -> 0x01ac, NullPointerException -> 0x01a8, all -> 0x01a5 }
        r19 = 0;
        r10 = r18[r19];	 Catch:{ IOException -> 0x01ac, NullPointerException -> 0x01a8, all -> 0x01a5 }
        r0 = r23;
        r0 = r0.CountryList;	 Catch:{ IOException -> 0x01ac, NullPointerException -> 0x01a8, all -> 0x01a5 }
        r19 = r0;
        r0 = r19;
        r0.add(r10);	 Catch:{ IOException -> 0x01ac, NullPointerException -> 0x01a8, all -> 0x01a5 }
        r19 = "\\+";
        r0 = r19;
        r4 = r10.split(r0);	 Catch:{ IOException -> 0x01ac, NullPointerException -> 0x01a8, all -> 0x01a5 }
        r19 = 1;
        r6 = r4[r19];	 Catch:{ IOException -> 0x01ac, NullPointerException -> 0x01a8, all -> 0x01a5 }
        r19 = "\\)";
        r0 = r19;
        r5 = r6.split(r0);	 Catch:{ IOException -> 0x01ac, NullPointerException -> 0x01a8, all -> 0x01a5 }
        r19 = 0;
        r7 = r5[r19];	 Catch:{ IOException -> 0x01ac, NullPointerException -> 0x01a8, all -> 0x01a5 }
        r0 = r23;
        r0 = r0.CountryCodeList;	 Catch:{ IOException -> 0x01ac, NullPointerException -> 0x01a8, all -> 0x01a5 }
        r19 = r0;
        r0 = r19;
        r0.add(r7);	 Catch:{ IOException -> 0x01ac, NullPointerException -> 0x01a8, all -> 0x01a5 }
        r11 = r11 + 1;
        goto L_0x0050;
    L_0x00a1:
        if (r15 == 0) goto L_0x00a6;
    L_0x00a3:
        r15.close();	 Catch:{ IOException -> 0x019b }
    L_0x00a6:
        r3 = new android.widget.ArrayAdapter;
        r19 = r23.getApplicationContext();
        r20 = 17367048; // 0x1090008 float:2.5162948E-38 double:8.580462E-317;
        r0 = r23;
        r0 = r0.CountryList;
        r21 = r0;
        r0 = r19;
        r1 = r20;
        r2 = r21;
        r3.<init>(r0, r1, r2);
        r19 = 17367049; // 0x1090009 float:2.516295E-38 double:8.5804623E-317;
        r0 = r19;
        r3.setDropDownViewResource(r0);
        r0 = r23;
        r0 = r0.mCountrySpinnerSignUp;
        r19 = r0;
        r0 = r19;
        r0.setAdapter(r3);
        r0 = r23;
        r0 = r0.mCountrySpinnerSignUp;
        r19 = r0;
        r20 = 0;
        r19.setSelection(r20);
        r14 = r15;
    L_0x00dd:
        return;
    L_0x00de:
        r12 = move-exception;
    L_0x00df:
        r12.printStackTrace();	 Catch:{ all -> 0x015e }
        if (r14 == 0) goto L_0x00e7;
    L_0x00e4:
        r14.close();	 Catch:{ IOException -> 0x019e }
    L_0x00e7:
        r3 = new android.widget.ArrayAdapter;
        r19 = r23.getApplicationContext();
        r20 = 17367048; // 0x1090008 float:2.5162948E-38 double:8.580462E-317;
        r0 = r23;
        r0 = r0.CountryList;
        r21 = r0;
        r0 = r19;
        r1 = r20;
        r2 = r21;
        r3.<init>(r0, r1, r2);
        r19 = 17367049; // 0x1090009 float:2.516295E-38 double:8.5804623E-317;
        r0 = r19;
        r3.setDropDownViewResource(r0);
        r0 = r23;
        r0 = r0.mCountrySpinnerSignUp;
        r19 = r0;
        r0 = r19;
        r0.setAdapter(r3);
        r0 = r23;
        r0 = r0.mCountrySpinnerSignUp;
        r19 = r0;
        r20 = 0;
        r19.setSelection(r20);
        goto L_0x00dd;
    L_0x011e:
        r8 = move-exception;
    L_0x011f:
        r8.printStackTrace();	 Catch:{ all -> 0x015e }
        if (r14 == 0) goto L_0x0127;
    L_0x0124:
        r14.close();	 Catch:{ IOException -> 0x01a1 }
    L_0x0127:
        r3 = new android.widget.ArrayAdapter;
        r19 = r23.getApplicationContext();
        r20 = 17367048; // 0x1090008 float:2.5162948E-38 double:8.580462E-317;
        r0 = r23;
        r0 = r0.CountryList;
        r21 = r0;
        r0 = r19;
        r1 = r20;
        r2 = r21;
        r3.<init>(r0, r1, r2);
        r19 = 17367049; // 0x1090009 float:2.516295E-38 double:8.5804623E-317;
        r0 = r19;
        r3.setDropDownViewResource(r0);
        r0 = r23;
        r0 = r0.mCountrySpinnerSignUp;
        r19 = r0;
        r0 = r19;
        r0.setAdapter(r3);
        r0 = r23;
        r0 = r0.mCountrySpinnerSignUp;
        r19 = r0;
        r20 = 0;
        r19.setSelection(r20);
        goto L_0x00dd;
    L_0x015e:
        r19 = move-exception;
    L_0x015f:
        if (r14 == 0) goto L_0x0164;
    L_0x0161:
        r14.close();	 Catch:{ IOException -> 0x01a3 }
    L_0x0164:
        r3 = new android.widget.ArrayAdapter;
        r20 = r23.getApplicationContext();
        r21 = 17367048; // 0x1090008 float:2.5162948E-38 double:8.580462E-317;
        r0 = r23;
        r0 = r0.CountryList;
        r22 = r0;
        r0 = r20;
        r1 = r21;
        r2 = r22;
        r3.<init>(r0, r1, r2);
        r20 = 17367049; // 0x1090009 float:2.516295E-38 double:8.5804623E-317;
        r0 = r20;
        r3.setDropDownViewResource(r0);
        r0 = r23;
        r0 = r0.mCountrySpinnerSignUp;
        r20 = r0;
        r0 = r20;
        r0.setAdapter(r3);
        r0 = r23;
        r0 = r0.mCountrySpinnerSignUp;
        r20 = r0;
        r21 = 0;
        r20.setSelection(r21);
        throw r19;
    L_0x019b:
        r19 = move-exception;
        goto L_0x00a6;
    L_0x019e:
        r19 = move-exception;
        goto L_0x00e7;
    L_0x01a1:
        r19 = move-exception;
        goto L_0x0127;
    L_0x01a3:
        r20 = move-exception;
        goto L_0x0164;
    L_0x01a5:
        r19 = move-exception;
        r14 = r15;
        goto L_0x015f;
    L_0x01a8:
        r8 = move-exception;
        r14 = r15;
        goto L_0x011f;
    L_0x01ac:
        r12 = move-exception;
        r14 = r15;
        goto L_0x00df;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.vizsafe.app.InitialPages.SignUpPage.ReadFile(java.lang.String):void");
    }

    private void getLocationPermission() {
        Log.d(TAG, "getLocationPermission: getting location permissions");
        String[] permissions = new String[]{FINE_LOCATION, COURSE_LOCATION};
        if (ContextCompat.checkSelfPermission(getApplicationContext(), FINE_LOCATION) != 0) {
            ActivityCompat.requestPermissions(this, permissions, LOCATION_PERMISSION_REQUEST_CODE);
        } else if (ContextCompat.checkSelfPermission(getApplicationContext(), COURSE_LOCATION) == 0) {
            this.mLocationPermissionsGranted = true;
            if (checkPermission()) {
                this.AllPermissionGranted = true;
            } else {
                requestPermission();
            }
        } else {
            ActivityCompat.requestPermissions(this, permissions, LOCATION_PERMISSION_REQUEST_CODE);
        }
    }

    @TargetApi(23)
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case 101:
                if (grantResults.length > 0) {
                    boolean CameraPermission;
                    boolean CallPermission;
                    boolean AccessFineLocationPermission;
                    boolean ReadSMSPermission;
                    boolean ReceiveSMSPermission;
                    if (grantResults[0] == 0) {
                        CameraPermission = true;
                    } else {
                        CameraPermission = false;
                    }
                    boolean ReadExternalPermission;
                    if (grantResults[1] == 0) {
                        ReadExternalPermission = true;
                    } else {
                        ReadExternalPermission = false;
                    }
                    if (grantResults[2] == 0) {
                        CallPermission = true;
                    } else {
                        CallPermission = false;
                    }
                    boolean WriteExternalPermission;
                    if (grantResults[3] == 0) {
                        WriteExternalPermission = true;
                    } else {
                        WriteExternalPermission = false;
                    }
                    boolean RecordAudioPermission;
                    if (grantResults[4] == 0) {
                        RecordAudioPermission = true;
                    } else {
                        RecordAudioPermission = false;
                    }
                    if (grantResults[5] == 0) {
                        boolean AccessCoarseLocationPermission = true;
                    } else {
                        int i = 0;
                    }
                    if (grantResults[6] == 0) {
                        AccessFineLocationPermission = true;
                    } else {
                        AccessFineLocationPermission = false;
                    }
                    if (grantResults[7] == 0) {
                        ReadSMSPermission = true;
                    } else {
                        ReadSMSPermission = false;
                    }
                    if (grantResults[8] == 0) {
                        ReceiveSMSPermission = true;
                    } else {
                        ReceiveSMSPermission = false;
                    }
                    if (AccessFineLocationPermission) {
                        this.mLocationPermissionsGranted = true;
                        return;
                    } else if (CameraPermission && ReadExternalPermission && WriteExternalPermission) {
                        this.mCameraPermission = true;
                        return;
                    } else if (CameraPermission && RecordAudioPermission && ReadExternalPermission && WriteExternalPermission) {
                        this.mVideoPermission = true;
                        return;
                    } else if (CallPermission) {
                        this.mCallPermission = true;
                        return;
                    } else if (ReadSMSPermission) {
                        this.mReadSMSpermission = true;
                        return;
                    } else if (ReceiveSMSPermission) {
                        this.mReceiveSMSpermission = true;
                        return;
                    } else {
                        Toast.makeText(getApplicationContext(), "Permission Denied", 1).show();
                        return;
                    }
                }
                return;
            default:
                return;
        }
    }

    @TargetApi(23)
    private void requestPermission() {
        requestPermissions(new String[]{"android.permission.CAMERA", "android.permission.READ_EXTERNAL_STORAGE", "android.permission.CALL_PHONE", "android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.RECORD_AUDIO", COURSE_LOCATION, FINE_LOCATION, "android.permission.READ_SMS", "android.permission.RECEIVE_SMS"}, 101);
    }

    private void AsyncTaskRegister() {
        this.mTransparentProgressDialog.show();
        String uuid = this.mUuid;
        String mRegisterId = PreferenceHandler.getInstance(this.mSignup).getRegisterId();
        String mDeviceType = SystemMediaRouteProvider.PACKAGE_NAME;
        if (mRegisterId == null || mRegisterId.isEmpty() || mRegisterId.equals("null")) {
            new C03605().execute(new Object[]{null, null, null});
            return;
        }
        RegisterGCMIdApi.getInstance().Callresponse(this.mSignup, uuid, mRegisterId, mDeviceType, new C03594());
    }

    public boolean checkPermission() {
        int camera = ContextCompat.checkSelfPermission(getApplicationContext(), "android.permission.CAMERA");
        int read_external = ContextCompat.checkSelfPermission(getApplicationContext(), "android.permission.READ_EXTERNAL_STORAGE");
        int call_per = ContextCompat.checkSelfPermission(getApplicationContext(), "android.permission.CALL_PHONE");
        int write_external = ContextCompat.checkSelfPermission(getApplicationContext(), "android.permission.WRITE_EXTERNAL_STORAGE");
        int record_video = ContextCompat.checkSelfPermission(getApplicationContext(), "android.permission.RECORD_AUDIO");
        int Coarse_loc = ContextCompat.checkSelfPermission(getApplicationContext(), COURSE_LOCATION);
        int fine_loc = ContextCompat.checkSelfPermission(getApplicationContext(), FINE_LOCATION);
        int receive_sms = ContextCompat.checkSelfPermission(getApplicationContext(), "android.permission.RECEIVE_SMS");
        int read_sms = ContextCompat.checkSelfPermission(getApplicationContext(), "android.permission.READ_SMS");
        if (fine_loc == 0) {
            this.mLocationPermissionsGranted = true;
        }
        if (call_per == 0) {
            this.mCallPermission = true;
        }
        if (camera == 0 && write_external == 0) {
            this.mCameraPermission = true;
        }
        if (camera == 0 && write_external == 0 && record_video == 0) {
            this.mVideoPermission = true;
        }
        if (read_external == 0 && write_external == 0) {
            this.mGallerypermission = true;
        }
        if (read_sms == 0 && write_external == 0) {
            this.mReadSMSpermission = true;
        }
        if (receive_sms == 0 && write_external == 0) {
            this.mReceiveSMSpermission = true;
        }
        if (camera == 0 && read_external == 0 && call_per == 0 && write_external == 0 && record_video == 0 && Coarse_loc == 0 && fine_loc == 0 && read_sms == 0 && receive_sms == 0) {
            return true;
        }
        return false;
    }

    public void showOTPDialog() {
        this.dialog = new Dialog(this.mSignup);
        this.dialog.requestWindowFeature(1);
        this.dialog.setCancelable(false);
        this.dialog.setContentView(C0421R.layout.otp_layout);
        this.dialog.setTitle(getResources().getString(C0421R.string.app_name));
        this.OTPtext = (EditText) this.dialog.findViewById(C0421R.C0419id.otp_signup);
        Button dialogButton = (Button) this.dialog.findViewById(C0421R.C0419id.verify_otp_btn);
        ImageView cancelButton = (ImageView) this.dialog.findViewById(C0421R.C0419id.close_button);
        ((TextView) this.dialog.findViewById(C0421R.C0419id.resend_otp)).setOnClickListener(new C03616());
        dialogButton.setOnClickListener(new C03627());
        cancelButton.setOnClickListener(new C03638());
        this.dialog.show();
    }

    private String parseCode(String message) {
        Matcher m = Pattern.compile("\\b\\d{7}\\b").matcher(message);
        String code = "";
        while (m.find()) {
            code = m.group(0);
        }
        return code;
    }

    protected void onStart() {
        super.onStart();
    }

    protected void onDestroy() {
        super.onDestroy();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(this.receiver);
    }

    public void onResume() {
        super.onResume();
        LocalBroadcastManager.getInstance(this).registerReceiver(this.receiver, new IntentFilter("otp"));
    }

    public void onPause() {
        super.onPause();
    }

    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
