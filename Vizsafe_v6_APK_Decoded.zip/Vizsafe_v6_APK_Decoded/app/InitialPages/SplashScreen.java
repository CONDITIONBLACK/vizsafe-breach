package com.vizsafe.app.InitialPages;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.support.p001v4.content.ContextCompat;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.gcm.GoogleCloudMessaging;
import com.google.firebase.auth.PhoneAuthProvider;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.HomePage.MainActivity;
import com.vizsafe.app.Utils.Constants;
import com.vizsafe.app.Utils.PreferenceHandler;
import java.io.IOException;
import java.util.UUID;

public class SplashScreen extends Activity {
    public static String DEVICE_ID = "";
    private static int SPLASH_TIME_OUT = 2000;
    private static final String TAG = "SplashScreen";
    private Context context = null;
    private GoogleCloudMessaging gcm = null;
    private BroadcastReceiver mRegistrationBroadcastReceiver;
    private String regid = null;

    /* renamed from: com.vizsafe.app.InitialPages.SplashScreen$1 */
    class C03651 implements Runnable {
        C03651() {
        }

        public void run() {
            if (PreferenceHandler.getInstance(SplashScreen.this).getUserName().equals("") && PreferenceHandler.getInstance(SplashScreen.this).getPassword().equals("")) {
                SplashScreen.this.startActivity(new Intent(SplashScreen.this, SignInPage.class));
            } else {
                String[] arrayStr = PreferenceHandler.getInstance(SplashScreen.this).getUserName().trim().split("/");
                Intent i = new Intent(SplashScreen.this, MainActivity.class);
                Bundle passValue = new Bundle();
                passValue.putString("incident_uuid_from_notification", "");
                i.addFlags(603979776);
                i.putExtras(passValue);
                SplashScreen.this.startActivity(i);
            }
            SplashScreen.this.finish();
        }
    }

    /* renamed from: com.vizsafe.app.InitialPages.SplashScreen$2 */
    class C03662 extends AsyncTask {
        C03662() {
        }

        protected Object doInBackground(Object[] objects) {
            String msg = "";
            try {
                if (SplashScreen.this.gcm == null) {
                    SplashScreen.this.gcm = GoogleCloudMessaging.getInstance(SplashScreen.this.context);
                }
                SplashScreen.this.regid = SplashScreen.this.gcm.register(Constants.PROJECT_NUMBER);
                msg = "Device registered, registration ID=" + SplashScreen.this.regid;
                PreferenceHandler.getInstance(SplashScreen.this).setRegisterId(SplashScreen.this.regid);
                return msg;
            } catch (IOException ex) {
                return "Error :" + ex.getMessage();
            }
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0421R.layout.activity_splash_screen);
        this.context = getApplicationContext();
        if (!checkPlayServices()) {
            Toast.makeText(this, getResources().getString(C0421R.string.google_play_update), 1).show();
        }
        register();
        DEVICE_ID = getDeviceSn(this);
        new Handler().postDelayed(new C03651(), (long) SPLASH_TIME_OUT);
    }

    private boolean checkPlayServices() {
        GoogleApiAvailability apiAvailability = GoogleApiAvailability.getInstance();
        int resultCode = apiAvailability.isGooglePlayServicesAvailable(this);
        if (resultCode == 0) {
            return true;
        }
        if (apiAvailability.isUserResolvableError(resultCode)) {
            apiAvailability.getErrorDialog(this, resultCode, Constants.PLAY_SERVICES_RESOLUTION_REQUEST).show();
        } else {
            Log.i(TAG, "This device is not supported.");
            finish();
        }
        return false;
    }

    @SuppressLint({"HardwareIds"})
    public static String getDeviceSn(Context context) {
        String deviceSN = "";
        if (ContextCompat.checkSelfPermission(context, "android.permission.READ_PHONE_STATE") != 0) {
            return null;
        }
        if (((TelephonyManager) context.getSystemService(PhoneAuthProvider.PROVIDER_ID)).getDeviceId() != null) {
            deviceSN = ((TelephonyManager) context.getSystemService(PhoneAuthProvider.PROVIDER_ID)).getDeviceId();
        } else if (VERSION.SDK_INT >= 9 && Build.SERIAL != null) {
            deviceSN = Build.SERIAL;
        }
        if (deviceSN.length() == 0) {
            deviceSN = UUID.randomUUID().toString();
        }
        return deviceSN;
    }

    private void register() {
        this.regid = PreferenceHandler.getInstance(this).getRegisterId();
        if (this.regid == null) {
            new C03662().execute(new Object[]{null, null, null});
        }
    }
}
