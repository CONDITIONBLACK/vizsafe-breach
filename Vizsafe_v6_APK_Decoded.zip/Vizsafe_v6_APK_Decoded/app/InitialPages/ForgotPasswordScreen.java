package com.vizsafe.app.InitialPages;

import android.annotation.TargetApi;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.p001v4.content.ContextCompat;
import android.support.p001v4.content.LocalBroadcastManager;
import android.support.p002v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.analytics.ecommerce.ProductAction;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.GCMIntentService.GCMClientManager;
import com.vizsafe.app.Utils.CommonMember;
import com.vizsafe.app.Utils.Constants;
import com.vizsafe.app.Utils.PreferenceHandler;
import com.vizsafe.app.Utils.Webservice;
import dmax.dialog.SpotsDialog;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONException;
import org.json.JSONObject;

public class ForgotPasswordScreen extends AppCompatActivity {
    private boolean AllPermissionGranted = false;
    private EditText OTPtext;
    private ImageView cancelBtn;
    private EditText enterEmail;
    ForgotPasswordScreen forgotPasswordScreen;
    private Integer mAuthyId;
    private String mEmail;
    private String mOtp;
    private boolean mOtpClicked = false;
    private boolean mReadSMSpermission = false;
    private boolean mReceiveSMSpermission = false;
    private TextView mTitle;
    private SpotsDialog mTransparentProgressDialog;
    private BroadcastReceiver receiver = new C03507();
    private Button sendBtn;

    /* renamed from: com.vizsafe.app.InitialPages.ForgotPasswordScreen$1 */
    class C03441 implements OnClickListener {
        C03441() {
        }

        public void onClick(View v) {
            if (ForgotPasswordScreen.this.enterEmail.getText().toString().trim().isEmpty() || !ForgotPasswordScreen.this.enterEmail.getText().toString().trim().matches(Constants.emailPattern)) {
                ForgotPasswordScreen.this.enterEmail.setError(ForgotPasswordScreen.this.getString(C0421R.string.error_enter_email));
            } else if (ForgotPasswordScreen.this.checkPermission()) {
                ForgotPasswordScreen.this.AllPermissionGranted = true;
                ForgotPasswordScreen.this.mEmail = ForgotPasswordScreen.this.enterEmail.getText().toString().trim();
                ForgotPasswordScreen.this.ForgotPasswordTask(ForgotPasswordScreen.this.mEmail);
            } else {
                Toast.makeText(ForgotPasswordScreen.this.getApplicationContext(), "Permission needed", 1).show();
                ForgotPasswordScreen.this.requestPermission();
            }
        }
    }

    /* renamed from: com.vizsafe.app.InitialPages.ForgotPasswordScreen$2 */
    class C03452 implements OnClickListener {
        C03452() {
        }

        public void onClick(View v) {
            ForgotPasswordScreen.this.finish();
        }
    }

    /* renamed from: com.vizsafe.app.InitialPages.ForgotPasswordScreen$3 */
    class C03463 implements OnFocusChangeListener {
        C03463() {
        }

        public void onFocusChange(View v, boolean hasFocus) {
            ForgotPasswordScreen.this.enterEmail.setError(null);
        }
    }

    /* renamed from: com.vizsafe.app.InitialPages.ForgotPasswordScreen$7 */
    class C03507 extends BroadcastReceiver {
        C03507() {
        }

        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equalsIgnoreCase("otp")) {
                String code = ForgotPasswordScreen.this.parseCode(intent.getStringExtra(GCMClientManager.EXTRA_MESSAGE));
                if (ForgotPasswordScreen.this.OTPtext != null) {
                    ForgotPasswordScreen.this.OTPtext.setText(code);
                    ForgotPasswordScreen.this.OTPtext.setSelection(ForgotPasswordScreen.this.OTPtext.getText().length());
                }
            }
        }
    }

    private class AsyncTaskForgotPassword extends AsyncTask<String, String, String> {
        JSONObject response;

        private AsyncTaskForgotPassword() {
        }

        /* synthetic */ AsyncTaskForgotPassword(ForgotPasswordScreen x0, C03441 x1) {
            this();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            ForgotPasswordScreen.this.mTransparentProgressDialog.show();
        }

        protected String doInBackground(String... arg0) {
            Webservice mWebservice = new Webservice();
            this.response = Webservice.ForgotPasswordAPI(ForgotPasswordScreen.this.mEmail);
            return null;
        }

        protected void onPostExecute(String result) {
            if (ForgotPasswordScreen.this.mTransparentProgressDialog.isShowing()) {
                ForgotPasswordScreen.this.mTransparentProgressDialog.dismiss();
            }
            if (this.response != null) {
                try {
                    JSONObject mJsonResponse = new JSONObject(String.valueOf(this.response));
                    try {
                        int httpCode = mJsonResponse.getInt("httpCode");
                        String mMessage = mJsonResponse.getString(GCMClientManager.EXTRA_MESSAGE);
                        if (httpCode == 200) {
                            ForgotPasswordScreen.this.mAuthyId = Integer.valueOf(mJsonResponse.getJSONObject(ProductAction.ACTION_DETAIL).getInt("authyid"));
                            ForgotPasswordScreen.this.showOTPDialog();
                            return;
                        }
                        Toast.makeText(ForgotPasswordScreen.this.forgotPasswordScreen, mMessage, 0).show();
                        return;
                    } catch (Exception e) {
                        e.printStackTrace();
                        return;
                    }
                } catch (JSONException e2) {
                    e2.printStackTrace();
                    return;
                }
            }
            Toast.makeText(ForgotPasswordScreen.this.getApplicationContext(), ForgotPasswordScreen.this.getResources().getString(C0421R.string.unable_to_process_your_request), 1).show();
        }
    }

    private class AsyncTaskResend extends AsyncTask<String, String, String> {
        JSONObject response;

        private AsyncTaskResend() {
        }

        /* synthetic */ AsyncTaskResend(ForgotPasswordScreen x0, C03441 x1) {
            this();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            ForgotPasswordScreen.this.mTransparentProgressDialog.show();
        }

        protected String doInBackground(String... arg0) {
            Webservice mWebservice = new Webservice();
            this.response = Webservice.ResendOtp(ForgotPasswordScreen.this.mAuthyId.toString());
            return null;
        }

        protected void onPostExecute(String result) {
            if (ForgotPasswordScreen.this.mTransparentProgressDialog.isShowing()) {
                ForgotPasswordScreen.this.mTransparentProgressDialog.dismiss();
            }
            if (this.response != null) {
                try {
                    JSONObject mJsonResponse = new JSONObject(String.valueOf(this.response));
                    try {
                        ForgotPasswordScreen.this.showOTPDialog();
                        return;
                    } catch (Exception e) {
                        e.printStackTrace();
                        return;
                    }
                } catch (JSONException e2) {
                    e2.printStackTrace();
                    return;
                }
            }
            Toast.makeText(ForgotPasswordScreen.this.getApplicationContext(), ForgotPasswordScreen.this.getResources().getString(C0421R.string.unable_to_process_your_request), 1).show();
        }
    }

    private class AsyncTaskVerifyOtp extends AsyncTask<String, String, String> {
        JSONObject response;

        private AsyncTaskVerifyOtp() {
        }

        /* synthetic */ AsyncTaskVerifyOtp(ForgotPasswordScreen x0, C03441 x1) {
            this();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            ForgotPasswordScreen.this.mTransparentProgressDialog.show();
        }

        protected String doInBackground(String... arg0) {
            String mUserid = PreferenceHandler.getInstance(ForgotPasswordScreen.this.forgotPasswordScreen).getUserUUID();
            ForgotPasswordScreen.this.mOtp = "o" + ForgotPasswordScreen.this.mOtp;
            this.response = new Webservice().VerifyOtpFromReset(ForgotPasswordScreen.this.getApplicationContext(), ForgotPasswordScreen.this.mEmail, ForgotPasswordScreen.this.mOtp, ForgotPasswordScreen.this.mAuthyId.toString());
            return null;
        }

        protected void onPostExecute(String result) {
            if (ForgotPasswordScreen.this.mTransparentProgressDialog.isShowing()) {
                ForgotPasswordScreen.this.mTransparentProgressDialog.dismiss();
            }
            if (this.response != null) {
                try {
                    JSONObject mJsonResponse = new JSONObject(String.valueOf(this.response));
                    try {
                        int httpCode = mJsonResponse.getInt("httpCode");
                        String mMessage = mJsonResponse.getString(GCMClientManager.EXTRA_MESSAGE);
                        if (httpCode == 200) {
                            ForgotPasswordScreen.this.mOtpClicked = false;
                            Toast.makeText(ForgotPasswordScreen.this, ForgotPasswordScreen.this.getResources().getString(C0421R.string.password_sent), 0).show();
                            return;
                        }
                        Toast.makeText(ForgotPasswordScreen.this.forgotPasswordScreen, mMessage, 0).show();
                        return;
                    } catch (Exception e) {
                        e.printStackTrace();
                        return;
                    }
                } catch (JSONException e2) {
                    e2.printStackTrace();
                    return;
                }
            }
            Toast.makeText(ForgotPasswordScreen.this.getApplicationContext(), ForgotPasswordScreen.this.getResources().getString(C0421R.string.unable_to_process_your_request), 1).show();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0421R.layout.activity_forgot_password);
        this.forgotPasswordScreen = this;
        this.sendBtn = (Button) findViewById(C0421R.C0419id.send_btn);
        this.cancelBtn = (ImageView) findViewById(C0421R.C0419id.action_bar_back);
        this.mTitle = (TextView) findViewById(2131689653);
        this.enterEmail = (EditText) findViewById(C0421R.C0419id.enter_email);
        this.mTransparentProgressDialog = new SpotsDialog(this);
        this.mTransparentProgressDialog.setCanceledOnTouchOutside(false);
        this.mTransparentProgressDialog.setCancelable(false);
        this.mTitle.setText(getString(C0421R.string.forgot_password));
        this.sendBtn.setOnClickListener(new C03441());
        this.cancelBtn.setOnClickListener(new C03452());
        this.enterEmail.setOnFocusChangeListener(new C03463());
    }

    @TargetApi(23)
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case 101:
                if (grantResults.length > 0) {
                    boolean ReadSMSPermission;
                    boolean ReceiveSMSPermission;
                    if (grantResults[0] == 0) {
                        ReadSMSPermission = true;
                    } else {
                        ReadSMSPermission = false;
                    }
                    if (grantResults[1] == 0) {
                        ReceiveSMSPermission = true;
                    } else {
                        ReceiveSMSPermission = false;
                    }
                    if (ReadSMSPermission) {
                        this.mReadSMSpermission = true;
                        return;
                    } else if (ReceiveSMSPermission) {
                        this.mReceiveSMSpermission = true;
                        return;
                    } else {
                        Toast.makeText(getApplicationContext(), "Permission Denied", 1).show();
                        return;
                    }
                }
                return;
            default:
                return;
        }
    }

    public boolean checkPermission() {
        int receive_sms = ContextCompat.checkSelfPermission(getApplicationContext(), "android.permission.RECEIVE_SMS");
        int read_sms = ContextCompat.checkSelfPermission(getApplicationContext(), "android.permission.READ_SMS");
        if (read_sms == 0) {
            this.mReadSMSpermission = true;
        }
        if (receive_sms == 0) {
            this.mReceiveSMSpermission = true;
        }
        if (read_sms == 0 && receive_sms == 0) {
            return true;
        }
        return false;
    }

    @TargetApi(23)
    private void requestPermission() {
        requestPermissions(new String[]{"android.permission.READ_SMS", "android.permission.RECEIVE_SMS"}, 101);
    }

    private void ForgotPasswordTask(String email) {
        CommonMember.hideKeyboard(this);
        if (CommonMember.isNetworkOnline((ConnectivityManager) getSystemService("connectivity"), this)) {
            new AsyncTaskForgotPassword(this, null).execute(new String[0]);
        } else {
            CommonMember.NetworkStatusAlert(this);
        }
    }

    public void showOTPDialog() {
        final Dialog dialog = new Dialog(this.forgotPasswordScreen);
        dialog.requestWindowFeature(1);
        dialog.setCancelable(false);
        dialog.setContentView(C0421R.layout.otp_layout);
        dialog.setTitle(getResources().getString(C0421R.string.app_name));
        this.OTPtext = (EditText) dialog.findViewById(C0421R.C0419id.otp_signup);
        Button dialogButton = (Button) dialog.findViewById(C0421R.C0419id.verify_otp_btn);
        ImageView cancelButton = (ImageView) dialog.findViewById(C0421R.C0419id.close_button);
        ((TextView) dialog.findViewById(C0421R.C0419id.resend_otp)).setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                dialog.dismiss();
                new AsyncTaskResend(ForgotPasswordScreen.this, null).execute(new String[0]);
            }
        });
        dialogButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                if (ForgotPasswordScreen.this.OTPtext.getText().toString().isEmpty()) {
                    ForgotPasswordScreen.this.OTPtext.setError("Please enter valid OTP code");
                    return;
                }
                dialog.dismiss();
                ForgotPasswordScreen.this.mOtpClicked = true;
                ForgotPasswordScreen.this.mOtp = ForgotPasswordScreen.this.OTPtext.getText().toString();
                new AsyncTaskVerifyOtp(ForgotPasswordScreen.this, null).execute(new String[0]);
            }
        });
        cancelButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                ForgotPasswordScreen.this.mOtpClicked = false;
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    private String parseCode(String message) {
        Matcher m = Pattern.compile("\\b\\d{7}\\b").matcher(message);
        String code = "";
        while (m.find()) {
            code = m.group(0);
        }
        return code;
    }

    protected void onStart() {
        super.onStart();
    }

    protected void onDestroy() {
        super.onDestroy();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(this.receiver);
    }

    public void onResume() {
        super.onResume();
        LocalBroadcastManager.getInstance(this).registerReceiver(this.receiver, new IntentFilter("otp"));
    }

    public void onPause() {
        super.onPause();
    }

    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
