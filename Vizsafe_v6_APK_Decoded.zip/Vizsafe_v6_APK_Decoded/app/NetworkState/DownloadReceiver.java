package com.vizsafe.app.NetworkState;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import com.vizsafe.app.Adapters.FeedListAdapter;
import com.vizsafe.app.Feeds.ReportDetails;
import com.vizsafe.app.HomePage.FeedPage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class DownloadReceiver extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        if (ReportDetails.DOWNLOAD_IMAGE) {
            ReportDetails.DOWNLOAD_IMAGE = false;
        } else if (FeedListAdapter.DOWNLOAD_IMAGE) {
            FeedListAdapter.DOWNLOAD_IMAGE = false;
        } else {
            if ("android.intent.action.DOWNLOAD_COMPLETE".equals(intent.getAction())) {
                Bitmap bitmap = null;
                File f = new File("/storage/sdcard0/VizsafeImages/fileName.jpg");
                Options options = new Options();
                options.inPreferredConfig = Config.ARGB_8888;
                try {
                    bitmap = BitmapFactory.decodeStream(new FileInputStream(f), null, options);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
                FeedPage.assignToContact(bitmap);
            }
        }
    }
}
