package com.vizsafe.app.NetworkState;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.util.Log;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.vizsafe.app.NetworkState.ConnectivityReceiver.ConnectivityReceiverListener;
import com.vizsafe.app.Outbox.OutboxSentPostItems;
import com.vizsafe.app.Utils.PreferenceHandler;
import com.vizsafe.app.Utils.Webservice;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONObject;

public class NetworkSchedulerService extends JobService implements ConnectivityReceiverListener {
    private static final String TAG = NetworkSchedulerService.class.getSimpleName();
    private static boolean firstConnect = true;
    ArrayList<OutboxSentPostItems> arrayList = new ArrayList();
    private ConnectivityReceiver mConnectivityReceiver;

    /* renamed from: com.vizsafe.app.NetworkState.NetworkSchedulerService$1 */
    class C03901 extends TypeToken<List<OutboxSentPostItems>> {
        C03901() {
        }
    }

    private class AsyncTaskPostFeed extends AsyncTask<String, String, JSONObject> {
        int position;
        JSONObject response;

        /* renamed from: com.vizsafe.app.NetworkState.NetworkSchedulerService$AsyncTaskPostFeed$1 */
        class C03911 extends TypeToken<List<OutboxSentPostItems>> {
            C03911() {
            }
        }

        public AsyncTaskPostFeed(int position) {
            this.position = position;
        }

        protected JSONObject doInBackground(String... params) {
            String email = PreferenceHandler.getInstance(NetworkSchedulerService.this.getApplicationContext()).getUserName();
            String password = PreferenceHandler.getInstance(NetworkSchedulerService.this.getApplicationContext()).getPassword();
            try {
                this.response = new Webservice().postFeedWebService(NetworkSchedulerService.this.getApplicationContext(), email, password, params[0]);
            } catch (Exception e) {
                e.printStackTrace();
                this.response = null;
            }
            return this.response;
        }

        protected void onPostExecute(JSONObject result) {
            super.onPostExecute(result);
            if (result != null) {
                Gson gson = new Gson();
                String jsonCars = PreferenceHandler.getInstance(NetworkSchedulerService.this.getApplicationContext()).getOutBoxSet();
                Type type = new C03911().getType();
                NetworkSchedulerService.this.arrayList = (ArrayList) gson.fromJson(jsonCars, type);
                if (NetworkSchedulerService.this.arrayList == null || NetworkSchedulerService.this.arrayList.size() <= 0) {
                    PreferenceHandler.getInstance(NetworkSchedulerService.this.getApplicationContext()).setOutBoxSet("");
                } else {
                    NetworkSchedulerService.this.arrayList.remove(NetworkSchedulerService.this.arrayList.size() - 1);
                    PreferenceHandler.getInstance(NetworkSchedulerService.this.getApplicationContext()).setOutBoxSet(gson.toJson(NetworkSchedulerService.this.arrayList));
                }
                NetworkSchedulerService.this.broadcastOutboxIntent();
            }
        }
    }

    public void onCreate() {
        super.onCreate();
        Log.i(TAG, "Service created");
        this.mConnectivityReceiver = new ConnectivityReceiver(this);
    }

    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.i(TAG, "onStartCommand");
        return 2;
    }

    public boolean onStartJob(JobParameters params) {
        Log.i(TAG, "onStartJob" + this.mConnectivityReceiver);
        registerReceiver(this.mConnectivityReceiver, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
        return true;
    }

    public boolean onStopJob(JobParameters params) {
        Log.i(TAG, "onStopJob");
        unregisterReceiver(this.mConnectivityReceiver);
        return true;
    }

    public void onNetworkConnectionChanged(boolean isConnected) {
        String message;
        if (isConnected) {
            message = "Good! Connected to Internet";
        } else {
            message = "Sorry! Not connected to internet";
        }
        if (!isConnected) {
            firstConnect = true;
        } else if (firstConnect && PreferenceHandler.getInstance(getApplicationContext()).getLoginTypeSignIn().booleanValue()) {
            this.arrayList = (ArrayList) new Gson().fromJson(PreferenceHandler.getInstance(this).getOutBoxSet(), new C03901().getType());
            if (this.arrayList != null && this.arrayList.size() > 0) {
                for (int i = 0; i < this.arrayList.size(); i++) {
                    String postData = ((OutboxSentPostItems) this.arrayList.get(i)).getSentMessageUrl();
                    new AsyncTaskPostFeed(i).execute(new String[]{postData});
                }
            }
            firstConnect = false;
        }
    }

    public void broadcastOutboxIntent() {
        Intent intent = new Intent();
        intent.setAction("com.vizsafe.UPDATE_OUTBOX");
        sendBroadcast(intent);
    }
}
