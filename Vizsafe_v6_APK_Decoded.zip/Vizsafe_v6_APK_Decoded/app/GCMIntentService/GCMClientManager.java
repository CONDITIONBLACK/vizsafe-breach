package com.vizsafe.app.GCMIntentService;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.AsyncTask;
import android.util.Log;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.gcm.GoogleCloudMessaging;
import com.google.android.gms.iid.InstanceID;
import java.io.IOException;

public class GCMClientManager {
    public static final String EXTRA_MESSAGE = "message";
    private static final int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;
    private static final String PROPERTY_APP_VERSION = "appVersion";
    public static final String PROPERTY_REG_ID = "registration_id";
    public static final String TAG = "GCMClientManager";
    private Activity activity;
    private GoogleCloudMessaging gcm;
    private String projectNumber;
    private String regid;

    public static abstract class RegistrationCompletedHandler {
        public abstract void onSuccess(String str, boolean z);

        public void onFailure(String ex) {
            Log.e(GCMClientManager.TAG, ex);
        }
    }

    public GCMClientManager(Activity activity, String projectNumber) {
        this.activity = activity;
        this.projectNumber = projectNumber;
        this.gcm = GoogleCloudMessaging.getInstance(activity);
    }

    private static int getAppVersion(Context context) {
        try {
            return context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode;
        } catch (NameNotFoundException e) {
            throw new RuntimeException("Could not get package name: " + e);
        }
    }

    public void registerIfNeeded(RegistrationCompletedHandler handler) {
        if (checkPlayServices()) {
            this.regid = getRegistrationId(getContext());
            if (this.regid.isEmpty()) {
                registerInBackground(handler);
                return;
            } else {
                handler.onSuccess(this.regid, false);
                return;
            }
        }
        Log.i(TAG, "No valid Google Play Services APK found.");
    }

    private void registerInBackground(final RegistrationCompletedHandler handler) {
        new AsyncTask<Void, Void, String>() {
            protected String doInBackground(Void... params) {
                try {
                    if (GCMClientManager.this.gcm == null) {
                        GCMClientManager.this.gcm = GoogleCloudMessaging.getInstance(GCMClientManager.this.getContext());
                    }
                    GCMClientManager.this.regid = InstanceID.getInstance(GCMClientManager.this.getContext()).getToken(GCMClientManager.this.projectNumber, GoogleCloudMessaging.INSTANCE_ID_SCOPE, null);
                    GCMClientManager.this.storeRegistrationId(GCMClientManager.this.getContext(), GCMClientManager.this.regid);
                } catch (IOException ex) {
                    handler.onFailure("Error :" + ex.getMessage());
                }
                return GCMClientManager.this.regid;
            }

            protected void onPostExecute(String regId) {
                if (regId != null) {
                    handler.onSuccess(regId, true);
                }
            }
        }.execute(new Void[]{null, null, null});
    }

    private String getRegistrationId(Context context) {
        SharedPreferences prefs = getGCMPreferences(context);
        String registrationId = prefs.getString(PROPERTY_REG_ID, "");
        if (registrationId.isEmpty()) {
            Log.i(TAG, "Registration not found.");
            return "";
        } else if (prefs.getInt(PROPERTY_APP_VERSION, Integer.MIN_VALUE) == getAppVersion(context)) {
            return registrationId;
        } else {
            Log.i(TAG, "App version changed.");
            return "";
        }
    }

    private void storeRegistrationId(Context context, String regId) {
        SharedPreferences prefs = getGCMPreferences(context);
        int appVersion = getAppVersion(context);
        Editor editor = prefs.edit();
        editor.putString(PROPERTY_REG_ID, regId);
        editor.putInt(PROPERTY_APP_VERSION, appVersion);
        editor.commit();
    }

    private SharedPreferences getGCMPreferences(Context context) {
        return getContext().getSharedPreferences(context.getPackageName(), 0);
    }

    private boolean checkPlayServices() {
        int resultCode = GooglePlayServicesUtil.isGooglePlayServicesAvailable(getContext());
        if (resultCode == 0) {
            return true;
        }
        if (GooglePlayServicesUtil.isUserRecoverableError(resultCode)) {
            GooglePlayServicesUtil.getErrorDialog(resultCode, getActivity(), 9000).show();
        } else {
            Log.i(TAG, "This device is not supported.");
        }
        return false;
    }

    private Context getContext() {
        return this.activity;
    }

    private Activity getActivity() {
        return this.activity;
    }
}
