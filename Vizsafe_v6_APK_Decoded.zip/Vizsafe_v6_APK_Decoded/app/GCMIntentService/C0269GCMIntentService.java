package com.vizsafe.app.GCMIntentService;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningTaskInfo;
import android.app.IntentService;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.media.RingtoneManager;
import android.os.Bundle;
import android.support.p001v4.app.NotificationCompat;
import android.support.p001v4.app.NotificationCompat.BigTextStyle;
import android.support.p001v4.app.NotificationCompat.Builder;
import android.support.p001v4.app.NotificationCompat.InboxStyle;
import android.support.p001v4.content.WakefulBroadcastReceiver;
import com.google.android.gms.plus.PlusShare;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.HomePage.MainActivity;
import com.vizsafe.app.Utils.PreferenceHandler;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;

/* renamed from: com.vizsafe.app.GCMIntentService.GCMIntentService */
public class C0269GCMIntentService extends IntentService {
    public static HashSet<String> mMessages = new HashSet();
    private NotificationManager mNotificationManager;

    public C0269GCMIntentService() {
        super("com.vizsafe.receiver.GCMIntentService");
    }

    protected void onHandleIntent(Intent intent) {
        Bundle extras = intent.getExtras();
        if (!extras.isEmpty()) {
            if (extras.getString("message_note") != null) {
                sendNotificationForUserAssignment(extras.getString("message_note"));
            } else if (extras.getString("incidentUUID") != null) {
                sendNotification(extras.getString(GCMClientManager.EXTRA_MESSAGE), extras.getString("incidentUUID"));
            }
        }
        WakefulBroadcastReceiver.completeWakefulIntent(intent);
    }

    public static void clear() {
        mMessages.clear();
    }

    private void sendNotification(String msg, String incidentUUID) {
        if (PreferenceHandler.getInstance(getApplicationContext()).getNotificationStatus() && PreferenceHandler.getInstance(getApplicationContext()).getLoginTypeSignIn().booleanValue()) {
            List<RunningTaskInfo> services = ((ActivityManager) getApplicationContext().getSystemService("activity")).getRunningTasks(Integer.MAX_VALUE);
            boolean isActivityFound = false;
            if (services.size() > 0 && ((RunningTaskInfo) services.get(0)).topActivity.getPackageName().toString().equalsIgnoreCase(getApplicationContext().getPackageName().toString())) {
                isActivityFound = true;
            }
            if (isActivityFound) {
                broadcastDialogIntent(msg, incidentUUID);
                return;
            }
            this.mNotificationManager = (NotificationManager) getSystemService("notification");
            Intent notificationIntent = new Intent(getApplicationContext(), MainActivity.class);
            Bundle passValue = new Bundle();
            passValue.putString("incident_uuid_from_notification", incidentUUID);
            notificationIntent.setAction("android.intent.action.MAIN");
            notificationIntent.addCategory("android.intent.category.LAUNCHER");
            notificationIntent.putExtras(passValue);
            notificationIntent.addFlags(603979776);
            PendingIntent intent = PendingIntent.getActivity(getApplicationContext(), 0, notificationIntent, 134217728);
            Builder mBuilder = new Builder(this);
            mBuilder.setSmallIcon(C0421R.C0418drawable.ic_launcher_vizsafe_icon).setContentTitle(getString(C0421R.string.app_name)).setStyle(new BigTextStyle().bigText(msg)).setContentText(msg).setAutoCancel(true).setSound(RingtoneManager.getDefaultUri(2));
            mMessages.add(msg);
            InboxStyle inBoxStyle = new InboxStyle();
            inBoxStyle.setBigContentTitle(getString(C0421R.string.app_name));
            int total = mMessages.size();
            if (total == 0) {
                C0269GCMIntentService.setBadge(this, 0);
            } else {
                C0269GCMIntentService.setBadge(this, total);
            }
            Iterator iterator = mMessages.iterator();
            while (iterator.hasNext()) {
                inBoxStyle.addLine((CharSequence) iterator.next());
            }
            mBuilder.setContentIntent(intent);
            mBuilder.setStyle(inBoxStyle);
            Notification notification = mBuilder.build();
            notification.flags |= 16;
            this.mNotificationManager.notify(0, notification);
        }
    }

    private void sendNotificationForUserAssignment(String msgNote) {
        if (msgNote != null && PreferenceHandler.getInstance(getApplicationContext()).getNotificationStatus() && PreferenceHandler.getInstance(getApplicationContext()).getLoginTypeSignIn().booleanValue()) {
            List<RunningTaskInfo> services = ((ActivityManager) getApplicationContext().getSystemService("activity")).getRunningTasks(Integer.MAX_VALUE);
            boolean isActivityFound = false;
            String msg = null;
            String incidentUUID = null;
            String mDisplayName = null;
            try {
                JSONObject mJsonResponse = new JSONObject(String.valueOf(msgNote));
                if (mJsonResponse.has(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_DESCRIPTION)) {
                    msg = mJsonResponse.getString(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_DESCRIPTION);
                }
                if (mJsonResponse.has("incidentid")) {
                    incidentUUID = mJsonResponse.getString("incidentid");
                }
                if (mJsonResponse.has("displayname")) {
                    mDisplayName = mJsonResponse.getString("displayname");
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            if (services.size() > 0 && ((RunningTaskInfo) services.get(0)).topActivity.getPackageName().toString().equalsIgnoreCase(getApplicationContext().getPackageName().toString())) {
                isActivityFound = true;
            }
            if (isActivityFound) {
                broadcastDialogIntentForUserAssignment(msg, incidentUUID, mDisplayName);
                return;
            }
            NotificationManager mNotificationManager1 = (NotificationManager) getSystemService("notification");
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            Bundle passValue = new Bundle();
            passValue.putString("incident_uuid_from_user_assignment_notification", incidentUUID);
            intent.setAction("android.intent.action.MAIN");
            intent.addCategory("android.intent.category.LAUNCHER");
            intent.putExtras(passValue);
            intent.addFlags(603979776);
            PendingIntent intent2 = PendingIntent.getActivity(getApplicationContext(), 0, intent, 134217728);
            Builder mBuilder = new Builder(this);
            mBuilder.setSmallIcon(C0421R.C0418drawable.ic_launcher_vizsafe_icon).setContentTitle(getString(C0421R.string.app_name)).setStyle(new BigTextStyle().bigText("New Task: " + msg)).setContentText("New Task: " + msg).setAutoCancel(true).setSound(RingtoneManager.getDefaultUri(2));
            mMessages.add("New Task: " + msg);
            InboxStyle inBoxStyle = new InboxStyle();
            inBoxStyle.setBigContentTitle(getString(C0421R.string.app_name));
            int total = mMessages.size();
            if (total == 0) {
                C0269GCMIntentService.setBadge(this, 0);
            } else {
                C0269GCMIntentService.setBadge(this, total);
            }
            Iterator iterator = mMessages.iterator();
            while (iterator.hasNext()) {
                inBoxStyle.addLine((CharSequence) iterator.next());
            }
            mBuilder.setContentIntent(intent2);
            mBuilder.setStyle(inBoxStyle);
            Notification notification = mBuilder.build();
            notification.flags |= 16;
            mNotificationManager1.notify(0, notification);
        }
    }

    public static void setBadge(Context context, int count) {
        String launcherClassName = C0269GCMIntentService.getLauncherClassName(context);
        if (launcherClassName != null) {
            Intent intent = new Intent("android.intent.action.BADGE_COUNT_UPDATE");
            intent.putExtra("badge_count", count);
            intent.putExtra("badge_count_package_name", context.getPackageName());
            intent.putExtra("badge_count_class_name", launcherClassName);
            context.sendBroadcast(intent);
        }
    }

    public static String getLauncherClassName(Context context) {
        PackageManager pm = context.getPackageManager();
        Intent intent = new Intent("android.intent.action.MAIN");
        intent.addCategory("android.intent.category.LAUNCHER");
        for (ResolveInfo resolveInfo : pm.queryIntentActivities(intent, 0)) {
            if (resolveInfo.activityInfo.applicationInfo.packageName.equalsIgnoreCase(context.getPackageName())) {
                return resolveInfo.activityInfo.name;
            }
        }
        return null;
    }

    public void broadcastDialogIntentForUserAssignment(String msg, String incidentUUID, String mDisplayName) {
        Intent intent = new Intent();
        Bundle passValue = new Bundle();
        passValue.putString("incident_uuid_from_user_assignment_notification", incidentUUID);
        passValue.putString(NotificationCompat.CATEGORY_MESSAGE, msg);
        passValue.putString("DisplayName", mDisplayName);
        intent.putExtras(passValue);
        intent.setAction("com.vizsafe.SHOW_DIALOG");
        sendBroadcast(intent);
    }

    public void broadcastDialogIntent(String msg, String incidentUUID) {
        Intent intent = new Intent();
        Bundle passValue = new Bundle();
        passValue.putString("incident_uuid_from_dialog", incidentUUID);
        passValue.putString(NotificationCompat.CATEGORY_MESSAGE, msg);
        intent.putExtras(passValue);
        intent.setAction("com.vizsafe.SHOW_DIALOG");
        sendBroadcast(intent);
    }
}
