package com.vizsafe.app.Channels;

import android.os.Bundle;
import android.support.p002v7.app.AppCompatActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import com.vizsafe.app.C0421R;

public class ChannelDetailScreen extends AppCompatActivity {
    private TextView channelDesc;
    private TextView channelTitle;
    private ImageView doneBtn;
    private TextView mTitle;
    private TextView memberShipStatus;

    /* renamed from: com.vizsafe.app.Channels.ChannelDetailScreen$1 */
    class C02101 implements OnClickListener {
        C02101() {
        }

        public void onClick(View v) {
            ChannelDetailScreen.this.finish();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0421R.layout.channel_detail_screen);
        this.doneBtn = (ImageView) findViewById(C0421R.C0419id.action_bar_back);
        this.channelTitle = (TextView) findViewById(C0421R.C0419id.channel_title);
        this.channelDesc = (TextView) findViewById(C0421R.C0419id.channel_description);
        this.memberShipStatus = (TextView) findViewById(C0421R.C0419id.memberShipStatus);
        this.mTitle = (TextView) findViewById(2131689653);
        this.mTitle.setText(getResources().getString(C0421R.string.channels));
        this.channelTitle.setText(getIntent().getExtras().getString("channel_name"));
        String channelDescription = getIntent().getExtras().getString("channel_description");
        if (channelDescription == null || channelDescription.isEmpty()) {
            this.channelDesc.setVisibility(8);
        } else {
            this.channelDesc.setText(channelDescription);
        }
        if (getIntent().getExtras().getBoolean("channel_member")) {
            this.memberShipStatus.setText(getResources().getString(C0421R.string.you_are_member));
        } else {
            this.memberShipStatus.setText(getResources().getString(C0421R.string.you_are_not_member));
        }
        this.doneBtn.setOnClickListener(new C02101());
    }
}
