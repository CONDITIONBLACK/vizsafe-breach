package com.vizsafe.app.Channels;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ListActivity;
import android.content.Context;
import android.content.DialogInterface;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Base64;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.analytics.ecommerce.ProductAction;
import com.google.gson.JsonObject;
import com.vizsafe.app.APIClientMethods.AllChannelsApi;
import com.vizsafe.app.APIClientMethods.AllChannelsApi.ResponseAllChannelsApi;
import com.vizsafe.app.APIClientMethods.FavouriteChannelsApi;
import com.vizsafe.app.APIClientMethods.FavouriteChannelsApi.Channel;
import com.vizsafe.app.APIClientMethods.FavouriteChannelsApi.Detail;
import com.vizsafe.app.APIClientMethods.FavouriteChannelsApi.ResponseFavouriteChannelsApi;
import com.vizsafe.app.APIClientMethods.JoinChannelApi;
import com.vizsafe.app.APIClientMethods.LeaveChannelApi;
import com.vizsafe.app.APIClientMethods.LeaveChannelApi.ResponseLeaveChannelApi;
import com.vizsafe.app.APIClientMethods.LeaveChannelDetailApi;
import com.vizsafe.app.APIClientMethods.VizsafeChannelsApi;
import com.vizsafe.app.APIClientMethods.VizsafeChannelsApi.ResponseVizsafeChannelsApi;
import com.vizsafe.app.Adapters.CustomChannelListAdapter;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.GCMIntentService.GCMClientManager;
import com.vizsafe.app.POJO.ChannelsListItem;
import com.vizsafe.app.POJO.Item;
import com.vizsafe.app.POJO.SectionItem;
import com.vizsafe.app.Utils.CommonMember;
import com.vizsafe.app.Utils.PreferenceHandler;
import dmax.dialog.SpotsDialog;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class ChannelsScreen extends ListActivity {
    CustomChannelListAdapter adapter;
    ArrayList<Item> allChannels = new ArrayList();
    private String authenticationString;
    String channelPictureUrl;
    ChannelsScreen channelScreen;
    private ImageView doneBtn;
    String email;
    ArrayList<ChannelsListItem> favouriteChannelItems = new ArrayList();
    String feedIcon;
    boolean isTipsChannel = false;
    ArrayList<Item> items = new ArrayList();
    private List<Channel> mChannelsList;
    JSONObject mJsonResponse;
    private TextView mTitle;
    private AlertDialog mTransparentProgressDialog;
    private String memberUuid;
    String password;
    Parcelable scrollState = null;
    ArrayList<Item> tipsChannel = new ArrayList();
    ArrayList<ChannelsListItem> tipsFavChannel = new ArrayList();
    String uuidForJoinOrLeave;
    ArrayList<Item> vizsafeChannel = new ArrayList();

    /* renamed from: com.vizsafe.app.Channels.ChannelsScreen$1 */
    class C02111 implements OnClickListener {
        C02111() {
        }

        public void onClick(View v) {
            ChannelsScreen.this.finish();
        }
    }

    /* renamed from: com.vizsafe.app.Channels.ChannelsScreen$2 */
    class C02122 implements Callback<ResponseFavouriteChannelsApi> {
        C02122() {
        }

        public void success(ResponseFavouriteChannelsApi responseFavouriteChannelsApi, Response response) {
            if (responseFavouriteChannelsApi.getHttpCode().intValue() == 200) {
                if (!ChannelsScreen.this.items.isEmpty()) {
                    ChannelsScreen.this.items.clear();
                }
                if (!ChannelsScreen.this.favouriteChannelItems.isEmpty()) {
                    ChannelsScreen.this.favouriteChannelItems.clear();
                }
                Detail mDetailChannels = responseFavouriteChannelsApi.getDetail();
                try {
                    ChannelsScreen.this.mChannelsList.clear();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (mDetailChannels.getTotal().intValue() != 0) {
                    ChannelsScreen.this.mChannelsList = mDetailChannels.getChannels();
                    if (ChannelsScreen.this.mChannelsList != null) {
                        int count = 0;
                        while (count < ChannelsScreen.this.mChannelsList.size()) {
                            String channelName = ((Channel) ChannelsScreen.this.mChannelsList.get(count)).getName();
                            String channelDescription = ((Channel) ChannelsScreen.this.mChannelsList.get(count)).getDescription();
                            String channelUuid = ((Channel) ChannelsScreen.this.mChannelsList.get(count)).getUuid();
                            String channelPicture = ((Channel) ChannelsScreen.this.mChannelsList.get(count)).getChannelPicture();
                            String channelOwner = ((Channel) ChannelsScreen.this.mChannelsList.get(count)).getOwner();
                            boolean channelVizsafe = ((Channel) ChannelsScreen.this.mChannelsList.get(count)).getVizsafeChannel().booleanValue();
                            boolean channelPrivate = ((Channel) ChannelsScreen.this.mChannelsList.get(count)).getPrivateChannel().booleanValue();
                            boolean channelSecret = ((Channel) ChannelsScreen.this.mChannelsList.get(count)).getSecretChannel().booleanValue();
                            boolean channelMassaged = ((Channel) ChannelsScreen.this.mChannelsList.get(count)).getMassaged().booleanValue();
                            if (((Channel) ChannelsScreen.this.mChannelsList.get(count)).equals("tips") && ((Channel) ChannelsScreen.this.mChannelsList.get(count)).getTips().booleanValue()) {
                                ChannelsScreen.this.tipsFavChannel.add(new ChannelsListItem(channelName, channelDescription, ChannelsScreen.this.channelPictureUrl + channelPicture, channelUuid, channelOwner, channelVizsafe, channelPrivate, channelSecret, channelMassaged));
                            }
                            ChannelsScreen.this.favouriteChannelItems.add(new ChannelsListItem(channelName, channelDescription, ChannelsScreen.this.channelPictureUrl + channelPicture, channelUuid, channelOwner, channelVizsafe, channelPrivate, channelSecret, channelMassaged));
                            count++;
                        }
                    }
                }
                ChannelsScreen.this.TaskVizsafeChannels();
                return;
            }
            ChannelsScreen.this.mTransparentProgressDialog.dismiss();
            Toast.makeText(ChannelsScreen.this.getApplicationContext(), responseFavouriteChannelsApi.getMessage(), 0).show();
        }

        public void failure(RetrofitError error) {
            ChannelsScreen.this.mTransparentProgressDialog.dismiss();
            Toast.makeText(ChannelsScreen.this.getApplicationContext(), ChannelsScreen.this.getString(C0421R.string.unable_to_get_channels), 0).show();
            error.printStackTrace();
        }
    }

    /* renamed from: com.vizsafe.app.Channels.ChannelsScreen$3 */
    class C02133 implements Callback<ResponseVizsafeChannelsApi> {
        C02133() {
        }

        public void success(ResponseVizsafeChannelsApi responseVizsafeChannelsApi, Response response) {
            if (responseVizsafeChannelsApi.getHttpCode().intValue() == 200) {
                Detail mDetailChannels = responseVizsafeChannelsApi.getDetail();
                try {
                    ChannelsScreen.this.mChannelsList.clear();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (mDetailChannels.getTotal().intValue() != 0) {
                    ChannelsScreen.this.mChannelsList = mDetailChannels.getChannels();
                    if (!ChannelsScreen.this.vizsafeChannel.isEmpty()) {
                        ChannelsScreen.this.vizsafeChannel.clear();
                    }
                    if (ChannelsScreen.this.mChannelsList != null) {
                        for (int count = 0; count < ChannelsScreen.this.mChannelsList.size(); count++) {
                            String channelName = ((Channel) ChannelsScreen.this.mChannelsList.get(count)).getName();
                            String channelDescription = ((Channel) ChannelsScreen.this.mChannelsList.get(count)).getDescription();
                            String channelUuid = ((Channel) ChannelsScreen.this.mChannelsList.get(count)).getUuid();
                            String channelPicture = ((Channel) ChannelsScreen.this.mChannelsList.get(count)).getChannelPicture();
                            String channelOwner = ((Channel) ChannelsScreen.this.mChannelsList.get(count)).getOwner();
                            boolean channelVizsafe = ((Channel) ChannelsScreen.this.mChannelsList.get(count)).getVizsafeChannel().booleanValue();
                            boolean channelPrivate = ((Channel) ChannelsScreen.this.mChannelsList.get(count)).getPrivateChannel().booleanValue();
                            boolean channelSecret = ((Channel) ChannelsScreen.this.mChannelsList.get(count)).getSecretChannel().booleanValue();
                            boolean channelMassaged = ((Channel) ChannelsScreen.this.mChannelsList.get(count)).getMassaged().booleanValue();
                            ChannelsScreen.this.vizsafeChannel.add(new ChannelsListItem(channelName, channelDescription, ChannelsScreen.this.channelPictureUrl + channelPicture, channelUuid, channelOwner, channelVizsafe, channelPrivate, channelSecret, channelMassaged));
                        }
                    }
                }
                ChannelsScreen.this.TaskAllChannels();
                return;
            }
            ChannelsScreen.this.mTransparentProgressDialog.dismiss();
            Toast.makeText(ChannelsScreen.this.getApplicationContext(), responseVizsafeChannelsApi.getMessage(), 0).show();
        }

        public void failure(RetrofitError error) {
            ChannelsScreen.this.mTransparentProgressDialog.dismiss();
            Toast.makeText(ChannelsScreen.this.getApplicationContext(), ChannelsScreen.this.getString(C0421R.string.unable_to_get_channels), 0).show();
            error.printStackTrace();
        }
    }

    /* renamed from: com.vizsafe.app.Channels.ChannelsScreen$4 */
    class C02144 implements Callback<ResponseAllChannelsApi> {
        C02144() {
        }

        public void success(ResponseAllChannelsApi responseAllChannelsApi, Response response) {
            ChannelsScreen.this.mTransparentProgressDialog.dismiss();
            if (responseAllChannelsApi.getHttpCode().intValue() == 200) {
                Detail mDetailChannels = responseAllChannelsApi.getDetail();
                try {
                    ChannelsScreen.this.mChannelsList.clear();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (mDetailChannels.getTotal().intValue() != 0) {
                    ChannelsScreen.this.mChannelsList = mDetailChannels.getChannels();
                    if (!ChannelsScreen.this.tipsChannel.isEmpty()) {
                        ChannelsScreen.this.tipsChannel.clear();
                    }
                    if (!ChannelsScreen.this.allChannels.isEmpty()) {
                        ChannelsScreen.this.allChannels.clear();
                    }
                    if (ChannelsScreen.this.mChannelsList != null) {
                        for (int count = 0; count < ChannelsScreen.this.mChannelsList.size(); count++) {
                            String channelName = ((Channel) ChannelsScreen.this.mChannelsList.get(count)).getName();
                            String channelDescription = ((Channel) ChannelsScreen.this.mChannelsList.get(count)).getDescription();
                            String channelUuid = ((Channel) ChannelsScreen.this.mChannelsList.get(count)).getUuid();
                            String channelPicture = ((Channel) ChannelsScreen.this.mChannelsList.get(count)).getChannelPicture();
                            String channelOwner = ((Channel) ChannelsScreen.this.mChannelsList.get(count)).getOwner();
                            boolean channelVizsafe = ((Channel) ChannelsScreen.this.mChannelsList.get(count)).getVizsafeChannel().booleanValue();
                            boolean channelPrivate = ((Channel) ChannelsScreen.this.mChannelsList.get(count)).getPrivateChannel().booleanValue();
                            boolean channelSecret = ((Channel) ChannelsScreen.this.mChannelsList.get(count)).getSecretChannel().booleanValue();
                            boolean channelMassaged = ((Channel) ChannelsScreen.this.mChannelsList.get(count)).getMassaged().booleanValue();
                            if (!((Channel) ChannelsScreen.this.mChannelsList.get(count)).equals("tips")) {
                                ChannelsScreen.this.allChannels.add(new ChannelsListItem(channelName, channelDescription, ChannelsScreen.this.channelPictureUrl + channelPicture, channelUuid, channelOwner, channelVizsafe, channelPrivate, channelSecret, channelMassaged));
                            } else if (((Channel) ChannelsScreen.this.mChannelsList.get(count)).getTips().booleanValue()) {
                                if (PreferenceHandler.getInstance(ChannelsScreen.this.channelScreen).getSuperUser().booleanValue()) {
                                    ChannelsScreen.this.tipsChannel.add(new ChannelsListItem(channelName, channelDescription, ChannelsScreen.this.channelPictureUrl + channelPicture, channelUuid, channelOwner, channelVizsafe, channelPrivate, channelSecret, channelMassaged));
                                    ChannelsScreen.this.allChannels.add(new ChannelsListItem(channelName, channelDescription, ChannelsScreen.this.channelPictureUrl + channelPicture, channelUuid, channelOwner, channelVizsafe, channelPrivate, channelSecret, channelMassaged));
                                } else if (ChannelsScreen.this.tipsFavChannel.size() > 0) {
                                    for (int j = 0; j < ChannelsScreen.this.tipsFavChannel.size(); j++) {
                                        if (channelUuid.equals(((ChannelsListItem) ChannelsScreen.this.tipsFavChannel.get(j)).uuid)) {
                                            ChannelsScreen.this.tipsChannel.add(new ChannelsListItem(channelName, channelDescription, ChannelsScreen.this.channelPictureUrl + channelPicture, channelUuid, channelOwner, channelVizsafe, channelPrivate, channelSecret, channelMassaged));
                                            ChannelsScreen.this.isTipsChannel = true;
                                            break;
                                        }
                                    }
                                    if (ChannelsScreen.this.isTipsChannel) {
                                        ChannelsScreen.this.allChannels.add(new ChannelsListItem(channelName, channelDescription, ChannelsScreen.this.channelPictureUrl + channelPicture, channelUuid, channelOwner, channelVizsafe, channelPrivate, channelSecret, channelMassaged));
                                        ChannelsScreen.this.isTipsChannel = false;
                                    }
                                }
                            }
                        }
                    }
                }
                if (!(ChannelsScreen.this.tipsChannel == null || ChannelsScreen.this.tipsChannel.isEmpty())) {
                    ChannelsScreen.this.items.add(new SectionItem(ChannelsScreen.this.getResources().getString(C0421R.string.tips_channels)));
                    ChannelsScreen.this.items.addAll(ChannelsScreen.this.tipsChannel);
                }
                if (!(ChannelsScreen.this.favouriteChannelItems == null || ChannelsScreen.this.favouriteChannelItems.isEmpty())) {
                    ChannelsScreen.this.items.add(new SectionItem(ChannelsScreen.this.getResources().getString(C0421R.string.favorite_channels)));
                    ChannelsScreen.this.items.addAll(ChannelsScreen.this.favouriteChannelItems);
                }
                if (!(ChannelsScreen.this.vizsafeChannel == null || ChannelsScreen.this.vizsafeChannel.isEmpty())) {
                    ChannelsScreen.this.items.add(new SectionItem(ChannelsScreen.this.getResources().getString(C0421R.string.vizsafe_channels)));
                    ChannelsScreen.this.items.addAll(ChannelsScreen.this.vizsafeChannel);
                }
                if (!(ChannelsScreen.this.allChannels == null || ChannelsScreen.this.allChannels.isEmpty())) {
                    ChannelsScreen.this.items.add(new SectionItem(ChannelsScreen.this.getResources().getString(C0421R.string.all_channels)));
                    ChannelsScreen.this.items.addAll(ChannelsScreen.this.allChannels);
                }
                ChannelsScreen.this.adapter = new CustomChannelListAdapter(ChannelsScreen.this, ChannelsScreen.this.items, ChannelsScreen.this.favouriteChannelItems);
                ChannelsScreen.this.setListAdapter(ChannelsScreen.this.adapter);
                ChannelsScreen.this.adapter.notifyDataSetChanged();
                if (ChannelsScreen.this.scrollState != null) {
                    ChannelsScreen.this.getListView().onRestoreInstanceState(ChannelsScreen.this.scrollState);
                    ChannelsScreen.this.scrollState = null;
                }
            }
        }

        public void failure(RetrofitError error) {
            ChannelsScreen.this.mTransparentProgressDialog.dismiss();
            Toast.makeText(ChannelsScreen.this.getApplicationContext(), ChannelsScreen.this.getString(C0421R.string.unable_to_get_channels), 0).show();
            error.printStackTrace();
        }
    }

    /* renamed from: com.vizsafe.app.Channels.ChannelsScreen$5 */
    class C02155 implements Callback<JsonObject> {
        C02155() {
        }

        public void success(JsonObject responseLeaveChannelDetailApi, Response response) {
            String mResponse = String.valueOf(responseLeaveChannelDetailApi);
            try {
                ChannelsScreen.this.mJsonResponse = new JSONObject(mResponse);
                Toast.makeText(ChannelsScreen.this.getApplicationContext(), ChannelsScreen.this.mJsonResponse.getString(GCMClientManager.EXTRA_MESSAGE), 0).show();
                JSONArray mMemberShips = ChannelsScreen.this.mJsonResponse.getJSONObject(ProductAction.ACTION_DETAIL).getJSONArray("memberships");
                for (int i = 0; i < mMemberShips.length(); i++) {
                    JSONObject singleIncidentObject = mMemberShips.getJSONObject(i);
                    ChannelsScreen.this.feedIcon = singleIncidentObject.getString("uuid");
                    ChannelsScreen.this.memberUuid = ChannelsScreen.this.feedIcon;
                }
                ChannelsScreen.this.TaskLeaveChannel(ChannelsScreen.this.memberUuid);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        public void failure(RetrofitError error) {
            ChannelsScreen.this.mTransparentProgressDialog.dismiss();
            error.printStackTrace();
        }
    }

    /* renamed from: com.vizsafe.app.Channels.ChannelsScreen$6 */
    class C02166 implements Callback<ResponseLeaveChannelApi> {
        C02166() {
        }

        public void success(ResponseLeaveChannelApi responseLeaveChannelApi, Response response) {
            ChannelsScreen.this.mTransparentProgressDialog.dismiss();
            if (responseLeaveChannelApi.getHttpCode().intValue() == 200) {
                Toast.makeText(ChannelsScreen.this.getApplicationContext(), responseLeaveChannelApi.getMessage(), 0).show();
                ChannelsScreen.this.TaskFavouriteChannels();
                return;
            }
            Toast.makeText(ChannelsScreen.this.getApplicationContext(), responseLeaveChannelApi.getMessage(), 0).show();
        }

        public void failure(RetrofitError error) {
            ChannelsScreen.this.mTransparentProgressDialog.dismiss();
            error.printStackTrace();
        }
    }

    /* renamed from: com.vizsafe.app.Channels.ChannelsScreen$7 */
    class C02177 implements Callback<JsonObject> {
        C02177() {
        }

        public void success(JsonObject responseJoinChannelApi, Response response) {
            ChannelsScreen.this.mTransparentProgressDialog.dismiss();
            if (responseJoinChannelApi != null) {
                String mResponse = String.valueOf(responseJoinChannelApi);
                try {
                    ChannelsScreen.this.mJsonResponse = new JSONObject(mResponse);
                    Toast.makeText(ChannelsScreen.this.getApplicationContext(), ChannelsScreen.this.mJsonResponse.getString(GCMClientManager.EXTRA_MESSAGE), 0).show();
                    ChannelsScreen.this.TaskFavouriteChannels();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }

        public void failure(RetrofitError error) {
            ChannelsScreen.this.mTransparentProgressDialog.dismiss();
            error.printStackTrace();
        }
    }

    /* renamed from: com.vizsafe.app.Channels.ChannelsScreen$8 */
    class C02188 implements DialogInterface.OnClickListener {
        C02188() {
        }

        public void onClick(DialogInterface dialog, int which) {
            dialog.cancel();
            ChannelsScreen.this.TaskLeaveDetailChannel();
        }
    }

    /* renamed from: com.vizsafe.app.Channels.ChannelsScreen$9 */
    class C02199 implements DialogInterface.OnClickListener {
        C02199() {
        }

        public void onClick(DialogInterface dialog, int which) {
            dialog.cancel();
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0421R.layout.channel_screen);
        this.channelScreen = this;
        this.channelPictureUrl = CommonMember.getURL(this.channelScreen) + "/picture/";
        this.doneBtn = (ImageView) findViewById(C0421R.C0419id.action_bar_back);
        this.mTransparentProgressDialog = new SpotsDialog((Context) this, getResources().getString(C0421R.string.please_wait_loading));
        this.mTransparentProgressDialog.setCanceledOnTouchOutside(false);
        this.mTransparentProgressDialog.setCancelable(false);
        this.mTitle = (TextView) findViewById(2131689653);
        this.mTitle.setText(getResources().getString(C0421R.string.channels));
        this.email = PreferenceHandler.getInstance(this.channelScreen).getUserName();
        this.password = PreferenceHandler.getInstance(this.channelScreen).getPassword();
        this.authenticationString = "Basic " + Base64.encodeToString((this.email + ":" + this.password).getBytes(), 2);
        if (CommonMember.isNetworkOnline((ConnectivityManager) getSystemService("connectivity"), this)) {
            TaskFavouriteChannels();
        } else {
            CommonMember.getErrorDialog(getResources().getString(C0421R.string.no_internet_access), this).show();
        }
        this.doneBtn.setOnClickListener(new C02111());
    }

    private void TaskFavouriteChannels() {
        this.mTransparentProgressDialog.show();
        FavouriteChannelsApi.getInstance().Callresponse(getApplicationContext(), this.authenticationString, PreferenceHandler.getInstance(getApplicationContext()).getUserUUID(), new C02122());
    }

    private void TaskVizsafeChannels() {
        VizsafeChannelsApi.getInstance().Callresponse(getApplicationContext(), this.authenticationString, "VIZSAFE", new C02133());
    }

    private void TaskAllChannels() {
        AllChannelsApi.getInstance().Callresponse(getApplicationContext(), this.authenticationString, new C02144());
    }

    protected void onListItemClick(ListView l, View v, int position, long id) {
        if (!CommonMember.isNetworkOnline((ConnectivityManager) getSystemService("connectivity"), this)) {
            CommonMember.getErrorDialog(getResources().getString(C0421R.string.no_internet_access), this.channelScreen).show();
        } else if (!((Item) this.items.get(position)).isSection()) {
            this.scrollState = l.onSaveInstanceState();
            ChannelsListItem item = (ChannelsListItem) this.items.get(position);
            if (item.isVizsafe) {
                ImageView checkMark = (ImageView) v.findViewById(C0421R.C0419id.check_mark);
                this.uuidForJoinOrLeave = item.uuid;
                if (checkMark.getVisibility() != 0) {
                    if (CommonMember.isNetworkOnline((ConnectivityManager) getSystemService("connectivity"), this)) {
                        TaskJoinChannel();
                    } else {
                        CommonMember.NetworkStatusAlert(this);
                    }
                } else if (CommonMember.isNetworkOnline((ConnectivityManager) getSystemService("connectivity"), this)) {
                    showSettingsAlert();
                } else {
                    CommonMember.NetworkStatusAlert(this);
                }
            }
        }
        super.onListItemClick(l, v, position, id);
    }

    private void TaskLeaveDetailChannel() {
        this.mTransparentProgressDialog.show();
        LeaveChannelDetailApi.getInstance().Callresponse(getApplicationContext(), this.authenticationString, PreferenceHandler.getInstance(this.channelScreen).getUserUUID(), this.uuidForJoinOrLeave, new C02155());
    }

    private void TaskLeaveChannel(String memberUuid) {
        LeaveChannelApi.getInstance().Callresponse(getApplicationContext(), this.authenticationString, memberUuid, new C02166());
    }

    private void TaskJoinChannel() {
        this.mTransparentProgressDialog.show();
        JoinChannelApi.getInstance().Callresponse(getApplicationContext(), this.authenticationString, PreferenceHandler.getInstance(this.channelScreen).getUserUUID(), this.uuidForJoinOrLeave, new C02177());
    }

    public void showSettingsAlert() {
        Builder alertDialog = new Builder(this.channelScreen);
        alertDialog.setTitle(getResources().getString(C0421R.string.alert_title));
        alertDialog.setMessage(getResources().getString(C0421R.string.channels_title));
        alertDialog.setPositiveButton(getResources().getString(C0421R.string.okTxt), new C02188());
        alertDialog.setNegativeButton(getResources().getString(C0421R.string.cancel), new C02199());
        alertDialog.show();
    }
}
