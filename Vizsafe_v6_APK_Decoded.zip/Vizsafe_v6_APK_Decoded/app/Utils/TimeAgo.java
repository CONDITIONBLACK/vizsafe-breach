package com.vizsafe.app.Utils;

import java.text.MessageFormat;
import java.util.Date;

public class TimeAgo {
    private String day = "a day";
    private String days = "{0} days";
    private String hour = "about 1 hour";
    private String hours = "{0} hours";
    private String minute = "about a minute";
    private String minutes = "{0} minutes";
    private String month = "about a month";
    private String months = "{0} months";
    private String prefixAgo = null;
    private String prefixFromNow = null;
    private String seconds = "less than a minute";
    private String suffixAgo = "ago";
    private String suffixFromNow = "from now";
    private String week = "about a week";
    private String weeks = "{0} weeks";
    private String year = "about a year";
    private String years = "{0} years";

    public String timeUntil(Date date) {
        return timeUntil(date.getTime());
    }

    public String timeAgo(Date date) {
        return timeAgo(date.getTime());
    }

    public String timeUntil(long millis) {
        return time(millis - System.currentTimeMillis(), true);
    }

    public String timeAgo(long millis) {
        return time(System.currentTimeMillis() - millis, false);
    }

    public String time(long distanceMillis, boolean allowFuture) {
        String prefix;
        String suffix;
        String time;
        if (!allowFuture || distanceMillis >= 0) {
            prefix = this.prefixAgo;
            suffix = this.suffixAgo;
        } else {
            distanceMillis = Math.abs(distanceMillis);
            prefix = this.prefixFromNow;
            suffix = this.suffixFromNow;
        }
        double seconds = (double) (distanceMillis / 1000);
        double minutes = seconds / 60.0d;
        double hours = minutes / 60.0d;
        double days = hours / 24.0d;
        double weeks = days / 7.0d;
        double months = weeks / 4.0d;
        double years = months / 12.0d;
        if (seconds < 45.0d) {
            time = this.seconds;
        } else if (seconds < 90.0d) {
            time = this.minute;
        } else if (minutes < 45.0d) {
            time = MessageFormat.format(this.minutes, new Object[]{Long.valueOf(Math.round(minutes))});
        } else if (minutes < 90.0d) {
            time = this.hour;
        } else if (hours < 24.0d) {
            time = MessageFormat.format(this.hours, new Object[]{Long.valueOf(Math.round(hours))});
        } else if (hours < 48.0d) {
            time = this.day;
        } else if (days < 7.0d) {
            time = MessageFormat.format(this.days, new Object[]{Double.valueOf(Math.floor(days))});
        } else if (days < 14.0d) {
            time = this.week;
        } else if (weeks < 4.0d) {
            time = MessageFormat.format(this.weeks, new Object[]{Double.valueOf(Math.floor(weeks))});
        } else if (weeks < 8.0d) {
            time = this.month;
        } else if (months < 12.0d) {
            time = MessageFormat.format(this.months, new Object[]{Double.valueOf(Math.floor(months))});
        } else if (months < 24.0d) {
            time = this.year;
        } else {
            time = MessageFormat.format(this.years, new Object[]{Double.valueOf(Math.floor(years))});
        }
        return join(prefix, time, suffix);
    }

    public String join(String prefix, String time, String suffix) {
        StringBuilder joined = new StringBuilder();
        if (prefix != null && prefix.length() > 0) {
            joined.append(prefix).append(' ');
        }
        joined.append(time);
        if (suffix != null && suffix.length() > 0) {
            joined.append(' ').append(suffix);
        }
        return joined.toString();
    }

    public String getPrefixAgo() {
        return this.prefixAgo;
    }

    public TimeAgo setPrefixAgo(String prefixAgo) {
        this.prefixAgo = prefixAgo;
        return this;
    }

    public String getPrefixFromNow() {
        return this.prefixFromNow;
    }

    public TimeAgo setPrefixFromNow(String prefixFromNow) {
        this.prefixFromNow = prefixFromNow;
        return this;
    }

    public String getSuffixAgo() {
        return this.suffixAgo;
    }

    public TimeAgo setSuffixAgo(String suffixAgo) {
        this.suffixAgo = suffixAgo;
        return this;
    }

    public String getSuffixFromNow() {
        return this.suffixFromNow;
    }

    public TimeAgo setSuffixFromNow(String suffixFromNow) {
        this.suffixFromNow = suffixFromNow;
        return this;
    }

    public String getSeconds() {
        return this.seconds;
    }

    public TimeAgo setSeconds(String seconds) {
        this.seconds = seconds;
        return this;
    }

    public String getMinute() {
        return this.minute;
    }

    public TimeAgo setMinute(String minute) {
        this.minute = minute;
        return this;
    }

    public String getMinutes() {
        return this.minutes;
    }

    public TimeAgo setMinutes(String minutes) {
        this.minutes = minutes;
        return this;
    }

    public String getHour() {
        return this.hour;
    }

    public TimeAgo setHour(String hour) {
        this.hour = hour;
        return this;
    }

    public String getHours() {
        return this.hours;
    }

    public TimeAgo setHours(String hours) {
        this.hours = hours;
        return this;
    }

    public String getDay() {
        return this.day;
    }

    public TimeAgo setDay(String day) {
        this.day = day;
        return this;
    }

    public String getDays() {
        return this.days;
    }

    public TimeAgo setDays(String days) {
        this.days = days;
        return this;
    }

    public String getWeek() {
        return this.week;
    }

    public TimeAgo setWeek(String week) {
        this.week = week;
        return this;
    }

    public String getWeeks() {
        return this.days;
    }

    public TimeAgo setWeeks(String weeks) {
        this.weeks = weeks;
        return this;
    }

    public String getMonth() {
        return this.month;
    }

    public TimeAgo setMonth(String month) {
        this.month = month;
        return this;
    }

    public String getMonths() {
        return this.months;
    }

    public TimeAgo setMonths(String months) {
        this.months = months;
        return this;
    }

    public String getYear() {
        return this.year;
    }

    public TimeAgo setYear(String year) {
        this.year = year;
        return this;
    }

    public String getYears() {
        return this.years;
    }

    public TimeAgo setYears(String years) {
        this.years = years;
        return this;
    }
}
