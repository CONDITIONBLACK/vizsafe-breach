package com.vizsafe.app.Utils;

import android.content.Context;
import android.util.Base64;
import android.util.Log;
import com.google.android.gms.search.SearchAuth.StatusCodes;
import com.google.firebase.auth.EmailAuthProvider;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

public class Webservice {
    public JSONObject LoginUser(Context context, String email, String password, String mZone) {
        DefaultHttpClient httpclient = new DefaultHttpClient();
        String responseString = "";
        try {
            String verifyDisplayNameUrl;
            if (mZone.isEmpty()) {
                verifyDisplayNameUrl = Constants.INITIALURL + "/currentuser";
            } else {
                verifyDisplayNameUrl = Constants.INITIALURL + "/currentuser?zone=" + mZone;
            }
            HttpGet get = new HttpGet(verifyDisplayNameUrl);
            get.addHeader("Authorization", "Basic " + Base64.encodeToString((email + ":" + password).getBytes(), 2));
            HttpResponse response = httpclient.execute(get);
            StatusLine statusLine = response.getStatusLine();
            if (statusLine.getStatusCode() == 200) {
                return new JSONObject(EntityUtils.toString(response.getEntity()));
            }
            response.getEntity().getContent().close();
            throw new IOException(statusLine.getReasonPhrase());
        } catch (Exception e) {
            Log.w("error logging in", e);
            return null;
        }
    }

    public static JSONObject ForgotPasswordAPI(String mEmail) {
        String responseString = "";
        try {
            HttpResponse response = new DefaultHttpClient().execute(new HttpGet(Constants.INITIALURL + "/passwordreset?email=" + mEmail));
            StatusLine statusLine = response.getStatusLine();
            return new JSONObject(EntityUtils.toString(response.getEntity()));
        } catch (Exception e) {
            Log.w("error logging in", e);
            return null;
        }
    }

    public static JSONObject ResendOtp(String mAuthyid) {
        String responseString = "";
        try {
            HttpResponse response = new DefaultHttpClient().execute(new HttpGet(Constants.INITIALURL + "/verifyotp?authyid=" + mAuthyid));
            StatusLine statusLine = response.getStatusLine();
            if (statusLine.getStatusCode() == 200) {
                return new JSONObject(EntityUtils.toString(response.getEntity()));
            }
            response.getEntity().getContent().close();
            throw new IOException(statusLine.getReasonPhrase());
        } catch (Exception e) {
            Log.w("error logging in", e);
            return null;
        }
    }

    public JSONObject VerifyMobileFromSignIn(Context context, String mEmail, String mPhoneNumber, String mCountryCode) {
        try {
            HttpClient httpClient = new DefaultHttpClient();
            HttpContext localContext = new BasicHttpContext();
            HttpParams httpParameters = new BasicHttpParams();
            HttpUriRequest httpPost = new HttpPost(Constants.INITIALURL + "/verifyusermobile");
            List<NameValuePair> Details = new ArrayList();
            Details.add(new BasicNameValuePair("email", mEmail));
            Details.add(new BasicNameValuePair("mobilenumber", mPhoneNumber));
            Details.add(new BasicNameValuePair("countrycode", mCountryCode));
            HttpConnectionParams.setConnectionTimeout(httpParameters, 50000);
            HttpConnectionParams.setSoTimeout(httpParameters, StatusCodes.AUTH_DISABLED);
            httpPost.setEntity(new UrlEncodedFormEntity(Details));
            return new JSONObject(EntityUtils.toString(httpClient.execute(httpPost, localContext).getEntity()));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return null;
        } catch (ClientProtocolException e2) {
            e2.printStackTrace();
            return null;
        } catch (IOException e3) {
            e3.printStackTrace();
            return null;
        } catch (Exception e4) {
            e4.printStackTrace();
            return null;
        }
    }

    public JSONObject VerifyOtp(Context context, String mUserId, String mOtp, String mAuthyid) {
        try {
            HttpClient httpClient = new DefaultHttpClient();
            HttpContext localContext = new BasicHttpContext();
            HttpParams httpParameters = new BasicHttpParams();
            HttpUriRequest httpPost = new HttpPost(Constants.INITIALURL + "/verifymobile");
            List<NameValuePair> Details = new ArrayList();
            Details.add(new BasicNameValuePair("userid", mUserId));
            Details.add(new BasicNameValuePair("otp", mOtp));
            Details.add(new BasicNameValuePair("authyid", mAuthyid));
            HttpConnectionParams.setConnectionTimeout(httpParameters, 50000);
            HttpConnectionParams.setSoTimeout(httpParameters, StatusCodes.AUTH_DISABLED);
            httpPost.setEntity(new UrlEncodedFormEntity(Details));
            return new JSONObject(EntityUtils.toString(httpClient.execute(httpPost, localContext).getEntity()));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return null;
        } catch (ClientProtocolException e2) {
            e2.printStackTrace();
            return null;
        } catch (IOException e3) {
            e3.printStackTrace();
            return null;
        } catch (Exception e4) {
            e4.printStackTrace();
            return null;
        }
    }

    public JSONObject VerifyOtpFromSignIn(Context context, String mEmail, String mOtp, String mAuthyid, String mPhoneNumber, String mCountryCode) {
        try {
            HttpClient httpClient = new DefaultHttpClient();
            HttpContext localContext = new BasicHttpContext();
            HttpParams httpParameters = new BasicHttpParams();
            HttpUriRequest httpPost = new HttpPost(Constants.INITIALURL + "/verifymobileotp");
            List<NameValuePair> Details = new ArrayList();
            Details.add(new BasicNameValuePair("email", mEmail));
            Details.add(new BasicNameValuePair("otp", mOtp));
            Details.add(new BasicNameValuePair("authyid", mAuthyid));
            Details.add(new BasicNameValuePair("mobilenumber", mPhoneNumber));
            Details.add(new BasicNameValuePair("countrycode", mCountryCode));
            HttpConnectionParams.setConnectionTimeout(httpParameters, 50000);
            HttpConnectionParams.setSoTimeout(httpParameters, StatusCodes.AUTH_DISABLED);
            httpPost.setEntity(new UrlEncodedFormEntity(Details));
            return new JSONObject(EntityUtils.toString(httpClient.execute(httpPost, localContext).getEntity()));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return null;
        } catch (ClientProtocolException e2) {
            e2.printStackTrace();
            return null;
        } catch (IOException e3) {
            e3.printStackTrace();
            return null;
        } catch (Exception e4) {
            e4.printStackTrace();
            return null;
        }
    }

    public JSONObject VerifyOtpFromReset(Context context, String mEmail, String mOtp, String mAuthyid) {
        try {
            HttpClient httpClient = new DefaultHttpClient();
            HttpContext localContext = new BasicHttpContext();
            HttpParams httpParameters = new BasicHttpParams();
            HttpUriRequest httpPost = new HttpPost(Constants.INITIALURL + "/verifyotp");
            List<NameValuePair> Details = new ArrayList();
            Details.add(new BasicNameValuePair("email", mEmail));
            Details.add(new BasicNameValuePair("otp", mOtp));
            Details.add(new BasicNameValuePair("authyid", mAuthyid));
            HttpConnectionParams.setConnectionTimeout(httpParameters, 50000);
            HttpConnectionParams.setSoTimeout(httpParameters, StatusCodes.AUTH_DISABLED);
            httpPost.setEntity(new UrlEncodedFormEntity(Details));
            return new JSONObject(EntityUtils.toString(httpClient.execute(httpPost, localContext).getEntity()));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return null;
        } catch (ClientProtocolException e2) {
            e2.printStackTrace();
            return null;
        } catch (IOException e3) {
            e3.printStackTrace();
            return null;
        } catch (Exception e4) {
            e4.printStackTrace();
            return null;
        }
    }

    public JSONObject submitUser(Context context, String mEmail, String displayname, String password, String Zone, String mPhoneNumber, String mCountryCode) {
        try {
            HttpClient httpClient = new DefaultHttpClient();
            HttpContext localContext = new BasicHttpContext();
            HttpParams httpParameters = new BasicHttpParams();
            HttpUriRequest httpPost = new HttpPost(Constants.INITIALURL + "/user");
            List<NameValuePair> Details = new ArrayList();
            Details.add(new BasicNameValuePair("email", mEmail));
            Details.add(new BasicNameValuePair("displayname", displayname));
            Details.add(new BasicNameValuePair(EmailAuthProvider.PROVIDER_ID, password));
            Details.add(new BasicNameValuePair("username", mEmail));
            Details.add(new BasicNameValuePair("mobilenumber", mPhoneNumber));
            Details.add(new BasicNameValuePair("countrycode", mCountryCode));
            if (!Zone.isEmpty()) {
                Details.add(new BasicNameValuePair("zone", Zone));
            }
            HttpConnectionParams.setConnectionTimeout(httpParameters, 50000);
            HttpConnectionParams.setSoTimeout(httpParameters, StatusCodes.AUTH_DISABLED);
            httpPost.setEntity(new UrlEncodedFormEntity(Details));
            return new JSONObject(EntityUtils.toString(httpClient.execute(httpPost, localContext).getEntity()));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return null;
        } catch (ClientProtocolException e2) {
            e2.printStackTrace();
            return null;
        } catch (IOException e3) {
            e3.printStackTrace();
            return null;
        } catch (Exception e4) {
            e4.printStackTrace();
            return null;
        }
    }

    public JSONObject postFeedWebService(Context context, String email, String password, String postData) {
        DefaultHttpClient httpclient = new DefaultHttpClient();
        String responseString = "";
        try {
            HttpPost httpPost = new HttpPost(CommonMember.getURL(context) + "/incident");
            httpPost.addHeader("Authorization", "Basic " + Base64.encodeToString((email + ":" + password).getBytes(), 2));
            httpPost.setEntity(new StringEntity(postData));
            HttpResponse response = httpclient.execute(httpPost);
            StatusLine statusLine = response.getStatusLine();
            if (statusLine.getStatusCode() == 200) {
                return new JSONObject(EntityUtils.toString(response.getEntity()));
            }
            response.getEntity().getContent().close();
            throw new IOException(statusLine.getReasonPhrase());
        } catch (Exception e) {
            Log.w("error logging in", e);
            return null;
        }
    }

    public JSONObject reportAbuseAction(Context context, String email, String password, String feedUuid) {
        DefaultHttpClient httpclient = new DefaultHttpClient();
        String responseString = "";
        try {
            HttpPost httpPost = new HttpPost(CommonMember.getURL(context) + "/incident/" + feedUuid + "/reportabuse");
            httpPost.addHeader("Authorization", "Basic " + Base64.encodeToString((email + ":" + password).getBytes(), 2));
            HttpResponse response = httpclient.execute(httpPost);
            StatusLine statusLine = response.getStatusLine();
            if (statusLine.getStatusCode() == 200) {
                return new JSONObject(EntityUtils.toString(response.getEntity()));
            }
            response.getEntity().getContent().close();
            throw new IOException(statusLine.getReasonPhrase());
        } catch (Exception e) {
            Log.w("error logging in", e);
            return null;
        }
    }

    public JSONObject reportIncidentState(Context context, String email, String password, String feedUuid) {
        DefaultHttpClient httpclient = new DefaultHttpClient();
        String responseString = "";
        try {
            HttpPost httpPost = new HttpPost(CommonMember.getURL(context) + "/incidents/" + feedUuid + "/State");
            httpPost.addHeader("Authorization", "Basic " + Base64.encodeToString((email + ":" + password).getBytes(), 2));
            HttpResponse response = httpclient.execute(httpPost);
            StatusLine statusLine = response.getStatusLine();
            if (statusLine.getStatusCode() == 200) {
                return new JSONObject(EntityUtils.toString(response.getEntity()));
            }
            response.getEntity().getContent().close();
            throw new IOException(statusLine.getReasonPhrase());
        } catch (Exception e) {
            Log.w("error logging in", e);
            return null;
        }
    }

    public String deleteFeedAction(Context context, String email, String password, String feedUuid) {
        DefaultHttpClient httpclient = new DefaultHttpClient();
        String responseString = "";
        String successStatus = "failed";
        try {
            HttpDelete httpDelete = new HttpDelete(CommonMember.getURL(context) + "/incident/" + feedUuid);
            httpDelete.addHeader("Authorization", "Basic " + Base64.encodeToString((email + ":" + password).getBytes(), 2));
            HttpResponse response = httpclient.execute(httpDelete);
            StatusLine statusLine = response.getStatusLine();
            if (statusLine.getStatusCode() == 200) {
                responseString = EntityUtils.toString(response.getEntity());
                return "ok";
            }
            response.getEntity().getContent().close();
            throw new IOException(statusLine.getReasonPhrase());
        } catch (Exception e) {
            Log.w("error logging in", e);
            return successStatus;
        }
    }

    public JSONObject getFeedListMicello(Context context, String email, String password, String placeid, String drawingId) {
        DefaultHttpClient httpclient = new DefaultHttpClient();
        String responseString = "";
        try {
            HttpGet get = new HttpGet(CommonMember.getURL(context) + "/indoormap/indoorpins/" + placeid + "/" + drawingId);
            get.addHeader("Authorization", "Basic " + Base64.encodeToString((email + ":" + password).getBytes(), 2));
            HttpResponse response = httpclient.execute(get);
            StatusLine statusLine = response.getStatusLine();
            if (statusLine.getStatusCode() == 200) {
                return new JSONObject(EntityUtils.toString(response.getEntity()));
            }
            response.getEntity().getContent().close();
            throw new IOException(statusLine.getReasonPhrase());
        } catch (Exception e) {
            Log.w("error logging in", e);
            return null;
        }
    }

    public JSONObject GetMicelloIndoorMapsListOnDurationWebService(Context context, String email, String password, String placeid, String drawingid, String fromDuration) {
        DefaultHttpClient httpclient = new DefaultHttpClient();
        String responseString = "";
        try {
            HttpGet get = new HttpGet(CommonMember.getURL(context) + "/indoormap/indoorpins/" + placeid + "/" + drawingid + "?&fromDuration=" + fromDuration);
            get.addHeader("Authorization", "Basic " + Base64.encodeToString((email + ":" + password).getBytes(), 2));
            HttpResponse response = httpclient.execute(get);
            StatusLine statusLine = response.getStatusLine();
            if (statusLine.getStatusCode() == 200) {
                return new JSONObject(EntityUtils.toString(response.getEntity()));
            }
            response.getEntity().getContent().close();
            throw new IOException(statusLine.getReasonPhrase());
        } catch (Exception e) {
            Log.w("error logging in", e);
            return null;
        }
    }

    public JSONObject getCameraListMicello(Context context, String email, String password, String mDrawingId, String mMapgroupUuid) {
        DefaultHttpClient httpclient = new DefaultHttpClient();
        String responseString = "";
        try {
            HttpGet get = new HttpGet(CommonMember.getURL(context) + "/indoormap/camera/" + mDrawingId + "/" + mMapgroupUuid);
            get.addHeader("Authorization", "Basic " + Base64.encodeToString((email + ":" + password).getBytes(), 2));
            HttpResponse response = httpclient.execute(get);
            StatusLine statusLine = response.getStatusLine();
            if (statusLine.getStatusCode() == 200) {
                return new JSONObject(EntityUtils.toString(response.getEntity()));
            }
            response.getEntity().getContent().close();
            throw new IOException(statusLine.getReasonPhrase());
        } catch (Exception e) {
            Log.w("error logging in", e);
            return null;
        }
    }

    public JSONObject getNotesList(Context context, String email, String password, String feedUuid) {
        DefaultHttpClient httpclient = new DefaultHttpClient();
        String responseString = "";
        try {
            HttpGet get = new HttpGet(CommonMember.getURL(context) + "/incidents/" + feedUuid + "/Notes");
            get.addHeader("Authorization", "Basic " + Base64.encodeToString((email + ":" + password).getBytes(), 2));
            HttpResponse response = httpclient.execute(get);
            StatusLine statusLine = response.getStatusLine();
            if (statusLine.getStatusCode() == 200) {
                return new JSONObject(EntityUtils.toString(response.getEntity()));
            }
            response.getEntity().getContent().close();
            throw new IOException(statusLine.getReasonPhrase());
        } catch (Exception e) {
            Log.w("error logging in", e);
            return null;
        }
    }

    public JSONObject getFeedDetails(Context context, String email, String password, String feedUuid) {
        DefaultHttpClient httpclient = new DefaultHttpClient();
        String responseString = "";
        try {
            HttpGet get = new HttpGet(CommonMember.getURL(context) + "/incident/" + feedUuid);
            get.addHeader("Authorization", "Basic " + Base64.encodeToString((email + ":" + password).getBytes(), 2));
            HttpResponse response = httpclient.execute(get);
            StatusLine statusLine = response.getStatusLine();
            if (statusLine.getStatusCode() == 200) {
                return new JSONObject(EntityUtils.toString(response.getEntity()));
            }
            response.getEntity().getContent().close();
            throw new IOException(statusLine.getReasonPhrase());
        } catch (Exception e) {
            Log.w("error logging in", e);
            return null;
        }
    }

    public JSONObject getNotesUserGroupList(Context context, String email, String password, String feedUuid) {
        DefaultHttpClient httpclient = new DefaultHttpClient();
        String responseString = "";
        try {
            HttpGet get = new HttpGet(CommonMember.getURL(context) + "/incidents/" + feedUuid + "/Userassignment/");
            get.addHeader("Authorization", "Basic " + Base64.encodeToString((email + ":" + password).getBytes(), 2));
            HttpResponse response = httpclient.execute(get);
            StatusLine statusLine = response.getStatusLine();
            if (statusLine.getStatusCode() == 200) {
                return new JSONObject(EntityUtils.toString(response.getEntity()));
            }
            response.getEntity().getContent().close();
            throw new IOException(statusLine.getReasonPhrase());
        } catch (Exception e) {
            Log.w("error logging in", e);
            return null;
        }
    }

    public JSONObject AddNotesWebService(Context context, String email, String password, String Path, String postData) {
        DefaultHttpClient httpclient = new DefaultHttpClient();
        String responseString = "";
        try {
            HttpPost httpPost = new HttpPost(CommonMember.getURL(context) + "/incidents/" + Path);
            httpPost.addHeader("Authorization", "Basic " + Base64.encodeToString((email + ":" + password).getBytes(), 2));
            httpPost.setEntity(new StringEntity(postData));
            HttpResponse response = httpclient.execute(httpPost);
            StatusLine statusLine = response.getStatusLine();
            if (statusLine.getStatusCode() == 200) {
                return new JSONObject(EntityUtils.toString(response.getEntity()));
            }
            response.getEntity().getContent().close();
            throw new IOException(statusLine.getReasonPhrase());
        } catch (Exception e) {
            Log.w("error logging in", e);
            return null;
        }
    }

    public JSONObject GetMicelloIndoorMapsListWebService(Context context, String email, String password) {
        DefaultHttpClient httpclient = new DefaultHttpClient();
        String responseString = "";
        try {
            HttpGet get = new HttpGet(CommonMember.getURL(context) + "/indoormap");
            get.addHeader("Authorization", "Basic " + Base64.encodeToString((email + ":" + password).getBytes(), 2));
            HttpResponse response = httpclient.execute(get);
            StatusLine statusLine = response.getStatusLine();
            if (statusLine.getStatusCode() == 200) {
                return new JSONObject(EntityUtils.toString(response.getEntity()));
            }
            response.getEntity().getContent().close();
            throw new IOException(statusLine.getReasonPhrase());
        } catch (Exception e) {
            Log.w("error logging in", e);
            return null;
        }
    }

    public JSONObject GetFeedDetailsUsingUuid(Context context, String email, String password, String uuid) {
        DefaultHttpClient httpclient = new DefaultHttpClient();
        String responseString = "";
        try {
            HttpGet get = new HttpGet(CommonMember.getURL(context) + "/incident/" + uuid);
            get.addHeader("Authorization", "Basic " + Base64.encodeToString((email + ":" + password).getBytes(), 2));
            HttpResponse response = httpclient.execute(get);
            StatusLine statusLine = response.getStatusLine();
            if (statusLine.getStatusCode() == 200) {
                return new JSONObject(EntityUtils.toString(response.getEntity()));
            }
            response.getEntity().getContent().close();
            throw new IOException(statusLine.getReasonPhrase());
        } catch (Exception e) {
            Log.w("error logging in", e);
            return null;
        }
    }

    public static JSONObject GetWalletBalanceWebService(String mAddress) {
        String responseString = "";
        try {
            HttpResponse response = new DefaultHttpClient().execute(new HttpGet(Constants.WalletURL + "module=account&action=balance&address=" + mAddress + "&tag=latest&apikey=" + Constants.mAPIToken));
            StatusLine statusLine = response.getStatusLine();
            if (statusLine.getStatusCode() == 200) {
                return new JSONObject(EntityUtils.toString(response.getEntity()));
            }
            response.getEntity().getContent().close();
            throw new IOException(statusLine.getReasonPhrase());
        } catch (Exception e) {
            Log.w("error logging in", e);
            return null;
        }
    }

    public static JSONObject GetWalletBalanceVizsafeResponse(Context context, String email, String password, String mAddress) {
        DefaultHttpClient httpclient = new DefaultHttpClient();
        String responseString = "";
        try {
            HttpPost httpPost = new HttpPost(CommonMember.getURL(context) + "/gettokenbalance");
            httpPost.addHeader("Authorization", "Basic " + Base64.encodeToString((email + ":" + password).getBytes(), 2));
            List<NameValuePair> Details = new ArrayList();
            Details.add(new BasicNameValuePair("publicAddress", mAddress));
            httpPost.setEntity(new UrlEncodedFormEntity(Details));
            HttpResponse response = httpclient.execute(httpPost);
            StatusLine statusLine = response.getStatusLine();
            if (statusLine.getStatusCode() == 200) {
                return new JSONObject(EntityUtils.toString(response.getEntity()));
            }
            response.getEntity().getContent().close();
            throw new IOException(statusLine.getReasonPhrase());
        } catch (Exception e) {
            Log.w("error logging in", e);
            return null;
        }
    }

    public static JSONObject GetWalletTransactionListWebService(String mAddress) {
        String responseString = "";
        try {
            HttpResponse response = new DefaultHttpClient().execute(new HttpGet(Constants.WalletURL + "module=account&action=tokentx&address=" + mAddress + "&startblock=0&endblock=999999999&sort=asc&apikey=" + Constants.mAPIToken));
            StatusLine statusLine = response.getStatusLine();
            if (statusLine.getStatusCode() == 200) {
                return new JSONObject(EntityUtils.toString(response.getEntity()));
            }
            response.getEntity().getContent().close();
            throw new IOException(statusLine.getReasonPhrase());
        } catch (Exception e) {
            Log.w("error logging in", e);
            return null;
        }
    }

    public static double getElevationFromGoogleMaps(double longitude, double latitude) throws IOException {
        double result = Double.NaN;
        String responseString = "";
        try {
            HttpEntity entity = new DefaultHttpClient().execute(new HttpGet("http://maps.googleapis.com/maps/api/elevation/xml?locations=" + String.valueOf(latitude) + "," + String.valueOf(longitude) + "&sensor=true")).getEntity();
            if (entity != null) {
                InputStream instream = entity.getContent();
                StringBuffer respStr = new StringBuffer();
                while (true) {
                    int r = instream.read();
                    if (r == -1) {
                        break;
                    }
                    respStr.append((char) r);
                }
                String tagOpen = "<elevation>";
                String tagClose = "</elevation>";
                if (respStr.indexOf(tagOpen) != -1) {
                    String value = respStr.substring(respStr.indexOf(tagOpen) + tagOpen.length(), respStr.indexOf(tagClose));
                    result = Double.parseDouble(value);
                    Double.parseDouble(value);
                }
                instream.close();
            }
        } catch (IOException e) {
            Log.w("error logging in", e);
        }
        return result;
    }

    public static JSONObject CheckPublicAddress(Context context, String email, String password, String mUserUuid) {
        DefaultHttpClient httpclient = new DefaultHttpClient();
        String responseString = "";
        try {
            HttpGet get = new HttpGet(CommonMember.getURL(context) + "/settingsethereumaddress?useruuid=" + mUserUuid);
            get.addHeader("Authorization", "Basic " + Base64.encodeToString((email + ":" + password).getBytes(), 2));
            HttpResponse response = httpclient.execute(get);
            StatusLine statusLine = response.getStatusLine();
            if (statusLine.getStatusCode() == 200) {
                return new JSONObject(EntityUtils.toString(response.getEntity()));
            }
            response.getEntity().getContent().close();
            throw new IOException(statusLine.getReasonPhrase());
        } catch (Exception e) {
            Log.w("error logging in", e);
            return null;
        }
    }

    public static JSONObject SaveNewPublicAddressResponse(Context context, String email, String password, String mAddress) {
        DefaultHttpClient httpclient = new DefaultHttpClient();
        String responseString = "";
        try {
            HttpPut httpPut = new HttpPut(CommonMember.getURL(context) + "/settingsethereumaddress");
            httpPut.addHeader("Authorization", "Basic " + Base64.encodeToString((email + ":" + password).getBytes(), 2));
            List<NameValuePair> Details = new ArrayList();
            Details.add(new BasicNameValuePair("publicAddress", mAddress));
            httpPut.setEntity(new UrlEncodedFormEntity(Details));
            HttpResponse response = httpclient.execute(httpPut);
            StatusLine statusLine = response.getStatusLine();
            if (statusLine.getStatusCode() == 200) {
                return new JSONObject(EntityUtils.toString(response.getEntity()));
            }
            response.getEntity().getContent().close();
            throw new IOException(statusLine.getReasonPhrase());
        } catch (Exception e) {
            Log.w("error logging in", e);
            return null;
        }
    }

    public static JSONObject SavePublicAddressResponse(Context context, String email, String password, String mAddress, String useruuid) {
        DefaultHttpClient httpclient = new DefaultHttpClient();
        String responseString = "";
        try {
            HttpPost httpPost = new HttpPost(CommonMember.getURL(context) + "/settingsethereumaddress");
            httpPost.addHeader("Authorization", "Basic " + Base64.encodeToString((email + ":" + password).getBytes(), 2));
            List<NameValuePair> Details = new ArrayList();
            Details.add(new BasicNameValuePair("publicAddress", mAddress));
            Details.add(new BasicNameValuePair("useruuid", useruuid));
            httpPost.setEntity(new UrlEncodedFormEntity(Details));
            HttpResponse response = httpclient.execute(httpPost);
            StatusLine statusLine = response.getStatusLine();
            if (statusLine.getStatusCode() == 200) {
                return new JSONObject(EntityUtils.toString(response.getEntity()));
            }
            response.getEntity().getContent().close();
            throw new IOException(statusLine.getReasonPhrase());
        } catch (Exception e) {
            Log.w("error logging in", e);
            return null;
        }
    }

    public static JSONObject GetEGSURL(Context context, String uuid) {
        DefaultHttpClient httpclient = new DefaultHttpClient();
        String responseString = "";
        try {
            HttpResponse response = httpclient.execute(new HttpGet(CommonMember.getURL(context) + "/camera/" + uuid + "/sldp"));
            StatusLine statusLine = response.getStatusLine();
            if (statusLine.getStatusCode() == 200) {
                return new JSONObject(EntityUtils.toString(response.getEntity()));
            }
            response.getEntity().getContent().close();
            throw new IOException(statusLine.getReasonPhrase());
        } catch (Exception e) {
            Log.w("error logging in", e);
            return null;
        }
    }

    public static JSONObject CheckUserGroupExistingWebService(Context context, String email, String password, String uuid) {
        DefaultHttpClient httpclient = new DefaultHttpClient();
        String responseString = "";
        try {
            HttpPost httpPost = new HttpPost(CommonMember.getURL(context) + "/incident/checkforusergroup");
            httpPost.addHeader("Authorization", "Basic " + Base64.encodeToString((email + ":" + password).getBytes(), 2));
            List<NameValuePair> Details = new ArrayList();
            Details.add(new BasicNameValuePair("uuid", uuid));
            httpPost.setEntity(new UrlEncodedFormEntity(Details));
            HttpResponse response = httpclient.execute(httpPost);
            StatusLine statusLine = response.getStatusLine();
            if (statusLine.getStatusCode() == 200) {
                return new JSONObject(EntityUtils.toString(response.getEntity()));
            }
            response.getEntity().getContent().close();
            throw new IOException(statusLine.getReasonPhrase());
        } catch (Exception e) {
            Log.w("error logging in", e);
            return null;
        }
    }
}
