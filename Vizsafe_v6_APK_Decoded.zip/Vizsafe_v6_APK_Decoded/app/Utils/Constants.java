package com.vizsafe.app.Utils;

import com.google.android.gms.games.GamesStatusCodes;

public class Constants {
    public static String CAMERAURL = ("https://" + SERVER);
    public static String INITIALSERVER = "app.vizsafe.com";
    public static String INITIALURL = ("https://" + INITIALSERVER + "/api/mobile");
    public static int PLAY_SERVICES_RESOLUTION_REQUEST = GamesStatusCodes.STATUS_VIDEO_NOT_ACTIVE;
    public static String PROJECT_NUMBER = "454242664726";
    public static String SERVER;
    public static String SHARE_URL = "https://play.google.com/store/apps/details?id=com.vizsafe.app&hl=en";
    public static String URL = ("https://" + SERVER + "/api/mobile");
    public static String WEBSITE_URL = "http://www.vizsafe.com/";
    public static String WalletURL = "https://ropsten.etherscan.io/api?";
    public static String emailPattern = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
    public static String mAPIToken = "BP3418MKGJEG4WIJZJSEWYZ8IJ6C51F3Q8";
}
