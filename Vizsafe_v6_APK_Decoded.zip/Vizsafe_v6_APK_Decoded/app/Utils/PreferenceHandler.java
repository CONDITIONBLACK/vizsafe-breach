package com.vizsafe.app.Utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import com.google.android.gms.nearby.messages.Strategy;
import com.google.firebase.auth.EmailAuthProvider;

public class PreferenceHandler {
    private static PreferenceHandler instance = null;
    /* renamed from: sh */
    private SharedPreferences f458sh;

    private PreferenceHandler() {
    }

    private PreferenceHandler(Context mContext) {
        this.f458sh = PreferenceManager.getDefaultSharedPreferences(mContext);
    }

    public static synchronized PreferenceHandler getInstance(Context mContext) {
        PreferenceHandler preferenceHandler;
        synchronized (PreferenceHandler.class) {
            if (instance == null) {
                instance = new PreferenceHandler(mContext);
            }
            preferenceHandler = instance;
        }
        return preferenceHandler;
    }

    public int getImageName() {
        return this.f458sh.getInt("imagename", 0);
    }

    public void setImageName(int imagename) {
        this.f458sh.edit().putInt("imagename", imagename).commit();
    }

    public String getRegisterId() {
        return this.f458sh.getString("reg_id", null);
    }

    public void setRegisterId(String reg_id) {
        this.f458sh.edit().putString("reg_id", reg_id).commit();
    }

    public String getMapStyle() {
        return this.f458sh.getString("mapstyle", "Hybrid");
    }

    public void setMapStyle(String mapstyle) {
        this.f458sh.edit().putString("mapstyle", mapstyle).commit();
    }

    public int getProgressLevelMap() {
        return this.f458sh.getInt("progress_level", 66);
    }

    public void setProgressLevelMap(int progress_level) {
        this.f458sh.edit().putInt("progress_level", progress_level).commit();
    }

    public String getProgressTextMap() {
        return this.f458sh.getString("progress_text", "Showing last 24 hours");
    }

    public void setProgressTextMap(String progress_text) {
        this.f458sh.edit().putString("progress_text", progress_text).commit();
    }

    public int getFromDuration() {
        return this.f458sh.getInt("from_duration", Strategy.TTL_SECONDS_MAX);
    }

    public void setFromDuration(int from_duration) {
        this.f458sh.edit().putInt("from_duration", from_duration).commit();
    }

    public int getListByCountFeed() {
        return this.f458sh.getInt("list_count", 0);
    }

    public void setListByCountFeed(int list_count) {
        this.f458sh.edit().putInt("list_count", list_count).commit();
    }

    public int getListByCountFeedState() {
        return this.f458sh.getInt("list_count_state", 0);
    }

    public void setListByCountFeedState(int list_count_state) {
        this.f458sh.edit().putInt("list_count_state", list_count_state).commit();
    }

    public boolean getPublicCamraStatus() {
        return this.f458sh.getBoolean("camera_status", true);
    }

    public void setPublicCamraStatus(boolean camera_status) {
        this.f458sh.edit().putBoolean("camera_status", camera_status).commit();
    }

    public boolean getNotificationStatus() {
        return this.f458sh.getBoolean("notification_status", true);
    }

    public void setNotificationStatus(boolean notification_status) {
        this.f458sh.edit().putBoolean("notification_status", notification_status).commit();
    }

    public boolean getMyBubbleStatus() {
        return this.f458sh.getBoolean("my_bubble_status", true);
    }

    public void setMyBubbleStatus(boolean my_bubble_status) {
        this.f458sh.edit().putBoolean("my_bubble_status", my_bubble_status).commit();
    }

    public String getUserName() {
        return this.f458sh.getString("userName", "");
    }

    public void setUserName(String userName) {
        this.f458sh.edit().putString("userName", userName).commit();
    }

    public String getUserEmail() {
        return this.f458sh.getString("useremail", "");
    }

    public void setUserEmail(String email) {
        this.f458sh.edit().putString("useremail", email).commit();
    }

    public String getPassword() {
        return this.f458sh.getString(EmailAuthProvider.PROVIDER_ID, "");
    }

    public void setPassword(String password) {
        this.f458sh.edit().putString(EmailAuthProvider.PROVIDER_ID, password).commit();
    }

    public String getUserUUID() {
        return this.f458sh.getString("user_uuid", "");
    }

    public void setUserUUID(String user_uuid) {
        this.f458sh.edit().putString("user_uuid", user_uuid).commit();
    }

    public String getUserDisplayName() {
        return this.f458sh.getString("user_display_name", "");
    }

    public void setUserDisplayName(String user_display_name) {
        this.f458sh.edit().putString("user_display_name", user_display_name).commit();
    }

    public Boolean getSuperUser() {
        return Boolean.valueOf(this.f458sh.getBoolean("is_super_user", false));
    }

    public void setSuperUser(Boolean super_user) {
        this.f458sh.edit().putBoolean("is_super_user", super_user.booleanValue()).commit();
    }

    public String getOutBoxSet() {
        return this.f458sh.getString("outboxset", "");
    }

    public void setOutBoxSet(String outboxset) {
        this.f458sh.edit().putString("outboxset", outboxset).commit();
    }

    public String getServerName() {
        return this.f458sh.getString("server_name", "");
    }

    public void setServerName(String server_name) {
        this.f458sh.edit().putString("server_name", server_name).commit();
    }

    public int getMaxVideoDuration() {
        return this.f458sh.getInt("video_duration", 0);
    }

    public void setMaxVideoDuration(int video_duration) {
        this.f458sh.edit().putInt("video_duration", video_duration).commit();
    }

    public String getCurrentEthAddress() {
        return this.f458sh.getString("current_address", "0");
    }

    public void setCurrentEthAddress(String current_address) {
        this.f458sh.edit().putString("current_address", current_address).commit();
    }

    public String getPrivateEthAddress() {
        return this.f458sh.getString("private_address", "");
    }

    public void setPrivateEthAddress(String current_address) {
        this.f458sh.edit().putString("private_address", current_address).commit();
    }

    public String getPublicEthAddress() {
        return this.f458sh.getString("public_address", "");
    }

    public void setPublicEthAddress(String current_address) {
        this.f458sh.edit().putString("public_address", current_address).commit();
    }

    public String getMnemonicPhrase() {
        return this.f458sh.getString("mnemonic", "");
    }

    public void setMnemonicPhrase(String mnemonic) {
        this.f458sh.edit().putString("mnemonic", mnemonic).commit();
    }

    public int getShowVerifyPhrase() {
        return this.f458sh.getInt("show_verify_phrase", 0);
    }

    public void setShowVerifyPhrase(int verify_phrase) {
        this.f458sh.edit().putInt("show_verify_phrase", verify_phrase).commit();
    }

    public int getVerifyPhrase() {
        return this.f458sh.getInt("verify_phrase", 0);
    }

    public void setVerifyPhrase(int verify_phrase) {
        this.f458sh.edit().putInt("verify_phrase", verify_phrase).commit();
    }

    public int getVerifyPasswordWallet() {
        return this.f458sh.getInt("verify_password_wallet", 0);
    }

    public void setVerifyPasswordWallet(int verify_phrase) {
        this.f458sh.edit().putInt("verify_password_wallet", verify_phrase).commit();
    }

    public String getCheckImportPublicAddress() {
        return this.f458sh.getString("check_import", "");
    }

    public void setCheckImportPublicAddress(String mnemonic) {
        this.f458sh.edit().putString("check_import", mnemonic).commit();
    }

    public Boolean getLoginTypeSignIn() {
        return Boolean.valueOf(this.f458sh.getBoolean("is_login_user", true));
    }

    public void setLoginTypeSignIn(Boolean super_user) {
        this.f458sh.edit().putBoolean("is_login_user", super_user.booleanValue()).commit();
    }

    public Boolean getVerifiedOTPForSignUp() {
        return Boolean.valueOf(this.f458sh.getBoolean("verify_otp_signup", false));
    }

    public void setVerifiedOTPForSignUp(Boolean super_user) {
        this.f458sh.edit().putBoolean("verify_otp_signup", super_user.booleanValue()).commit();
    }

    public String getMobileNumber() {
        return this.f458sh.getString("mobile_number", "");
    }

    public void setMobileNumber(String mobilenumber) {
        this.f458sh.edit().putString("mobile_number", mobilenumber).commit();
    }

    public String getAuthyId() {
        return this.f458sh.getString("authyid", "");
    }

    public void setAuthyId(String authyid) {
        this.f458sh.edit().putString("authyid", authyid).commit();
    }

    public void clear() {
        this.f458sh.edit().clear().commit();
    }
}
