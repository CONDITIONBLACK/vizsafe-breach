package com.vizsafe.app.Utils;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.net.ConnectivityManager;
import android.os.Build.VERSION;
import android.support.p001v4.app.ActivityCompat;
import android.support.p001v4.content.ContextCompat;
import android.text.format.DateFormat;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.display.SimpleBitmapDisplayer;
import com.squareup.okhttp.OkHttpClient;
import com.vizsafe.app.C0421R;
import java.io.File;
import java.io.FileInputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Calendar;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.http.HttpHeaders;
import org.apache.http.protocol.HTTP;
import retrofit.RestAdapter;
import retrofit.RestAdapter.Builder;
import retrofit.RestAdapter.Log;
import retrofit.RestAdapter.LogLevel;
import retrofit.client.OkClient;

public class CommonMember {
    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    public static final int MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE = 123;
    public static ImageLoader imgloader = ImageLoader.getInstance();
    private static boolean mNetworkStatus = false;
    private static CommonMember ourInstance = new CommonMember();
    static final Pattern qrPattern = Pattern.compile("^ethereum:(0x[0-9a-f]{40,})([?]value=[0-9]{1,10})?");
    private static String weiInEth = "1000000000000000000";
    private static String weiInGwei = "1000000000";
    private RestAdapter ApiBuilder;
    private String PrefName_User = "User";

    /* renamed from: com.vizsafe.app.Utils.CommonMember$1 */
    class C04221 implements Log {
        C04221() {
        }

        public void log(String msg) {
            int i = 0;
            String[] blacklist = new String[]{"Access-Control", HttpHeaders.CACHE_CONTROL, "Connection", "Content-Type", HTTP.CONN_KEEP_ALIVE, HttpHeaders.PRAGMA, "Server", HttpHeaders.VARY, "X-Powered-By"};
            int length = blacklist.length;
            while (i < length && !msg.startsWith(blacklist[i])) {
                i++;
            }
        }
    }

    /* renamed from: com.vizsafe.app.Utils.CommonMember$2 */
    class C04232 implements Log {
        C04232() {
        }

        public void log(String msg) {
            int i = 0;
            String[] blacklist = new String[]{"Access-Control", HttpHeaders.CACHE_CONTROL, "Connection", "Content-Type", HTTP.CONN_KEEP_ALIVE, HttpHeaders.PRAGMA, "Server", HttpHeaders.VARY, "X-Powered-By"};
            int length = blacklist.length;
            while (i < length && !msg.startsWith(blacklist[i])) {
                i++;
            }
        }
    }

    /* renamed from: com.vizsafe.app.Utils.CommonMember$3 */
    static class C04243 implements OnClickListener {
        C04243() {
        }

        public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
        }
    }

    /* renamed from: com.vizsafe.app.Utils.CommonMember$4 */
    static class C04254 implements OnClickListener {
        C04254() {
        }

        public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
        }
    }

    public static class Config {
        public static final boolean DEVELOPER_MODE = false;
    }

    public static CommonMember getInstance(Context context) {
        if (ourInstance == null) {
            synchronized (CommonMember.class) {
                if (ourInstance == null) {
                    ourInstance = new CommonMember();
                }
            }
        }
        ourInstance.config(context);
        return ourInstance;
    }

    public static CommonMember getInstanceZone() {
        if (ourInstance == null) {
            synchronized (CommonMember.class) {
                if (ourInstance == null) {
                    ourInstance = new CommonMember();
                }
            }
        }
        ourInstance.config1();
        return ourInstance;
    }

    private void config1() {
        OkHttpClient mOkHttp = new OkHttpClient();
        mOkHttp.setReadTimeout(150, TimeUnit.SECONDS);
        mOkHttp.setConnectTimeout(150, TimeUnit.SECONDS);
        this.ApiBuilder = new Builder().setLogLevel(LogLevel.FULL).setClient(new OkClient(mOkHttp)).setEndpoint(Constants.INITIALURL).setLog(new C04221()).build();
    }

    private void config(Context context) {
        String URL = "https://" + PreferenceHandler.getInstance(context).getServerName() + "/api/mobile";
        OkHttpClient mOkHttp = new OkHttpClient();
        mOkHttp.setReadTimeout(150, TimeUnit.SECONDS);
        mOkHttp.setConnectTimeout(150, TimeUnit.SECONDS);
        this.ApiBuilder = new Builder().setLogLevel(LogLevel.FULL).setClient(new OkClient(mOkHttp)).setEndpoint(URL).setLog(new C04232()).build();
    }

    public RestAdapter getApiBuilder() {
        return this.ApiBuilder;
    }

    public void setApiBuilder(RestAdapter apiBuilder) {
        this.ApiBuilder = apiBuilder;
    }

    public static String getURL(Context context) {
        String SERVER = PreferenceHandler.getInstance(context).getServerName();
        if (SERVER == null && SERVER.isEmpty()) {
            return Constants.INITIALURL;
        }
        return "https://" + SERVER + "/api/mobile";
    }

    public static DisplayImageOptions imageLoader() {
        return new DisplayImageOptions.Builder().showImageForEmptyUri((int) C0421R.mipmap.ic_launcher).cacheInMemory().showImageForEmptyUri((int) C0421R.mipmap.ic_launcher).cacheInMemory().cacheOnDisc().displayer(new SimpleBitmapDisplayer()).cacheInMemory().cacheOnDisc().build();
    }

    public static void HideKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService("input_method");
        View view = activity.getCurrentFocus();
        if (view == null) {
            view = new View(activity);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    public static boolean isNetworkOnline(ConnectivityManager cm, Context mContext) {
        try {
            ConnectivityManager connectivityManager = (ConnectivityManager) mContext.getSystemService("connectivity");
            boolean isWifiConn = connectivityManager.getNetworkInfo(1).isConnected();
            boolean isMobileConn = connectivityManager.getNetworkInfo(0).isConnected();
            if (isWifiConn || isMobileConn) {
                mNetworkStatus = true;
                return mNetworkStatus;
            }
            mNetworkStatus = false;
            return mNetworkStatus;
        } catch (Exception e) {
            e.printStackTrace();
            mNetworkStatus = false;
        }
    }

    public static void NetworkStatusAlert(Context getActivity) {
        try {
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity);
            builder.setMessage(getActivity.getResources().getString(C0421R.string.no_internet_access));
            builder.setTitle(getActivity.getResources().getString(C0421R.string.NetworkStatusTxt));
            builder.setNeutralButton(getActivity.getResources().getString(C0421R.string.okTxt), new C04243());
            builder.create().show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static AlertDialog getErrorDialog(String message, Context context) {
        AlertDialog.Builder dialog = new AlertDialog.Builder(context);
        dialog.setTitle(context.getString(C0421R.string.app_name));
        dialog.setMessage(message);
        dialog.setPositiveButton(context.getResources().getString(C0421R.string.okTxt), new C04254());
        AlertDialog errorDialog = dialog.create();
        errorDialog.setCanceledOnTouchOutside(true);
        return errorDialog;
    }

    public static Bitmap decodeFile(String path) {
        Exception e;
        Bitmap b = null;
        File f = new File(path);
        Options o = new Options();
        o.inJustDecodeBounds = true;
        try {
            FileInputStream fis = new FileInputStream(f);
            FileInputStream fis2;
            try {
                BitmapFactory.decodeStream(fis, null, o);
                fis.close();
                int scale = 1;
                if (o.outHeight > 1024 || o.outWidth > 1024) {
                    scale = (int) Math.pow(2.0d, (double) ((int) Math.round(Math.log(((double) 1024) / ((double) Math.max(o.outHeight, o.outWidth))) / Math.log(0.5d))));
                }
                Options o2 = new Options();
                o2.inSampleSize = scale;
                fis2 = new FileInputStream(f);
                b = BitmapFactory.decodeStream(fis2, null, o2);
                fis2.close();
                return b;
            } catch (Exception e2) {
                e = e2;
                fis2 = fis;
                e.printStackTrace();
                return b;
            }
        } catch (Exception e3) {
            e = e3;
        }
    }

    public static Bitmap showBitmapFromFile(String file_path) {
        try {
            if (new File(file_path).exists()) {
                return decodeFile(file_path);
            }
            return null;
        } catch (Exception e) {
            return null;
        }
    }

    public static String GetKeyString() {
        try {
            int mMinute = new Random().nextInt(8) + 1;
            return String.valueOf(mMinute) + reverse(Long.valueOf(System.currentTimeMillis() / 1000).toString());
        } catch (Exception e) {
            return null;
        }
    }

    public static String GetOrinalKey(String mKey) throws NoSuchAlgorithmException {
        String mSHAKey = "0";
        try {
            return SHA256(mKey + "-Vizsafe-" + reverse(mKey));
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return mSHAKey;
        }
    }

    public static String reverse(String input) {
        char[] in = input.toCharArray();
        int end = in.length - 1;
        for (int begin = 0; end > begin; begin++) {
            char temp = in[begin];
            in[begin] = in[end];
            in[end] = temp;
            end--;
        }
        return new String(in);
    }

    public static String SHA256(String text) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        md.update(text.getBytes());
        byte[] byteData = md.digest();
        StringBuffer sb = new StringBuffer();
        for (byte b : byteData) {
            sb.append(Integer.toString((b & 255) + 256, 16).substring(1));
        }
        StringBuffer hexString = new StringBuffer();
        for (byte b2 : byteData) {
            String hex = Integer.toHexString(b2 & 255);
            if (hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        return hexString.toString();
    }

    public static String extractAddressFromQrString(String qrString) {
        Matcher m = qrPattern.matcher(qrString);
        if (m.find()) {
            return m.group(1);
        }
        return null;
    }

    public static String WeiToEth(String wei, int sigFig) throws Exception {
        BigDecimal eth = new BigDecimal(wei).divide(new BigDecimal(weiInEth));
        return eth.setScale((sigFig - eth.precision()) + eth.scale(), RoundingMode.HALF_UP).toString();
    }

    public static String GetDate(long time) {
        Calendar cal = Calendar.getInstance(Locale.ENGLISH);
        cal.setTimeInMillis(1000 * time);
        return DateFormat.format("MM/dd/yy H:mm:ss zzz", cal).toString();
    }

    public static String WeiToGwei(String wei) {
        return new BigDecimal(wei).divide(new BigDecimal(weiInGwei)).toString();
    }

    public static String WeiToEth(String wei) {
        return new BigDecimal(wei).divide(new BigDecimal(weiInEth)).toString();
    }

    @TargetApi(16)
    public static boolean checkPermission(final Context context) {
        if (VERSION.SDK_INT < 23) {
            return true;
        }
        if (ContextCompat.checkSelfPermission(context, "android.permission.READ_EXTERNAL_STORAGE") == 0) {
            return true;
        }
        if (ActivityCompat.shouldShowRequestPermissionRationale((Activity) context, "android.permission.READ_EXTERNAL_STORAGE")) {
            AlertDialog.Builder alertBuilder = new AlertDialog.Builder(context);
            alertBuilder.setCancelable(true);
            alertBuilder.setTitle("Permission necessary");
            alertBuilder.setMessage("External storage permission is necessary");
            alertBuilder.setPositiveButton(17039379, new OnClickListener() {
                @TargetApi(16)
                public void onClick(DialogInterface dialog, int which) {
                    ActivityCompat.requestPermissions((Activity) context, new String[]{"android.permission.READ_EXTERNAL_STORAGE"}, CommonMember.MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE);
                }
            });
            alertBuilder.create().show();
        } else {
            ActivityCompat.requestPermissions((Activity) context, new String[]{"android.permission.READ_EXTERNAL_STORAGE"}, MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE);
        }
        return false;
    }

    public static boolean checkLocationPermission(Activity activity) {
        if (ContextCompat.checkSelfPermission(activity, "android.permission.ACCESS_FINE_LOCATION") == 0) {
            return true;
        }
        if (ActivityCompat.shouldShowRequestPermissionRationale(activity, "android.permission.ACCESS_FINE_LOCATION")) {
            ActivityCompat.requestPermissions(activity, new String[]{"android.permission.ACCESS_FINE_LOCATION"}, 99);
            return false;
        }
        ActivityCompat.requestPermissions(activity, new String[]{"android.permission.ACCESS_FINE_LOCATION"}, 99);
        return false;
    }

    public static void hideKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService("input_method");
        View view = activity.getCurrentFocus();
        if (view == null) {
            view = new View(activity);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }
}
