package com.vizsafe.app.Utils;

public class VizsafeConfigFile {
    public static String[] mStadiumCommunityId = new String[]{"20316", "18351"};
    public static String[] mStadiumName = new String[]{"Gillette Stadium", "MCCA Organization"};
    public static String[] mZipCode = new String[]{"02035", "02210"};
}
