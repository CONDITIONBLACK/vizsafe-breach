package com.vizsafe.app.GeoFence;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.p001v4.app.Fragment;
import android.support.p001v4.widget.SwipeRefreshLayout;
import android.support.p001v4.widget.SwipeRefreshLayout.OnRefreshListener;
import android.support.p002v7.media.SystemMediaRouteProvider;
import android.support.p002v7.widget.DefaultItemAnimator;
import android.support.p002v7.widget.LinearLayoutManager;
import android.support.p002v7.widget.RecyclerView;
import android.util.Base64;
import android.view.InflateException;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import com.google.android.gms.analytics.ecommerce.ProductAction;
import com.google.firebase.analytics.FirebaseAnalytics.Param;
import com.google.gson.JsonObject;
import com.vizsafe.app.APIClientMethods.GetGeoFenceListAPI;
import com.vizsafe.app.APIClientMethods.RegisterGCMIdApi;
import com.vizsafe.app.APIClientMethods.RegisterGCMIdApi.ResponseRegisterGCMIdApi;
import com.vizsafe.app.APIClientMethods.UnregisterDeviceIdApi;
import com.vizsafe.app.APIClientMethods.UnregisterDeviceIdApi.ResponseUnregisterDeviceIdApi;
import com.vizsafe.app.Adapters.GeofencesListAdapter;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.GCMIntentService.GCMClientManager;
import com.vizsafe.app.POJO.GeofencesListItems;
import com.vizsafe.app.Utils.CommonMember;
import com.vizsafe.app.Utils.PreferenceHandler;
import dmax.dialog.SpotsDialog;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class GeofencesScreen extends Fragment {
    public static boolean byPressingAddGeofences = false;
    public static View lowerLine;
    public static View upperLine;
    public static Button visibleBtn;
    GeofencesListAdapter adapter;
    private TextView addGeofencesBtn;
    ArrayList<GeofencesListItems> arraylist = new ArrayList();
    String authenticationString;
    Button deleteBtn = null;
    String devicetoken = null;
    ImageView doneBtn;
    private RecyclerView geofencesList;
    private Context mContext;
    private JSONObject mJsonResponse;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    AlertDialog mTransparentProgressDialog;
    String mUserUuid;
    private ToggleButton myBubbleStatus;
    private ToggleButton notificationStatus;
    private View vPage;

    /* renamed from: com.vizsafe.app.GeoFence.GeofencesScreen$1 */
    class C02801 implements OnRefreshListener {
        C02801() {
        }

        public void onRefresh() {
            if (CommonMember.isNetworkOnline((ConnectivityManager) GeofencesScreen.this.mContext.getSystemService("connectivity"), GeofencesScreen.this.mContext)) {
                GeofencesScreen.this.TaskGetGeofencesList();
            } else {
                CommonMember.getErrorDialog(GeofencesScreen.this.getString(C0421R.string.no_internet_access), GeofencesScreen.this.mContext).show();
            }
        }
    }

    /* renamed from: com.vizsafe.app.GeoFence.GeofencesScreen$2 */
    class C02812 implements OnClickListener {
        C02812() {
        }

        public void onClick(View v) {
            Intent goToAddGeoFences = new Intent(GeofencesScreen.this.mContext, AddGeofencesScreen.class);
            goToAddGeoFences.putExtra("geoFence_uuid", "");
            GeofencesScreen.this.startActivityForResult(goToAddGeoFences, 1);
            GeofencesScreen.byPressingAddGeofences = true;
        }
    }

    /* renamed from: com.vizsafe.app.GeoFence.GeofencesScreen$3 */
    class C02823 implements OnClickListener {
        C02823() {
        }

        public void onClick(View v) {
            ((onGoToSettingsPageListener) GeofencesScreen.this.mContext).onGoToSettingsPage();
        }
    }

    /* renamed from: com.vizsafe.app.GeoFence.GeofencesScreen$4 */
    class C02834 implements OnCheckedChangeListener {
        C02834() {
        }

        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            if (!CommonMember.isNetworkOnline((ConnectivityManager) GeofencesScreen.this.mContext.getSystemService("connectivity"), GeofencesScreen.this.mContext)) {
                CommonMember.getErrorDialog(GeofencesScreen.this.getString(C0421R.string.no_internet_access), GeofencesScreen.this.mContext).show();
            } else if (isChecked) {
                PreferenceHandler.getInstance(GeofencesScreen.this.mContext).setNotificationStatus(true);
                GeofencesScreen.this.TaskRegisterDeviceForNotification();
            } else {
                PreferenceHandler.getInstance(GeofencesScreen.this.mContext).setNotificationStatus(false);
                GeofencesScreen.this.TaskUnregisterDeviceForNotification();
            }
        }
    }

    /* renamed from: com.vizsafe.app.GeoFence.GeofencesScreen$5 */
    class C02845 implements OnCheckedChangeListener {
        C02845() {
        }

        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            if (isChecked) {
                PreferenceHandler.getInstance(GeofencesScreen.this.mContext).setMyBubbleStatus(true);
            } else {
                PreferenceHandler.getInstance(GeofencesScreen.this.mContext).setMyBubbleStatus(false);
            }
        }
    }

    /* renamed from: com.vizsafe.app.GeoFence.GeofencesScreen$7 */
    class C02867 implements Callback<ResponseUnregisterDeviceIdApi> {
        C02867() {
        }

        public void success(ResponseUnregisterDeviceIdApi responseUnregisterDeviceIdApi, Response response) {
            GeofencesScreen.this.mTransparentProgressDialog.dismiss();
            if (responseUnregisterDeviceIdApi.getHttpCode().intValue() == 200) {
                Toast.makeText(GeofencesScreen.this.mContext, responseUnregisterDeviceIdApi.getMessage(), 0).show();
            } else {
                Toast.makeText(GeofencesScreen.this.mContext, responseUnregisterDeviceIdApi.getMessage(), 0).show();
            }
        }

        public void failure(RetrofitError error) {
            error.printStackTrace();
            GeofencesScreen.this.mTransparentProgressDialog.dismiss();
        }
    }

    /* renamed from: com.vizsafe.app.GeoFence.GeofencesScreen$8 */
    class C02878 implements Callback<JsonObject> {
        C02878() {
        }

        public void success(JsonObject responseFeedListGeoZoneApi, Response response) {
            GeofencesScreen.this.mTransparentProgressDialog.dismiss();
            if (responseFeedListGeoZoneApi != null) {
                try {
                    GeofencesScreen.this.mJsonResponse = new JSONObject(String.valueOf(responseFeedListGeoZoneApi));
                    int httpCode = GeofencesScreen.this.mJsonResponse.getInt("httpCode");
                    String message = GeofencesScreen.this.mJsonResponse.getString(GCMClientManager.EXTRA_MESSAGE);
                    if (httpCode == 200) {
                        if (!GeofencesScreen.this.arraylist.isEmpty()) {
                            GeofencesScreen.this.arraylist.clear();
                        }
                        JSONObject mDetail = GeofencesScreen.this.mJsonResponse.getJSONObject(ProductAction.ACTION_DETAIL);
                        if (mDetail.getInt("total") > 0) {
                            JSONArray mFilters = mDetail.getJSONArray("filters");
                            for (int i = 0; i < mFilters.length(); i++) {
                                String geoFenceLatitude = null;
                                String geoFenceLongitude = null;
                                JSONObject singleIncidentObject = mFilters.getJSONObject(i);
                                String geoFencesName = singleIncidentObject.getString("name");
                                String geoFenceLocationLevel = String.valueOf(singleIncidentObject.getInt("locationLevel"));
                                String geoFenceUuid = singleIncidentObject.getString("uuid");
                                JSONObject feedLocationAndGeoObject = singleIncidentObject.getJSONObject(Param.LOCATION);
                                if (feedLocationAndGeoObject != null) {
                                    JSONObject feedLocationObject = feedLocationAndGeoObject.getJSONObject("loc");
                                    if (feedLocationObject != null) {
                                        geoFenceLatitude = feedLocationObject.getString("lat");
                                        geoFenceLongitude = feedLocationObject.getString("lng");
                                    }
                                }
                                GeofencesScreen.this.arraylist.add(new GeofencesListItems(geoFencesName, geoFenceUuid, geoFenceLocationLevel, geoFenceLatitude, geoFenceLongitude));
                            }
                            GeofencesScreen.this.adapter = new GeofencesListAdapter(GeofencesScreen.this.mContext, GeofencesScreen.this.arraylist);
                            GeofencesScreen.this.geofencesList.setAdapter(GeofencesScreen.this.adapter);
                            return;
                        }
                        return;
                    }
                    GeofencesScreen.this.mTransparentProgressDialog.dismiss();
                    Toast.makeText(GeofencesScreen.this.mContext, message, 0).show();
                    return;
                } catch (JSONException e) {
                    e.printStackTrace();
                    return;
                }
            }
            GeofencesScreen.this.mTransparentProgressDialog.dismiss();
            Toast.makeText(GeofencesScreen.this.mContext, "Error", 0).show();
        }

        public void failure(RetrofitError error) {
            GeofencesScreen.this.mTransparentProgressDialog.dismiss();
            error.printStackTrace();
        }
    }

    public interface onGoToSettingsPageListener {
        void onGoToSettingsPage();
    }

    public static GeofencesScreen newInstance() {
        return new GeofencesScreen();
    }

    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.clear();
    }

    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (this.vPage != null) {
            ViewGroup parent = (ViewGroup) this.vPage.getParent();
            if (parent != null) {
                parent.removeView(this.vPage);
            }
        }
        try {
            getActivity().getWindow().setSoftInputMode(3);
            this.vPage = inflater.inflate(C0421R.layout.geofences_screen, container, false);
            this.mContext = getContext();
            this.mTransparentProgressDialog = new SpotsDialog(this.mContext, getResources().getString(C0421R.string.please_wait_loading));
            this.mTransparentProgressDialog.setCanceledOnTouchOutside(false);
            this.mTransparentProgressDialog.setCancelable(false);
            this.addGeofencesBtn = (TextView) this.vPage.findViewById(C0421R.C0419id.action_bar_next);
            this.doneBtn = (ImageView) this.vPage.findViewById(C0421R.C0419id.action_bar_back);
            this.notificationStatus = (ToggleButton) this.vPage.findViewById(C0421R.C0419id.notification_status);
            this.myBubbleStatus = (ToggleButton) this.vPage.findViewById(C0421R.C0419id.my_bubble_status);
            this.notificationStatus.setChecked(PreferenceHandler.getInstance(this.mContext).getNotificationStatus());
            this.myBubbleStatus.setChecked(PreferenceHandler.getInstance(this.mContext).getMyBubbleStatus());
            this.addGeofencesBtn.setVisibility(0);
            this.addGeofencesBtn.setText(getString(C0421R.string.add_geos));
            this.geofencesList = (RecyclerView) this.vPage.findViewById(C0421R.C0419id.geofences_list);
            this.mSwipeRefreshLayout = (SwipeRefreshLayout) this.vPage.findViewById(C0421R.C0419id.swipeRefreshLayout);
            this.mSwipeRefreshLayout.setColorSchemeResources(C0421R.color.colorPrimary, C0421R.color.colorPrimaryDark, C0421R.color.blue, 17170451);
            this.geofencesList.setLayoutManager(new LinearLayoutManager(getActivity()));
            this.geofencesList.setItemAnimator(new DefaultItemAnimator());
            this.adapter = new GeofencesListAdapter(this.mContext, this.arraylist);
            this.geofencesList.setAdapter(this.adapter);
            upperLine = this.vPage.findViewById(C0421R.C0419id.upper_line);
            lowerLine = this.vPage.findViewById(C0421R.C0419id.lower_line);
            String email = PreferenceHandler.getInstance(this.mContext).getUserName();
            String password = PreferenceHandler.getInstance(this.mContext).getPassword();
            this.devicetoken = PreferenceHandler.getInstance(this.mContext).getRegisterId();
            this.mUserUuid = PreferenceHandler.getInstance(this.mContext).getUserUUID();
            this.authenticationString = "Basic " + Base64.encodeToString((email + ":" + password).getBytes(), 2);
            if (PreferenceHandler.getInstance(this.mContext).getNotificationStatus()) {
                this.notificationStatus.setChecked(true);
            } else {
                this.notificationStatus.setChecked(false);
            }
            if (CommonMember.isNetworkOnline((ConnectivityManager) this.mContext.getSystemService("connectivity"), this.mContext)) {
                TaskGetGeofencesList();
            } else {
                CommonMember.getErrorDialog(getString(C0421R.string.no_internet_access), this.mContext).show();
            }
            this.mSwipeRefreshLayout.setOnRefreshListener(new C02801());
            this.addGeofencesBtn.setOnClickListener(new C02812());
            this.doneBtn.setOnClickListener(new C02823());
            this.notificationStatus.setOnCheckedChangeListener(new C02834());
            this.myBubbleStatus.setOnCheckedChangeListener(new C02845());
        } catch (InflateException e) {
        }
        return this.vPage;
    }

    private void TaskRegisterDeviceForNotification() {
        this.mTransparentProgressDialog.show();
        String uuid = PreferenceHandler.getInstance(this.mContext).getUserUUID();
        final String mRegisterId = PreferenceHandler.getInstance(this.mContext).getRegisterId();
        RegisterGCMIdApi.getInstance().Callresponse(this.mContext, uuid, mRegisterId, SystemMediaRouteProvider.PACKAGE_NAME, new Callback<ResponseRegisterGCMIdApi>() {
            public void success(ResponseRegisterGCMIdApi responseRegisterGCMIdApi, Response response) {
                GeofencesScreen.this.mTransparentProgressDialog.dismiss();
                if (responseRegisterGCMIdApi.getHttpCode().intValue() == 200) {
                    Toast.makeText(GeofencesScreen.this.mContext, responseRegisterGCMIdApi.getMessage(), 0).show();
                    PreferenceHandler.getInstance(GeofencesScreen.this.mContext).setRegisterId(mRegisterId);
                    return;
                }
                Toast.makeText(GeofencesScreen.this.mContext, responseRegisterGCMIdApi.getMessage(), 0).show();
            }

            public void failure(RetrofitError error) {
                GeofencesScreen.this.mTransparentProgressDialog.dismiss();
                error.printStackTrace();
            }
        });
    }

    private void TaskUnregisterDeviceForNotification() {
        String registerId = PreferenceHandler.getInstance(this.mContext).getRegisterId();
        this.mTransparentProgressDialog.show();
        UnregisterDeviceIdApi.getInstance().Callresponse(this.mContext, this.authenticationString, registerId, new C02867());
    }

    private void TaskGetGeofencesList() {
        this.mTransparentProgressDialog.show();
        this.mSwipeRefreshLayout.setRefreshing(false);
        GetGeoFenceListAPI.getInstance().Callresponse(this.mContext, this.authenticationString, this.devicetoken, this.mUserUuid, new C02878());
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 1) {
            if (resultCode == -1) {
                if (CommonMember.isNetworkOnline((ConnectivityManager) this.mContext.getSystemService("connectivity"), this.mContext)) {
                    TaskGetGeofencesList();
                } else {
                    CommonMember.getErrorDialog(getString(C0421R.string.no_internet_access), this.mContext).show();
                }
            }
            if (resultCode == 0) {
            }
        } else if (requestCode == 2) {
            if (resultCode == -1) {
                if (CommonMember.isNetworkOnline((ConnectivityManager) this.mContext.getSystemService("connectivity"), this.mContext)) {
                    TaskGetGeofencesList();
                } else {
                    CommonMember.getErrorDialog(getString(C0421R.string.no_internet_access), this.mContext).show();
                }
            }
            if (resultCode == 0) {
            }
        }
    }

    public void onResume() {
        super.onResume();
        if (CommonMember.isNetworkOnline((ConnectivityManager) this.mContext.getSystemService("connectivity"), this.mContext)) {
            TaskGetGeofencesList();
        } else {
            CommonMember.getErrorDialog(getString(C0421R.string.no_internet_access), this.mContext).show();
        }
    }
}
