package com.vizsafe.app.GeoFence;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.p001v4.app.ActivityCompat;
import android.support.p001v4.content.ContextCompat;
import android.support.p002v7.app.AppCompatActivity;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnMapLongClickListener;
import com.google.android.gms.maps.GoogleMap.OnMyLocationButtonClickListener;
import com.google.android.gms.maps.GoogleMap.OnMyLocationClickListener;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition.Builder;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.analytics.FirebaseAnalytics.Param;
import com.vizsafe.app.APIClientMethods.AddUploadGeoFenceApi;
import com.vizsafe.app.APIClientMethods.AddUploadGeoFenceApi.ResponseAddUploadGeoFenceApi;
import com.vizsafe.app.APIClientMethods.EditUploadGeoFenceApi;
import com.vizsafe.app.APIClientMethods.EditUploadGeoFenceApi.ResponseEditUploadGeoFenceApi;
import com.vizsafe.app.APIClientMethods.GetLocationAddressApi;
import com.vizsafe.app.APIClientMethods.GetLocationAddressApi.ResponseGetLocationAddressApi;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.Utils.CommonMember;
import com.vizsafe.app.Utils.PreferenceHandler;
import com.vizsafe.app.Utils.VizsafeGPSTracker;
import dmax.dialog.SpotsDialog;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class AddGeofencesScreen extends AppCompatActivity implements OnMyLocationButtonClickListener, OnMyLocationClickListener, OnMapReadyCallback, OnMapLongClickListener, ConnectionCallbacks, LocationListener {
    private static final String COURSE_LOCATION = "android.permission.ACCESS_COARSE_LOCATION";
    private static final float DEFAULT_ZOOM = 18.0f;
    private static final String FINE_LOCATION = "android.permission.ACCESS_FINE_LOCATION";
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1234;
    private static final String TAG = "AddGeoFence";
    AddGeofencesScreen addGeofencesScreen;
    private String authenticationString;
    ImageView cancelBtn;
    private String cityString;
    private String countryString;
    private String devicetoken;
    String encodedStringLocation;
    String geoFenceUuid = "";
    private VizsafeGPSTracker gps;
    private boolean gps_enabled;
    double latitude;
    int locationLevel = 0;
    String locationStringToSend;
    TextView locationText;
    HashMap<String, String> locationValues;
    double longitude;
    private FusedLocationProviderClient mFusedLocationClient;
    GoogleApiClient mGoogleApiClient;
    Location mLastLocation;
    private Boolean mLocationPermissionsGranted = Boolean.valueOf(false);
    LocationRequest mLocationRequest;
    GoogleMap mMap;
    private AlertDialog mTransparentProgressDialog;
    private String mUserUuid;
    Marker marker = null;
    TextView saveBtn;
    private String stateString;
    int stepperCount = 0;
    Button stepperDown;
    Button stepperUp;
    String stringCropped;
    String stringForStepper = null;
    private String zipCodeString;

    /* renamed from: com.vizsafe.app.GeoFence.AddGeofencesScreen$10 */
    class C027010 implements OnClickListener {
        C027010() {
        }

        public void onClick(DialogInterface dialog, int id) {
            AddGeofencesScreen.this.startActivity(new Intent("android.settings.LOCATION_SOURCE_SETTINGS"));
        }
    }

    /* renamed from: com.vizsafe.app.GeoFence.AddGeofencesScreen$1 */
    class C02711 implements View.OnClickListener {
        C02711() {
        }

        public void onClick(View v) {
            AddGeofencesScreen.this.setResult(0, new Intent());
            AddGeofencesScreen.this.finish();
        }
    }

    /* renamed from: com.vizsafe.app.GeoFence.AddGeofencesScreen$2 */
    class C02722 implements View.OnClickListener {
        C02722() {
        }

        public void onClick(View v) {
            if (!CommonMember.isNetworkOnline((ConnectivityManager) AddGeofencesScreen.this.getSystemService("connectivity"), AddGeofencesScreen.this)) {
                CommonMember.getErrorDialog(AddGeofencesScreen.this.getString(C0421R.string.no_internet_access), AddGeofencesScreen.this.addGeofencesScreen).show();
            } else if (AddGeofencesScreen.this.locationText.getText().toString().isEmpty()) {
                Toast.makeText(AddGeofencesScreen.this.addGeofencesScreen, AddGeofencesScreen.this.getResources().getString(C0421R.string.select_any_location), 1).show();
            } else {
                AddGeofencesScreen.this.locationValues = new HashMap();
                AddGeofencesScreen.this.locationValues.put("uuid", PreferenceHandler.getInstance(AddGeofencesScreen.this.addGeofencesScreen).getUserUUID());
                AddGeofencesScreen.this.locationValues.put("name", AddGeofencesScreen.this.locationText.getText().toString());
                AddGeofencesScreen.this.locationValues.put("type", Param.LOCATION);
                AddGeofencesScreen.this.locationValues.put("latitude", "" + AddGeofencesScreen.this.latitude);
                AddGeofencesScreen.this.locationValues.put("longitude", "" + AddGeofencesScreen.this.longitude);
                AddGeofencesScreen.this.locationValues.put("locationLevel", "" + AddGeofencesScreen.this.locationLevel);
                AddGeofencesScreen.this.TaskUploadGeoFence();
            }
        }
    }

    /* renamed from: com.vizsafe.app.GeoFence.AddGeofencesScreen$3 */
    class C02733 implements View.OnClickListener {
        C02733() {
        }

        public void onClick(View v) {
            if (AddGeofencesScreen.this.stringCropped == null) {
                return;
            }
            if (AddGeofencesScreen.this.stepperCount > 0) {
                AddGeofencesScreen.this.stringCropped = AddGeofencesScreen.this.stringCropped.substring(AddGeofencesScreen.this.stringCropped.indexOf(",") + 1).trim();
                AddGeofencesScreen.this.locationText.setText(AddGeofencesScreen.this.stringCropped);
                AddGeofencesScreen addGeofencesScreen = AddGeofencesScreen.this;
                addGeofencesScreen.stepperCount--;
            } else if (AddGeofencesScreen.this.stepperCount == 0) {
                AddGeofencesScreen.this.stringCropped = AddGeofencesScreen.this.stringForStepper;
                AddGeofencesScreen.this.locationText.setText(AddGeofencesScreen.this.stringCropped);
                for (char c : AddGeofencesScreen.this.stringCropped.toCharArray()) {
                    if (c == ',') {
                        AddGeofencesScreen addGeofencesScreen2 = AddGeofencesScreen.this;
                        addGeofencesScreen2.stepperCount++;
                    }
                }
            }
        }
    }

    /* renamed from: com.vizsafe.app.GeoFence.AddGeofencesScreen$4 */
    class C02744 implements View.OnClickListener {
        C02744() {
        }

        public void onClick(View v) {
            if (AddGeofencesScreen.this.stringCropped == null) {
                return;
            }
            if (AddGeofencesScreen.this.stepperCount > 0) {
                AddGeofencesScreen.this.locationText.setText(AddGeofencesScreen.this.stringCropped.substring(AddGeofencesScreen.nthOccurrence(AddGeofencesScreen.this.stringCropped, ',', AddGeofencesScreen.this.stepperCount) + 1).trim());
                AddGeofencesScreen addGeofencesScreen = AddGeofencesScreen.this;
                addGeofencesScreen.stepperCount--;
            } else if (AddGeofencesScreen.this.stepperCount == 0) {
                AddGeofencesScreen.this.stringCropped = AddGeofencesScreen.this.stringForStepper;
                AddGeofencesScreen.this.locationText.setText(AddGeofencesScreen.this.stringCropped);
                for (char c : AddGeofencesScreen.this.stringCropped.toCharArray()) {
                    if (c == ',') {
                        AddGeofencesScreen addGeofencesScreen2 = AddGeofencesScreen.this;
                        addGeofencesScreen2.stepperCount++;
                    }
                }
            }
        }
    }

    /* renamed from: com.vizsafe.app.GeoFence.AddGeofencesScreen$5 */
    class C02755 implements OnCompleteListener {
        C02755() {
        }

        public void onComplete(@NonNull Task task) {
            if (task.isSuccessful()) {
                Log.d(AddGeofencesScreen.TAG, "onComplete: found location!");
                Location currentLocation = (Location) task.getResult();
                AddGeofencesScreen.this.moveCamera(new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude()), AddGeofencesScreen.DEFAULT_ZOOM);
                return;
            }
            Log.d(AddGeofencesScreen.TAG, "onComplete: current location is null");
            Toast.makeText(AddGeofencesScreen.this, "unable to get current location", 0).show();
        }
    }

    /* renamed from: com.vizsafe.app.GeoFence.AddGeofencesScreen$6 */
    class C02766 implements Callback<ResponseEditUploadGeoFenceApi> {
        C02766() {
        }

        public void success(ResponseEditUploadGeoFenceApi responseEditUploadGeoFenceApi, Response response) {
            AddGeofencesScreen.this.mTransparentProgressDialog.dismiss();
            if (responseEditUploadGeoFenceApi != null) {
                Intent returnIntent = new Intent();
                returnIntent.putExtra("result", "1");
                AddGeofencesScreen.this.setResult(-1, returnIntent);
                AddGeofencesScreen.this.finish();
            }
        }

        public void failure(RetrofitError error) {
            AddGeofencesScreen.this.mTransparentProgressDialog.dismiss();
            error.printStackTrace();
        }
    }

    /* renamed from: com.vizsafe.app.GeoFence.AddGeofencesScreen$7 */
    class C02777 implements Callback<ResponseAddUploadGeoFenceApi> {
        C02777() {
        }

        public void success(ResponseAddUploadGeoFenceApi responseAddUploadGeoFenceApi, Response response) {
            AddGeofencesScreen.this.mTransparentProgressDialog.dismiss();
            if (responseAddUploadGeoFenceApi != null) {
                Intent returnIntent = new Intent();
                returnIntent.putExtra("result", "1");
                AddGeofencesScreen.this.setResult(-1, returnIntent);
                AddGeofencesScreen.this.finish();
            }
        }

        public void failure(RetrofitError error) {
            AddGeofencesScreen.this.mTransparentProgressDialog.dismiss();
            error.printStackTrace();
        }
    }

    /* renamed from: com.vizsafe.app.GeoFence.AddGeofencesScreen$8 */
    class C02788 implements Callback<ResponseGetLocationAddressApi> {
        C02788() {
        }

        public void success(ResponseGetLocationAddressApi responseGetLocationAddressApi, Response response) {
            int i = 0;
            if (responseGetLocationAddressApi != null) {
                AddGeofencesScreen.this.countryString = responseGetLocationAddressApi.getDetail().getCountry();
                AddGeofencesScreen.this.stateString = responseGetLocationAddressApi.getDetail().getState();
                AddGeofencesScreen.this.cityString = responseGetLocationAddressApi.getDetail().getCity();
                AddGeofencesScreen.this.zipCodeString = responseGetLocationAddressApi.getDetail().getZipcode();
                if (AddGeofencesScreen.this.zipCodeString != null) {
                    AddGeofencesScreen.this.locationLevel = 0;
                } else if (AddGeofencesScreen.this.cityString != null) {
                    AddGeofencesScreen.this.locationLevel = 1;
                } else if (AddGeofencesScreen.this.stateString != null) {
                    AddGeofencesScreen.this.locationLevel = 2;
                } else if (AddGeofencesScreen.this.countryString != null) {
                    AddGeofencesScreen.this.locationLevel = 3;
                } else {
                    AddGeofencesScreen.this.locationLevel = -1;
                }
                AddGeofencesScreen.this.stringForStepper = null;
                if (AddGeofencesScreen.this.locationLevel == 0) {
                    AddGeofencesScreen.this.locationText.setText(AddGeofencesScreen.this.zipCodeString + ", " + AddGeofencesScreen.this.stateString + ", " + AddGeofencesScreen.this.countryString);
                    AddGeofencesScreen.this.stringForStepper = AddGeofencesScreen.this.zipCodeString + "," + AddGeofencesScreen.this.cityString + "," + AddGeofencesScreen.this.stateString + "," + AddGeofencesScreen.this.countryString;
                } else if (AddGeofencesScreen.this.locationLevel == 1) {
                    AddGeofencesScreen.this.locationText.setText(AddGeofencesScreen.this.cityString + ", " + AddGeofencesScreen.this.stateString + ", " + AddGeofencesScreen.this.countryString);
                    AddGeofencesScreen.this.stringForStepper = AddGeofencesScreen.this.cityString + "," + AddGeofencesScreen.this.stateString + "," + AddGeofencesScreen.this.countryString;
                } else if (AddGeofencesScreen.this.locationLevel == 2) {
                    AddGeofencesScreen.this.locationText.setText(AddGeofencesScreen.this.stateString + ", " + AddGeofencesScreen.this.countryString);
                    AddGeofencesScreen.this.stringForStepper = AddGeofencesScreen.this.stateString + "," + AddGeofencesScreen.this.countryString;
                } else if (AddGeofencesScreen.this.locationLevel == 3) {
                    AddGeofencesScreen.this.locationText.setText(AddGeofencesScreen.this.countryString);
                    AddGeofencesScreen.this.stringForStepper = AddGeofencesScreen.this.countryString;
                } else {
                    AddGeofencesScreen.this.locationText.setText(AddGeofencesScreen.this.getString(C0421R.string.unknown_location));
                    AddGeofencesScreen.this.locationLevel = 0;
                    AddGeofencesScreen.this.stringForStepper = AddGeofencesScreen.this.getString(C0421R.string.unknown_location);
                }
                AddGeofencesScreen.this.stringCropped = AddGeofencesScreen.this.stringForStepper;
                char[] toCharArray = AddGeofencesScreen.this.stringCropped.toCharArray();
                int length = toCharArray.length;
                while (i < length) {
                    if (toCharArray[i] == ',') {
                        AddGeofencesScreen addGeofencesScreen = AddGeofencesScreen.this;
                        addGeofencesScreen.stepperCount++;
                    }
                    i++;
                }
            }
        }

        public void failure(RetrofitError error) {
            error.printStackTrace();
        }
    }

    /* renamed from: com.vizsafe.app.GeoFence.AddGeofencesScreen$9 */
    class C02799 implements OnClickListener {
        C02799() {
        }

        public void onClick(DialogInterface dialog, int id) {
            dialog.cancel();
        }
    }

    @RequiresApi(api = 23)
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0421R.layout.add_geofences_screen);
        this.addGeofencesScreen = this;
        this.mTransparentProgressDialog = new SpotsDialog((Context) this, getResources().getString(C0421R.string.please_wait_loading));
        this.mTransparentProgressDialog.setCanceledOnTouchOutside(false);
        this.mTransparentProgressDialog.setCancelable(false);
        this.locationText = (TextView) findViewById(C0421R.C0419id.location);
        this.saveBtn = (TextView) findViewById(C0421R.C0419id.action_bar_next);
        this.cancelBtn = (ImageView) findViewById(C0421R.C0419id.action_bar_back);
        this.stepperUp = (Button) findViewById(C0421R.C0419id.stepper_up);
        this.stepperDown = (Button) findViewById(C0421R.C0419id.stepper_down);
        this.geoFenceUuid = getIntent().getExtras().getString("geoFence_uuid");
        String email = PreferenceHandler.getInstance(this.addGeofencesScreen).getUserName();
        String password = PreferenceHandler.getInstance(this.addGeofencesScreen).getPassword();
        this.devicetoken = PreferenceHandler.getInstance(this.addGeofencesScreen).getRegisterId();
        this.mUserUuid = PreferenceHandler.getInstance(this.addGeofencesScreen).getUserUUID();
        this.authenticationString = "Basic " + Base64.encodeToString((email + ":" + password).getBytes(), 2);
        this.saveBtn.setVisibility(0);
        this.saveBtn.setText(getString(C0421R.string.save));
        this.gps = new VizsafeGPSTracker(getApplicationContext());
        this.gps_enabled = ((LocationManager) getApplicationContext().getSystemService(Param.LOCATION)).isProviderEnabled("gps");
        getLocationPermission();
        ((SupportMapFragment) getSupportFragmentManager().findFragmentById(C0421R.C0419id.mapInGeofences)).getMapAsync(this);
        this.cancelBtn.setOnClickListener(new C02711());
        this.saveBtn.setOnClickListener(new C02722());
        this.stepperDown.setOnClickListener(new C02733());
        this.stepperUp.setOnClickListener(new C02744());
    }

    @RequiresApi(api = 23)
    private boolean getLocationPermission() {
        Log.d(TAG, "getLocationPermission: getting location permissions");
        if (ContextCompat.checkSelfPermission(this, COURSE_LOCATION) == 0) {
            return true;
        }
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, COURSE_LOCATION)) {
            requestPermissions(new String[]{COURSE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
            return false;
        }
        requestPermissions(new String[]{COURSE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
        return false;
    }

    private void moveCamera(LatLng latLng, float zoom) {
        Log.d(TAG, "moveCamera: moving the camera to: lat: " + latLng.latitude + ", lng: " + latLng.longitude);
        BitmapDescriptor icon;
        MarkerOptions markerOption;
        if (getIntent().getExtras().getString("geoFence_latitude") == null || getIntent().getExtras().getString("geoFence_longitude") == null) {
            this.mMap.animateCamera(CameraUpdateFactory.newCameraPosition(new Builder().target(latLng).tilt(0.0f).zoom(zoom).bearing(0.0f).build()));
            this.latitude = latLng.latitude;
            this.longitude = latLng.longitude;
            if (this.marker != null) {
                this.marker.remove();
            }
            icon = BitmapDescriptorFactory.fromResource(C0421R.C0418drawable.marker_report_map);
            markerOption = new MarkerOptions();
            markerOption.position(new LatLng(this.latitude, this.longitude)).icon(icon);
            this.marker = this.mMap.addMarker(markerOption);
            GetLocationAddress();
            return;
        }
        LatLng newLatLng = new LatLng(Double.parseDouble(getIntent().getExtras().getString("geoFence_latitude")), Double.parseDouble(getIntent().getExtras().getString("geoFence_longitude")));
        this.mMap.animateCamera(CameraUpdateFactory.newCameraPosition(new Builder().target(newLatLng).tilt(0.0f).zoom(zoom).bearing(0.0f).build()));
        if (this.marker != null) {
            this.marker.remove();
        }
        icon = BitmapDescriptorFactory.fromResource(C0421R.C0418drawable.marker_report_map);
        markerOption = new MarkerOptions();
        markerOption.position(newLatLng).icon(icon);
        this.marker = this.mMap.addMarker(markerOption);
        this.stringCropped = getIntent().getExtras().getString("geoFence_name");
        this.locationText.setText(this.stringCropped);
        this.stringForStepper = this.stringCropped;
        for (char c : this.stringCropped.toCharArray()) {
            if (c == ',') {
                this.stepperCount++;
            }
        }
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case LOCATION_PERMISSION_REQUEST_CODE /*1234*/:
                if (grantResults.length > 0 && grantResults[0] == 0 && ContextCompat.checkSelfPermission(this, COURSE_LOCATION) == 0) {
                    if (this.mGoogleApiClient == null) {
                        buildGoogleApiClient();
                    }
                    this.mMap.setMyLocationEnabled(true);
                    return;
                }
                return;
            default:
                return;
        }
    }

    public void onMapReady(GoogleMap googleMap) {
        Log.d(TAG, "onMapReady: map is ready");
        this.mMap = googleMap;
        if (VERSION.SDK_INT < 23) {
            buildGoogleApiClient();
            this.mMap.setMapType(4);
            googleMap.getUiSettings().setZoomControlsEnabled(true);
            googleMap.setTrafficEnabled(true);
            this.mMap.setMyLocationEnabled(true);
            this.mMap.setOnMyLocationButtonClickListener(this);
            this.mMap.setOnMyLocationClickListener(this);
            this.mMap.setOnMapLongClickListener(this);
        } else if (ContextCompat.checkSelfPermission(this, COURSE_LOCATION) == 0) {
            buildGoogleApiClient();
            this.mMap.setMapType(4);
            googleMap.getUiSettings().setZoomControlsEnabled(true);
            googleMap.setTrafficEnabled(true);
            this.mMap.setMyLocationEnabled(true);
            this.mMap.setOnMyLocationButtonClickListener(this);
            this.mMap.setOnMyLocationClickListener(this);
            this.mMap.setOnMapLongClickListener(this);
        }
    }

    private void getDeviceLocation() {
        Log.d(TAG, "getDeviceLocation: getting the devices current location");
        this.mFusedLocationClient = LocationServices.getFusedLocationProviderClient((Activity) this);
        try {
            if (this.mLocationPermissionsGranted.booleanValue()) {
                this.mFusedLocationClient.getLastLocation().addOnCompleteListener(new C02755());
            }
        } catch (SecurityException e) {
            Log.e(TAG, "getDeviceLocation: SecurityException: " + e.getMessage());
        }
    }

    private void TaskUploadGeoFence() {
        if (this.geoFenceUuid.equals("")) {
            AddUploadGeoFence();
        } else {
            EditUploadGeoFence(this.geoFenceUuid);
        }
    }

    private void EditUploadGeoFence(String geoFenceUuid) {
        this.mTransparentProgressDialog.show();
        String str = geoFenceUuid;
        EditUploadGeoFenceApi.getInstance().Callresponse(getApplicationContext(), str, this.authenticationString, this.mUserUuid, this.locationText.getText().toString(), Param.LOCATION, String.valueOf(this.latitude), String.valueOf(this.longitude), String.valueOf(this.locationLevel), new C02766());
    }

    private void AddUploadGeoFence() {
        this.mTransparentProgressDialog.show();
        AddUploadGeoFenceApi.getInstance().Callresponse(getApplicationContext(), this.authenticationString, this.mUserUuid, this.locationText.getText().toString(), Param.LOCATION, String.valueOf(this.latitude), String.valueOf(this.longitude), String.valueOf(this.locationLevel), new C02777());
    }

    private void GetLocationAddress() {
        GetLocationAddressApi.getInstance().Callresponse(getApplicationContext(), this.latitude, this.longitude, new C02788());
    }

    private void buildAlertMessageNoGps() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(getString(C0421R.string.gps_warning)).setCancelable(false).setPositiveButton(getString(C0421R.string.enable), new C027010()).setNegativeButton(getString(C0421R.string.cancel), new C02799());
        builder.create().show();
    }

    public boolean onMyLocationButtonClick() {
        return false;
    }

    public void setLocationText(LatLng latLng) {
        String fullLocation = "";
        String postalCode = null;
        try {
            List<Address> addresses = new Geocoder(this, Locale.getDefault()).getFromLocation(latLng.latitude, latLng.longitude, 1);
            if (addresses.isEmpty()) {
                fullLocation = getString(C0421R.string.unknown_location);
            } else {
                String country = ((Address) addresses.get(0)).getCountryName();
                String city = ((Address) addresses.get(0)).getLocality();
                String state = ((Address) addresses.get(0)).getAdminArea();
                if (((Address) addresses.get(0)).getAddressLine(2) != null) {
                    postalCode = ((Address) addresses.get(0)).getAddressLine(2).replaceAll("[^0-9]", "");
                }
                if (postalCode != null && !postalCode.isEmpty()) {
                    fullLocation = postalCode + ", " + state + ", " + country;
                } else if (city != null) {
                    fullLocation = city + ", " + state + ", " + country;
                } else if (state != null) {
                    fullLocation = state + ", " + country;
                } else if (country == null) {
                    fullLocation = getString(C0421R.string.unknown_location);
                } else {
                    fullLocation = country;
                }
            }
            this.stringCropped = fullLocation;
            this.locationText.setText(this.stringCropped);
            this.stringForStepper = this.stringCropped;
            for (char c : this.stringCropped.toCharArray()) {
                if (c == ',') {
                    this.stepperCount++;
                }
            }
            this.latitude = latLng.latitude;
            this.longitude = latLng.longitude;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    protected void onResume() {
        super.onResume();
    }

    public static int nthOccurrence(String str, char c, int n) {
        int pos = str.indexOf(c, 0);
        while (true) {
            n--;
            if (n <= 0 || pos == -1) {
                return pos;
            }
            pos = str.indexOf(c, pos + 1);
        }
        return pos;
    }

    public void onMapLongClick(LatLng latLng) {
        if (CommonMember.isNetworkOnline((ConnectivityManager) getSystemService("connectivity"), this)) {
            if (this.marker != null) {
                this.marker.remove();
            }
            BitmapDescriptor icon = BitmapDescriptorFactory.fromResource(C0421R.C0418drawable.marker_report_map);
            MarkerOptions markerOption = new MarkerOptions();
            markerOption.position(latLng).icon(icon);
            this.marker = this.mMap.addMarker(markerOption);
            this.latitude = latLng.latitude;
            this.longitude = latLng.longitude;
            GetLocationAddress();
            return;
        }
        CommonMember.getErrorDialog(getString(C0421R.string.no_internet_access), this.addGeofencesScreen).show();
    }

    public void onMyLocationClick(@NonNull Location location) {
    }

    protected synchronized void buildGoogleApiClient() {
        this.mGoogleApiClient = new GoogleApiClient.Builder(this).addConnectionCallbacks(this).addApi(LocationServices.API).build();
        this.mGoogleApiClient.connect();
    }

    public void onConnected(@Nullable Bundle bundle) {
        this.mLocationRequest = new LocationRequest();
        this.mLocationRequest.setInterval(2000);
        if (ContextCompat.checkSelfPermission(this, COURSE_LOCATION) == 0) {
            LocationServices.FusedLocationApi.requestLocationUpdates(this.mGoogleApiClient, this.mLocationRequest, (LocationListener) this);
        }
    }

    public void onConnectionSuspended(int i) {
    }

    public void onLocationChanged(Location location) {
        if (!(location == null || this.mLocationPermissionsGranted.booleanValue())) {
            this.mLocationPermissionsGranted = Boolean.valueOf(true);
            getDeviceLocation();
        }
        if (this.mGoogleApiClient != null) {
            LocationServices.FusedLocationApi.removeLocationUpdates(this.mGoogleApiClient, (LocationListener) this);
        }
    }

    protected void onDestroy() {
        super.onDestroy();
        if (this.mGoogleApiClient != null) {
            LocationServices.FusedLocationApi.removeLocationUpdates(this.mGoogleApiClient, (LocationListener) this);
        }
    }
}
