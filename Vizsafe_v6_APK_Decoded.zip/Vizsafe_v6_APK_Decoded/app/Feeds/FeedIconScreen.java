package com.vizsafe.app.Feeds;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnPreparedListener;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.VideoView;
import com.polites.android.GestureImageView;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.Utils.CommonMember;
import dmax.dialog.SpotsDialog;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.entity.BufferedHttpEntity;
import org.apache.http.impl.client.DefaultHttpClient;

public class FeedIconScreen extends Activity {
    private static final int IO_BUFFER_SIZE = 4096;
    Bitmap bitmap;
    private ImageView doneBtn;
    FeedIconScreen feedIconScreen;
    String feedIconUrl;
    private GestureImageView feedImage;
    String feedType;
    private VideoView feedVideo;
    private AlertDialog mTransparentProgressDialog;
    ProgressDialog pDialogVideo;

    /* renamed from: com.vizsafe.app.Feeds.FeedIconScreen$1 */
    class C02371 implements OnPreparedListener {
        C02371() {
        }

        public void onPrepared(MediaPlayer mp) {
            if (FeedIconScreen.this.mTransparentProgressDialog.isShowing()) {
                FeedIconScreen.this.mTransparentProgressDialog.dismiss();
            }
            FeedIconScreen.this.feedVideo.start();
        }
    }

    /* renamed from: com.vizsafe.app.Feeds.FeedIconScreen$2 */
    class C02382 implements OnClickListener {
        C02382() {
        }

        public void onClick(View v) {
            FeedIconScreen.this.finish();
        }
    }

    private class LoadImage extends AsyncTask<String, String, Bitmap> {
        ProgressDialog pDialog;

        private LoadImage() {
        }

        /* synthetic */ LoadImage(FeedIconScreen x0, C02371 x1) {
            this();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            FeedIconScreen.this.mTransparentProgressDialog.show();
        }

        protected Bitmap doInBackground(String... args) {
            Bitmap img = null;
            try {
                return BitmapFactory.decodeStream(new BufferedHttpEntity(new DefaultHttpClient().execute(new HttpGet(args[0])).getEntity()).getContent());
            } catch (Exception e) {
                e.printStackTrace();
                return img;
            }
        }

        protected void onPostExecute(Bitmap image) {
            if (image != null) {
                FeedIconScreen.this.feedImage.setImageBitmap(Bitmap.createScaledBitmap(image, 512, (image.getHeight() * 512) / image.getWidth(), true));
                FeedIconScreen.this.mTransparentProgressDialog.dismiss();
                return;
            }
            FeedIconScreen.this.mTransparentProgressDialog.dismiss();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0421R.layout.feed_icon_screen);
        this.feedIconScreen = this;
        this.feedIconUrl = CommonMember.getURL(this.feedIconScreen) + "/incident/";
        this.mTransparentProgressDialog = new SpotsDialog((Context) this, getResources().getString(C0421R.string.please_wait_loading));
        this.mTransparentProgressDialog.setCanceledOnTouchOutside(false);
        this.mTransparentProgressDialog.setCancelable(false);
        this.feedImage = (GestureImageView) findViewById(C0421R.C0419id.feedImage);
        this.feedVideo = (VideoView) findViewById(C0421R.C0419id.feedVideo);
        this.doneBtn = (ImageView) findViewById(C0421R.C0419id.action_bar_back);
        this.feedType = getIntent().getExtras().getString("feed_type");
        if (!CommonMember.isNetworkOnline((ConnectivityManager) getSystemService("connectivity"), this)) {
            CommonMember.getErrorDialog(getString(C0421R.string.no_internet_access), this.feedIconScreen);
        } else if (this.feedType.equals("photo")) {
            this.feedImage.setVisibility(0);
            this.feedVideo.setVisibility(8);
            String feedIconString = this.feedIconUrl + getIntent().getExtras().getString("feed_icon") + "/png";
            new LoadImage(this, null).execute(new String[]{feedIconString});
        } else {
            this.feedImage.setVisibility(8);
            this.feedVideo.setVisibility(0);
            String feedVideoString = this.feedIconUrl + getIntent().getExtras().getString("feed_icon") + "/h264";
            try {
                MediaController mediaController = new MediaController(this);
                mediaController.setAnchorView(this.feedVideo);
                Uri video = Uri.parse(feedVideoString);
                this.feedVideo.setMediaController(mediaController);
                this.feedVideo.setVideoURI(video);
                this.feedVideo.requestFocus();
                this.mTransparentProgressDialog.show();
                this.feedVideo.setOnPreparedListener(new C02371());
            } catch (Exception e) {
                e.printStackTrace();
                if (this.mTransparentProgressDialog.isShowing()) {
                    this.mTransparentProgressDialog.dismiss();
                }
            }
        }
        this.doneBtn.setOnClickListener(new C02382());
    }

    public static Bitmap loadBitmap(String url) {
        Throwable th;
        Bitmap bitmap = null;
        InputStream in = null;
        BufferedOutputStream out = null;
        try {
            InputStream in2 = new BufferedInputStream(new URL(url).openStream(), 4096);
            try {
                ByteArrayOutputStream dataStream = new ByteArrayOutputStream();
                BufferedOutputStream out2 = new BufferedOutputStream(dataStream, 4096);
                try {
                    copy(in2, out2);
                    out2.flush();
                    byte[] data = dataStream.toByteArray();
                    bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
                    closeStream(in2);
                    closeStream(out2);
                    out = out2;
                    in = in2;
                } catch (IOException e) {
                    out = out2;
                    in = in2;
                    closeStream(in);
                    closeStream(out);
                    return bitmap;
                } catch (Throwable th2) {
                    th = th2;
                    out = out2;
                    in = in2;
                    closeStream(in);
                    closeStream(out);
                    throw th;
                }
            } catch (IOException e2) {
                in = in2;
                closeStream(in);
                closeStream(out);
                return bitmap;
            } catch (Throwable th3) {
                th = th3;
                in = in2;
                closeStream(in);
                closeStream(out);
                throw th;
            }
        } catch (IOException e3) {
            closeStream(in);
            closeStream(out);
            return bitmap;
        } catch (Throwable th4) {
            th = th4;
            closeStream(in);
            closeStream(out);
            throw th;
        }
        return bitmap;
    }

    private static void closeStream(Closeable stream) {
        if (stream != null) {
            try {
                stream.close();
            } catch (IOException e) {
            }
        }
    }

    private static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] b = new byte[4096];
        while (true) {
            int read = in.read(b);
            if (read != -1) {
                out.write(b, 0, read);
            } else {
                return;
            }
        }
    }

    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
