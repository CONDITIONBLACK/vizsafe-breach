package com.vizsafe.app.Feeds;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.GeolocationPermissions.Callback;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;
import com.google.android.gms.analytics.ecommerce.ProductAction;
import com.google.android.gms.measurement.AppMeasurement.Param;
import com.google.android.gms.plus.PlusShare;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.POJO.ChannelsListItem;
import com.vizsafe.app.POJO.NotesItems;
import com.vizsafe.app.Utils.CommonMember;
import com.vizsafe.app.Utils.PreferenceHandler;
import com.vizsafe.app.Utils.Webservice;
import dmax.dialog.SpotsDialog;
import java.io.IOException;
import java.util.ArrayList;
import org.apache.commons.p004io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class LoadMicelloSingleFeed extends Activity {
    int FEED_CLEARED = 100;
    String channelPictureUrl;
    private String content = null;
    private String email;
    private String feed_description;
    private String feed_latitude;
    private String feed_longitude;
    private String feed_state;
    private String feed_type;
    private String feedid;
    private ImageView mDoneBtn;
    private int mDrawingId;
    private int mLevelId;
    private LoadMicelloSingleFeed mLoadMicelloSingleFeed;
    private WebView mMicelloWebView;
    private int mPlaceId;
    private LinearLayout mTimeslider_layout;
    private AlertDialog mTransparentProgressDialog;
    private String mUuid;
    private String password;

    /* renamed from: com.vizsafe.app.Feeds.LoadMicelloSingleFeed$1 */
    class C02391 implements OnClickListener {
        C02391() {
        }

        public void onClick(View v) {
            LoadMicelloSingleFeed.this.finish();
        }
    }

    /* renamed from: com.vizsafe.app.Feeds.LoadMicelloSingleFeed$2 */
    class C02402 extends WebChromeClient {
        C02402() {
        }

        public void onGeolocationPermissionsShowPrompt(String origin, Callback callback) {
            callback.invoke(origin, true, false);
        }
    }

    private class AsyncTaskGetFeedDetails extends AsyncTask<String, String, String> {
        JSONObject response;

        /* renamed from: com.vizsafe.app.Feeds.LoadMicelloSingleFeed$AsyncTaskGetFeedDetails$1 */
        class C02411 implements Runnable {
            C02411() {
            }

            public void run() {
                try {
                    LoadMicelloSingleFeed.this.mTransparentProgressDialog.show();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        /* renamed from: com.vizsafe.app.Feeds.LoadMicelloSingleFeed$AsyncTaskGetFeedDetails$2 */
        class C02422 implements Runnable {
            C02422() {
            }

            public void run() {
                try {
                    if (LoadMicelloSingleFeed.this.mTransparentProgressDialog.isShowing()) {
                        LoadMicelloSingleFeed.this.mTransparentProgressDialog.dismiss();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        private AsyncTaskGetFeedDetails() {
        }

        protected void onPreExecute() {
            super.onPreExecute();
            LoadMicelloSingleFeed.this.runOnUiThread(new C02411());
        }

        protected String doInBackground(String... arg0) {
            this.response = new Webservice().GetFeedDetailsUsingUuid(LoadMicelloSingleFeed.this.getApplicationContext(), LoadMicelloSingleFeed.this.email, LoadMicelloSingleFeed.this.password, LoadMicelloSingleFeed.this.mUuid);
            return null;
        }

        protected void onPostExecute(String result) {
            LoadMicelloSingleFeed.this.runOnUiThread(new C02422());
            if (this.response != null) {
                JSONObject feedRatingsObject = null;
                String feedPostedBy = null;
                String feedLatitude = null;
                String feedLongitude = null;
                String incidentState = null;
                String incidentClearedBy = null;
                String incidentClearedTimeStamp = null;
                try {
                    String severityLevel = "0";
                    ArrayList<NotesItems> notesItem = null;
                    int communityid = 0;
                    int drawingid = 0;
                    int levelid = 0;
                    String feedAbuseOrNot = "false";
                    boolean feedRatingByMe = false;
                    int feedRatings = 0;
                    JSONObject jSONObject = new JSONObject(String.valueOf(this.response));
                    if (jSONObject.getInt("httpCode") == 200) {
                        JSONObject singleIncidentObject = jSONObject.getJSONObject(ProductAction.ACTION_DETAIL);
                        String feedType = singleIncidentObject.getString("type");
                        String feedIcon = singleIncidentObject.getString("uuid");
                        if (singleIncidentObject.has("severitylevel")) {
                            severityLevel = singleIncidentObject.getString("severitylevel");
                        }
                        if (singleIncidentObject.has("communityid")) {
                            communityid = singleIncidentObject.getInt("communityid");
                        }
                        if (singleIncidentObject.has("drawingid")) {
                            drawingid = singleIncidentObject.getInt("drawingid");
                        }
                        if (singleIncidentObject.has("levelid")) {
                            levelid = singleIncidentObject.getInt("levelid");
                        }
                        if (singleIncidentObject.has("incidentState")) {
                            incidentState = singleIncidentObject.getString("incidentState");
                        }
                        if (singleIncidentObject.has("incidentClearedBy")) {
                            incidentClearedBy = singleIncidentObject.getString("incidentClearedBy");
                        }
                        if (singleIncidentObject.has("incidentClearedTimeStamp")) {
                            incidentClearedTimeStamp = singleIncidentObject.getString("incidentClearedTimeStamp");
                        }
                        String feedDetail = singleIncidentObject.getString(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_DESCRIPTION);
                        if (singleIncidentObject.has("uploadedBy")) {
                            String feedUploadedByUuid = singleIncidentObject.getString("uploadedBy");
                        }
                        if (singleIncidentObject.has("uploadedByDisplayName")) {
                            feedPostedBy = singleIncidentObject.getString("uploadedByDisplayName");
                        }
                        if (singleIncidentObject.has("abuseReported")) {
                            feedAbuseOrNot = singleIncidentObject.getString("abuseReported");
                        }
                        String feedUploadedTime = singleIncidentObject.getLong(Param.TIMESTAMP) + "000";
                        JSONObject feedLocationAndGeoObject = singleIncidentObject.getJSONObject(FirebaseAnalytics.Param.LOCATION);
                        if (feedLocationAndGeoObject != null) {
                            JSONObject feedLocationObject = feedLocationAndGeoObject.getJSONObject("loc");
                            if (feedLocationObject != null) {
                                feedLatitude = feedLocationObject.getString("lat");
                                feedLongitude = feedLocationObject.getString("lng");
                            }
                        }
                        if (singleIncidentObject.has("ratings")) {
                            try {
                                feedRatingsObject = singleIncidentObject.getJSONObject("ratings");
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            if (feedRatingsObject != null) {
                                feedRatings = feedRatingsObject.length();
                                if (feedRatingsObject.has(PreferenceHandler.getInstance(LoadMicelloSingleFeed.this).getUserUUID())) {
                                    feedRatingByMe = true;
                                }
                            }
                        }
                        JSONArray feedChannelsArray = singleIncidentObject.getJSONArray("channels");
                        ArrayList<ChannelsListItem> channelsInFeed = null;
                        if (feedChannelsArray != null) {
                            channelsInFeed = new ArrayList();
                            for (int j = 0; j < feedChannelsArray.length(); j++) {
                                JSONObject feedChannelsObject = feedChannelsArray.getJSONObject(j);
                                boolean channelPrivate = false;
                                boolean channelSecret = false;
                                boolean channelMassaged = false;
                                boolean channelVizsafe = false;
                                String channelUuid = feedChannelsObject.getString("uuid");
                                String channelName = feedChannelsObject.getString("name");
                                String channelDescription = feedChannelsObject.getString(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_DESCRIPTION);
                                String channelOwner = feedChannelsObject.getString("owner");
                                String channelPicture = feedChannelsObject.getString("channelPicture");
                                if (feedChannelsObject.has("owner")) {
                                    channelOwner = feedChannelsObject.getString("owner");
                                }
                                if (feedChannelsObject.has("vizsafeChannel")) {
                                    channelVizsafe = Boolean.parseBoolean(feedChannelsObject.getString("vizsafeChannel"));
                                }
                                if (feedChannelsObject.has("privateChannel")) {
                                    channelPrivate = Boolean.parseBoolean(feedChannelsObject.getString("privateChannel"));
                                }
                                if (feedChannelsObject.has("secretChannel")) {
                                    channelSecret = Boolean.parseBoolean(feedChannelsObject.getString("secretChannel"));
                                }
                                if (feedChannelsObject.has("massaged")) {
                                    channelMassaged = Boolean.parseBoolean(feedChannelsObject.getString("massaged"));
                                }
                                channelsInFeed.add(new ChannelsListItem(channelName, channelDescription, LoadMicelloSingleFeed.this.channelPictureUrl + channelPicture, channelUuid, channelOwner, channelVizsafe, channelPrivate, channelSecret, channelMassaged));
                            }
                        }
                        if (singleIncidentObject.has("notes")) {
                            JSONObject feedNotesJsonObject = singleIncidentObject.getJSONObject("notes");
                            if (feedNotesJsonObject.getInt("number") > 0) {
                                notesItem = new ArrayList();
                                JSONArray feedNotesArray = feedNotesJsonObject.getJSONArray("notes");
                                for (int k = 0; k < feedNotesArray.length(); k++) {
                                    JSONObject notesDataObject = feedNotesArray.getJSONObject(k);
                                    ArrayList<NotesItems> arrayList = notesItem;
                                    arrayList.add(new NotesItems(notesDataObject.getString("uploadedBy"), notesDataObject.getString(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_DESCRIPTION), notesDataObject.getLong("uploadedDate"), notesDataObject.getString("incidentID"), notesDataObject.getString("noteuuid")));
                                }
                            }
                        }
                        boolean isSecretChannel = false;
                        int i = 0;
                        while (i < feedChannelsArray.length()) {
                            if (((ChannelsListItem) channelsInFeed.get(i)).isSecret) {
                                isSecretChannel = true;
                                break;
                            } else {
                                isSecretChannel = false;
                                i++;
                            }
                        }
                        boolean isPrivateChannel = false;
                        i = 0;
                        while (i < feedChannelsArray.length()) {
                            if (((ChannelsListItem) channelsInFeed.get(i)).isPrivate) {
                                isPrivateChannel = true;
                                break;
                            } else {
                                isPrivateChannel = false;
                                i++;
                            }
                        }
                        Intent intent = new Intent(LoadMicelloSingleFeed.this, ReportDetails.class);
                        intent.putExtra("feed_uploadedBy", feedPostedBy);
                        intent.putExtra("feed_description", feedDetail);
                        intent.putExtra("feed_timestamp", feedUploadedTime);
                        intent.putExtra("feed_imageUrl", feedIcon);
                        intent.putExtra("feed_abuse", feedAbuseOrNot);
                        intent.putExtra("feed_latitude", feedLatitude);
                        intent.putExtra("feed_longitude", feedLongitude);
                        intent.putExtra("feed_ratings", feedRatings);
                        intent.putExtra("feed_rating_by_me", feedRatingByMe);
                        intent.putExtra("feed_type", feedType);
                        intent.putExtra("incident_state", incidentState);
                        intent.putExtra("incident_cleared_by", incidentClearedBy);
                        intent.putExtra("incident_cleared_timestamp", incidentClearedTimeStamp);
                        intent.putExtra("feed_posted_by", feedPostedBy);
                        intent.putExtra("is_channel_secret", isSecretChannel);
                        intent.putExtra("is_channel_private", isPrivateChannel);
                        intent.putExtra("CommunityId", communityid);
                        intent.putExtra("Drawingid", drawingid);
                        intent.putExtra("LevelId", levelid);
                        intent.putParcelableArrayListExtra("notes_data_list", notesItem);
                        intent.putExtra("channel_list", channelsInFeed);
                        intent.putExtra("severity", severityLevel);
                        LoadMicelloSingleFeed.this.startActivityForResult(intent, LoadMicelloSingleFeed.this.FEED_CLEARED);
                        return;
                    }
                    return;
                } catch (JSONException e2) {
                    e2.printStackTrace();
                    return;
                }
            }
            Toast.makeText(LoadMicelloSingleFeed.this.getApplicationContext(), LoadMicelloSingleFeed.this.getString(C0421R.string.unable_to_load_feed), 0).show();
        }
    }

    public class WebViewJavaScriptInterface {
        private Context context;

        public WebViewJavaScriptInterface(Context context) {
            this.context = context;
        }

        @JavascriptInterface
        public void makeToast(String uuid) {
            LoadMicelloSingleFeed.this.mUuid = uuid;
            if (CommonMember.isNetworkOnline((ConnectivityManager) LoadMicelloSingleFeed.this.getSystemService("connectivity"), LoadMicelloSingleFeed.this)) {
                LoadMicelloSingleFeed.this.finish();
            } else {
                CommonMember.NetworkStatusAlert(LoadMicelloSingleFeed.this);
            }
        }

        @JavascriptInterface
        public void makeToast1() {
            LoadMicelloSingleFeed.this.finish();
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0421R.layout.activity_floor_micello_floorplan);
        this.mLoadMicelloSingleFeed = this;
        this.channelPictureUrl = CommonMember.getURL(this.mLoadMicelloSingleFeed) + "/picture/";
        this.mTransparentProgressDialog = new SpotsDialog((Context) this, getResources().getString(C0421R.string.please_wait_loading));
        this.mTransparentProgressDialog.setCanceledOnTouchOutside(false);
        this.mTransparentProgressDialog.setCancelable(false);
        this.mDoneBtn = (ImageView) findViewById(C0421R.C0419id.action_bar_back);
        this.mMicelloWebView = (WebView) findViewById(C0421R.C0419id.micellowebview);
        this.mTimeslider_layout = (LinearLayout) findViewById(C0421R.C0419id.timeslider_layout);
        this.mTimeslider_layout.setVisibility(8);
        this.email = PreferenceHandler.getInstance(this).getUserName();
        this.password = PreferenceHandler.getInstance(this).getPassword();
        this.mPlaceId = getIntent().getExtras().getInt("mIndoorMapCommunity");
        this.mDrawingId = getIntent().getExtras().getInt("mIndoorMapdrawingid");
        this.mLevelId = getIntent().getExtras().getInt("mIndoorMaplevelid");
        this.feed_description = getIntent().getExtras().getString("feed_description");
        this.feed_latitude = getIntent().getExtras().getString("feed_latitude");
        this.feed_longitude = getIntent().getExtras().getString("feed_longitude");
        this.feed_type = getIntent().getExtras().getString("feed_type");
        this.feedid = getIntent().getExtras().getString("feedUUID");
        this.feed_state = getIntent().getExtras().getString("feedState");
        this.mDoneBtn.setOnClickListener(new C02391());
        this.mMicelloWebView.getSettings().setJavaScriptEnabled(true);
        this.mMicelloWebView.setWebChromeClient(new C02402());
        this.mMicelloWebView.addJavascriptInterface(new WebViewJavaScriptInterface(this), "app");
        this.feed_type = "\"" + this.feed_type + "\"";
        this.feedid = "\"" + this.feedid + "\"";
        this.feed_description = "\"" + this.feed_description + "\"";
        if (!(this.feed_state.startsWith("\"") || this.feed_state.endsWith("\""))) {
            this.feed_state = "\"" + this.feed_state + "\"";
        }
        try {
            this.content = IOUtils.toString(getAssets().open("SingleFeed.html")).replaceAll("mCommunityIdValue", String.valueOf(this.mPlaceId)).replaceAll("mDrawingIdValue", String.valueOf(this.mDrawingId)).replaceAll("mLevelIdValue", String.valueOf(this.mLevelId)).replaceAll("currentLatitudePin", this.feed_latitude).replaceAll("currentLongitudePin", this.feed_longitude).replaceAll("feedtype", this.feed_type).replaceAll("feeddescription", this.feed_description).replaceAll("feeduuid", this.feedid).replaceAll("feedstate", this.feed_state);
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.mMicelloWebView.loadDataWithBaseURL("file:///android_asset/SingleFeed.html", this.content, "text/html", "UTF-8", null);
    }
}
