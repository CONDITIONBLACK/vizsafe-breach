package com.vizsafe.app.Feeds;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.DownloadManager;
import android.app.DownloadManager.Request;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.Point;
import android.hardware.SensorManager;
import android.media.ExifInterface;
import android.media.MediaMetadataRetriever;
import android.media.ThumbnailUtils;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore.Images.Media;
import android.support.annotation.Nullable;
import android.support.p001v4.app.Fragment;
import android.support.p001v4.app.FragmentActivity;
import android.support.p001v4.view.ViewCompat;
import android.text.TextUtils.TruncateAt;
import android.util.Base64;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.bumptech.glide.Glide;
import com.google.android.gms.analytics.ecommerce.ProductAction;
import com.google.android.gms.plus.PlusShare;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import com.google.gson.JsonObject;
import com.vizsafe.app.APIClientMethods.AddAwardStarApi;
import com.vizsafe.app.APIClientMethods.AddAwardStarApi.ResponseAddAwardStarApi;
import com.vizsafe.app.APIClientMethods.AddNotesApi;
import com.vizsafe.app.APIClientMethods.AddNotesApi.ResponseAddNotesApi;
import com.vizsafe.app.APIClientMethods.AddNotesWithAttachment;
import com.vizsafe.app.APIClientMethods.AddNotesWithAttachment.ResponseAddNotesWithAttachmentApi;
import com.vizsafe.app.APIClientMethods.RemoveAwardStarApi;
import com.vizsafe.app.APIClientMethods.ReportAbuseApi;
import com.vizsafe.app.APIClientMethods.ReportAbuseApi.ResponseReportAbuseApi;
import com.vizsafe.app.APIClientMethods.ReportClearedStateApi;
import com.vizsafe.app.APIClientMethods.ReportClearedStateApi.ResponseReportClearedStateApi;
import com.vizsafe.app.Adapters.CameraListAdapter.onGoToMapPageListener;
import com.vizsafe.app.Adapters.CustomNotesListAdapter;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.GCMIntentService.GCMClientManager;
import com.vizsafe.app.HomePage.FeedPage;
import com.vizsafe.app.HomePage.ReportPage;
import com.vizsafe.app.POJO.ChannelsListItem;
import com.vizsafe.app.POJO.FeedListItems;
import com.vizsafe.app.POJO.Incident;
import com.vizsafe.app.POJO.NotesItems;
import com.vizsafe.app.PostReportPages.SelectChannelToPost;
import com.vizsafe.app.Utils.CommonMember;
import com.vizsafe.app.Utils.PreferenceHandler;
import com.vizsafe.app.Utils.VizsafeGPSTracker;
import com.vizsafe.app.Utils.Webservice;
import dmax.dialog.SpotsDialog;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.entity.BufferedHttpEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.HTTP;
import org.json.JSONException;
import org.json.JSONObject;
import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class ReportDetails extends Fragment {
    public static String ALTITUDE = "Altitude";
    public static String CURRENT_DATE = "current_date";
    public static String CURRENT_TIME = "current_time";
    public static boolean DOWNLOAD_IMAGE = false;
    public static Double FinalAltitudeValue = Double.valueOf(FirebaseRemoteConfig.DEFAULT_VALUE_FOR_DOUBLE);
    private static final int INTERVAL = 60000;
    public static String KEY_FOR_POST_FEED = "";
    public static String LATITUDE = "latitude";
    public static String LONGITUDE = "longitude";
    public static int MAX_VIDEO_DURATION = 0;
    public static int MAX_VIDEO_FILE_SIZE = 51200;
    public static String PATH = "";
    private static final int REQUEST_CODE_CAMERA_ROLL = 103;
    private static final int REQUEST_CODE_PHOTO = 101;
    private static final int REQUEST_CODE_VIDEO = 102;
    private static final int RESULT_OK = -1;
    public static final int STATUS_CHANGED = 100;
    private static final String TAG = "mContext";
    private static final String TYPE_IMAGE = "photo";
    private static final String TYPE_VIDEO = "video";
    public static int VIDEO_SECONDS;
    public static ProgressDialog downloadImageDialog = null;
    public static double mAltitudeValue;
    private static Bundle mBundle;
    static Double mGoogleAPIAltitudeValue;
    Double GPSLatitudeValue;
    Double GPSLongitudeValue;
    private String POST_DATA;
    private CustomNotesListAdapter adapter;
    ArrayList<NotesItems> arraylist = new ArrayList();
    String authenticationString;
    private ImageView awardStarImage;
    private LinearLayout awardStarLayout;
    private String base64Altitude;
    private String base64AnonymusStatus;
    private String base64ChannelsUuidToPost;
    private String base64Description;
    private String base64Image;
    private String base64Latitude;
    private String base64Longitude;
    private String base64PostType;
    private String base64ThumnailImage;
    private String base64TimeAndDate;
    Bitmap bitmap;
    String currentDate;
    String currentTime;
    long dateAndTimeInMilliseconds;
    private ImageView doneBtn;
    private String email;
    private String exifOrientation;
    private LinearLayout feedChannelsImages;
    private TextView feedCleared;
    private TextView feedClearedBy;
    private TextView feedClearedTimeStamp;
    private ImageView feedDownload;
    private ImageView feedIcon;
    String feedIconUrl;
    private TextView feedInfo;
    FeedListItems feedItem;
    int feedRatings = 0;
    boolean feedRatingsByMe = false;
    String feedSeverity = "0";
    String feedState;
    private TextView feedTimeStamp;
    private ImageView feedToMap;
    private ImageView feedToindoorMap;
    String feedUUID;
    private String feed_description;
    private String feed_latitude;
    private String feed_longitude;
    private String feed_type;
    private Uri fileUri;
    ExifInterface getDetailFromGallery = null;
    VizsafeGPSTracker gps;
    int imageHeight;
    int imageWidth;
    private ImageView imgIncidentNote;
    private ImageView imgPostPinDetail;
    private Incident incident = null;
    private String incidentClearedBy;
    private String incidentClearedTimeStemp;
    String incidentState = null;
    boolean isPrivateChannel = false;
    boolean isSecretChannel = false;
    boolean isStatusChanged = false;
    boolean isSuperUser = false;
    private long lastUpdate;
    String latitudeGoogleMap = null;
    LinearLayout layoutPinNote;
    LinearLayout layoutReportStatus;
    String longitudeGoogleMap = null;
    private Activity mActivity;
    Double mBarometerAltitudeValue;
    ArrayList<ChannelsListItem> mChannelsList;
    private FragmentActivity mContext;
    String mFrom;
    Double mGpsAltitudeValue;
    int mIndoorMapCommunity = 0;
    int mIndoorMapdrawingid = 0;
    int mIndoorMaplevelid = 0;
    private JSONObject mJsonResponse;
    private ListView mNotesListview;
    private LinearLayout mNotesListviewLayout;
    private ImageView mNotespostImage;
    private AlertDialog mTransparentProgressDialog;
    private Bitmap myBitmap;
    private TextView noOfRatings;
    String noteMedia;
    ArrayList<NotesItems> notesArrayList;
    private String password;
    private String postType = TYPE_IMAGE;
    private float presure;
    private ImageView reportAbuseButton;
    private ImageView reportAbuseImage;
    float rotationDegree;
    private SensorManager sensorManager;
    private ImageView severityImage;
    private ImageView shareFeed;
    private String shareString;
    private TextView txtReportStatus;
    private TextView uploadedBy;
    String userDisplayName;
    private EditText userInput;
    String userNote;
    String userUUID;
    private ImageView videoIcon;

    /* renamed from: com.vizsafe.app.Feeds.ReportDetails$10 */
    class C024410 implements OnClickListener {

        /* renamed from: com.vizsafe.app.Feeds.ReportDetails$10$1 */
        class C02431 implements DialogInterface.OnClickListener {
            C02431() {
            }

            public void onClick(DialogInterface dialog, int which) {
                if (!CommonMember.isNetworkOnline((ConnectivityManager) ReportDetails.this.mContext.getSystemService("connectivity"), ReportDetails.this.mContext)) {
                    CommonMember.getErrorDialog(ReportDetails.this.getResources().getString(C0421R.string.image_not_exist), ReportDetails.this.mContext).show();
                } else if (which == 0) {
                    String downloadImageUrl = ReportDetails.this.feedIconUrl + ReportDetails.mBundle.getString("feed_imageUrl") + "/resize?height=" + 100 + "&width=" + 100;
                    File direct = new File(Environment.getExternalStorageDirectory() + "/VizsafeImages");
                    if (!direct.exists()) {
                        direct.mkdirs();
                    }
                    ReportDetails.downloadImageDialog = ProgressDialog.show(ReportDetails.this.mContext, null, ReportDetails.this.getResources().getString(C0421R.string.downloading_image));
                    ReportDetails.this.downloadFile(downloadImageUrl);
                } else {
                    ReportDetails.DOWNLOAD_IMAGE = true;
                    ReportDetails.this.downloadFile(ReportDetails.this.feedIconUrl + ReportDetails.mBundle.getString("feed_imageUrl") + "/png");
                }
            }
        }

        C024410() {
        }

        public void onClick(View v) {
            String assign_contact = ReportDetails.this.getResources().getString(C0421R.string.assign_contact);
            String download_image = ReportDetails.this.getResources().getString(C0421R.string.download_image);
            String[] MenuItems = new String[]{assign_contact, download_image};
            Builder alertDialogBuilder = new Builder(ReportDetails.this.mContext);
            alertDialogBuilder.setCancelable(true).setItems(MenuItems, new C02431());
            AlertDialog alertDialog = alertDialogBuilder.create();
            alertDialog.setCanceledOnTouchOutside(true);
            alertDialog.show();
        }
    }

    /* renamed from: com.vizsafe.app.Feeds.ReportDetails$11 */
    class C024511 implements OnClickListener {
        C024511() {
        }

        public void onClick(View v) {
            Intent goToFeedIconScreen = new Intent(ReportDetails.this.mContext, FeedIconScreen.class);
            goToFeedIconScreen.putExtra("feed_type", ReportDetails.mBundle.getString("feed_type"));
            goToFeedIconScreen.putExtra("feed_icon", ReportDetails.mBundle.getString("feed_imageUrl"));
            ReportDetails.this.startActivity(goToFeedIconScreen);
        }
    }

    /* renamed from: com.vizsafe.app.Feeds.ReportDetails$12 */
    class C024612 implements Callback<ResponseReportClearedStateApi> {
        C024612() {
        }

        public void success(ResponseReportClearedStateApi responseReportClearedStateApi, Response response) {
            ReportDetails.this.mTransparentProgressDialog.dismiss();
            Toast.makeText(ReportDetails.this.mContext, responseReportClearedStateApi.getMessage(), 0).show();
            if (responseReportClearedStateApi != null) {
                try {
                    ReportDetails.this.incidentClearedBy = responseReportClearedStateApi.getDetail().getIncidentClearedBy();
                    ReportDetails.this.incidentClearedTimeStemp = String.valueOf(responseReportClearedStateApi.getDetail().getIncidentClearedTimeStamp());
                    ReportDetails.this.feedItem.setIncidentClearedBy(ReportDetails.this.incidentClearedBy);
                    ReportDetails.this.feedItem.setIncidentClearedTimeStamp(ReportDetails.this.incidentClearedTimeStemp);
                    ReportDetails.this.feedItem.setIncidentState("clear");
                    ReportDetails.this.incidentState = ReportDetails.this.feedItem.getIncidentState();
                    ReportDetails.this.txtReportStatus.setPaintFlags(0);
                    ReportDetails.this.txtReportStatus.setTextColor(ViewCompat.MEASURED_STATE_MASK);
                    ReportDetails.this.txtReportStatus.setText(ReportDetails.this.getString(C0421R.string.report_cleared));
                    ReportDetails.this.imgPostPinDetail.setImageResource(C0421R.C0418drawable.green_marker);
                    ReportDetails.this.layoutReportStatus.setClickable(false);
                    ReportDetails.this.feedCleared.setVisibility(0);
                    ReportDetails.this.feedClearedBy.setVisibility(0);
                    ReportDetails.this.feedClearedTimeStamp.setVisibility(0);
                    ReportDetails.this.feedClearedBy.setText(ReportDetails.this.incidentClearedBy);
                    ReportDetails.this.feedClearedTimeStamp.setText(ReportDetails.getFormattedDateFromTimestamp(((long) Double.parseDouble(ReportDetails.this.incidentClearedTimeStemp)) * 1000));
                    ReportDetails.this.isStatusChanged = true;
                    ReportDetails.this.feedState = "clear";
                    FeedPage.loadFeedPage = true;
                    Toast.makeText(ReportDetails.this.mContext, ReportDetails.this.getResources().getString(C0421R.string.report_Cleared), 0).show();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        public void failure(RetrofitError error) {
            ReportDetails.this.mTransparentProgressDialog.dismiss();
            error.printStackTrace();
        }
    }

    /* renamed from: com.vizsafe.app.Feeds.ReportDetails$13 */
    class C024713 implements Callback<ResponseReportAbuseApi> {
        C024713() {
        }

        public void success(ResponseReportAbuseApi responseReportAbuseApi, Response response) {
            ReportDetails.this.mTransparentProgressDialog.dismiss();
            Toast.makeText(ReportDetails.this.mContext, responseReportAbuseApi.getMessage(), 0).show();
            ReportDetails.this.reportAbuseImage.setVisibility(0);
            ReportDetails.this.isStatusChanged = true;
            FeedPage.loadFeedPage = true;
            ReportDetails.this.mContext.setResult(100);
        }

        public void failure(RetrofitError error) {
            ReportDetails.this.mTransparentProgressDialog.dismiss();
            error.printStackTrace();
        }
    }

    /* renamed from: com.vizsafe.app.Feeds.ReportDetails$14 */
    class C024814 implements Callback<JsonObject> {
        C024814() {
        }

        public void success(JsonObject responseRemoveAwardStarApi, Response response) {
            ReportDetails.this.mTransparentProgressDialog.dismiss();
            try {
                ReportDetails.this.mJsonResponse = new JSONObject(String.valueOf(responseRemoveAwardStarApi));
                int httpCode = ReportDetails.this.mJsonResponse.getInt("httpCode");
                Toast.makeText(ReportDetails.this.mContext, ReportDetails.this.mJsonResponse.getString(GCMClientManager.EXTRA_MESSAGE), 0).show();
                if (httpCode == 200) {
                    ReportDetails reportDetails = ReportDetails.this;
                    reportDetails.feedRatings--;
                    if (ReportDetails.this.feedRatings > 0) {
                        ReportDetails.this.noOfRatings.setText(String.valueOf(ReportDetails.this.feedRatings));
                        ReportDetails.this.awardStarImage.setImageResource(C0421R.C0418drawable.vizstar_rated);
                    } else {
                        ReportDetails.this.noOfRatings.setText("");
                        ReportDetails.this.awardStarImage.setImageResource(C0421R.C0418drawable.vizstar_not_rated);
                    }
                    ReportDetails.this.isStatusChanged = true;
                    if (ReportDetails.this.feedRatingsByMe) {
                        ReportDetails.this.feedRatingsByMe = false;
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        public void failure(RetrofitError error) {
            ReportDetails.this.mTransparentProgressDialog.dismiss();
            error.printStackTrace();
        }
    }

    /* renamed from: com.vizsafe.app.Feeds.ReportDetails$15 */
    class C024915 implements Callback<ResponseAddAwardStarApi> {
        C024915() {
        }

        public void success(ResponseAddAwardStarApi responseAddAwardStarApi, Response response) {
            ReportDetails.this.mTransparentProgressDialog.dismiss();
            Toast.makeText(ReportDetails.this.mContext, responseAddAwardStarApi.getMessage(), 0).show();
            ReportDetails.this.awardStarImage.setImageResource(C0421R.C0418drawable.vizstar_rated_by_me);
            ReportDetails reportDetails = ReportDetails.this;
            reportDetails.feedRatings++;
            ReportDetails.this.noOfRatings.setText(String.valueOf(ReportDetails.this.feedRatings));
            ReportDetails.this.isStatusChanged = true;
            if (!ReportDetails.this.feedRatingsByMe) {
                ReportDetails.this.feedRatingsByMe = true;
            }
        }

        public void failure(RetrofitError error) {
            ReportDetails.this.mTransparentProgressDialog.dismiss();
            error.printStackTrace();
        }
    }

    /* renamed from: com.vizsafe.app.Feeds.ReportDetails$16 */
    class C025016 implements Callback<ResponseAddNotesApi> {
        C025016() {
        }

        public void success(ResponseAddNotesApi responseAddNotesApi, Response response) {
            ReportDetails.this.mTransparentProgressDialog.dismiss();
            Toast.makeText(ReportDetails.this.mContext, responseAddNotesApi.getMessage(), 0).show();
            if (responseAddNotesApi.getHttpCode().intValue() == 200) {
                String uploadedBy = responseAddNotesApi.getDetail().getUploadedBy();
                String description = responseAddNotesApi.getDetail().getDescription();
                long uploadedDate = (long) responseAddNotesApi.getDetail().getUploadedDate().intValue();
                String mIncidentId = responseAddNotesApi.getDetail().getIncidentID();
                String noteuuid = null;
                if (responseAddNotesApi.getDetail().getNotesUuid() == null) {
                    noteuuid = responseAddNotesApi.getDetail().getNotesUuid();
                }
                ReportDetails.this.mNotesListviewLayout.setVisibility(0);
                ReportDetails.this.arraylist.add(new NotesItems(uploadedBy, description, uploadedDate, mIncidentId, noteuuid));
                if (ReportDetails.this.arraylist != null) {
                    ReportDetails.this.adapter = new CustomNotesListAdapter(ReportDetails.this.mContext, C0421R.layout.notes_raw_item, ReportDetails.this.arraylist);
                    ReportDetails.this.mNotesListview.setAdapter(ReportDetails.this.adapter);
                    ReportDetails.this.adapter.notifyDataSetChanged();
                }
                ReportDetails.this.mNotesListview.setSelection(ReportDetails.this.arraylist.size() - 1);
                ReportDetails.this.mContext.setResult(100);
                ReportDetails.this.imgIncidentNote.setImageResource(C0421R.C0418drawable.ic_note_blue);
                ReportDetails.this.isStatusChanged = true;
                if (ReportDetails.this.incidentState.equalsIgnoreCase("open")) {
                    ReportDetails.this.feedItem.setIncidentState("pending");
                    ReportDetails.this.feedState = "pending";
                    ReportDetails.this.txtReportStatus.setText(ReportDetails.this.getString(C0421R.string.pending));
                    ReportDetails.this.layoutReportStatus.setClickable(true);
                    ReportDetails.this.imgPostPinDetail.setImageResource(C0421R.C0418drawable.yellow_marker);
                }
            }
        }

        public void failure(RetrofitError error) {
            ReportDetails.this.mTransparentProgressDialog.dismiss();
            error.printStackTrace();
        }
    }

    /* renamed from: com.vizsafe.app.Feeds.ReportDetails$17 */
    class C025117 implements Callback<ResponseAddNotesWithAttachmentApi> {
        C025117() {
        }

        public void success(ResponseAddNotesWithAttachmentApi responseAddNotesApi, Response response) {
            ReportDetails.this.mTransparentProgressDialog.dismiss();
            Toast.makeText(ReportDetails.this.mContext, responseAddNotesApi.getMessage(), 0).show();
            if (responseAddNotesApi.getHttpCode().intValue() == 200) {
                String uploadedBy = responseAddNotesApi.getDetail().getUploadedBy();
                String description = responseAddNotesApi.getDetail().getDescription();
                long uploadedDate = (long) responseAddNotesApi.getDetail().getUploadedDate().intValue();
                String mIncidentId = responseAddNotesApi.getDetail().getIncidentID();
                String noteuuid = null;
                if (responseAddNotesApi.getDetail().getNotesUuid() == null) {
                    noteuuid = responseAddNotesApi.getDetail().getNotesUuid();
                }
                ReportDetails.this.mNotesListviewLayout.setVisibility(0);
                ReportDetails.this.arraylist.add(new NotesItems(uploadedBy, description, uploadedDate, mIncidentId, noteuuid));
                if (ReportDetails.this.arraylist != null) {
                    ReportDetails.this.adapter = new CustomNotesListAdapter(ReportDetails.this.mContext, C0421R.layout.notes_raw_item, ReportDetails.this.arraylist);
                    ReportDetails.this.mNotesListview.setAdapter(ReportDetails.this.adapter);
                    ReportDetails.this.adapter.notifyDataSetChanged();
                }
                ReportDetails.this.mNotesListview.setSelection(ReportDetails.this.arraylist.size() - 1);
                ReportDetails.this.mContext.setResult(100);
                ReportDetails.this.imgIncidentNote.setImageResource(C0421R.C0418drawable.ic_note_blue);
                ReportDetails.this.isStatusChanged = true;
                if (ReportDetails.this.incidentState.equalsIgnoreCase("open")) {
                    ReportDetails.this.feedItem.setIncidentState("pending");
                    ReportDetails.this.feedState = "pending";
                    ReportDetails.this.txtReportStatus.setText(ReportDetails.this.getString(C0421R.string.pending));
                    ReportDetails.this.layoutReportStatus.setClickable(true);
                    ReportDetails.this.imgPostPinDetail.setImageResource(C0421R.C0418drawable.ic_yellow_marker);
                }
            }
        }

        public void failure(RetrofitError error) {
            ReportDetails.this.mTransparentProgressDialog.dismiss();
            error.printStackTrace();
        }
    }

    /* renamed from: com.vizsafe.app.Feeds.ReportDetails$1 */
    class C02521 implements Runnable {
        C02521() {
        }

        public void run() {
            try {
                ReportDetails.mAltitudeValue = Webservice.getElevationFromGoogleMaps(ReportDetails.this.GPSLongitudeValue.doubleValue(), ReportDetails.this.GPSLatitudeValue.doubleValue());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /* renamed from: com.vizsafe.app.Feeds.ReportDetails$3 */
    class C02563 implements OnClickListener {

        /* renamed from: com.vizsafe.app.Feeds.ReportDetails$3$1 */
        class C02541 implements DialogInterface.OnClickListener {
            C02541() {
            }

            public void onClick(DialogInterface dialog, int which) {
            }
        }

        /* renamed from: com.vizsafe.app.Feeds.ReportDetails$3$2 */
        class C02552 implements DialogInterface.OnClickListener {
            C02552() {
            }

            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        }

        C02563() {
        }

        public void onClick(View v) {
            ReportDetails.this.feedUUID = ReportDetails.mBundle.getString("feed_imageUrl");
            if (ReportDetails.this.incidentState.equalsIgnoreCase("open") || ReportDetails.this.incidentState.equalsIgnoreCase("pending")) {
                if (ReportDetails.this.isSuperUser || ReportDetails.this.isSecretChannel) {
                    ReportDetails.this.TaskClearedState(ReportDetails.this.feedUUID);
                }
            } else if (ReportDetails.this.incidentState.equalsIgnoreCase("pending")) {
                new Builder(ReportDetails.this.mContext).setTitle(ReportDetails.this.getString(C0421R.string.app_name)).setMessage("Yellow Pin.").setPositiveButton(ReportDetails.this.getResources().getString(C0421R.string.okTxt), new C02552()).setNegativeButton(ReportDetails.this.getResources().getString(C0421R.string.cancel), new C02541()).create().show();
            }
        }
    }

    /* renamed from: com.vizsafe.app.Feeds.ReportDetails$4 */
    class C02624 implements OnClickListener {

        /* renamed from: com.vizsafe.app.Feeds.ReportDetails$4$1 */
        class C02571 implements OnClickListener {
            C02571() {
            }

            public void onClick(View view) {
                ReportDetails.this.HideSoftKeyBoard();
                ReportDetails.this.CallToEnhancementNotes(1);
            }
        }

        /* renamed from: com.vizsafe.app.Feeds.ReportDetails$4$2 */
        class C02582 implements OnClickListener {
            C02582() {
            }

            public void onClick(View view) {
                ReportDetails.this.CallToEnhancementNotes(2);
                ReportDetails.this.HideSoftKeyBoard();
            }
        }

        /* renamed from: com.vizsafe.app.Feeds.ReportDetails$4$3 */
        class C02593 implements OnClickListener {
            C02593() {
            }

            public void onClick(View view) {
                ReportDetails.this.CallToEnhancementNotes(3);
                ReportDetails.this.HideSoftKeyBoard();
            }
        }

        C02624() {
        }

        public void onClick(View v) {
            InputMethodManager imm = (InputMethodManager) ReportDetails.this.mContext.getSystemService("input_method");
            final Dialog dialog = new Dialog(ReportDetails.this.mContext);
            dialog.requestWindowFeature(1);
            dialog.setCancelable(false);
            dialog.setContentView(C0421R.layout.notes_alert);
            dialog.show();
            imm.toggleSoftInput(2, 0);
            ReportDetails.PATH = "";
            ReportDetails.this.userInput = (EditText) dialog.findViewById(C0421R.C0419id.edtTxtAddNote);
            TextView mCancelNotes = (TextView) dialog.findViewById(C0421R.C0419id.notes_cancel_button);
            TextView mSendNotes = (TextView) dialog.findViewById(C0421R.C0419id.notes_send_button);
            ReportDetails.this.mNotespostImage = (ImageView) dialog.findViewById(C0421R.C0419id.notespost_image);
            ImageView mPhotoNotes = (ImageView) dialog.findViewById(C0421R.C0419id.notes_photo);
            ImageView mVideoNotes = (ImageView) dialog.findViewById(C0421R.C0419id.notes_video);
            ImageView mGalleyNotes = (ImageView) dialog.findViewById(C0421R.C0419id.notes_galley);
            ReportDetails.this.userInput.requestFocus();
            mPhotoNotes.setOnClickListener(new C02571());
            mVideoNotes.setOnClickListener(new C02582());
            mGalleyNotes.setOnClickListener(new C02593());
            mCancelNotes.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    ReportDetails.this.HideSoftKeyBoard();
                    dialog.dismiss();
                }
            });
            mSendNotes.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    ReportDetails.this.HideSoftKeyBoard();
                    ReportDetails.this.userNote = ReportDetails.this.userInput.getText().toString();
                    if (ReportDetails.this.userNote.trim().isEmpty()) {
                        Toast.makeText(ReportDetails.this.mContext, ReportDetails.this.getResources().getString(C0421R.string.enter_notes), 1).show();
                        return;
                    }
                    dialog.dismiss();
                    if (CommonMember.isNetworkOnline((ConnectivityManager) ReportDetails.this.mContext.getSystemService("connectivity"), ReportDetails.this.mContext)) {
                        ReportDetails.this.GetPostData();
                    } else {
                        CommonMember.getErrorDialog(ReportDetails.this.getString(C0421R.string.no_internet_access), ReportDetails.this.mContext).show();
                    }
                }
            });
        }
    }

    /* renamed from: com.vizsafe.app.Feeds.ReportDetails$5 */
    class C02635 implements OnClickListener {
        C02635() {
        }

        public void onClick(View v) {
            if (ReportDetails.this.isStatusChanged) {
                ReportDetails.this.mContext.setResult(100);
            }
            if (ReportDetails.this.mFrom == null) {
                ((onGoToFeedPageListener) ReportDetails.this.mContext).onGoToFeedPage();
            } else if (ReportDetails.this.mFrom.equals("Map")) {
                ((onGoToMapPageListener) ReportDetails.this.mContext).onGoToMapPage(ReportDetails.mBundle.getString("feed_latitude"), ReportDetails.mBundle.getString("feed_longitude"));
            } else {
                ((onGoToFeedPageListener) ReportDetails.this.mContext).onGoToFeedPage();
            }
        }
    }

    /* renamed from: com.vizsafe.app.Feeds.ReportDetails$6 */
    class C02646 implements OnClickListener {
        C02646() {
        }

        public void onClick(View v) {
            if (CommonMember.isNetworkOnline((ConnectivityManager) ReportDetails.this.mContext.getSystemService("connectivity"), ReportDetails.this.mContext)) {
                ReportDetails.this.TaskAwardStar();
            } else {
                CommonMember.getErrorDialog(ReportDetails.this.getString(C0421R.string.no_internet_access), ReportDetails.this.mContext).show();
            }
        }
    }

    /* renamed from: com.vizsafe.app.Feeds.ReportDetails$7 */
    class C02657 implements OnClickListener {
        C02657() {
        }

        public void onClick(View v) {
            ((onGoToMapPageListener) ReportDetails.this.mContext).onGoToMapPage(ReportDetails.this.feed_latitude, ReportDetails.this.feed_longitude);
        }
    }

    /* renamed from: com.vizsafe.app.Feeds.ReportDetails$8 */
    class C02668 implements OnClickListener {
        C02668() {
        }

        public void onClick(View view) {
            if (ReportDetails.this.mIndoorMapCommunity != 0 && ReportDetails.this.mIndoorMapdrawingid != 0 && ReportDetails.this.mIndoorMaplevelid != 0) {
                Intent goToFeedIconScreen = new Intent(ReportDetails.this.mContext, LoadMicelloSingleFeed.class);
                goToFeedIconScreen.putExtra("mIndoorMapCommunity", ReportDetails.this.mIndoorMapCommunity);
                goToFeedIconScreen.putExtra("mIndoorMapdrawingid", ReportDetails.this.mIndoorMapdrawingid);
                goToFeedIconScreen.putExtra("mIndoorMaplevelid", ReportDetails.this.mIndoorMaplevelid);
                goToFeedIconScreen.putExtra("feed_description", ReportDetails.this.feed_description);
                goToFeedIconScreen.putExtra("feed_latitude", ReportDetails.this.feed_latitude);
                goToFeedIconScreen.putExtra("feed_longitude", ReportDetails.this.feed_longitude);
                goToFeedIconScreen.putExtra("feed_type", ReportDetails.this.feed_type);
                goToFeedIconScreen.putExtra("feedUUID", ReportDetails.this.feedUUID);
                goToFeedIconScreen.putExtra("feedState", ReportDetails.this.feedState);
                goToFeedIconScreen.setFlags(1073741824);
                ReportDetails.this.startActivity(goToFeedIconScreen);
            }
        }
    }

    /* renamed from: com.vizsafe.app.Feeds.ReportDetails$9 */
    class C02679 implements OnClickListener {
        C02679() {
        }

        public void onClick(View v) {
            try {
                ReportDetails.this.shareString = "https://" + PreferenceHandler.getInstance(ReportDetails.this.mContext).getServerName() + "/map?incidentUUID=";
                Intent i = new Intent("android.intent.action.SEND");
                i.setType(HTTP.PLAIN_TEXT_TYPE);
                i.putExtra("android.intent.extra.SUBJECT", "VizSafe:");
                ReportDetails.this.shareString = ReportDetails.this.shareString + ReportDetails.mBundle.getString("feed_imageUrl");
                i.putExtra("android.intent.extra.TEXT", ReportDetails.this.shareString);
                ReportDetails.this.startActivity(Intent.createChooser(i, "Share via"));
            } catch (Exception e) {
            }
        }
    }

    private class AsyncTaskAddNotes extends AsyncTask<String, String, String> {
        JSONObject response;
        String successStatus;

        private AsyncTaskAddNotes() {
            this.response = null;
            this.successStatus = "yes";
        }

        /* synthetic */ AsyncTaskAddNotes(ReportDetails x0, C02521 x1) {
            this();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            ReportDetails.this.mTransparentProgressDialog.show();
        }

        protected String doInBackground(String... arg0) {
            String email = PreferenceHandler.getInstance(ReportDetails.this.mContext).getUserName();
            String password = PreferenceHandler.getInstance(ReportDetails.this.mContext).getPassword();
            String Path = ReportDetails.this.userUUID + "/AddNotes";
            try {
                this.response = new Webservice().AddNotesWebService(ReportDetails.this.mContext, email, password, Path, ReportDetails.this.POST_DATA);
            } catch (Exception e) {
                e.printStackTrace();
                this.successStatus = "no";
            }
            return this.successStatus;
        }

        protected void onPostExecute(String result) {
            ReportDetails.this.mTransparentProgressDialog.dismiss();
            if (this.response != null) {
                String mResponse = String.valueOf(this.response);
                ReportDetails.PATH = "";
                try {
                    ReportDetails.this.mJsonResponse = new JSONObject(mResponse);
                    int httpCode = ReportDetails.this.mJsonResponse.getInt("httpCode");
                    Toast.makeText(ReportDetails.this.mContext, ReportDetails.this.mJsonResponse.getString(GCMClientManager.EXTRA_MESSAGE), 0).show();
                    if (httpCode == 200) {
                        JSONObject mDetail = ReportDetails.this.mJsonResponse.getJSONObject(ProductAction.ACTION_DETAIL);
                        String uploadedBy = mDetail.getString("uploadedBy");
                        String description = mDetail.getString(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_DESCRIPTION);
                        long uploadedDate = mDetail.getLong("uploadedDate");
                        String mIncidentId = mDetail.getString("incidentID");
                        String noteuuid = null;
                        if (mDetail.has("noteuuid")) {
                            noteuuid = mDetail.getString("noteuuid");
                        }
                        ReportDetails.this.mNotesListviewLayout.setVisibility(0);
                        ReportDetails.this.arraylist.add(new NotesItems(uploadedBy, description, uploadedDate, mIncidentId, noteuuid));
                        if (ReportDetails.this.arraylist != null) {
                            ReportDetails.this.adapter = new CustomNotesListAdapter(ReportDetails.this.mContext, C0421R.layout.notes_raw_item, ReportDetails.this.arraylist);
                            ReportDetails.this.mNotesListview.setAdapter(ReportDetails.this.adapter);
                            ReportDetails.this.adapter.notifyDataSetChanged();
                        }
                        ReportDetails.this.mNotesListview.setSelection(ReportDetails.this.arraylist.size() - 1);
                        ReportDetails.this.mContext.setResult(100);
                        ReportDetails.this.imgIncidentNote.setImageResource(C0421R.C0418drawable.ic_note_blue);
                        ReportDetails.this.isStatusChanged = true;
                        FeedPage.loadFeedPage = true;
                        if (ReportDetails.this.incidentState.equalsIgnoreCase("open")) {
                            ReportDetails.this.feedItem.setIncidentState("pending");
                            ReportDetails.this.feedState = "pending";
                            ReportDetails.this.txtReportStatus.setText(ReportDetails.this.getString(C0421R.string.pending));
                            ReportDetails.this.layoutReportStatus.setClickable(true);
                            ReportDetails.this.imgPostPinDetail.setImageResource(C0421R.C0418drawable.yellow_marker);
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private class AsyncTaskDecodeBase64toImage extends AsyncTask<String, String, String> {
        JSONObject response;
        String successStatus;

        private AsyncTaskDecodeBase64toImage() {
            this.response = null;
            this.successStatus = "yes";
        }

        /* synthetic */ AsyncTaskDecodeBase64toImage(ReportDetails x0, C02521 x1) {
            this();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            ReportDetails.this.mTransparentProgressDialog.show();
        }

        protected String doInBackground(String... arg0) {
            try {
                if (ReportDetails.PATH == null || ReportDetails.PATH.isEmpty() || ReportDetails.PATH.equals("")) {
                    ReportDetails.this.base64Image = ReportDetails.this.GetTextOnlyImage();
                    return this.successStatus;
                }
                ReportDetails.this.base64Image = SelectChannelToPost.getBase64DatafromImage(ReportDetails.PATH);
                return this.successStatus;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        protected void onPostExecute(String result) {
            ReportDetails.this.mTransparentProgressDialog.dismiss();
            if (ReportDetails.this.base64Image != null) {
                for (int i = 0; i <= ReportDetails.this.base64Image.length() / 3000; i++) {
                    int start = i * 3000;
                    int end = (i + 1) * 3000;
                    if (end > ReportDetails.this.base64Image.length()) {
                        end = ReportDetails.this.base64Image.length();
                    }
                    Log.v(ReportDetails.TAG, ReportDetails.this.base64Image.substring(start, end));
                    Log.d(ReportDetails.TAG, "/n");
                }
                ReportDetails.this.POST_DATA = "note=" + ReportDetails.this.userNote + "&iID=" + ReportDetails.this.feedUUID + "&noteMedia=" + ReportDetails.this.base64Image;
                new AsyncTaskAddNotes(ReportDetails.this, null).execute(new String[0]);
            }
        }
    }

    private class LoadImage extends AsyncTask<String, String, Bitmap> {
        ProgressDialog pDialog;

        private LoadImage() {
        }

        protected void onPreExecute() {
            super.onPreExecute();
            ReportDetails.this.mTransparentProgressDialog.show();
        }

        protected Bitmap doInBackground(String... args) {
            Bitmap img = null;
            try {
                return BitmapFactory.decodeStream(new BufferedHttpEntity(new DefaultHttpClient().execute(new HttpGet(args[0])).getEntity()).getContent());
            } catch (Exception e) {
                e.printStackTrace();
                return img;
            }
        }

        protected void onPostExecute(Bitmap image) {
            ReportDetails.this.mTransparentProgressDialog.dismiss();
            if (image != null) {
                ReportDetails.this.feedIcon.setImageBitmap(image);
            }
        }
    }

    public interface onGoToFeedPageListener {
        void onGoToFeedPage();
    }

    public static ReportDetails newInstance(Bundle bundle) {
        mBundle = bundle;
        return new ReportDetails();
    }

    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.clear();
    }

    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        ((InputMethodManager) getActivity().getSystemService("input_method")).hideSoftInputFromWindow(getView().getWindowToken(), 0);
    }

    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ((InputMethodManager) getActivity().getSystemService("input_method")).hideSoftInputFromWindow(getView().getWindowToken(), 0);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getActivity().getWindow().setSoftInputMode(3);
        View vReportDetails = inflater.inflate(C0421R.layout.marker_info_detail, container, false);
        this.mContext = getActivity();
        this.feedIconUrl = CommonMember.getURL(this.mContext) + "/incident/";
        this.doneBtn = (ImageView) vReportDetails.findViewById(C0421R.C0419id.action_bar_back);
        this.uploadedBy = (TextView) vReportDetails.findViewById(C0421R.C0419id.feedUploadedBy);
        this.feedInfo = (TextView) vReportDetails.findViewById(C0421R.C0419id.feedDescription);
        this.feedTimeStamp = (TextView) vReportDetails.findViewById(C0421R.C0419id.feedTimeStamp);
        this.feedIcon = (ImageView) vReportDetails.findViewById(C0421R.C0419id.feedIcon);
        this.awardStarLayout = (LinearLayout) vReportDetails.findViewById(C0421R.C0419id.awardStarLayout);
        this.awardStarImage = (ImageView) vReportDetails.findViewById(C0421R.C0419id.awardStarImage);
        this.reportAbuseImage = (ImageView) vReportDetails.findViewById(C0421R.C0419id.reportAbuseImage);
        this.feedToMap = (ImageView) vReportDetails.findViewById(C0421R.C0419id.action_bar_map);
        this.feedToindoorMap = (ImageView) vReportDetails.findViewById(C0421R.C0419id.action_bar_indoor_map);
        this.reportAbuseButton = (ImageView) vReportDetails.findViewById(C0421R.C0419id.action_bar_abuse);
        this.shareFeed = (ImageView) vReportDetails.findViewById(C0421R.C0419id.action_bar_share);
        this.videoIcon = (ImageView) vReportDetails.findViewById(C0421R.C0419id.videoIcon);
        this.feedDownload = (ImageView) vReportDetails.findViewById(C0421R.C0419id.action_bar_download);
        this.noOfRatings = (TextView) vReportDetails.findViewById(C0421R.C0419id.noOfRatings);
        this.mNotesListview = (ListView) vReportDetails.findViewById(C0421R.C0419id.notes_listview);
        this.mNotesListviewLayout = (LinearLayout) vReportDetails.findViewById(C0421R.C0419id.notes_listview_layout);
        this.imgPostPinDetail = (ImageView) vReportDetails.findViewById(C0421R.C0419id.imgPostPinDetail);
        this.feedCleared = (TextView) vReportDetails.findViewById(C0421R.C0419id.feedCleared);
        this.feedClearedBy = (TextView) vReportDetails.findViewById(C0421R.C0419id.feedClearedBy);
        this.feedClearedTimeStamp = (TextView) vReportDetails.findViewById(C0421R.C0419id.feedClearedTimeStamp);
        this.txtReportStatus = (TextView) vReportDetails.findViewById(C0421R.C0419id.txtReportStatus);
        this.layoutReportStatus = (LinearLayout) vReportDetails.findViewById(C0421R.C0419id.layoutReportStatus);
        this.layoutPinNote = (LinearLayout) vReportDetails.findViewById(C0421R.C0419id.layoutPinNote);
        this.imgIncidentNote = (ImageView) vReportDetails.findViewById(C0421R.C0419id.imgIncidentNote);
        this.severityImage = (ImageView) vReportDetails.findViewById(C0421R.C0419id.severity_image);
        this.feedChannelsImages = (LinearLayout) vReportDetails.findViewById(C0421R.C0419id.feed_channels_images);
        this.userUUID = PreferenceHandler.getInstance(this.mContext).getUserUUID();
        this.email = PreferenceHandler.getInstance(this.mContext).getUserName();
        this.password = PreferenceHandler.getInstance(this.mContext).getPassword();
        this.isSuperUser = PreferenceHandler.getInstance(this.mContext).getSuperUser().booleanValue();
        this.userDisplayName = PreferenceHandler.getInstance(this.mContext).getUserDisplayName();
        this.feedUUID = mBundle.getString("feed_imageUrl");
        this.isSecretChannel = mBundle.getBoolean("is_channel_secret");
        this.isPrivateChannel = mBundle.getBoolean("is_channel_private");
        this.incidentState = mBundle.getString("incident_state");
        this.notesArrayList = mBundle.getParcelableArrayList("notes_data_list");
        this.mChannelsList = (ArrayList) mBundle.getSerializable("channel_list");
        this.feedRatings = mBundle.getInt("feed_ratings");
        this.feedRatingsByMe = mBundle.getBoolean("feed_rating_by_me");
        this.mFrom = mBundle.getString("from");
        this.feed_latitude = mBundle.getString("feed_latitude");
        this.feed_longitude = mBundle.getString("feed_longitude");
        this.feed_type = mBundle.getString("feed_type");
        this.feed_description = mBundle.getString("feed_description");
        this.mIndoorMapCommunity = mBundle.getInt("CommunityId");
        this.mIndoorMapdrawingid = mBundle.getInt("Drawingid");
        this.mIndoorMaplevelid = mBundle.getInt("LevelId");
        this.feedState = mBundle.getString("incident_state");
        this.feedSeverity = mBundle.getString("severity");
        String feedContext = mBundle.getString("Context");
        this.gps = new VizsafeGPSTracker(this.mContext);
        if (this.gps.canGetLocation()) {
            this.GPSLatitudeValue = Double.valueOf(this.gps.getLatitude());
            this.GPSLongitudeValue = Double.valueOf(this.gps.getLongitude());
            this.mGpsAltitudeValue = Double.valueOf(this.gps.getAltitude());
            new Thread(new C02521()).start();
        } else {
            this.gps.showSettingsAlert();
        }
        if (this.feedSeverity.equals("0")) {
            this.severityImage.setVisibility(8);
        } else {
            this.severityImage.setVisibility(0);
            if (this.feedSeverity.equals("1")) {
                this.severityImage.setBackgroundResource(C0421R.C0418drawable.severity_s1_off);
            } else if (this.feedSeverity.equals("2")) {
                this.severityImage.setBackgroundResource(C0421R.C0418drawable.severity_s2_off);
            } else {
                this.severityImage.setBackgroundResource(C0421R.C0418drawable.severity_s3_off);
            }
        }
        if (!(this.mIndoorMapCommunity == 0 || this.mIndoorMapdrawingid == 0 || this.mIndoorMaplevelid == 0)) {
            this.feedToindoorMap.setVisibility(0);
        }
        this.mTransparentProgressDialog = new SpotsDialog(this.mContext, getResources().getString(C0421R.string.please_wait_loading));
        String email = PreferenceHandler.getInstance(this.mContext).getUserName();
        this.authenticationString = "Basic " + Base64.encodeToString((email + ":" + PreferenceHandler.getInstance(this.mContext).getPassword()).getBytes(), 2);
        Display display = this.mContext.getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        int height = size.y / 3;
        this.feedIcon.getLayoutParams().height = height;
        this.reportAbuseImage.getLayoutParams().height = height;
        this.videoIcon.getLayoutParams().height = height;
        this.feedItem = new FeedListItems();
        if (this.isSecretChannel || this.isPrivateChannel || this.isSuperUser) {
            this.feedUUID = mBundle.getString("feed_imageUrl");
            this.imgIncidentNote.setVisibility(0);
            if (this.notesArrayList != null) {
                this.mNotesListviewLayout.setVisibility(0);
                getNotes(this.notesArrayList);
                this.imgIncidentNote.setImageResource(C0421R.C0418drawable.ic_note_blue);
            } else {
                this.imgIncidentNote.setImageResource(C0421R.C0418drawable.ic_note_grey);
                this.mNotesListviewLayout.setVisibility(8);
            }
        }
        if (isTablet(this.mContext)) {
            this.imageHeight = 200;
            this.imageWidth = 200;
        } else {
            this.imageHeight = 200;
            this.imageWidth = 200;
        }
        if (!CommonMember.isNetworkOnline((ConnectivityManager) this.mContext.getSystemService("connectivity"), this.mContext)) {
            CommonMember.getErrorDialog(getString(C0421R.string.no_internet_access), this.mContext);
        } else if (mBundle.getString("feed_type").equalsIgnoreCase(TYPE_IMAGE)) {
            this.videoIcon.setVisibility(8);
            Glide.with(this.mContext).load(this.feedIconUrl + mBundle.getString("feed_imageUrl") + "/resize?height=" + this.imageHeight + "&width=" + this.imageWidth).error((int) C0421R.C0418drawable.loading_image).placeholder((int) C0421R.C0418drawable.loading_image).into(this.feedIcon);
        } else {
            if (isTablet(this.mContext)) {
                this.imageHeight = 176;
                this.imageWidth = 142;
            } else {
                this.imageHeight = 96;
                this.imageWidth = 108;
            }
            this.videoIcon.setVisibility(0);
            Glide.with(this.mContext).load(this.feedIconUrl + mBundle.getString("feed_imageUrl") + "/still?height=" + this.imageHeight + "&width=" + this.imageWidth).error((int) C0421R.C0418drawable.loading_image).placeholder((int) C0421R.C0418drawable.loading_image).into(this.feedIcon);
        }
        this.reportAbuseButton.setVisibility(8);
        if (Boolean.parseBoolean(mBundle.getString("feed_abuse"))) {
            this.reportAbuseImage.setVisibility(0);
            this.reportAbuseButton.setVisibility(8);
        } else {
            this.reportAbuseImage.setVisibility(8);
            this.reportAbuseButton.setVisibility(8);
        }
        this.uploadedBy.setText(mBundle.getString("feed_uploadedBy"));
        this.feedInfo.setSingleLine(false);
        this.feedInfo.setEllipsize(TruncateAt.END);
        this.feedInfo.setLines(2);
        this.feedInfo.setText(mBundle.getString("feed_description"));
        double timeStamp = Double.parseDouble(mBundle.getString("feed_timestamp"));
        if (((double) ((long) timeStamp)) == timeStamp) {
            this.feedTimeStamp.setText(getFormattedDateFromTimestamp((long) timeStamp));
        }
        if (this.incidentState == null) {
            this.feedItem.setIncidentState("open");
            this.incidentState = this.feedItem.getIncidentState();
        }
        if (this.incidentState.equalsIgnoreCase("open")) {
            this.imgPostPinDetail.setImageResource(C0421R.C0418drawable.red_marker);
            this.layoutReportStatus.setClickable(true);
            if (this.isSuperUser || this.isSecretChannel) {
                this.txtReportStatus.setPaintFlags(this.txtReportStatus.getPaintFlags() | 8);
                this.txtReportStatus.setTextColor(-16776961);
                this.txtReportStatus.setText(getString(C0421R.string.clear_report));
                this.txtReportStatus.setVisibility(0);
            } else {
                this.txtReportStatus.setVisibility(8);
            }
        } else if (this.incidentState.equalsIgnoreCase("pending")) {
            this.imgPostPinDetail.setImageResource(C0421R.C0418drawable.yellow_marker);
            this.layoutReportStatus.setClickable(true);
            if (this.isSecretChannel || this.isPrivateChannel || this.isSuperUser) {
                this.txtReportStatus.setPaintFlags(this.txtReportStatus.getPaintFlags() | 8);
                this.txtReportStatus.setTextColor(-16776961);
                this.txtReportStatus.setText(getString(C0421R.string.pending));
                this.txtReportStatus.setVisibility(0);
                this.imgIncidentNote.setVisibility(0);
            } else {
                this.txtReportStatus.setVisibility(8);
            }
        } else {
            this.imgPostPinDetail.setImageResource(C0421R.C0418drawable.green_marker);
            this.layoutReportStatus.setClickable(false);
            this.txtReportStatus.setText(getString(C0421R.string.report_cleared));
            String clearTime = mBundle.getString("incident_cleared_timestamp");
            String clearedBy = mBundle.getString("incident_cleared_by");
            this.feedCleared.setVisibility(0);
            this.txtReportStatus.setVisibility(0);
            if (!(clearedBy == null || clearedBy.equalsIgnoreCase("null") || clearedBy.trim().isEmpty())) {
                this.feedClearedBy.setVisibility(0);
                this.feedClearedBy.setText(clearedBy);
            }
            if (!(clearTime == null || clearTime.trim().isEmpty())) {
                this.feedClearedTimeStamp.setText(getFormattedDateFromTimestamp(((long) Double.parseDouble(clearTime)) * 1000));
                this.feedClearedTimeStamp.setVisibility(0);
            }
        }
        this.feedChannelsImages.removeAllViews();
        for (int i = 0; i < this.mChannelsList.size(); i++) {
            LayoutParams layoutParams = new LayoutParams(dpToPx(40), dpToPx(40));
            View imageView = new ImageView(this.mContext);
            layoutParams.setMargins(0, 0, 10, 0);
            imageView.setLayoutParams(layoutParams);
            imageView.setId(i);
            Glide.with(this.mContext).load(((ChannelsListItem) this.mChannelsList.get(i)).image).error((int) C0421R.C0418drawable.loading_image).into(imageView);
            this.feedChannelsImages.addView(imageView);
            final int i2 = i;
            imageView.setOnClickListener(new OnClickListener() {
                public void onClick(View v) {
                    Toast.makeText(ReportDetails.this.mContext, ((ChannelsListItem) ReportDetails.this.mChannelsList.get(i2)).title, 0).show();
                }
            });
        }
        this.layoutReportStatus.setOnClickListener(new C02563());
        this.imgIncidentNote.setOnClickListener(new C02624());
        if (this.feedRatings > 0) {
            if (this.feedRatingsByMe) {
                this.awardStarImage.setImageResource(C0421R.C0418drawable.vizstar_rated_by_me);
            } else {
                this.awardStarImage.setImageResource(C0421R.C0418drawable.vizstar_rated);
            }
            this.noOfRatings.setText("" + this.feedRatings);
        } else {
            this.noOfRatings.setText("");
            this.awardStarImage.setImageResource(C0421R.C0418drawable.vizstar_not_rated);
        }
        this.doneBtn.setOnClickListener(new C02635());
        this.awardStarLayout.setOnClickListener(new C02646());
        this.feedToMap.setOnClickListener(new C02657());
        this.feedToindoorMap.setOnClickListener(new C02668());
        this.shareFeed.setOnClickListener(new C02679());
        this.feedDownload.setOnClickListener(new C024410());
        this.feedIcon.setOnClickListener(new C024511());
        return vReportDetails;
    }

    private void HideSoftKeyBoard() {
        ((InputMethodManager) this.mContext.getSystemService("input_method")).toggleSoftInput(2, 0);
    }

    private void CallToEnhancementNotes(int mCount) {
        if (mCount == 1) {
            this.fileUri = getOutputMediaFileUri(101);
            Intent picIntent = new Intent("android.media.action.IMAGE_CAPTURE");
            if (picIntent.resolveActivity(getActivity().getPackageManager()) != null) {
                startActivityForResult(picIntent, 101);
            }
        } else if (mCount == 2) {
            VIDEO_SECONDS = PreferenceHandler.getInstance(this.mContext).getMaxVideoDuration();
            MAX_VIDEO_DURATION = VIDEO_SECONDS * 1000;
            this.fileUri = getOutputMediaFileUri(102);
            Intent intent1 = new Intent("android.media.action.VIDEO_CAPTURE");
            intent1.putExtra("android.intent.extra.durationLimit", VIDEO_SECONDS);
            intent1.putExtra("android.intent.extra.videoQuality", 0);
            intent1.putExtra("android.intent.extra.sizeLimit", 20971520);
            startActivityForResult(intent1, 102);
        } else {
            VIDEO_SECONDS = PreferenceHandler.getInstance(this.mContext).getMaxVideoDuration();
            MAX_VIDEO_DURATION = VIDEO_SECONDS * 1000;
            Intent intent2 = new Intent("android.intent.action.PICK", Media.EXTERNAL_CONTENT_URI);
            intent2.setType("image/*");
            startActivityForResult(intent2, 103);
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        try {
            SimpleDateFormat currDate;
            SimpleDateFormat currTime;
            String path;
            int file_size;
            long timeInmillisec;
            MediaMetadataRetriever retriever;
            super.onActivityResult(requestCode, resultCode, data);
            if (requestCode == 101 && resultCode == -1) {
                this.fileUri = ReportPage.getImageUri(getActivity(), (Bitmap) data.getExtras().get("data"));
                PATH = ReportPage.getPath(getActivity(), this.fileUri);
                if (PATH == null) {
                    PATH = this.fileUri.getPath();
                }
                currDate = new SimpleDateFormat("MMM dd, yyyy");
                currTime = new SimpleDateFormat("HH:mm:ss");
                this.currentDate = currDate.format(new Date());
                this.currentTime = currTime.format(new Date());
                this.postType = TYPE_IMAGE;
                createNewIncident(TYPE_IMAGE, PATH);
                KEY_FOR_POST_FEED = "imagepath";
                DoBackgroudProcessOfNotes();
            }
            if (requestCode == 102 && resultCode == -1) {
                currDate = new SimpleDateFormat("MMM dd, yyyy");
                currTime = new SimpleDateFormat("HH:mm:ss");
                this.currentDate = currDate.format(new Date());
                this.currentTime = currTime.format(new Date());
                this.fileUri = data.getData();
                path = getRealPath(this.fileUri);
                if (path == null) {
                    path = this.fileUri.getPath();
                }
                this.postType = TYPE_VIDEO;
                file_size = Integer.parseInt(String.valueOf(new File(path).length() / 1024));
                timeInmillisec = 0;
                if (path.endsWith(".mp4") || path.endsWith(".3gp") || path.endsWith(".mkv") || path.endsWith(".avi")) {
                    retriever = new MediaMetadataRetriever();
                    retriever.setDataSource(path);
                    timeInmillisec = Long.parseLong(retriever.extractMetadata(9));
                }
                if (file_size > 0 && file_size < MAX_VIDEO_FILE_SIZE && timeInmillisec < ((long) MAX_VIDEO_DURATION)) {
                    createNewIncident(TYPE_VIDEO, path);
                    KEY_FOR_POST_FEED = "videofile";
                    PATH = path;
                    DoBackgroudProcessOfNotes();
                } else if (file_size == 0) {
                    CommonMember.getErrorDialog(getResources().getString(C0421R.string.media_not_valid), this.mContext).show();
                } else {
                    CommonMember.getErrorDialog(getResources().getString(C0421R.string.file_size_more) + " " + VIDEO_SECONDS + getResources().getString(C0421R.string.seconds_or_less), this.mContext).show();
                }
            }
            if (requestCode == 103 && resultCode == -1) {
                this.fileUri = data.getData();
                path = ReportPage.getPath(this.mContext, this.fileUri);
                file_size = Integer.parseInt(String.valueOf(new File(path).length() / 1024));
                timeInmillisec = 0;
                if (path.endsWith(".mp4") || path.endsWith(".3gp") || path.endsWith(".mkv") || path.endsWith(".avi")) {
                    retriever = new MediaMetadataRetriever();
                    retriever.setDataSource(path);
                    timeInmillisec = Long.parseLong(retriever.extractMetadata(9));
                    this.postType = TYPE_VIDEO;
                } else {
                    this.postType = TYPE_IMAGE;
                }
                if (this.postType.equals(TYPE_IMAGE)) {
                    if (file_size > 0) {
                        createNewIncident(TYPE_IMAGE, path);
                        KEY_FOR_POST_FEED = "imagefromsdcard";
                        PATH = path;
                        this.getDetailFromGallery = new ExifInterface(PATH);
                        if (this.getDetailFromGallery != null) {
                            DoBackgroudProcessOfNotes();
                        }
                    } else if (file_size == 0) {
                        CommonMember.getErrorDialog(getResources().getString(C0421R.string.media_not_valid), this.mContext).show();
                    } else {
                        CommonMember.getErrorDialog(getResources().getString(C0421R.string.file_size_more) + VIDEO_SECONDS + getResources().getString(C0421R.string.seconds_or_less), this.mContext).show();
                    }
                }
                if (!this.postType.equals(TYPE_VIDEO)) {
                    return;
                }
                if (file_size > 0 && file_size < MAX_VIDEO_FILE_SIZE && timeInmillisec < ((long) MAX_VIDEO_DURATION)) {
                    createNewIncident(TYPE_IMAGE, path);
                    KEY_FOR_POST_FEED = "imagefromsdcard";
                    PATH = path;
                    try {
                        this.getDetailFromGallery = new ExifInterface(PATH);
                        if (this.getDetailFromGallery != null) {
                            try {
                                String dateAndTime = this.getDetailFromGallery.getAttribute("DateTime");
                                DoBackgroudProcessOfNotes();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    } catch (Exception e2) {
                        e2.printStackTrace();
                    }
                } else if (file_size == 0) {
                    CommonMember.getErrorDialog(getResources().getString(C0421R.string.media_not_valid), this.mContext).show();
                } else {
                    CommonMember.getErrorDialog(getResources().getString(C0421R.string.file_size_more) + VIDEO_SECONDS + getResources().getString(C0421R.string.seconds_or_less), this.mContext).show();
                }
            }
        } catch (Exception e22) {
            e22.printStackTrace();
            CommonMember.getErrorDialog(getResources().getString(C0421R.string.media_not_valid), this.mContext).show();
        }
    }

    private void DoBackgroudProcessOfNotes() {
        SimpleDateFormat currDate = new SimpleDateFormat("MMM dd, yyyy");
        SimpleDateFormat currTime = new SimpleDateFormat("HH:mm:ss");
        this.currentDate = currDate.format(new Date());
        this.currentTime = currTime.format(new Date());
        this.dateAndTimeInMilliseconds = Calendar.getInstance().getTimeInMillis();
        SetImageBitmap();
        if (this.postType.equalsIgnoreCase(TYPE_VIDEO)) {
            this.base64ThumnailImage = Base64.encodeToString(SelectChannelToPost.getBytesFromBitmap(ThumbnailUtils.createVideoThumbnail(PATH, 1)), 2);
        }
        this.userNote = this.userInput.getText().toString().trim();
    }

    public String getEncoded64ImageStringFromBitmap() {
        Bitmap map = CommonMember.showBitmapFromFile(PATH);
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        map.compress(CompressFormat.JPEG, 70, stream);
        return Base64.encodeToString(stream.toByteArray(), 2);
    }

    /* JADX WARNING: Removed duplicated region for block: B:18:0x009a  */
    /* JADX WARNING: Removed duplicated region for block: B:45:? A:{SYNTHETIC, RETURN} */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x00d6  */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x009a  */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x00c0  */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x012c  */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x0149  */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x00d6  */
    /* JADX WARNING: Removed duplicated region for block: B:45:? A:{SYNTHETIC, RETURN} */
    private void SetImageBitmap() {
        /*
        r20 = this;
        r14 = PATH;	 Catch:{ IOException -> 0x0115 }
        r8 = com.vizsafe.app.Utils.CommonMember.showBitmapFromFile(r14);	 Catch:{ IOException -> 0x0115 }
        r0 = r20;
        r14 = r0.mNotespostImage;	 Catch:{ IOException -> 0x0115 }
        r14.setImageBitmap(r8);	 Catch:{ IOException -> 0x0115 }
        r4 = new android.media.ExifInterface;	 Catch:{ IOException -> 0x0115 }
        r14 = PATH;	 Catch:{ IOException -> 0x0115 }
        r4.<init>(r14);	 Catch:{ IOException -> 0x0115 }
        r14 = "Orientation";
        r14 = r4.getAttribute(r14);	 Catch:{ IOException -> 0x0115 }
        r0 = r20;
        r0.exifOrientation = r14;	 Catch:{ IOException -> 0x0115 }
    L_0x001e:
        r5 = new java.io.File;
        r14 = PATH;
        r5.<init>(r14);
        r10 = new android.graphics.BitmapFactory$Options;
        r10.<init>();
        r14 = 1;
        r10.inJustDecodeBounds = r14;
        r6 = 0;
        r7 = new java.io.FileInputStream;	 Catch:{ Exception -> 0x011b }
        r7.<init>(r5);	 Catch:{ Exception -> 0x011b }
        r14 = 0;
        android.graphics.BitmapFactory.decodeStream(r7, r14, r10);	 Catch:{ Exception -> 0x0165 }
        r7.close();	 Catch:{ Exception -> 0x0165 }
        r2 = 1024; // 0x400 float:1.435E-42 double:5.06E-321;
        r12 = 1;
        r14 = r10.outHeight;	 Catch:{ Exception -> 0x0165 }
        if (r14 > r2) goto L_0x0045;
    L_0x0041:
        r14 = r10.outWidth;	 Catch:{ Exception -> 0x0165 }
        if (r14 <= r2) goto L_0x007c;
    L_0x0045:
        r14 = 4611686018427387904; // 0x4000000000000000 float:0.0 double:2.0;
        r0 = (double) r2;	 Catch:{ Exception -> 0x0165 }
        r16 = r0;
        r0 = r10.outHeight;	 Catch:{ Exception -> 0x0165 }
        r18 = r0;
        r0 = r10.outWidth;	 Catch:{ Exception -> 0x0165 }
        r19 = r0;
        r18 = java.lang.Math.max(r18, r19);	 Catch:{ Exception -> 0x0165 }
        r0 = r18;
        r0 = (double) r0;	 Catch:{ Exception -> 0x0165 }
        r18 = r0;
        r16 = r16 / r18;
        r16 = java.lang.Math.log(r16);	 Catch:{ Exception -> 0x0165 }
        r18 = 4602678819172646912; // 0x3fe0000000000000 float:0.0 double:0.5;
        r18 = java.lang.Math.log(r18);	 Catch:{ Exception -> 0x0165 }
        r16 = r16 / r18;
        r16 = java.lang.Math.round(r16);	 Catch:{ Exception -> 0x0165 }
        r0 = r16;
        r0 = (int) r0;	 Catch:{ Exception -> 0x0165 }
        r16 = r0;
        r0 = r16;
        r0 = (double) r0;	 Catch:{ Exception -> 0x0165 }
        r16 = r0;
        r14 = java.lang.Math.pow(r14, r16);	 Catch:{ Exception -> 0x0165 }
        r12 = (int) r14;	 Catch:{ Exception -> 0x0165 }
    L_0x007c:
        r11 = new android.graphics.BitmapFactory$Options;	 Catch:{ Exception -> 0x0165 }
        r11.<init>();	 Catch:{ Exception -> 0x0165 }
        r11.inSampleSize = r12;	 Catch:{ Exception -> 0x0165 }
        r6 = new java.io.FileInputStream;	 Catch:{ Exception -> 0x0165 }
        r6.<init>(r5);	 Catch:{ Exception -> 0x0165 }
        r14 = 0;
        r14 = android.graphics.BitmapFactory.decodeStream(r6, r14, r11);	 Catch:{ Exception -> 0x011b }
        r0 = r20;
        r0.myBitmap = r14;	 Catch:{ Exception -> 0x011b }
        r6.close();	 Catch:{ Exception -> 0x011b }
    L_0x0094:
        r0 = r20;
        r14 = r0.myBitmap;
        if (r14 != 0) goto L_0x00b6;
    L_0x009a:
        r14 = PATH;
        r15 = 3;
        r14 = android.media.ThumbnailUtils.createVideoThumbnail(r14, r15);
        r0 = r20;
        r0.myBitmap = r14;
        r0 = r20;
        r14 = r0.mNotespostImage;
        r0 = r20;
        r15 = r0.myBitmap;
        r14.setImageBitmap(r15);
        r14 = "video";
        r0 = r20;
        r0.postType = r14;
    L_0x00b6:
        r0 = r20;
        r14 = r0.exifOrientation;
        r14 = java.lang.Integer.parseInt(r14);
        if (r14 < 0) goto L_0x0121;
    L_0x00c0:
        r0 = r20;
        r14 = r0.exifOrientation;
        r14 = java.lang.Integer.parseInt(r14);
        r15 = 1;
        if (r14 > r15) goto L_0x0121;
    L_0x00cb:
        r14 = 0;
        r0 = r20;
        r0.rotationDegree = r14;
    L_0x00d0:
        r0 = r20;
        r14 = r0.myBitmap;
        if (r14 == 0) goto L_0x0114;
    L_0x00d6:
        r0 = r20;
        r14 = r0.myBitmap;
        r14 = r14.getHeight();
        r14 = (double) r14;
        r16 = 4647714815446351872; // 0x4080000000000000 float:0.0 double:512.0;
        r0 = r20;
        r0 = r0.myBitmap;
        r18 = r0;
        r18 = r18.getWidth();
        r0 = r18;
        r0 = (double) r0;
        r18 = r0;
        r16 = r16 / r18;
        r14 = r14 * r16;
        r9 = (int) r14;
        r0 = r20;
        r14 = r0.myBitmap;
        r15 = 512; // 0x200 float:7.175E-43 double:2.53E-321;
        r16 = 1;
        r0 = r16;
        r13 = android.graphics.Bitmap.createScaledBitmap(r14, r15, r9, r0);
        r0 = r20;
        r14 = r0.mNotespostImage;
        r0 = r20;
        r15 = r0.rotationDegree;
        r0 = r20;
        r15 = r0.rotateImage(r13, r15);
        r14.setImageBitmap(r15);
    L_0x0114:
        return;
    L_0x0115:
        r3 = move-exception;
        r3.printStackTrace();
        goto L_0x001e;
    L_0x011b:
        r3 = move-exception;
    L_0x011c:
        r3.printStackTrace();
        goto L_0x0094;
    L_0x0121:
        r0 = r20;
        r14 = r0.exifOrientation;
        r14 = java.lang.Integer.parseInt(r14);
        r15 = 2;
        if (r14 < r15) goto L_0x013e;
    L_0x012c:
        r0 = r20;
        r14 = r0.exifOrientation;
        r14 = java.lang.Integer.parseInt(r14);
        r15 = 4;
        if (r14 > r15) goto L_0x013e;
    L_0x0137:
        r14 = 1127481344; // 0x43340000 float:180.0 double:5.570497984E-315;
        r0 = r20;
        r0.rotationDegree = r14;
        goto L_0x00d0;
    L_0x013e:
        r0 = r20;
        r14 = r0.exifOrientation;
        r14 = java.lang.Integer.parseInt(r14);
        r15 = 7;
        if (r14 < r15) goto L_0x015d;
    L_0x0149:
        r0 = r20;
        r14 = r0.exifOrientation;
        r14 = java.lang.Integer.parseInt(r14);
        r15 = 8;
        if (r14 < r15) goto L_0x015d;
    L_0x0155:
        r14 = 1132920832; // 0x43870000 float:270.0 double:5.597372625E-315;
        r0 = r20;
        r0.rotationDegree = r14;
        goto L_0x00d0;
    L_0x015d:
        r14 = 1119092736; // 0x42b40000 float:90.0 double:5.529052754E-315;
        r0 = r20;
        r0.rotationDegree = r14;
        goto L_0x00d0;
    L_0x0165:
        r3 = move-exception;
        r6 = r7;
        goto L_0x011c;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.vizsafe.app.Feeds.ReportDetails.SetImageBitmap():void");
    }

    public Bitmap rotateImage(Bitmap src, float degree) {
        Matrix matrix = new Matrix();
        matrix.postRotate(degree);
        return Bitmap.createBitmap(src, 0, 0, src.getWidth(), src.getHeight(), matrix, true);
    }

    private void TaskClearedState(String feedUUID) {
        this.mTransparentProgressDialog.show();
        ReportClearedStateApi.getInstance().Callresponse(this.mContext, this.authenticationString, feedUUID, new C024612());
    }

    private void TaskReportAbuse() {
        this.mTransparentProgressDialog.show();
        ReportAbuseApi.getInstance().Callresponse(this.mContext, this.authenticationString, this.feedUUID, new C024713());
    }

    private void TaskAwardStar() {
        if (this.feedRatingsByMe) {
            RemoveAwardStar(this.authenticationString, this.feedUUID);
        } else {
            AddAwardStar(this.authenticationString, this.feedUUID, "1");
        }
    }

    private void RemoveAwardStar(String authenticationString, String feedUUID) {
        this.mTransparentProgressDialog.show();
        RemoveAwardStarApi.getInstance().Callresponse(this.mContext, authenticationString, feedUUID, new C024814());
    }

    private void AddAwardStar(String authenticationString, String feedUUID, String rating) {
        this.mTransparentProgressDialog.show();
        AddAwardStarApi.getInstance().Callresponse(this.mContext, authenticationString, feedUUID, rating, new C024915());
    }

    private void TaskAddNotes(String userUUID, String userNote, String feedUUID) {
        this.mTransparentProgressDialog.show();
        AddNotesApi.getInstance().Callresponse(this.mContext, this.authenticationString, userUUID, userNote, feedUUID, new C025016());
    }

    private void TaskAddNotesWithAttachment(String userUUID, String userNote, String feedUUID, String noteMedia) {
        this.mTransparentProgressDialog.show();
        AddNotesWithAttachment.getInstance().Callresponse(this.mContext, this.authenticationString, userUUID, userNote, feedUUID, noteMedia, new C025117());
    }

    public static String getFormattedDateFromTimestamp(long timestampInMilliSeconds) {
        Date date = new Date();
        date.setTime(timestampInMilliSeconds);
        return new SimpleDateFormat("dd MMM yyyy, HH:mm").format(date);
    }

    private void GetPostData() {
        new AsyncTaskDecodeBase64toImage(this, null).execute(new String[0]);
    }

    private String GetTextOnlyImage() {
        Bitmap myBitmap = BitmapFactory.decodeResource(getResources(), C0421R.C0418drawable.text_vizsafe_new);
        File directory = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/VizsafeImages");
        directory.mkdirs();
        String filename = "TextOnlyImageNew.PNG";
        String pathOfFile = null;
        File yourFile = new File(directory, filename);
        if (yourFile.exists()) {
            pathOfFile = "/storage/emulated/0/VizSafeImages/" + filename;
        } else if (directory.canWrite()) {
            try {
                FileOutputStream out = new FileOutputStream(yourFile, true);
                myBitmap.compress(CompressFormat.JPEG, 90, out);
                out.flush();
                out.close();
                pathOfFile = "/storage/emulated/0/VizSafeImages/" + filename;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        if (pathOfFile != null) {
            this.base64Image = SelectChannelToPost.getBase64DatafromImage(pathOfFile);
        }
        return this.base64Image;
    }

    private void getNotes(ArrayList<NotesItems> getIncidentNotes) {
        if (!this.arraylist.isEmpty()) {
            this.arraylist.clear();
        }
        for (int i = 0; i < getIncidentNotes.size(); i++) {
            this.arraylist.add(new NotesItems(((NotesItems) getIncidentNotes.get(i)).uploadedBy, ((NotesItems) getIncidentNotes.get(i)).description, ((NotesItems) getIncidentNotes.get(i)).uploadedDate, ((NotesItems) getIncidentNotes.get(i)).incidentID, ((NotesItems) getIncidentNotes.get(i)).noteuuid));
        }
        if (this.arraylist != null) {
            this.adapter = new CustomNotesListAdapter(this.mContext, C0421R.layout.notes_raw_item, this.arraylist);
            this.mNotesListview.setAdapter(this.adapter);
            this.adapter.notifyDataSetChanged();
        }
    }

    public void downloadFile(String url) {
        DownloadManager mgr = (DownloadManager) this.mContext.getSystemService("download");
        Request request = new Request(Uri.parse(url));
        request.setAllowedNetworkTypes(3).setAllowedOverRoaming(false).setTitle(getResources().getString(C0421R.string.app_name)).setDescription(getResources().getString(C0421R.string.downloading_image)).setDestinationInExternalPublicDir("/VizsafeImages", "fileName.jpg");
        mgr.enqueue(request);
    }

    public static boolean isTablet(Context context) {
        return (context.getResources().getConfiguration().screenLayout & 15) >= 3;
    }

    private Uri getOutputMediaFileUri(int type) {
        File imagesFolder = new File(Environment.getExternalStorageDirectory(), "VizSafeImages");
        if (!(imagesFolder == null || imagesFolder.exists())) {
            imagesFolder.mkdirs();
        }
        PreferenceHandler.getInstance(this.mContext).setImageName(PreferenceHandler.getInstance(this.mContext).getImageName() + 1);
        return Uri.fromFile(new File(imagesFolder, String.format("image%08d.jpeg", new Object[]{Integer.valueOf(photonum)})));
    }

    private void createNewIncident(String type, String path) {
        this.incident = Incident.create(type, path);
    }

    public String getRealPath(Uri uri) {
        Cursor cursor = this.mContext.managedQuery(uri, new String[]{"_data"}, null, null, null);
        if (cursor == null) {
            return null;
        }
        int column_index = cursor.getColumnIndexOrThrow("_data");
        cursor.moveToFirst();
        return cursor.getString(column_index);
    }

    public int dpToPx(int dp) {
        return Math.round(((float) dp) * (this.mContext.getResources().getDisplayMetrics().xdpi / 160.0f));
    }
}
