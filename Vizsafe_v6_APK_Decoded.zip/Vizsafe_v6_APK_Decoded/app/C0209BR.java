package com.vizsafe.app;

/* renamed from: com.vizsafe.app.BR */
public class C0209BR {
    public static final int _all = 0;
}
