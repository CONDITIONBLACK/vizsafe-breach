package com.vizsafe.app.Database.DAO;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import com.vizsafe.app.Database.Tables.FavChannelTable;
import java.util.List;

@Dao
public interface FavChannelDao {
    @Query("DELETE FROM FavChannel")
    void delete();

    @Query("SELECT * FROM FavChannel")
    List<FavChannelTable> getAll();

    @Insert
    void insertAll(FavChannelTable... favChannelTableArr);
}
