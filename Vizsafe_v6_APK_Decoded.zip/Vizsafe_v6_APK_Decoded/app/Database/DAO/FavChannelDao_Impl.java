package com.vizsafe.app.Database.DAO;

import android.arch.persistence.p000db.SupportSQLiteStatement;
import android.arch.persistence.room.EntityInsertionAdapter;
import android.arch.persistence.room.RoomDatabase;
import android.arch.persistence.room.RoomSQLiteQuery;
import android.arch.persistence.room.SharedSQLiteStatement;
import android.database.Cursor;
import com.google.android.gms.plus.PlusShare;
import com.vizsafe.app.Database.Tables.FavChannelTable;
import java.util.ArrayList;
import java.util.List;

public class FavChannelDao_Impl implements FavChannelDao {
    private final RoomDatabase __db;
    private final EntityInsertionAdapter __insertionAdapterOfFavChannelTable;
    private final SharedSQLiteStatement __preparedStmtOfDelete;

    public FavChannelDao_Impl(RoomDatabase __db) {
        this.__db = __db;
        this.__insertionAdapterOfFavChannelTable = new EntityInsertionAdapter<FavChannelTable>(__db) {
            public String createQuery() {
                return "INSERT OR ABORT INTO `FavChannel`(`id`,`title`,`subtitle`,`image`,`uuid`,`owner`,`vizsafechannel`,`privatechannel`,`secretchannel`,`massaged`) VALUES (nullif(?, 0),?,?,?,?,?,?,?,?,?)";
            }

            public void bind(SupportSQLiteStatement stmt, FavChannelTable value) {
                int _tmp;
                int _tmp_1;
                int _tmp_2;
                int _tmp_3;
                stmt.bindLong(1, (long) value.getId());
                if (value.getTitle() == null) {
                    stmt.bindNull(2);
                } else {
                    stmt.bindString(2, value.getTitle());
                }
                if (value.getSubtitle() == null) {
                    stmt.bindNull(3);
                } else {
                    stmt.bindString(3, value.getSubtitle());
                }
                if (value.getImage() == null) {
                    stmt.bindNull(4);
                } else {
                    stmt.bindString(4, value.getImage());
                }
                if (value.getUuid() == null) {
                    stmt.bindNull(5);
                } else {
                    stmt.bindString(5, value.getUuid());
                }
                if (value.getOwner() == null) {
                    stmt.bindNull(6);
                } else {
                    stmt.bindString(6, value.getOwner());
                }
                if (value.getVizsafechannel()) {
                    _tmp = 1;
                } else {
                    _tmp = 0;
                }
                stmt.bindLong(7, (long) _tmp);
                if (value.getPrivatechannel()) {
                    _tmp_1 = 1;
                } else {
                    _tmp_1 = 0;
                }
                stmt.bindLong(8, (long) _tmp_1);
                if (value.getSecretchannel()) {
                    _tmp_2 = 1;
                } else {
                    _tmp_2 = 0;
                }
                stmt.bindLong(9, (long) _tmp_2);
                if (value.getMassaged()) {
                    _tmp_3 = 1;
                } else {
                    _tmp_3 = 0;
                }
                stmt.bindLong(10, (long) _tmp_3);
            }
        };
        this.__preparedStmtOfDelete = new SharedSQLiteStatement(__db) {
            public String createQuery() {
                String _query = "DELETE FROM FavChannel";
                return "DELETE FROM FavChannel";
            }
        };
    }

    public void insertAll(FavChannelTable... channel) {
        this.__db.beginTransaction();
        try {
            this.__insertionAdapterOfFavChannelTable.insert((Object[]) channel);
            this.__db.setTransactionSuccessful();
        } finally {
            this.__db.endTransaction();
        }
    }

    public void delete() {
        SupportSQLiteStatement _stmt = this.__preparedStmtOfDelete.acquire();
        this.__db.beginTransaction();
        try {
            _stmt.executeUpdateDelete();
            this.__db.setTransactionSuccessful();
        } finally {
            this.__db.endTransaction();
            this.__preparedStmtOfDelete.release(_stmt);
        }
    }

    public List<FavChannelTable> getAll() {
        String _sql = "SELECT * FROM FavChannel";
        RoomSQLiteQuery _statement = RoomSQLiteQuery.acquire("SELECT * FROM FavChannel", 0);
        Cursor _cursor = this.__db.query(_statement);
        try {
            int _cursorIndexOfId = _cursor.getColumnIndexOrThrow("id");
            int _cursorIndexOfTitle = _cursor.getColumnIndexOrThrow(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_TITLE);
            int _cursorIndexOfSubtitle = _cursor.getColumnIndexOrThrow("subtitle");
            int _cursorIndexOfImage = _cursor.getColumnIndexOrThrow("image");
            int _cursorIndexOfUuid = _cursor.getColumnIndexOrThrow("uuid");
            int _cursorIndexOfOwner = _cursor.getColumnIndexOrThrow("owner");
            int _cursorIndexOfVizsafechannel = _cursor.getColumnIndexOrThrow("vizsafechannel");
            int _cursorIndexOfPrivatechannel = _cursor.getColumnIndexOrThrow("privatechannel");
            int _cursorIndexOfSecretchannel = _cursor.getColumnIndexOrThrow("secretchannel");
            int _cursorIndexOfMassaged = _cursor.getColumnIndexOrThrow("massaged");
            List<FavChannelTable> _result = new ArrayList(_cursor.getCount());
            while (_cursor.moveToNext()) {
                FavChannelTable _item = new FavChannelTable();
                _item.setId(_cursor.getInt(_cursorIndexOfId));
                _item.setTitle(_cursor.getString(_cursorIndexOfTitle));
                _item.setSubtitle(_cursor.getString(_cursorIndexOfSubtitle));
                _item.setImage(_cursor.getString(_cursorIndexOfImage));
                _item.setUuid(_cursor.getString(_cursorIndexOfUuid));
                _item.setOwner(_cursor.getString(_cursorIndexOfOwner));
                _item.setVizsafechannel(_cursor.getInt(_cursorIndexOfVizsafechannel) != 0);
                _item.setPrivatechannel(_cursor.getInt(_cursorIndexOfPrivatechannel) != 0);
                _item.setSecretchannel(_cursor.getInt(_cursorIndexOfSecretchannel) != 0);
                _item.setMassaged(_cursor.getInt(_cursorIndexOfMassaged) != 0);
                _result.add(_item);
            }
            return _result;
        } finally {
            _cursor.close();
            _statement.release();
        }
    }
}
