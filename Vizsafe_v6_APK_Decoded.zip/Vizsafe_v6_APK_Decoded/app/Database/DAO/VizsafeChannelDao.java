package com.vizsafe.app.Database.DAO;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import com.vizsafe.app.Database.Tables.VizsafeChannelTable;
import java.util.List;

@Dao
public interface VizsafeChannelDao {
    @Query("DELETE FROM VizsafeChannel")
    void delete();

    @Query("SELECT * FROM VizsafeChannel")
    List<VizsafeChannelTable> getAll();

    @Insert
    void insertAll(VizsafeChannelTable... vizsafeChannelTableArr);
}
