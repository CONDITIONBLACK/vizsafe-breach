package com.vizsafe.app.Database.DAO;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import com.vizsafe.app.Database.Tables.AllChannelsTable;
import java.util.List;

@Dao
public interface AllChannelsDao {
    @Query("DELETE FROM AllChannel")
    void delete();

    @Query("SELECT * FROM AllChannel")
    List<AllChannelsTable> getAll();

    @Insert
    void insertAll(AllChannelsTable... allChannelsTableArr);
}
