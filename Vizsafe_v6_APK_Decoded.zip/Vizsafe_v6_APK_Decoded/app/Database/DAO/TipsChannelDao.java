package com.vizsafe.app.Database.DAO;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import com.vizsafe.app.Database.Tables.TipsChannelTable;
import java.util.List;

@Dao
public interface TipsChannelDao {
    @Query("DELETE FROM TipsChannel")
    void delete();

    @Query("SELECT * FROM TipsChannel")
    List<TipsChannelTable> getAll();

    @Insert
    void insertAll(TipsChannelTable... tipsChannelTableArr);
}
