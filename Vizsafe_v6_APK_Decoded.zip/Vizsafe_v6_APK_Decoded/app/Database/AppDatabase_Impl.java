package com.vizsafe.app.Database;

import android.arch.persistence.p000db.SupportSQLiteDatabase;
import android.arch.persistence.p000db.SupportSQLiteOpenHelper;
import android.arch.persistence.p000db.SupportSQLiteOpenHelper.Configuration;
import android.arch.persistence.room.DatabaseConfiguration;
import android.arch.persistence.room.InvalidationTracker;
import android.arch.persistence.room.RoomDatabase.Callback;
import android.arch.persistence.room.RoomMasterTable;
import android.arch.persistence.room.RoomOpenHelper;
import android.arch.persistence.room.RoomOpenHelper.Delegate;
import android.arch.persistence.room.util.TableInfo;
import android.arch.persistence.room.util.TableInfo.Column;
import com.google.android.gms.plus.PlusShare;
import com.vizsafe.app.Database.DAO.AllChannelsDao;
import com.vizsafe.app.Database.DAO.AllChannelsDao_Impl;
import com.vizsafe.app.Database.DAO.FavChannelDao;
import com.vizsafe.app.Database.DAO.FavChannelDao_Impl;
import com.vizsafe.app.Database.DAO.TipsChannelDao;
import com.vizsafe.app.Database.DAO.TipsChannelDao_Impl;
import com.vizsafe.app.Database.DAO.VizsafeChannelDao;
import com.vizsafe.app.Database.DAO.VizsafeChannelDao_Impl;
import java.util.HashMap;
import java.util.HashSet;

public class AppDatabase_Impl extends AppDatabase {
    private volatile AllChannelsDao _allChannelsDao;
    private volatile FavChannelDao _favChannelDao;
    private volatile TipsChannelDao _tipsChannelDao;
    private volatile VizsafeChannelDao _vizsafeChannelDao;

    /* renamed from: com.vizsafe.app.Database.AppDatabase_Impl$1 */
    class C02281 extends Delegate {
        C02281() {
        }

        public void createAllTables(SupportSQLiteDatabase _db) {
            _db.execSQL("CREATE TABLE IF NOT EXISTS `TipsChannel` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `title` TEXT, `subtitle` TEXT, `image` TEXT, `uuid` TEXT, `owner` TEXT, `vizsafechannel` INTEGER NOT NULL, `privatechannel` INTEGER NOT NULL, `secretchannel` INTEGER NOT NULL, `massaged` INTEGER NOT NULL)");
            _db.execSQL("CREATE TABLE IF NOT EXISTS `FavChannel` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `title` TEXT, `subtitle` TEXT, `image` TEXT, `uuid` TEXT, `owner` TEXT, `vizsafechannel` INTEGER NOT NULL, `privatechannel` INTEGER NOT NULL, `secretchannel` INTEGER NOT NULL, `massaged` INTEGER NOT NULL)");
            _db.execSQL("CREATE TABLE IF NOT EXISTS `VizsafeChannel` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `title` TEXT, `subtitle` TEXT, `image` TEXT, `uuid` TEXT, `owner` TEXT, `vizsafechannel` INTEGER NOT NULL, `privatechannel` INTEGER NOT NULL, `secretchannel` INTEGER NOT NULL, `massaged` INTEGER NOT NULL)");
            _db.execSQL("CREATE TABLE IF NOT EXISTS `AllChannel` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `title` TEXT, `subtitle` TEXT, `image` TEXT, `uuid` TEXT, `owner` TEXT, `vizsafechannel` INTEGER NOT NULL, `privatechannel` INTEGER NOT NULL, `secretchannel` INTEGER NOT NULL, `massaged` INTEGER NOT NULL)");
            _db.execSQL(RoomMasterTable.CREATE_QUERY);
            _db.execSQL("INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, \"db43db8f068f07cf1df893053edb9aee\")");
        }

        public void dropAllTables(SupportSQLiteDatabase _db) {
            _db.execSQL("DROP TABLE IF EXISTS `TipsChannel`");
            _db.execSQL("DROP TABLE IF EXISTS `FavChannel`");
            _db.execSQL("DROP TABLE IF EXISTS `VizsafeChannel`");
            _db.execSQL("DROP TABLE IF EXISTS `AllChannel`");
        }

        protected void onCreate(SupportSQLiteDatabase _db) {
            if (AppDatabase_Impl.this.mCallbacks != null) {
                int _size = AppDatabase_Impl.this.mCallbacks.size();
                for (int _i = 0; _i < _size; _i++) {
                    ((Callback) AppDatabase_Impl.this.mCallbacks.get(_i)).onCreate(_db);
                }
            }
        }

        public void onOpen(SupportSQLiteDatabase _db) {
            AppDatabase_Impl.this.mDatabase = _db;
            AppDatabase_Impl.this.internalInitInvalidationTracker(_db);
            if (AppDatabase_Impl.this.mCallbacks != null) {
                int _size = AppDatabase_Impl.this.mCallbacks.size();
                for (int _i = 0; _i < _size; _i++) {
                    ((Callback) AppDatabase_Impl.this.mCallbacks.get(_i)).onOpen(_db);
                }
            }
        }

        protected void validateMigration(SupportSQLiteDatabase _db) {
            HashMap<String, Column> _columnsTipsChannel = new HashMap(10);
            _columnsTipsChannel.put("id", new Column("id", "INTEGER", true, 1));
            _columnsTipsChannel.put(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_TITLE, new Column(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_TITLE, "TEXT", false, 0));
            _columnsTipsChannel.put("subtitle", new Column("subtitle", "TEXT", false, 0));
            _columnsTipsChannel.put("image", new Column("image", "TEXT", false, 0));
            _columnsTipsChannel.put("uuid", new Column("uuid", "TEXT", false, 0));
            _columnsTipsChannel.put("owner", new Column("owner", "TEXT", false, 0));
            _columnsTipsChannel.put("vizsafechannel", new Column("vizsafechannel", "INTEGER", true, 0));
            _columnsTipsChannel.put("privatechannel", new Column("privatechannel", "INTEGER", true, 0));
            _columnsTipsChannel.put("secretchannel", new Column("secretchannel", "INTEGER", true, 0));
            _columnsTipsChannel.put("massaged", new Column("massaged", "INTEGER", true, 0));
            TableInfo tableInfo = new TableInfo("TipsChannel", _columnsTipsChannel, new HashSet(0));
            TableInfo _existingTipsChannel = TableInfo.read(_db, "TipsChannel");
            if (tableInfo.equals(_existingTipsChannel)) {
                HashMap<String, Column> _columnsFavChannel = new HashMap(10);
                _columnsFavChannel.put("id", new Column("id", "INTEGER", true, 1));
                _columnsFavChannel.put(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_TITLE, new Column(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_TITLE, "TEXT", false, 0));
                _columnsFavChannel.put("subtitle", new Column("subtitle", "TEXT", false, 0));
                _columnsFavChannel.put("image", new Column("image", "TEXT", false, 0));
                _columnsFavChannel.put("uuid", new Column("uuid", "TEXT", false, 0));
                _columnsFavChannel.put("owner", new Column("owner", "TEXT", false, 0));
                _columnsFavChannel.put("vizsafechannel", new Column("vizsafechannel", "INTEGER", true, 0));
                _columnsFavChannel.put("privatechannel", new Column("privatechannel", "INTEGER", true, 0));
                _columnsFavChannel.put("secretchannel", new Column("secretchannel", "INTEGER", true, 0));
                _columnsFavChannel.put("massaged", new Column("massaged", "INTEGER", true, 0));
                TableInfo _infoFavChannel = new TableInfo("FavChannel", _columnsFavChannel, new HashSet(0));
                TableInfo _existingFavChannel = TableInfo.read(_db, "FavChannel");
                if (_infoFavChannel.equals(_existingFavChannel)) {
                    HashMap<String, Column> _columnsVizsafeChannel = new HashMap(10);
                    _columnsVizsafeChannel.put("id", new Column("id", "INTEGER", true, 1));
                    _columnsVizsafeChannel.put(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_TITLE, new Column(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_TITLE, "TEXT", false, 0));
                    _columnsVizsafeChannel.put("subtitle", new Column("subtitle", "TEXT", false, 0));
                    _columnsVizsafeChannel.put("image", new Column("image", "TEXT", false, 0));
                    _columnsVizsafeChannel.put("uuid", new Column("uuid", "TEXT", false, 0));
                    _columnsVizsafeChannel.put("owner", new Column("owner", "TEXT", false, 0));
                    _columnsVizsafeChannel.put("vizsafechannel", new Column("vizsafechannel", "INTEGER", true, 0));
                    _columnsVizsafeChannel.put("privatechannel", new Column("privatechannel", "INTEGER", true, 0));
                    _columnsVizsafeChannel.put("secretchannel", new Column("secretchannel", "INTEGER", true, 0));
                    _columnsVizsafeChannel.put("massaged", new Column("massaged", "INTEGER", true, 0));
                    tableInfo = new TableInfo("VizsafeChannel", _columnsVizsafeChannel, new HashSet(0));
                    TableInfo _existingVizsafeChannel = TableInfo.read(_db, "VizsafeChannel");
                    if (tableInfo.equals(_existingVizsafeChannel)) {
                        HashMap<String, Column> _columnsAllChannel = new HashMap(10);
                        _columnsAllChannel.put("id", new Column("id", "INTEGER", true, 1));
                        _columnsAllChannel.put(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_TITLE, new Column(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_TITLE, "TEXT", false, 0));
                        _columnsAllChannel.put("subtitle", new Column("subtitle", "TEXT", false, 0));
                        _columnsAllChannel.put("image", new Column("image", "TEXT", false, 0));
                        _columnsAllChannel.put("uuid", new Column("uuid", "TEXT", false, 0));
                        _columnsAllChannel.put("owner", new Column("owner", "TEXT", false, 0));
                        _columnsAllChannel.put("vizsafechannel", new Column("vizsafechannel", "INTEGER", true, 0));
                        _columnsAllChannel.put("privatechannel", new Column("privatechannel", "INTEGER", true, 0));
                        _columnsAllChannel.put("secretchannel", new Column("secretchannel", "INTEGER", true, 0));
                        _columnsAllChannel.put("massaged", new Column("massaged", "INTEGER", true, 0));
                        TableInfo _infoAllChannel = new TableInfo("AllChannel", _columnsAllChannel, new HashSet(0));
                        TableInfo _existingAllChannel = TableInfo.read(_db, "AllChannel");
                        if (!_infoAllChannel.equals(_existingAllChannel)) {
                            throw new IllegalStateException("Migration didn't properly handle AllChannel(com.vizsafe.app.Database.Tables.AllChannelsTable).\n Expected:\n" + _infoAllChannel + "\n Found:\n" + _existingAllChannel);
                        }
                        return;
                    }
                    throw new IllegalStateException("Migration didn't properly handle VizsafeChannel(com.vizsafe.app.Database.Tables.VizsafeChannelTable).\n Expected:\n" + tableInfo + "\n Found:\n" + _existingVizsafeChannel);
                }
                throw new IllegalStateException("Migration didn't properly handle FavChannel(com.vizsafe.app.Database.Tables.FavChannelTable).\n Expected:\n" + _infoFavChannel + "\n Found:\n" + _existingFavChannel);
            }
            throw new IllegalStateException("Migration didn't properly handle TipsChannel(com.vizsafe.app.Database.Tables.TipsChannelTable).\n Expected:\n" + tableInfo + "\n Found:\n" + _existingTipsChannel);
        }
    }

    protected SupportSQLiteOpenHelper createOpenHelper(DatabaseConfiguration configuration) {
        return configuration.sqliteOpenHelperFactory.create(Configuration.builder(configuration.context).name(configuration.name).version(1).callback(new RoomOpenHelper(configuration, new C02281(), "db43db8f068f07cf1df893053edb9aee")).build());
    }

    protected InvalidationTracker createInvalidationTracker() {
        return new InvalidationTracker(this, "TipsChannel", "FavChannel", "VizsafeChannel", "AllChannel");
    }

    public TipsChannelDao mTipsChannelDao() {
        if (this._tipsChannelDao != null) {
            return this._tipsChannelDao;
        }
        TipsChannelDao tipsChannelDao;
        synchronized (this) {
            if (this._tipsChannelDao == null) {
                this._tipsChannelDao = new TipsChannelDao_Impl(this);
            }
            tipsChannelDao = this._tipsChannelDao;
        }
        return tipsChannelDao;
    }

    public FavChannelDao mFavChannelDao() {
        if (this._favChannelDao != null) {
            return this._favChannelDao;
        }
        FavChannelDao favChannelDao;
        synchronized (this) {
            if (this._favChannelDao == null) {
                this._favChannelDao = new FavChannelDao_Impl(this);
            }
            favChannelDao = this._favChannelDao;
        }
        return favChannelDao;
    }

    public VizsafeChannelDao mVizsafeChannelDao() {
        if (this._vizsafeChannelDao != null) {
            return this._vizsafeChannelDao;
        }
        VizsafeChannelDao vizsafeChannelDao;
        synchronized (this) {
            if (this._vizsafeChannelDao == null) {
                this._vizsafeChannelDao = new VizsafeChannelDao_Impl(this);
            }
            vizsafeChannelDao = this._vizsafeChannelDao;
        }
        return vizsafeChannelDao;
    }

    public AllChannelsDao mAllChannelsDao() {
        if (this._allChannelsDao != null) {
            return this._allChannelsDao;
        }
        AllChannelsDao allChannelsDao;
        synchronized (this) {
            if (this._allChannelsDao == null) {
                this._allChannelsDao = new AllChannelsDao_Impl(this);
            }
            allChannelsDao = this._allChannelsDao;
        }
        return allChannelsDao;
    }
}
