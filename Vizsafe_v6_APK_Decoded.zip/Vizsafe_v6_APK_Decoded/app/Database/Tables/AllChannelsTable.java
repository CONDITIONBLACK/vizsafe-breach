package com.vizsafe.app.Database.Tables;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

@Entity(tableName = "AllChannel")
public class AllChannelsTable {
    @PrimaryKey(autoGenerate = true)
    /* renamed from: id */
    private int f30id;
    @ColumnInfo(name = "image")
    private String image;
    @ColumnInfo(name = "massaged")
    private boolean massaged;
    @ColumnInfo(name = "owner")
    private String owner;
    @ColumnInfo(name = "privatechannel")
    private boolean privatechannel;
    @ColumnInfo(name = "secretchannel")
    private boolean secretchannel;
    @ColumnInfo(name = "subtitle")
    private String subtitle;
    @ColumnInfo(name = "title")
    private String title;
    @ColumnInfo(name = "uuid")
    private String uuid;
    @ColumnInfo(name = "vizsafechannel")
    private boolean vizsafechannel;

    public int getId() {
        return this.f30id;
    }

    public void setId(int id) {
        this.f30id = id;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSubtitle() {
        return this.subtitle;
    }

    public void setSubtitle(String subtitle) {
        this.subtitle = subtitle;
    }

    public String getImage() {
        return this.image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getUuid() {
        return this.uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getOwner() {
        return this.owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public boolean getVizsafechannel() {
        return this.vizsafechannel;
    }

    public void setVizsafechannel(boolean vizsafechannel) {
        this.vizsafechannel = vizsafechannel;
    }

    public boolean getPrivatechannel() {
        return this.privatechannel;
    }

    public void setPrivatechannel(boolean privatechannel) {
        this.privatechannel = privatechannel;
    }

    public boolean getSecretchannel() {
        return this.secretchannel;
    }

    public void setSecretchannel(boolean secretchannel) {
        this.secretchannel = secretchannel;
    }

    public boolean getMassaged() {
        return this.massaged;
    }

    public void setMassaged(boolean massaged) {
        this.massaged = massaged;
    }
}
