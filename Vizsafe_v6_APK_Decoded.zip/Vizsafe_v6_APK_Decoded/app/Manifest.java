package com.vizsafe.app;

public final class Manifest {

    public static final class permission {
        public static final String C2D_MESSAGE = "com.vizsafe.app.permission.C2D_MESSAGE";
    }
}
