package com.vizsafe.app.ImageUtil;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.util.Base64;
import android.widget.ImageView;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.Utils.PreferenceHandler;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.entity.BufferedHttpEntity;
import org.apache.http.impl.client.DefaultHttpClient;

public class ImageLoader {
    Context context;
    ExecutorService executorService;
    FileCache fileCache;
    private final Map<ImageView, String> imageViews = Collections.synchronizedMap(new WeakHashMap());
    MemoryCache memoryCache = new MemoryCache();
    final int stub_id = C0421R.C0418drawable.loading_image;

    class BitmapDisplayer implements Runnable {
        Bitmap bitmap;
        PhotoToLoad photoToLoad;

        public BitmapDisplayer(Bitmap b, PhotoToLoad p) {
            this.bitmap = b;
            this.photoToLoad = p;
        }

        public void run() {
            if (!ImageLoader.this.imageViewReused(this.photoToLoad) && this.bitmap != null) {
                this.photoToLoad.imageView.setImageBitmap(this.bitmap);
            }
        }
    }

    private class PhotoToLoad {
        public ImageView imageView;
        public boolean isCamera;
        public String url;

        public PhotoToLoad(String u, ImageView i, boolean isCamera) {
            this.url = u;
            this.imageView = i;
            this.isCamera = isCamera;
        }
    }

    class PhotosLoader implements Runnable {
        PhotoToLoad photoToLoad;

        PhotosLoader(PhotoToLoad photoToLoad) {
            this.photoToLoad = photoToLoad;
        }

        public void run() {
            if (!ImageLoader.this.imageViewReused(this.photoToLoad)) {
                Bitmap bmp = ImageLoader.this.getBitmap(this.photoToLoad.url, this.photoToLoad.isCamera);
                ImageLoader.this.memoryCache.put(this.photoToLoad.url, bmp);
                if (!ImageLoader.this.imageViewReused(this.photoToLoad)) {
                    ((Activity) this.photoToLoad.imageView.getContext()).runOnUiThread(new BitmapDisplayer(bmp, this.photoToLoad));
                }
            }
        }
    }

    public ImageLoader(Context context) {
        this.context = context;
        this.fileCache = new FileCache(context);
        this.executorService = Executors.newFixedThreadPool(5);
    }

    public void DisplayImage(String url, ImageView imageView, boolean isCamera) {
        this.imageViews.put(imageView, url);
        Bitmap bitmap = this.memoryCache.get(url);
        if (bitmap != null) {
            imageView.setImageBitmap(bitmap);
            return;
        }
        queuePhoto(url, imageView, isCamera);
        imageView.setImageResource(C0421R.C0418drawable.loading_image);
    }

    private void queuePhoto(String url, ImageView imageView, boolean isCamera) {
        this.executorService.submit(new PhotosLoader(new PhotoToLoad(url, imageView, isCamera)));
    }

    private Bitmap getBitmap(String url, boolean isCamera) {
        File f = this.fileCache.getFile(url);
        HttpClient client = new DefaultHttpClient();
        HttpGet request = new HttpGet(url);
        Bitmap b = decodeFile(f);
        if (b != null) {
            return b;
        }
        if (isCamera) {
            try {
                request.addHeader("Authorization", "Basic " + Base64.encodeToString((PreferenceHandler.getInstance(this.context).getUserName() + ":" + PreferenceHandler.getInstance(this.context).getPassword()).getBytes(), 2));
            } catch (Throwable ex) {
                ex.printStackTrace();
                if (ex instanceof OutOfMemoryError) {
                    this.memoryCache.clear();
                }
                return null;
            }
        }
        URL imageUrl = new URL(url);
        BufferedHttpEntity bufferedEntity = new BufferedHttpEntity(client.execute(request).getEntity());
        HttpURLConnection conn = (HttpURLConnection) imageUrl.openConnection();
        conn.setConnectTimeout(60000);
        conn.setReadTimeout(60000);
        conn.setInstanceFollowRedirects(true);
        InputStream is = bufferedEntity.getContent();
        OutputStream os = new FileOutputStream(f);
        C0340Utils.CopyStream(is, os);
        os.close();
        Bitmap bitmap = decodeFile(f);
        if (bitmap != null) {
            bitmap = Bitmap.createScaledBitmap(bitmap, 600, HttpStatus.SC_INTERNAL_SERVER_ERROR, true);
        }
        return bitmap;
    }

    private Bitmap decodeFile(File f) {
        try {
            Options o = new Options();
            o.inJustDecodeBounds = true;
            Bitmap img = BitmapFactory.decodeStream(new FileInputStream(f), null, o);
            int width_tmp = o.outWidth;
            int height_tmp = o.outHeight;
            int scale = 1;
            while (width_tmp / 2 >= 200 && height_tmp / 2 >= 200) {
                width_tmp /= 2;
                height_tmp /= 2;
                scale *= 2;
            }
            Options o2 = new Options();
            o2.inSampleSize = scale;
            return BitmapFactory.decodeStream(new FileInputStream(f), null, o2);
        } catch (FileNotFoundException e) {
            return null;
        }
    }

    boolean imageViewReused(PhotoToLoad photoToLoad) {
        String tag = (String) this.imageViews.get(photoToLoad.imageView);
        if (tag == null || !tag.equals(photoToLoad.url)) {
            return true;
        }
        return false;
    }

    public void clearCache() {
        this.memoryCache.clear();
        this.fileCache.clear();
    }
}
