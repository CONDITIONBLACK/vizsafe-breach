package com.vizsafe.app.GCMReceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.support.p001v4.content.LocalBroadcastManager;
import android.telephony.SmsMessage;
import com.vizsafe.app.GCMIntentService.GCMClientManager;

public class SmsReceiver extends BroadcastReceiver {
    private static SmsListener mListener;

    public void onReceive(Context context, Intent intent) {
        Object[] pdus = (Object[]) intent.getExtras().get("pdus");
        for (Object obj : pdus) {
            SmsMessage smsMessage = SmsMessage.createFromPdu((byte[]) obj);
            String sender = smsMessage.getDisplayOriginatingAddress();
            String messageBody = smsMessage.getMessageBody();
            Intent smsIntent = new Intent("otp");
            smsIntent.putExtra(GCMClientManager.EXTRA_MESSAGE, messageBody);
            LocalBroadcastManager.getInstance(context).sendBroadcast(smsIntent);
        }
    }

    public static void bindListener(SmsListener listener) {
        mListener = listener;
    }
}
