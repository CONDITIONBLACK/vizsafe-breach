package com.vizsafe.app.GCMReceiver;

import android.content.Context;
import android.content.Intent;
import android.support.p001v4.content.WakefulBroadcastReceiver;
import com.vizsafe.app.GCMIntentService.C0269GCMIntentService;
import com.vizsafe.app.Utils.PreferenceHandler;

public class GCMBroadcastReceiver extends WakefulBroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (action.equals("notification_cancelled")) {
            C0269GCMIntentService.clear();
        }
        if (action.equals("com.google.android.c2dm.intent.RECEIVE") && PreferenceHandler.getInstance(context).getNotificationStatus()) {
            Intent service = new Intent(context, C0269GCMIntentService.class);
            service.putExtras(intent);
            WakefulBroadcastReceiver.startWakefulService(context, service);
            setResultCode(-1);
        }
    }
}
