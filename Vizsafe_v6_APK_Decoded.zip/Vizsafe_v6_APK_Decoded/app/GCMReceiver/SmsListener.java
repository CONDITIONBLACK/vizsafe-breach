package com.vizsafe.app.GCMReceiver;

public interface SmsListener {
    void messageReceived(String str);
}
