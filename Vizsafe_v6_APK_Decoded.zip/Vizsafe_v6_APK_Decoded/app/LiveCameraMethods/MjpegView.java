package com.vizsafe.app.LiveCameraMethods;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceHolder.Callback;
import android.view.SurfaceView;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import yjkim.mjpegviewer.MjpegCallback;
import yjkim.mjpegviewer.MjpegInputStream;
import yjkim.mjpegviewer.MjpegViewThread;

public class MjpegView extends SurfaceView implements Callback {
    public static final int SIZE_FIT = 1;
    public static final int SIZE_FULL = 2;
    private DoRead StreamReader = null;
    public Bitmap currentBitmap;
    private Handler handler = null;
    private SurfaceHolder mHolder = getHolder();
    private MjpegInputStream mIn = null;
    private State state;
    private boolean suspending = false;
    private MjpegViewThread thread = null;

    /* renamed from: com.vizsafe.app.LiveCameraMethods.MjpegView$1 */
    class C03771 implements MjpegCallback {
        C03771() {
        }

        public void onStateChange(int s) {
            MjpegView.this.state = State.values()[s];
            if (MjpegView.this.state == State.CONNECTION_ERROR) {
                MjpegView.this.mIn = null;
            }
            MjpegView.this.alertState();
        }
    }

    public class DoRead extends AsyncTask<String, Void, Void> {
        public void alertState() {
            if (MjpegView.this.handler != null) {
                Message msg = MjpegView.this.handler.obtainMessage();
                msg.obj = MjpegView.this.state.toString();
                MjpegView.this.handler.sendMessage(msg);
            }
        }

        protected Void doInBackground(String... urls) {
            try {
                MjpegView.this.suspending = true;
                MjpegView.this.state = State.CONNECTION_PROGRESS;
                alertState();
                HttpURLConnection conn = (HttpURLConnection) new URL(urls[0]).openConnection();
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);
                if (conn.getResponseCode() != 200) {
                    MjpegView.this.state = State.CONNECTION_ERROR;
                    alertState();
                } else {
                    MjpegView.this.state = State.CONNECTED;
                    alertState();
                    MjpegView.this.mIn = new MjpegInputStream(conn.getInputStream());
                    MjpegView.this.currentBitmap = MjpegView.this.mIn.readMjpegFrame();
                    MjpegView.this.thread.setInputStream(MjpegView.this.mIn);
                }
            } catch (Exception e) {
                MjpegView.this.state = State.CONNECTION_ERROR;
                alertState();
            }
            return null;
        }

        protected void onPostExecute(Void result) {
            if (MjpegView.this.state == State.CONNECTED) {
                MjpegView.this.thread.start();
                MjpegView.this.suspending = false;
            }
        }
    }

    public enum State {
        DISCONNECTED,
        CONNECTION_PROGRESS,
        CONNECTED,
        CONNECTION_ERROR,
        STOPPING_PROGRESS
    }

    public MjpegView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mHolder.addCallback(this);
        this.state = State.DISCONNECTED;
        setKeepScreenOn(true);
    }

    private void SetThread() {
        Log.d("State : ", "Set Thread");
        if (this.thread == null) {
            this.thread = new MjpegViewThread(this.mHolder, this);
            this.thread.mCallback = new C03771();
        }
    }

    public void Stop() {
        Log.d("State : ", "Stop");
        this.state = State.STOPPING_PROGRESS;
        alertState();
        if (this.thread != null) {
            this.thread.StopRunning();
            boolean retry = true;
            while (retry) {
                try {
                    this.thread.join();
                    retry = false;
                } catch (InterruptedException e) {
                }
            }
            this.thread = null;
        }
        if (this.mIn != null) {
            try {
                this.mIn.close();
            } catch (IOException e2) {
            }
        }
        this.mIn = null;
        try {
            this.StreamReader.cancel(true);
            this.suspending = false;
        } catch (Exception e3) {
        }
        this.state = State.DISCONNECTED;
        alertState();
    }

    public void SetDisplayMode(int s) {
        this.thread.displayMode = s;
    }

    public void Start(String url, Handler parent_handler) {
        this.handler = parent_handler;
        Stop();
        if (!this.suspending) {
            SetThread();
            this.StreamReader = new DoRead();
            this.StreamReader.execute(new String[]{url});
        }
    }

    public void Start(String url) {
        Stop();
        if (!this.suspending) {
            SetThread();
            this.StreamReader = new DoRead();
            this.StreamReader.execute(new String[]{url});
        }
    }

    private void alertState() {
        if (this.handler != null) {
            Message msg = this.handler.obtainMessage();
            msg.obj = this.state.toString();
            this.handler.sendMessage(msg);
        }
    }

    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        if (this.thread != null) {
            this.thread.SetViewSize(width, height);
        }
    }

    public void surfaceCreated(SurfaceHolder holder) {
        if (this.thread != null) {
            this.thread.SetViewSize(getWidth(), getHeight());
        }
    }

    public void surfaceDestroyed(SurfaceHolder holder) {
    }
}
