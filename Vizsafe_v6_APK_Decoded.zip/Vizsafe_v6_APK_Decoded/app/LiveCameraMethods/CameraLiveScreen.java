package com.vizsafe.app.LiveCameraMethods;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.support.p002v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.Utils.CommonMember;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;

public class CameraLiveScreen extends AppCompatActivity {
    private static CameraLiveScreen mContext;
    @SuppressLint({"HandlerLeak"})
    private Handler MjpegViewHandler = new C03763();
    private String URL;
    private Bitmap bitmap;
    private String cameraPass;
    private String cameraUuid;
    private ImageView downloadImage;
    /* renamed from: i */
    private int f34i = 0;
    private ImageView mDoneBtn;
    /* renamed from: mv */
    private MjpegView f35mv;
    private FrameLayout zoomView;

    /* renamed from: com.vizsafe.app.LiveCameraMethods.CameraLiveScreen$1 */
    class C03741 implements OnClickListener {
        C03741() {
        }

        public void onClick(View v) {
            CameraLiveScreen.this.f35mv.Stop();
            CameraLiveScreen.this.finish();
        }
    }

    /* renamed from: com.vizsafe.app.LiveCameraMethods.CameraLiveScreen$2 */
    class C03752 implements OnClickListener {
        C03752() {
        }

        public void onClick(View v) {
            CameraLiveScreen.this.bitmap = CameraLiveScreen.this.f35mv.currentBitmap;
            if (CameraLiveScreen.this.bitmap == null) {
                return;
            }
            if ("mounted".equals(Environment.getExternalStorageState())) {
                File directory = new File(Environment.getExternalStorageDirectory() + "/VizsafeImages");
                directory.mkdirs();
                File yourFile = new File(directory, "CameraImage" + CameraLiveScreen.this.f34i + ".jpg");
                while (yourFile.exists()) {
                    CameraLiveScreen.this.f34i = CameraLiveScreen.this.f34i + 1;
                    yourFile = new File(directory, "CameraImage" + CameraLiveScreen.this.f34i + ".jpg");
                }
                if (!yourFile.exists() && directory.canWrite()) {
                    try {
                        FileOutputStream out = new FileOutputStream(yourFile, true);
                        CameraLiveScreen.this.bitmap.compress(CompressFormat.PNG, 90, out);
                        out.flush();
                        out.close();
                        Toast.makeText(CameraLiveScreen.this, "File Saved to /VizsafeImages/CameraImage" + CameraLiveScreen.this.f34i + ".jpg", 0).show();
                        CameraLiveScreen.this.f34i = CameraLiveScreen.this.f34i + 1;
                        return;
                    } catch (IOException e) {
                        e.printStackTrace();
                        return;
                    }
                }
                return;
            }
            Toast.makeText(CameraLiveScreen.this, CameraLiveScreen.this.getResources().getString(C0421R.string.sdcard_not_available), 0).show();
        }
    }

    /* renamed from: com.vizsafe.app.LiveCameraMethods.CameraLiveScreen$3 */
    class C03763 extends Handler {
        C03763() {
        }

        public void handleMessage(Message msg) {
            Log.d("State : ", msg.obj.toString());
            String obj = msg.obj.toString();
            Object obj2 = -1;
            switch (obj.hashCode()) {
                case -2087582999:
                    if (obj.equals("CONNECTED")) {
                        obj2 = 2;
                        break;
                    }
                    break;
                case -1905424057:
                    if (obj.equals("CONNECTION_ERROR")) {
                        obj2 = 3;
                        break;
                    }
                    break;
                case -302460306:
                    if (obj.equals("CONNECTION_PROGRESS")) {
                        obj2 = 1;
                        break;
                    }
                    break;
                case 935892539:
                    if (obj.equals("DISCONNECTED")) {
                        obj2 = null;
                        break;
                    }
                    break;
                case 1274772888:
                    if (obj.equals("STOPPING_PROGRESS")) {
                        obj2 = 4;
                        break;
                    }
                    break;
            }
            switch (obj2) {
            }
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView((int) C0421R.layout.activity_sample_view);
        this.f35mv = (MjpegView) findViewById(C0421R.C0419id.videwView);
        mContext = this;
        this.zoomView = (FrameLayout) findViewById(C0421R.C0419id.zoomView);
        this.cameraUuid = getIntent().getExtras().getString("camera_uuid");
        this.cameraPass = getIntent().getExtras().getString("camera_pass");
        this.mDoneBtn = (ImageView) findViewById(C0421R.C0419id.action_bar_back);
        this.downloadImage = (ImageView) findViewById(C0421R.C0419id.action_bar_imageview_right);
        this.downloadImage.setBackgroundResource(C0421R.C0418drawable.ic_file_download);
        this.downloadImage.setVisibility(0);
        String mKey = CommonMember.GetKeyString();
        String mToken = null;
        try {
            mToken = CommonMember.GetOrinalKey(mKey);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        this.URL = CommonMember.getURL(getApplicationContext());
        this.URL += "/camera/" + this.cameraUuid + "/mjpeg?key=" + mKey + "&token=" + mToken;
        this.f35mv.Start(this.URL, this.MjpegViewHandler);
        this.mDoneBtn.setOnClickListener(new C03741());
        this.downloadImage.setOnClickListener(new C03752());
    }

    public void onPause() {
        super.onPause();
        this.f35mv.Stop();
    }

    public void onBackPressed() {
        super.onBackPressed();
        this.f35mv.Stop();
        finish();
    }
}
