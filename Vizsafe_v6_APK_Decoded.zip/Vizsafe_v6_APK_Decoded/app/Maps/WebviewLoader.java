package com.vizsafe.app.Maps;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.TextView;
import com.google.android.gms.plus.PlusShare;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.Utils.PreferenceHandler;
import dmax.dialog.SpotsDialog;
import org.apache.http.HttpHeaders;

public class WebviewLoader extends Activity {
    String email;
    private ImageView mDoneBtn;
    private String mFrom;
    private AlertDialog mTransparentProgressDialog;
    private WebView mWebView;
    WebviewLoader mWebviewLoader;
    int orientation;
    String password;

    /* renamed from: com.vizsafe.app.Maps.WebviewLoader$1 */
    class C03871 implements OnClickListener {
        C03871() {
        }

        public void onClick(View v) {
            WebviewLoader.this.finish();
        }
    }

    /* renamed from: com.vizsafe.app.Maps.WebviewLoader$3 */
    class C03893 extends WebViewClient {
        C03893() {
        }

        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            WebviewLoader.this.mTransparentProgressDialog.show();
            view.loadUrl(url);
            return false;
        }

        public void onPageFinished(WebView view, String url) {
            if (WebviewLoader.this.mTransparentProgressDialog.isShowing()) {
                WebviewLoader.this.mTransparentProgressDialog.dismiss();
            }
        }

        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            if (WebviewLoader.this.mTransparentProgressDialog.isShowing()) {
                WebviewLoader.this.mTransparentProgressDialog.dismiss();
            }
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0421R.layout.activity_webview);
        this.mWebviewLoader = this;
        this.mWebView = (WebView) findViewById(C0421R.C0419id.webview);
        this.mDoneBtn = (ImageView) findViewById(C0421R.C0419id.action_bar_back);
        this.mFrom = getIntent().getExtras().getString(HttpHeaders.FROM);
        this.email = PreferenceHandler.getInstance(this.mWebviewLoader).getUserName();
        this.password = PreferenceHandler.getInstance(this.mWebviewLoader).getPassword();
        this.mTransparentProgressDialog = new SpotsDialog((Context) this, getResources().getString(C0421R.string.please_wait_loading));
        this.mTransparentProgressDialog.setCanceledOnTouchOutside(false);
        this.mTransparentProgressDialog.setCancelable(false);
        this.mDoneBtn.setOnClickListener(new C03871());
        this.email = Base64.encodeToString(this.email.getBytes(), 2);
        this.password = Base64.encodeToString(this.password.getBytes(), 2);
        this.mWebView.getSettings().setJavaScriptEnabled(true);
        this.mWebView.getSettings().setBuiltInZoomControls(true);
        this.mWebView.getSettings().setSupportZoom(true);
        this.mWebView.getSettings().setLoadsImagesAutomatically(true);
        this.mWebView.getSettings().setUseWideViewPort(true);
        String ServerName = PreferenceHandler.getInstance(this.mWebviewLoader).getServerName();
        this.mWebView.setWebChromeClient(new WebChromeClient() {
            public void onProgressChanged(WebView view, int progress) {
                this.setProgress(progress * 1000);
            }
        });
        this.mWebView.setWebViewClient(new C03893());
        if (this.mFrom.equalsIgnoreCase("MapPage")) {
            this.mWebView.loadUrl("https://" + ServerName + "/floorplansmobile?username=" + this.email + "&password=" + this.password);
            this.orientation = ((WindowManager) getSystemService("window")).getDefaultDisplay().getOrientation();
            this.mWebView.setVisibility(0);
        } else if (this.mFrom.equalsIgnoreCase("SettingsPage")) {
            String mURL = getIntent().getExtras().getString(PlusShare.KEY_CALL_TO_ACTION_URL);
            String title = getIntent().getExtras().getString(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_TITLE);
            TextView mTitle = (TextView) findViewById(2131689653);
            if (title != null) {
                mTitle.setText(title);
            }
            this.mWebView.loadUrl(mURL);
            this.orientation = ((WindowManager) getSystemService("window")).getDefaultDisplay().getOrientation();
            this.mWebView.setVisibility(0);
        }
    }
}
