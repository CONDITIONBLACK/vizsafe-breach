package com.vizsafe.app.Maps;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.p001v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.webkit.GeolocationPermissions.Callback;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.analytics.ecommerce.ProductAction;
import com.google.android.gms.internal.zzahn;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.measurement.AppMeasurement.Param;
import com.google.android.gms.nearby.messages.Strategy;
import com.google.android.gms.plus.PlusShare;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.CustomViews.SampleWebview;
import com.vizsafe.app.HomePage.MapsPage.onGoToMicelloIndoorPageListener;
import com.vizsafe.app.HomePage.MapsPage.onGoToReportDetailsPageListener;
import com.vizsafe.app.LiveCameraMethods.CameraLiveScreen;
import com.vizsafe.app.POJO.ChannelsListItem;
import com.vizsafe.app.POJO.NotesItems;
import com.vizsafe.app.Utils.CommonMember;
import com.vizsafe.app.Utils.PreferenceHandler;
import com.vizsafe.app.Utils.VizsafeGPSTracker;
import com.vizsafe.app.Utils.Webservice;
import dmax.dialog.SpotsDialog;
import java.io.IOException;
import java.util.ArrayList;
import org.apache.commons.p004io.IOUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class LoadMicelloFloorPlan extends Fragment {
    private static Bundle mBundle;
    private JSONObject CameraResponse = null;
    int FEED_CLEARED = 100;
    private String ImageSize;
    private String ImageUrl;
    private String IncidentResponse;
    String channelPictureUrl;
    String content = null;
    private String email;
    private int fromDuration = 0;
    private GoogleMap googleMap;
    VizsafeGPSTracker gps;
    private String latitude;
    Double latitudeGoogleMap = null;
    private String longitude;
    Double longitudeGoogleMap = null;
    private String mCameraResponse;
    String[] mDesvalue = null;
    private ImageView mDoneBtn;
    private String mDrawingId;
    private String mLevelId;
    private Context mLoadMicelloFloorPlan;
    private WebView mMicelloWebView;
    private String mPlaceId;
    private String mPlaceUUid;
    private AlertDialog mTransparentProgressDialog;
    private String mUuid;
    LocationManager manager;
    private ProgressBar mapProgress;
    LatLng myLatLng;
    Location myLocation;
    private String password;
    private SeekBar seekbar;
    private TextView showingText;
    private ImageView timeIcon;

    /* renamed from: com.vizsafe.app.Maps.LoadMicelloFloorPlan$1 */
    class C03781 implements OnClickListener {
        C03781() {
        }

        public void onClick(View v) {
            ((onGoToMicelloIndoorPageListener) LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).onGoToMicelloIndoorPage();
        }
    }

    /* renamed from: com.vizsafe.app.Maps.LoadMicelloFloorPlan$2 */
    class C03792 extends WebChromeClient {
        C03792() {
        }

        public void onGeolocationPermissionsShowPrompt(String origin, Callback callback) {
            callback.invoke(origin, true, false);
        }
    }

    /* renamed from: com.vizsafe.app.Maps.LoadMicelloFloorPlan$3 */
    class C03803 implements OnSeekBarChangeListener {
        C03803() {
        }

        public void onStopTrackingTouch(SeekBar seekBar) {
            int progress = seekBar.getProgress();
            if (CommonMember.isNetworkOnline((ConnectivityManager) LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan.getSystemService("connectivity"), LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan)) {
                progress = Math.round((float) (progress / 11)) * 11;
                PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).setProgressLevelMap(progress);
                if (progress == 0) {
                    LoadMicelloFloorPlan.this.showingText.setText(LoadMicelloFloorPlan.this.getString(C0421R.string.showing_last_ten_minutes));
                    PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).setProgressLevelMap(0);
                    PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).setProgressTextMap(LoadMicelloFloorPlan.this.getString(C0421R.string.showing_last_ten_minutes));
                    PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).setFromDuration(600);
                } else if (progress == 11) {
                    LoadMicelloFloorPlan.this.showingText.setText(LoadMicelloFloorPlan.this.getString(C0421R.string.showing_last_thirty_minutes));
                    PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).setProgressLevelMap(11);
                    PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).setProgressTextMap(LoadMicelloFloorPlan.this.getString(C0421R.string.showing_last_thirty_minutes));
                    PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).setFromDuration(1800);
                } else if (progress == 22) {
                    LoadMicelloFloorPlan.this.showingText.setText(LoadMicelloFloorPlan.this.getString(C0421R.string.showing_last_hour));
                    PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).setProgressLevelMap(22);
                    PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).setProgressTextMap(LoadMicelloFloorPlan.this.getString(C0421R.string.showing_last_hour));
                    PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).setFromDuration(3600);
                } else if (progress == 33) {
                    LoadMicelloFloorPlan.this.showingText.setText(LoadMicelloFloorPlan.this.getString(C0421R.string.showing_last_three_hours));
                    PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).setProgressLevelMap(33);
                    PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).setProgressTextMap(LoadMicelloFloorPlan.this.getString(C0421R.string.showing_last_three_hours));
                    PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).setFromDuration(10800);
                } else if (progress == 44) {
                    LoadMicelloFloorPlan.this.showingText.setText(LoadMicelloFloorPlan.this.getString(C0421R.string.showing_last_six_hours));
                    PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).setProgressLevelMap(44);
                    PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).setProgressTextMap(LoadMicelloFloorPlan.this.getString(C0421R.string.showing_last_six_hours));
                    PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).setFromDuration(21600);
                } else if (progress == 55) {
                    LoadMicelloFloorPlan.this.showingText.setText(LoadMicelloFloorPlan.this.getString(C0421R.string.showing_last_twelve_hours));
                    PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).setProgressLevelMap(55);
                    PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).setProgressTextMap(LoadMicelloFloorPlan.this.getString(C0421R.string.showing_last_twelve_hours));
                    PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).setFromDuration(43200);
                } else if (progress == 66) {
                    LoadMicelloFloorPlan.this.showingText.setText(LoadMicelloFloorPlan.this.getString(C0421R.string.showing_last_tewntyfour_hours));
                    PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).setProgressLevelMap(66);
                    PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).setProgressTextMap(LoadMicelloFloorPlan.this.getString(C0421R.string.showing_last_tewntyfour_hours));
                    PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).setFromDuration(Strategy.TTL_SECONDS_MAX);
                } else if (progress == 77) {
                    LoadMicelloFloorPlan.this.showingText.setText(LoadMicelloFloorPlan.this.getString(C0421R.string.showing_last_seven_days));
                    PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).setProgressLevelMap(77);
                    PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).setProgressTextMap(LoadMicelloFloorPlan.this.getString(C0421R.string.showing_last_seven_days));
                    PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).setFromDuration(604800);
                } else if (progress == 88) {
                    LoadMicelloFloorPlan.this.showingText.setText(LoadMicelloFloorPlan.this.getString(C0421R.string.showing_last_month));
                    PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).setProgressLevelMap(88);
                    PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).setProgressTextMap(LoadMicelloFloorPlan.this.getString(C0421R.string.showing_last_month));
                    PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).setFromDuration(2628000);
                } else {
                    LoadMicelloFloorPlan.this.showingText.setText(LoadMicelloFloorPlan.this.getString(C0421R.string.showing_all));
                    PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).setProgressLevelMap(99);
                    PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).setProgressTextMap(LoadMicelloFloorPlan.this.getString(C0421R.string.showing_all));
                    PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).setFromDuration(0);
                }
                if (progress <= 66) {
                    LoadMicelloFloorPlan.this.timeIcon.setImageResource(C0421R.C0418drawable.clock_blue);
                } else {
                    LoadMicelloFloorPlan.this.timeIcon.setImageResource(C0421R.C0418drawable.calender_blue);
                }
                LoadMicelloFloorPlan.this.fromDuration = PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).getFromDuration();
                if (CommonMember.isNetworkOnline((ConnectivityManager) LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan.getSystemService("connectivity"), LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan)) {
                    new AsyncTaskGetMicelloIndoorMapFloorPlanDetails(LoadMicelloFloorPlan.this, null).execute(new String[0]);
                } else {
                    CommonMember.NetworkStatusAlert(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan);
                }
            }
        }

        public void onStartTrackingTouch(SeekBar seekBar) {
        }

        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        }
    }

    private class AsyncEgsStreamResponse extends AsyncTask<String, String, String> {
        JSONObject mResponse = null;
        String mURL = null;
        String response = null;

        private AsyncEgsStreamResponse() {
        }

        protected void onPreExecute() {
            super.onPreExecute();
            LoadMicelloFloorPlan.this.mTransparentProgressDialog.show();
        }

        protected String doInBackground(String... arg0) {
            this.mResponse = Webservice.GetEGSURL(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan, arg0[0]);
            return null;
        }

        protected void onPostExecute(String result) {
            if (LoadMicelloFloorPlan.this.mTransparentProgressDialog.isShowing()) {
                LoadMicelloFloorPlan.this.mTransparentProgressDialog.dismiss();
            }
            if (this.mResponse != null) {
            }
        }
    }

    private class AsyncTaskGetFeedDetails extends AsyncTask<String, String, String> {
        JSONObject response;

        /* renamed from: com.vizsafe.app.Maps.LoadMicelloFloorPlan$AsyncTaskGetFeedDetails$1 */
        class C03811 implements Runnable {
            C03811() {
            }

            public void run() {
                try {
                    LoadMicelloFloorPlan.this.mTransparentProgressDialog.show();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        /* renamed from: com.vizsafe.app.Maps.LoadMicelloFloorPlan$AsyncTaskGetFeedDetails$2 */
        class C03822 implements Runnable {
            C03822() {
            }

            public void run() {
                try {
                    if (LoadMicelloFloorPlan.this.mTransparentProgressDialog.isShowing()) {
                        LoadMicelloFloorPlan.this.mTransparentProgressDialog.dismiss();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        private AsyncTaskGetFeedDetails() {
        }

        /* synthetic */ AsyncTaskGetFeedDetails(LoadMicelloFloorPlan x0, C03781 x1) {
            this();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            zzahn.runOnUiThread(new C03811());
        }

        protected String doInBackground(String... arg0) {
            this.response = new Webservice().GetFeedDetailsUsingUuid(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan, LoadMicelloFloorPlan.this.email, LoadMicelloFloorPlan.this.password, LoadMicelloFloorPlan.this.mUuid);
            return null;
        }

        protected void onPostExecute(String result) {
            zzahn.runOnUiThread(new C03822());
            if (this.response != null) {
                JSONObject feedRatingsObject = null;
                String feedPostedBy = null;
                String feedLatitude = null;
                String feedLongitude = null;
                String incidentState = null;
                String incidentClearedBy = null;
                String incidentClearedTimeStamp = null;
                try {
                    String severityLevel = "0";
                    int communityid = 0;
                    int drawingid = 0;
                    int levelid = 0;
                    ArrayList<NotesItems> notesItem = null;
                    String feedAbuseOrNot = "false";
                    boolean feedRatingByMe = false;
                    int feedRatings = 0;
                    JSONObject jSONObject = new JSONObject(String.valueOf(this.response));
                    if (jSONObject.getInt("httpCode") == 200) {
                        JSONObject singleIncidentObject = jSONObject.getJSONObject(ProductAction.ACTION_DETAIL);
                        String feedType = singleIncidentObject.getString("type");
                        String feedIcon = singleIncidentObject.getString("uuid");
                        if (singleIncidentObject.has("communityid")) {
                            communityid = singleIncidentObject.getInt("communityid");
                        }
                        if (singleIncidentObject.has("drawingid")) {
                            drawingid = singleIncidentObject.getInt("drawingid");
                        }
                        if (singleIncidentObject.has("levelid")) {
                            levelid = singleIncidentObject.getInt("levelid");
                        }
                        if (singleIncidentObject.has("severitylevel")) {
                            severityLevel = singleIncidentObject.getString("severitylevel");
                        }
                        if (singleIncidentObject.has("incidentState")) {
                            incidentState = singleIncidentObject.getString("incidentState");
                        }
                        if (singleIncidentObject.has("incidentClearedBy")) {
                            incidentClearedBy = singleIncidentObject.getString("incidentClearedBy");
                        }
                        if (singleIncidentObject.has("incidentClearedTimeStamp")) {
                            incidentClearedTimeStamp = singleIncidentObject.getString("incidentClearedTimeStamp");
                        }
                        String feedDetail = singleIncidentObject.getString(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_DESCRIPTION);
                        if (singleIncidentObject.has("uploadedBy")) {
                            String feedUploadedByUuid = singleIncidentObject.getString("uploadedBy");
                        }
                        if (singleIncidentObject.has("uploadedByDisplayName")) {
                            feedPostedBy = singleIncidentObject.getString("uploadedByDisplayName");
                        }
                        if (singleIncidentObject.has("abuseReported")) {
                            feedAbuseOrNot = singleIncidentObject.getString("abuseReported");
                        }
                        String feedUploadedTime = singleIncidentObject.getLong(Param.TIMESTAMP) + "000";
                        JSONObject feedLocationAndGeoObject = singleIncidentObject.getJSONObject(FirebaseAnalytics.Param.LOCATION);
                        if (feedLocationAndGeoObject != null) {
                            JSONObject feedLocationObject = feedLocationAndGeoObject.getJSONObject("loc");
                            if (feedLocationObject != null) {
                                feedLatitude = feedLocationObject.getString("lat");
                                feedLongitude = feedLocationObject.getString("lng");
                            }
                        }
                        if (singleIncidentObject.has("ratings")) {
                            try {
                                feedRatingsObject = singleIncidentObject.getJSONObject("ratings");
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            if (feedRatingsObject != null) {
                                feedRatings = feedRatingsObject.length();
                                if (feedRatingsObject.has(PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).getUserUUID())) {
                                    feedRatingByMe = true;
                                }
                            }
                        }
                        JSONArray feedChannelsArray = singleIncidentObject.getJSONArray("channels");
                        ArrayList<ChannelsListItem> channelsInFeed = null;
                        if (feedChannelsArray != null) {
                            channelsInFeed = new ArrayList();
                            for (int j = 0; j < feedChannelsArray.length(); j++) {
                                JSONObject feedChannelsObject = feedChannelsArray.getJSONObject(j);
                                boolean channelPrivate = false;
                                boolean channelSecret = false;
                                boolean channelMassaged = false;
                                boolean channelVizsafe = false;
                                String channelUuid = feedChannelsObject.getString("uuid");
                                String channelName = feedChannelsObject.getString("name");
                                String channelDescription = feedChannelsObject.getString(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_DESCRIPTION);
                                String channelOwner = feedChannelsObject.getString("owner");
                                String channelPicture = feedChannelsObject.getString("channelPicture");
                                if (feedChannelsObject.has("owner")) {
                                    channelOwner = feedChannelsObject.getString("owner");
                                }
                                if (feedChannelsObject.has("vizsafeChannel")) {
                                    channelVizsafe = Boolean.parseBoolean(feedChannelsObject.getString("vizsafeChannel"));
                                }
                                if (feedChannelsObject.has("privateChannel")) {
                                    channelPrivate = Boolean.parseBoolean(feedChannelsObject.getString("privateChannel"));
                                }
                                if (feedChannelsObject.has("secretChannel")) {
                                    channelSecret = Boolean.parseBoolean(feedChannelsObject.getString("secretChannel"));
                                }
                                if (feedChannelsObject.has("massaged")) {
                                    channelMassaged = Boolean.parseBoolean(feedChannelsObject.getString("massaged"));
                                }
                                channelsInFeed.add(new ChannelsListItem(channelName, channelDescription, LoadMicelloFloorPlan.this.channelPictureUrl + channelPicture, channelUuid, channelOwner, channelVizsafe, channelPrivate, channelSecret, channelMassaged));
                            }
                        }
                        if (singleIncidentObject.has("notes")) {
                            JSONObject feedNotesJsonObject = singleIncidentObject.getJSONObject("notes");
                            if (feedNotesJsonObject.getInt("number") > 0) {
                                notesItem = new ArrayList();
                                JSONArray feedNotesArray = feedNotesJsonObject.getJSONArray("notes");
                                for (int k = 0; k < feedNotesArray.length(); k++) {
                                    JSONObject notesDataObject = feedNotesArray.getJSONObject(k);
                                    ArrayList<NotesItems> arrayList = notesItem;
                                    arrayList.add(new NotesItems(notesDataObject.getString("uploadedBy"), notesDataObject.getString(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_DESCRIPTION), notesDataObject.getLong("uploadedDate"), notesDataObject.getString("incidentID"), notesDataObject.getString("noteuuid")));
                                }
                            }
                        }
                        boolean isSecretChannel = false;
                        int i = 0;
                        while (i < feedChannelsArray.length()) {
                            if (((ChannelsListItem) channelsInFeed.get(i)).isSecret) {
                                isSecretChannel = true;
                                break;
                            } else {
                                isSecretChannel = false;
                                i++;
                            }
                        }
                        boolean isPrivateChannel = false;
                        i = 0;
                        while (i < feedChannelsArray.length()) {
                            if (((ChannelsListItem) channelsInFeed.get(i)).isPrivate) {
                                isPrivateChannel = true;
                                break;
                            } else {
                                isPrivateChannel = false;
                                i++;
                            }
                        }
                        Bundle markerInfoDetail = new Bundle();
                        markerInfoDetail.putString("feed_uploadedBy", feedPostedBy);
                        markerInfoDetail.putString("severity", severityLevel);
                        markerInfoDetail.putString("feed_description", feedDetail);
                        markerInfoDetail.putString("feed_timestamp", feedUploadedTime);
                        markerInfoDetail.putString("feed_imageUrl", feedIcon);
                        markerInfoDetail.putString("feed_abuse", feedAbuseOrNot);
                        markerInfoDetail.putString("feed_latitude", feedLatitude);
                        markerInfoDetail.putString("feed_longitude", feedLongitude);
                        markerInfoDetail.putInt("feed_ratings", feedRatings);
                        markerInfoDetail.putBoolean("feed_rating_by_me", feedRatingByMe);
                        markerInfoDetail.putString("feed_type", feedType);
                        markerInfoDetail.putString("incident_state", incidentState);
                        markerInfoDetail.putString("incident_cleared_by", incidentClearedBy);
                        markerInfoDetail.putString("incident_cleared_timestamp", incidentClearedTimeStamp);
                        markerInfoDetail.putString("feed_posted_by", feedPostedBy);
                        markerInfoDetail.putBoolean("is_channel_secret", isSecretChannel);
                        markerInfoDetail.putBoolean("is_channel_private", isPrivateChannel);
                        markerInfoDetail.putInt("CommunityId", communityid);
                        markerInfoDetail.putInt("Drawingid", drawingid);
                        markerInfoDetail.putInt("LevelId", levelid);
                        markerInfoDetail.putString("from", "micello");
                        markerInfoDetail.putSerializable("notes_data_list", notesItem);
                        markerInfoDetail.putSerializable("channel_list", channelsInFeed);
                        ((onGoToReportDetailsPageListener) LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).onGoToReportDetailsPage(markerInfoDetail);
                        return;
                    }
                    return;
                } catch (JSONException e2) {
                    e2.printStackTrace();
                    return;
                }
            }
            Toast.makeText(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan, LoadMicelloFloorPlan.this.getString(C0421R.string.unable_to_load_feed), 0).show();
        }
    }

    private class AsyncTaskGetMicelloIndoorMapCameraDetails extends AsyncTask<String, String, JSONObject> {
        JSONArray incidentsArray;

        /* renamed from: com.vizsafe.app.Maps.LoadMicelloFloorPlan$AsyncTaskGetMicelloIndoorMapCameraDetails$1 */
        class C03831 implements Runnable {
            C03831() {
            }

            public void run() {
                try {
                    if (LoadMicelloFloorPlan.this.mTransparentProgressDialog.isShowing()) {
                        LoadMicelloFloorPlan.this.mTransparentProgressDialog.dismiss();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        private AsyncTaskGetMicelloIndoorMapCameraDetails() {
            this.incidentsArray = null;
        }

        /* synthetic */ AsyncTaskGetMicelloIndoorMapCameraDetails(LoadMicelloFloorPlan x0, C03781 x1) {
            this();
        }

        protected void onPreExecute() {
            super.onPreExecute();
        }

        protected JSONObject doInBackground(String... arg0) {
            try {
                LoadMicelloFloorPlan.this.CameraResponse = new Webservice().getCameraListMicello(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan, LoadMicelloFloorPlan.this.email, LoadMicelloFloorPlan.this.password, LoadMicelloFloorPlan.this.mDrawingId, LoadMicelloFloorPlan.this.mPlaceUUid);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        protected void onPostExecute(JSONObject jsonObject) {
            super.onPostExecute(jsonObject);
            zzahn.runOnUiThread(new C03831());
            LoadMicelloFloorPlan.this.mCameraResponse = String.valueOf(LoadMicelloFloorPlan.this.CameraResponse);
            try {
                if (LoadMicelloFloorPlan.this.IncidentResponse != null) {
                    LoadMicelloFloorPlan.this.content = IOUtils.toString(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan.getAssets().open("FloorPlan.html")).replaceAll("mCommunityIdValue", LoadMicelloFloorPlan.this.mPlaceId).replaceAll("mDrawingIdValue", LoadMicelloFloorPlan.this.mDrawingId).replaceAll("mLevelIdValue", LoadMicelloFloorPlan.this.mLevelId).replaceAll("currentLatitudePin", LoadMicelloFloorPlan.this.latitude).replaceAll("currentLongitudePin", LoadMicelloFloorPlan.this.longitude).replaceAll("IncidentResponse", LoadMicelloFloorPlan.this.IncidentResponse).replaceAll("mCameraResponse", LoadMicelloFloorPlan.this.mCameraResponse);
                } else {
                    LoadMicelloFloorPlan.this.content = IOUtils.toString(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan.getAssets().open("FloorPlan.html")).replaceAll("mCommunityIdValue", LoadMicelloFloorPlan.this.mPlaceId).replaceAll("mDrawingIdValue", LoadMicelloFloorPlan.this.mDrawingId).replaceAll("mLevelIdValue", LoadMicelloFloorPlan.this.mLevelId).replaceAll("currentLatitudePin", LoadMicelloFloorPlan.this.latitude).replaceAll("currentLongitudePin", LoadMicelloFloorPlan.this.longitude);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            LoadMicelloFloorPlan.this.mMicelloWebView.loadDataWithBaseURL("file:///android_asset/FloorPlan.html", LoadMicelloFloorPlan.this.content, "text/html", "UTF-8", null);
        }
    }

    private class AsyncTaskGetMicelloIndoorMapFloorPlanDetails extends AsyncTask<String, String, String> {
        JSONObject response;

        /* renamed from: com.vizsafe.app.Maps.LoadMicelloFloorPlan$AsyncTaskGetMicelloIndoorMapFloorPlanDetails$1 */
        class C03841 implements Runnable {
            C03841() {
            }

            public void run() {
                try {
                    LoadMicelloFloorPlan.this.mTransparentProgressDialog.show();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        private AsyncTaskGetMicelloIndoorMapFloorPlanDetails() {
            this.response = null;
        }

        /* synthetic */ AsyncTaskGetMicelloIndoorMapFloorPlanDetails(LoadMicelloFloorPlan x0, C03781 x1) {
            this();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            zzahn.runOnUiThread(new C03841());
        }

        protected String doInBackground(String... arg0) {
            LoadMicelloFloorPlan.this.fromDuration = PreferenceHandler.getInstance(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan).getFromDuration();
            try {
                Webservice mWebservice = new Webservice();
                if (LoadMicelloFloorPlan.this.fromDuration == 0) {
                    this.response = mWebservice.getFeedListMicello(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan, LoadMicelloFloorPlan.this.email, LoadMicelloFloorPlan.this.password, LoadMicelloFloorPlan.this.mPlaceId, LoadMicelloFloorPlan.this.mDrawingId);
                } else {
                    this.response = mWebservice.GetMicelloIndoorMapsListOnDurationWebService(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan, LoadMicelloFloorPlan.this.email, LoadMicelloFloorPlan.this.password, LoadMicelloFloorPlan.this.mPlaceId, LoadMicelloFloorPlan.this.mDrawingId, String.valueOf(LoadMicelloFloorPlan.this.fromDuration));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        protected void onPostExecute(String result) {
            LoadMicelloFloorPlan.this.IncidentResponse = String.valueOf(this.response);
            if (CommonMember.isNetworkOnline((ConnectivityManager) LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan.getSystemService("connectivity"), LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan)) {
                new AsyncTaskGetMicelloIndoorMapCameraDetails(LoadMicelloFloorPlan.this, null).execute(new String[0]);
            } else {
                CommonMember.NetworkStatusAlert(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan);
            }
        }
    }

    public class WebViewJavaScriptInterface {
        private Context context;

        public WebViewJavaScriptInterface(Context context) {
            this.context = context;
        }

        @JavascriptInterface
        public void makeToast(String uuid) {
            LoadMicelloFloorPlan.this.mUuid = uuid;
            if (CommonMember.isNetworkOnline((ConnectivityManager) LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan.getSystemService("connectivity"), LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan)) {
                new AsyncTaskGetFeedDetails(LoadMicelloFloorPlan.this, null).execute(new String[0]);
            } else {
                CommonMember.NetworkStatusAlert(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan);
            }
        }

        @JavascriptInterface
        public void makeToastCamera(String uuid, String videoinput) {
            LoadMicelloFloorPlan.this.mUuid = uuid;
            String videoInput = videoinput;
            Intent goToLiveCameraScreen;
            if (!CommonMember.isNetworkOnline((ConnectivityManager) LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan.getSystemService("connectivity"), LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan)) {
                CommonMember.NetworkStatusAlert(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan);
            } else if (VERSION.SDK_INT >= 23) {
                if (videoInput == null) {
                    goToLiveCameraScreen = new Intent(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan, SampleWebview.class);
                    goToLiveCameraScreen.putExtra("camera_uuid", LoadMicelloFloorPlan.this.mUuid);
                    goToLiveCameraScreen.putExtra("camera_pass", "true");
                    LoadMicelloFloorPlan.this.startActivity(goToLiveCameraScreen);
                } else if (!videoInput.equalsIgnoreCase("egs")) {
                    goToLiveCameraScreen = new Intent(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan, SampleWebview.class);
                    goToLiveCameraScreen.putExtra("camera_uuid", LoadMicelloFloorPlan.this.mUuid);
                    goToLiveCameraScreen.putExtra("camera_pass", "true");
                    LoadMicelloFloorPlan.this.startActivity(goToLiveCameraScreen);
                }
            } else if (videoInput == null) {
                goToLiveCameraScreen = new Intent(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan, CameraLiveScreen.class);
                goToLiveCameraScreen.putExtra("camera_uuid", LoadMicelloFloorPlan.this.mUuid);
                goToLiveCameraScreen.putExtra("camera_pass", "true");
                LoadMicelloFloorPlan.this.startActivity(goToLiveCameraScreen);
            } else if (!videoInput.equalsIgnoreCase("egs")) {
                goToLiveCameraScreen = new Intent(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan, CameraLiveScreen.class);
                goToLiveCameraScreen.putExtra("camera_uuid", LoadMicelloFloorPlan.this.mUuid);
                goToLiveCameraScreen.putExtra("camera_pass", "true");
                LoadMicelloFloorPlan.this.startActivity(goToLiveCameraScreen);
            }
        }

        @JavascriptInterface
        public void makeToastLoadIncidents(String thisCommunity, String thisDrawing, String getCurrentLevel) {
            LoadMicelloFloorPlan.this.mPlaceId = thisCommunity;
            LoadMicelloFloorPlan.this.mDrawingId = thisDrawing;
            LoadMicelloFloorPlan.this.mLevelId = getCurrentLevel;
            if (CommonMember.isNetworkOnline((ConnectivityManager) LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan.getSystemService("connectivity"), LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan)) {
                new AsyncTaskGetMicelloIndoorMapFloorPlanDetails(LoadMicelloFloorPlan.this, null).execute(new String[0]);
            } else {
                CommonMember.NetworkStatusAlert(LoadMicelloFloorPlan.this.mLoadMicelloFloorPlan);
            }
        }

        @JavascriptInterface
        public void makeToast1() {
            LoadMicelloFloorPlan.this.getActivity().finish();
        }
    }

    public static LoadMicelloFloorPlan newInstance(Bundle bundle) {
        mBundle = bundle;
        return new LoadMicelloFloorPlan();
    }

    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.clear();
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getActivity().getWindow().setSoftInputMode(3);
        View vPage = inflater.inflate(C0421R.layout.activity_floor_micello_floorplan, container, false);
        this.mLoadMicelloFloorPlan = getContext();
        this.channelPictureUrl = CommonMember.getURL(this.mLoadMicelloFloorPlan) + "/picture/";
        this.mTransparentProgressDialog = new SpotsDialog(this.mLoadMicelloFloorPlan, getResources().getString(C0421R.string.please_wait_loading));
        this.mTransparentProgressDialog.setCanceledOnTouchOutside(false);
        this.mTransparentProgressDialog.setCancelable(false);
        this.mDoneBtn = (ImageView) vPage.findViewById(C0421R.C0419id.action_bar_back);
        this.mMicelloWebView = (WebView) vPage.findViewById(C0421R.C0419id.micellowebview);
        this.showingText = (TextView) vPage.findViewById(2131689653);
        this.seekbar = (SeekBar) vPage.findViewById(C0421R.C0419id.seekBar1);
        this.timeIcon = (ImageView) vPage.findViewById(C0421R.C0419id.time_icon);
        this.email = PreferenceHandler.getInstance(this.mLoadMicelloFloorPlan).getUserName();
        this.password = PreferenceHandler.getInstance(this.mLoadMicelloFloorPlan).getPassword();
        this.mPlaceId = mBundle.getString("PlaceId");
        this.mDrawingId = mBundle.getString("DrawingId");
        this.mLevelId = mBundle.getString("LevelId");
        this.mPlaceUUid = mBundle.getString("PlaceUUId");
        this.IncidentResponse = mBundle.getString("IncidentResponse");
        this.mCameraResponse = mBundle.getString("CameraResponse");
        this.seekbar.setProgress(PreferenceHandler.getInstance(this.mLoadMicelloFloorPlan).getProgressLevelMap());
        this.showingText.setText(PreferenceHandler.getInstance(this.mLoadMicelloFloorPlan).getProgressTextMap());
        if (PreferenceHandler.getInstance(this.mLoadMicelloFloorPlan).getProgressLevelMap() <= 66) {
            this.timeIcon.setImageResource(C0421R.C0418drawable.clock_blue);
        } else {
            this.timeIcon.setImageResource(C0421R.C0418drawable.calender_blue);
        }
        this.gps = new VizsafeGPSTracker(this.mLoadMicelloFloorPlan);
        if (this.gps.canGetLocation()) {
            this.latitudeGoogleMap = Double.valueOf(this.gps.getLatitude());
            this.longitudeGoogleMap = Double.valueOf(this.gps.getLongitude());
        } else {
            this.gps.showSettingsAlert();
        }
        if (!CommonMember.isNetworkOnline((ConnectivityManager) this.mLoadMicelloFloorPlan.getSystemService("connectivity"), this.mLoadMicelloFloorPlan)) {
            CommonMember.NetworkStatusAlert(this.mLoadMicelloFloorPlan);
        } else if (this.latitudeGoogleMap == null || this.longitudeGoogleMap == null) {
            if (this.gps.canGetLocation()) {
                this.latitudeGoogleMap = Double.valueOf(this.gps.getLatitude());
                this.longitudeGoogleMap = Double.valueOf(this.gps.getLongitude());
                if (this.latitudeGoogleMap == null || this.longitudeGoogleMap != null) {
                }
            } else {
                this.gps.showSettingsAlert();
            }
        }
        this.mDoneBtn.setOnClickListener(new C03781());
        this.latitude = String.valueOf(this.latitudeGoogleMap);
        this.longitude = String.valueOf(this.longitudeGoogleMap);
        this.mMicelloWebView.getSettings().setJavaScriptEnabled(true);
        this.mMicelloWebView.setWebChromeClient(new C03792());
        this.mMicelloWebView.addJavascriptInterface(new WebViewJavaScriptInterface(this.mLoadMicelloFloorPlan), "app");
        try {
            if (this.IncidentResponse != null) {
                this.content = IOUtils.toString(this.mLoadMicelloFloorPlan.getAssets().open("FloorPlan.html")).replaceAll("mCommunityIdValue", this.mPlaceId).replaceAll("mDrawingIdValue", this.mDrawingId).replaceAll("mLevelIdValue", this.mLevelId).replaceAll("currentLatitudePin", this.latitude).replaceAll("currentLongitudePin", this.longitude).replaceAll("IncidentResponse", this.IncidentResponse).replaceAll("mCameraResponse", this.mCameraResponse);
            } else {
                this.content = IOUtils.toString(this.mLoadMicelloFloorPlan.getAssets().open("FloorPlan.html")).replaceAll("mCommunityIdValue", this.mPlaceId).replaceAll("mDrawingIdValue", this.mDrawingId).replaceAll("mLevelIdValue", this.mLevelId).replaceAll("currentLatitudePin", this.latitude).replaceAll("currentLongitudePin", this.longitude);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.mMicelloWebView.loadDataWithBaseURL("file:///android_asset/FloorPlan.html", this.content, "text/html", "UTF-8", null);
        this.seekbar.setOnSeekBarChangeListener(new C03803());
        return vPage;
    }

    public void onPause() {
        super.onPause();
        this.gps.stopUsingGPS();
    }

    public void onResume() {
        super.onResume();
    }

    public void onStop() {
        super.onStop();
        this.gps.stopUsingGPS();
    }

    public void onDestroy() {
        super.onDestroy();
        this.gps.stopUsingGPS();
    }
}
