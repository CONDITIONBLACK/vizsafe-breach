package com.vizsafe.app.Maps;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.p001v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;
import com.vizsafe.app.Adapters.CameraListAdapter.onGoToMapPageListener;
import com.vizsafe.app.Adapters.MicelloIndoorListViewAdapter;
import com.vizsafe.app.C0421R;
import com.vizsafe.app.Utils.CommonMember;
import com.vizsafe.app.Utils.PreferenceHandler;
import com.vizsafe.app.Utils.Webservice;
import dmax.dialog.SpotsDialog;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MicelloIndoor extends Fragment {
    JSONObject CameraResponse = null;
    JSONObject IncidentResponse = null;
    private String PlaceId;
    private ImageView mDoneBtn;
    private String mDrawingId;
    private ArrayList<String> mDrawingIdList = new ArrayList();
    private String mLevelId;
    private Context mMicelloIndoor;
    private MicelloIndoorListViewAdapter mMicelloIndoorListViewAdapter;
    private ListView mMicelloPlacesListview;
    private ArrayList<String> mPlaceIdList = new ArrayList();
    private ArrayList<String> mPlaceNameList = new ArrayList();
    private String mPlaceUUid;
    private ArrayList<String> mPlaceUuidList = new ArrayList();
    private ArrayList<Integer> mSelectedArraylist;
    private AlertDialog mTransparentProgressDialog;
    private ArrayList<String> mlevelIdList = new ArrayList();
    private ArrayList<ArrayList<Integer>> mlevelIdWholeList = new ArrayList();
    private int totalFeeds;

    public interface onGoToLoadMicelloFloorPlanPageListener {
        void onGoToLoadMicelloFloorPlanPage(Bundle bundle);
    }

    /* renamed from: com.vizsafe.app.Maps.MicelloIndoor$1 */
    class C03851 implements OnClickListener {
        C03851() {
        }

        public void onClick(View v) {
            ((onGoToMapPageListener) MicelloIndoor.this.mMicelloIndoor).onGoToMapPage(null, null);
        }
    }

    /* renamed from: com.vizsafe.app.Maps.MicelloIndoor$2 */
    class C03862 implements OnItemClickListener {
        C03862() {
        }

        public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
            String PlaceName = (String) MicelloIndoor.this.mPlaceNameList.get(position);
            MicelloIndoor.this.PlaceId = (String) MicelloIndoor.this.mPlaceIdList.get(position);
            MicelloIndoor.this.mDrawingId = (String) MicelloIndoor.this.mDrawingIdList.get(position);
            MicelloIndoor.this.mPlaceUUid = (String) MicelloIndoor.this.mPlaceUuidList.get(position);
            MicelloIndoor.this.mLevelId = String.valueOf(MicelloIndoor.this.mlevelIdList.get(position));
            if (CommonMember.isNetworkOnline((ConnectivityManager) MicelloIndoor.this.mMicelloIndoor.getSystemService("connectivity"), MicelloIndoor.this.mMicelloIndoor)) {
                new AsyncTaskGetMicelloIndoorMapFloorPlanDetails(MicelloIndoor.this, null).execute(new String[0]);
            }
        }
    }

    private class AsyncTaskGetMicelloIndoorMapCameraDetails extends AsyncTask<String, String, JSONObject> {
        JSONArray incidentsArray;

        private AsyncTaskGetMicelloIndoorMapCameraDetails() {
            this.incidentsArray = null;
        }

        /* synthetic */ AsyncTaskGetMicelloIndoorMapCameraDetails(MicelloIndoor x0, C03851 x1) {
            this();
        }

        protected void onPreExecute() {
            super.onPreExecute();
        }

        protected JSONObject doInBackground(String... arg0) {
            String email = PreferenceHandler.getInstance(MicelloIndoor.this.mMicelloIndoor).getUserName();
            String password = PreferenceHandler.getInstance(MicelloIndoor.this.mMicelloIndoor).getPassword();
            Webservice mWebservice = new Webservice();
            try {
                MicelloIndoor.this.CameraResponse = mWebservice.getCameraListMicello(MicelloIndoor.this.mMicelloIndoor, email, password, MicelloIndoor.this.mDrawingId, MicelloIndoor.this.mPlaceUUid);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        protected void onPostExecute(JSONObject jsonObject) {
            super.onPostExecute(jsonObject);
            if (MicelloIndoor.this.mTransparentProgressDialog.isShowing()) {
                MicelloIndoor.this.mTransparentProgressDialog.dismiss();
            }
            Bundle mIntent = new Bundle();
            mIntent.putString("PlaceId", MicelloIndoor.this.PlaceId);
            mIntent.putString("DrawingId", MicelloIndoor.this.mDrawingId);
            mIntent.putString("LevelId", MicelloIndoor.this.mLevelId);
            mIntent.putString("PlaceUUId", MicelloIndoor.this.mPlaceUUid);
            mIntent.putString("IncidentResponse", String.valueOf(MicelloIndoor.this.IncidentResponse));
            mIntent.putString("CameraResponse", String.valueOf(MicelloIndoor.this.CameraResponse));
            ((onGoToLoadMicelloFloorPlanPageListener) MicelloIndoor.this.mMicelloIndoor).onGoToLoadMicelloFloorPlanPage(mIntent);
        }
    }

    private class AsyncTaskGetMicelloIndoorMapFloorPlanDetails extends AsyncTask<String, String, JSONObject> {
        JSONArray incidentsArray;

        private AsyncTaskGetMicelloIndoorMapFloorPlanDetails() {
            this.incidentsArray = null;
        }

        /* synthetic */ AsyncTaskGetMicelloIndoorMapFloorPlanDetails(MicelloIndoor x0, C03851 x1) {
            this();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            MicelloIndoor.this.mTransparentProgressDialog.show();
        }

        protected JSONObject doInBackground(String... arg0) {
            String email = PreferenceHandler.getInstance(MicelloIndoor.this.mMicelloIndoor).getUserName();
            String password = PreferenceHandler.getInstance(MicelloIndoor.this.mMicelloIndoor).getPassword();
            int mDuration = PreferenceHandler.getInstance(MicelloIndoor.this.mMicelloIndoor).getFromDuration();
            Webservice mWebservice = new Webservice();
            try {
                MicelloIndoor.this.IncidentResponse = mWebservice.GetMicelloIndoorMapsListOnDurationWebService(MicelloIndoor.this.mMicelloIndoor, email, password, MicelloIndoor.this.PlaceId, MicelloIndoor.this.mDrawingId, String.valueOf(mDuration));
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        protected void onPostExecute(JSONObject jsonObject) {
            super.onPostExecute(jsonObject);
            new AsyncTaskGetMicelloIndoorMapCameraDetails(MicelloIndoor.this, null).execute(new String[0]);
        }
    }

    private class AsyncTaskGetMicelloIndoorMapsList extends AsyncTask<String, String, JSONObject> {
        JSONObject mDrawingListObject;
        JSONArray mDrawingsListArray;
        JSONArray mLevelListArray;
        JSONObject mLevelListObject;
        JSONArray mMapsListArray;
        JSONObject mMapsListObject;
        ProgressDialog pDialog;
        JSONObject response;

        private AsyncTaskGetMicelloIndoorMapsList() {
            this.response = null;
            this.mMapsListArray = null;
            this.mMapsListObject = null;
            this.mDrawingListObject = null;
            this.mDrawingsListArray = null;
            this.mLevelListObject = null;
            this.mLevelListArray = null;
        }

        /* synthetic */ AsyncTaskGetMicelloIndoorMapsList(MicelloIndoor x0, C03851 x1) {
            this();
        }

        protected void onPreExecute() {
            super.onPreExecute();
            MicelloIndoor.this.mTransparentProgressDialog.show();
        }

        protected JSONObject doInBackground(String... arg0) {
            try {
                this.response = new Webservice().GetMicelloIndoorMapsListWebService(MicelloIndoor.this.mMicelloIndoor, PreferenceHandler.getInstance(MicelloIndoor.this.mMicelloIndoor).getUserName(), PreferenceHandler.getInstance(MicelloIndoor.this.mMicelloIndoor).getPassword());
            } catch (Exception e) {
                e.printStackTrace();
            }
            return this.response;
        }

        protected void onPostExecute(JSONObject mResponse) {
            if (MicelloIndoor.this.mTransparentProgressDialog.isShowing()) {
                MicelloIndoor.this.mTransparentProgressDialog.dismiss();
            }
            if (mResponse != null) {
                try {
                    int mTotal = mResponse.getInt("total");
                    if (mTotal > 0) {
                        this.mMapsListArray = mResponse.getJSONArray("floorplans");
                        if (this.mMapsListArray != null) {
                            MicelloIndoor.this.mDrawingIdList.clear();
                            for (int i = 0; i < mTotal; i++) {
                                this.mMapsListObject = this.mMapsListArray.getJSONObject(i);
                                int mMap_community_id = this.mMapsListObject.getInt("map_community_id");
                                MicelloIndoor.this.mPlaceUuidList.add(this.mMapsListObject.getString("uuid"));
                                MicelloIndoor.this.mPlaceNameList.add(String.valueOf(this.mMapsListObject.getString("indoor_map_name")));
                                MicelloIndoor.this.mPlaceIdList.add(String.valueOf(mMap_community_id));
                                if (this.mMapsListObject.has("map_drawing_id")) {
                                    MicelloIndoor.this.mDrawingIdList.add(String.valueOf(this.mMapsListObject.getInt("map_drawing_id")));
                                } else {
                                    MicelloIndoor.this.mDrawingIdList.add(String.valueOf(0));
                                }
                                if (this.mMapsListObject.has("map_level_id")) {
                                    MicelloIndoor.this.mlevelIdList.add(String.valueOf(this.mMapsListObject.getInt("map_level_id")));
                                } else {
                                    MicelloIndoor.this.mlevelIdList.add(String.valueOf(0));
                                }
                            }
                        }
                        MicelloIndoor.this.mMicelloIndoorListViewAdapter = new MicelloIndoorListViewAdapter(MicelloIndoor.this.mMicelloIndoor, MicelloIndoor.this.mPlaceNameList, MicelloIndoor.this.mPlaceIdList);
                        MicelloIndoor.this.mMicelloPlacesListview.setAdapter(MicelloIndoor.this.mMicelloIndoorListViewAdapter);
                        return;
                    }
                    Toast.makeText(MicelloIndoor.this.mMicelloIndoor, "No Indoor Maps found", 0).show();
                    return;
                } catch (JSONException e) {
                    e.printStackTrace();
                    return;
                }
            }
            CommonMember.getErrorDialog(MicelloIndoor.this.getString(C0421R.string.wrong_details), MicelloIndoor.this.mMicelloIndoor).show();
        }
    }

    public static MicelloIndoor newInstance() {
        return new MicelloIndoor();
    }

    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.clear();
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getActivity().getWindow().setSoftInputMode(3);
        View vPage = inflater.inflate(C0421R.layout.activity_micello_listview, container, false);
        this.mMicelloIndoor = getContext();
        this.mMicelloPlacesListview = (ListView) vPage.findViewById(C0421R.C0419id.micello_places_listview);
        this.mDoneBtn = (ImageView) vPage.findViewById(C0421R.C0419id.action_bar_back);
        this.mTransparentProgressDialog = new SpotsDialog(this.mMicelloIndoor, getResources().getString(C0421R.string.please_wait_loading));
        this.mTransparentProgressDialog.setCanceledOnTouchOutside(false);
        this.mTransparentProgressDialog.setCancelable(false);
        this.mPlaceNameList.clear();
        this.mPlaceIdList.clear();
        this.mDrawingIdList.clear();
        this.mlevelIdList.clear();
        this.mPlaceUuidList.clear();
        if (CommonMember.isNetworkOnline((ConnectivityManager) this.mMicelloIndoor.getSystemService("connectivity"), this.mMicelloIndoor)) {
            new AsyncTaskGetMicelloIndoorMapsList(this, null).execute(new String[0]);
        }
        String mResponse = "done";
        this.mDoneBtn.setOnClickListener(new C03851());
        this.mMicelloPlacesListview.setOnItemClickListener(new C03862());
        return vPage;
    }
}
